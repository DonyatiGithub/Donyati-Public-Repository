ALTER TABLE fileservice.track_file_load_status
ADD COLUMN is_je_file BOOLEAN DEFAULT FALSE,
ADD COLUMN uploaded_by VARCHAR DEFAULT NULL,
ADD COLUMN file_type VARCHAR DEFAULT NULL;
 
update fileservice.track_file_load_status set file_type ='app';