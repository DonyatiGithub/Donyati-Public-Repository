alter table fileservice.recon_applications 
add column currency_thousand_separator char default ',';