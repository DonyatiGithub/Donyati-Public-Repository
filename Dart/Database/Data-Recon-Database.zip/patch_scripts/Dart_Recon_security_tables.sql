
-- Global variable tables changes
drop table if exists fileservice.client_role_group_xref cascade;

-- created_at to created_date
alter table fileservice.global_variables rename column created_at to created_date;

-- added the column 'global_recon_app_id'
alter table fileservice.global_recon_dimensions add column global_recon_app_id integer;

-- renaming column 'gloabl_recon_app_id' to 'global_recon_app_id'
alter table fileservice.global_recon_applications rename column gloabl_recon_app_id to global_recon_app_id;

--------------

-- Tables related to the DART Recon Security Data Model

-- DART_Account
create table if not exists fileservice.dart_account(
	account_id serial primary key,
	unique_id integer,
	owners varchar(320),
	created_date timestamp,
	created_by varchar(320)
)
TABLESPACE tbsp_meta;

ALTER TABLE fileservice.dart_account
    OWNER to "user_dataRecon_file";

GRANT ALL ON TABLE fileservice.dart_account TO postgres;

GRANT DELETE, UPDATE, INSERT, SELECT ON TABLE fileservice.dart_account TO "user_dataRecon_file";


-- Clinet.loB or Sub-Domain
create table if not exists fileservice.client_sub_domain(
	loB_id serial primary key,
	unique_id integer,
	account_unique_id integer,
	name varchar(320),
	owners varchar(320),
	created_date timestamp,
	created_by varchar(320)
)
TABLESPACE tbsp_meta;

ALTER TABLE fileservice.client_sub_domain
    OWNER to "user_dataRecon_file";

GRANT ALL ON TABLE fileservice.client_sub_domain TO postgres;

GRANT DELETE, UPDATE, INSERT, SELECT ON TABLE fileservice.client_sub_domain TO "user_dataRecon_file";

-- Client.Team
create table if not exists fileservice.client_team(
	team_id serial primary key,
	unique_id integer,
	account_unique_id integer,
	loB_unique_id integer,
	name varchar(320),
	owners varchar(320),
	created_date timestamp,
	created_by varchar(320)
)
TABLESPACE tbsp_meta;

ALTER TABLE fileservice.client_team
    OWNER to "user_dataRecon_file";

GRANT ALL ON TABLE fileservice.client_team TO postgres;

GRANT DELETE, UPDATE, INSERT, SELECT ON TABLE fileservice.client_team TO "user_dataRecon_file";


-- DART.User_Privileges
create table if not exists fileservice.user_privileges(
	user_priv_id serial primary key,
	user_unique_id integer unique,
	account_unique_id integer,
	"donyati_admin/owner" varchar(320),
	account_owner varchar(320),
	sub_domain_owner varchar(320),
	loB_unique_id integer,
	team_owner varchar(320),
	team_unique_id integer,
	recon_user varchar(320),
	group_owner varchar(320),
	group_unique_id integer unique,
	creation_date timestamp,
	last_modified_date timestamp,
	data_hash varchar(320)
)
TABLESPACE tbsp_meta;

ALTER TABLE fileservice.user_privileges
    OWNER to "user_dataRecon_file";

GRANT ALL ON TABLE fileservice.user_privileges TO postgres;

GRANT DELETE, UPDATE, INSERT, SELECT ON TABLE fileservice.user_privileges TO "user_dataRecon_file";

-- Client.User_Group_XRef
create table if not exists fileservice.client_user_group_xref(
	xref_id serial primary key,
	user_unique_id integer references fileservice.user_privileges(user_unique_id),
	group_unique_id integer references fileservice.user_privileges(group_unique_id),
	created_date timestamp
)
TABLESPACE tbsp_meta;

ALTER TABLE fileservice.client_user_group_xref
    OWNER to "user_dataRecon_file";

GRANT ALL ON TABLE fileservice.client_user_group_xref TO postgres;

GRANT DELETE, UPDATE, INSERT, SELECT ON TABLE fileservice.client_user_group_xref TO "user_dataRecon_file";

-- DART.User
create table if not exists fileservice.dart_user(
	user_id serial primary key,
	user_unique_id integer,
	username varchar(320),
	email_id varchar(320),
	account_unique_id integer,
	password varchar(320),
	validity_upto date,
	creation_date timestamp,
	last_modified_date timestamp,
	data_hash varchar(320)
)
TABLESPACE tbsp_meta;

ALTER TABLE fileservice.dart_user
    OWNER to "user_dataRecon_file";

GRANT ALL ON TABLE fileservice.dart_user TO postgres;

GRANT DELETE, UPDATE, INSERT, SELECT ON TABLE fileservice.dart_user TO "user_dataRecon_file";

-- Client.Group
create table if not exists fileservice.client_group(
	group_id serial primary key,
	group_unique_id integer unique,
	group_name varchar(320),
	group_owner varchar(320),
	created_date timestamp,
	modified_date timestamp,
	data_hash varchar(320)
)
TABLESPACE tbsp_meta;

ALTER TABLE fileservice.client_group
    OWNER to "user_dataRecon_file";

GRANT ALL ON TABLE fileservice.client_group TO postgres;

GRANT DELETE, UPDATE, INSERT, SELECT ON TABLE fileservice.client_group TO "user_dataRecon_file";

-- Client.Recon Group XRef
create table if not exists fileservice.client_recon_group_xref(
	xref_id serial primary key,
	recon_id integer references fileservice.recon(recon_id),
	group_unique_id integer references fileservice.client_group(group_unique_id),
	created_date timestamp
) 
TABLESPACE tbsp_meta;
ALTER TABLE fileservice.client_recon_group_xref
    OWNER to "user_dataRecon_file";

GRANT ALL ON TABLE fileservice.client_recon_group_xref TO postgres;

GRANT DELETE, UPDATE, INSERT, SELECT ON TABLE fileservice.client_recon_group_xref TO "user_dataRecon_file";

-- Client Role
create table if not exists fileservice.client_role(
	role_id serial primary key,
	role_unique_id integer unique,
	role_name varchar(320),
	role_privilege varchar(320),
	role_owner varchar(320),
	created_date timestamp,
	modified_date timestamp,
	data_hash varchar(320)
) 
TABLESPACE tbsp_meta;
ALTER TABLE fileservice.client_role
    OWNER to "user_dataRecon_file";

GRANT ALL ON TABLE fileservice.client_role TO postgres;

GRANT DELETE, UPDATE, INSERT, SELECT ON TABLE fileservice.client_role TO "user_dataRecon_file";


-- Client Role Group XRef
create table if not exists fileservice.client_role_group_xref(
	xref_id serial primary key,
	group_unique_id integer references fileservice.client_group(group_unique_id),
	role_unique_id integer references fileservice.client_role(role_unique_id),
	created_date timestamp	
)
TABLESPACE tbsp_meta;

ALTER TABLE fileservice.client_role_group_xref
    OWNER to "user_dataRecon_file";

GRANT ALL ON TABLE fileservice.client_role_group_xref TO postgres;

GRANT DELETE, UPDATE, INSERT, SELECT ON TABLE fileservice.client_role_group_xref TO "user_dataRecon_file";


---------
