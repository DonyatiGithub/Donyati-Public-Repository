-- DROP PROCEDURE fileservice.sp_create_report(int4);

CREATE OR REPLACE PROCEDURE fileservice.sp_create_report(IN recon_run_id integer)
 LANGUAGE plpgsql
AS $procedure$
declare
var_recon_id integer := recon_run_id;
s_schema_name text := 'fileservice';
--var_bridge_name text := 'bridge_'||var_recon_id;
var_app1_id integer;
var_app2_id integer;
var_name text;
var_round text := '';
var_query boolean := false;
var_q1_sel text := '';
var_yp text;
var_yp2 text;
var_union text;

--
var_tracking_refresh_sp_call boolean := FALSE;

var_refresh_exception TEXT := '';

var_insert_je_refresh text := 'INSERT INTO fileservice.track_recon_refresh (recon_id, je_report_timestamp) VALUES ($1, CURRENT_TIMESTAMP);';
var_update_je_bridge_refresh text := 'UPDATE fileservice.track_recon_refresh SET je_report_timestamp = CURRENT_TIMESTAMP WHERE recon_id = $1;';

var_insert_report_refresh TEXT := 'INSERT INTO fileservice.track_recon_refresh (recon_id, report_timestamp) VALUES ($1, CURRENT_TIMESTAMP);';
var_update_report_refresh TEXT := 'UPDATE fileservice.track_recon_refresh SET report_timestamp = CURRENT_TIMESTAMP WHERE recon_id = $1;';

begin
	
	/*
	 * if active get the individual application id that belong to the recon id
	 * 
	 */
	if
		exists (select 1 from fileservice.recon r where r.recon_id=var_recon_id and not(r.is_deleted))
		then
			select r.app1_id, r.app2_id, r.recon_id as view_name--, r.variance_threshold 
			into var_app1_id, var_app2_id, var_name--, var_threshold
			from fileservice.recon r 
			where r.recon_id = var_recon_id
			and not(r.is_deleted);
		else
			call fileService.sp_log_entry(
				null::integer, 
				'''ERROR: Recon id '|| var_recon_id ||' does not exist''', 
				var_recon_id, 
				null::text
			);
			return;
	end if;

	/*
	 * Check if recon is not signed-off
	 */	
	if
		not exists(SELECT 1 FROM fileservice.recon r WHERE r.recon_id = var_recon_id AND NOT r.sign_off)
		then 
			-- Log Script
			call fileService.sp_log_entry(
									NULL::integer,
									'''ERROR: Recon is signed-off'''::text,
									var_recon_id,
									NULL::text
									);
			return;		
	end if;

	/*
	 * Construct
	 * 1. Crosstab Query 1
	 * 2. Crosstab Query 1 modified for Grand Total
	 * 3. Crosstab Query 2
	 * 
	 * Merge above 1,3 into Query for main pivot table
	 * union 2
	 * add 'order_by column is to force the 'Grand Total' record to the end'
	 * 
	 * convert all of above to with clause and add:
	 * 'Below query will use with clause as the source table'
	 * 
	 * Store above as view or table
	 *   
	 */


	/* Procedure call to sp_recon_report*/
	call fileservice.sp_recon_report(var_recon_id); 
							
--	var_union = 'select * from '||s_schema_name||'.report_'||var_recon_id||' where '||var_union||' <> ''Grand Total'' union';

	 
	begin
		execute 'select exists (select 1 from information_schema."tables" where table_schema = '''||s_schema_name||''' and table_name = ''bridge_je_'||var_recon_id||''')'
		into var_query;
	exception
	    when others then
			call fileservice.sp_log_entry(
				null::integer,
				'''Error: '|| SQLERRM ||' ''', 
				var_recon_id,
				null::text
			);	
		
	end;
--	execute 'select 1 from information_schema."views" v where v.table_schema = '''||s_schema_name||''' and v.table_name = ''view_bridge_je_'||var_recon_id||'_kickout'''
--	into var_q1_sel;
--	raise notice '%', var_query;
	

	/*
	 * Same process as above, but for Journal Entries
	 */
	if var_query
		then
	/* Procedure call to sp_recon_je_report */
		call fileservice.sp_recon_je_report(var_recon_id);
		var_tracking_refresh_sp_call := TRUE;
	end if;

	/*
	 * Join report and je_report(if exists) to create another table
	 * This will create the final report for variance calculation irrespective of report_je table 
	 */
	call fileservice.sp_final_report(var_recon_id, var_query);

	update fileservice.recon 
	set status = 'Reporting'
	where recon_id = var_recon_id;	
/* 
		 * To insert the refresh trackings into the table 'track_recon_refresh'. 
		 */
		-- Check if the journal entry is true or not. If True, then check if the recon exists in the table or not.
		 IF (var_tracking_refresh_sp_call)
		THEN 

			-- If the recon does not exist then insert the values into the table.
			IF NOT EXISTS (SELECT 1 FROM fileservice.track_recon_refresh trr WHERE trr.recon_id = var_recon_id) THEN
	            begin
				    execute var_insert_je_refresh USING var_recon_id;
				exception
				    when others then
					var_refresh_exception = '''Error: '|| SQLERRM ||' ''';
				end;
	           
	        -- If the recon exists in the table then update the time stamp of the je_report_timestamp column.
	        ELSE
	           begin
				    execute var_update_je_refresh USING var_recon_id;
				exception
				    when others then
					var_refresh_exception = '''Error: '|| SQLERRM ||' ''';
				
				end;
	        END IF;
	    ELSE
	     	-- If not journal entry check for the same conditions as above but for the column 'report_timestamp'.
		    IF NOT EXISTS (SELECT 1 FROM fileservice.track_recon_refresh trr WHERE trr.recon_id = var_recon_id) THEN
	            begin
				    execute var_insert_report_refresh USING var_recon_id;
				exception
				    when others then
					var_refresh_exception = '''Error: '|| SQLERRM ||' ''';

				end;
	        ELSE
	            begin
				    execute var_update_report_refresh USING var_recon_id;
				exception
				    when others then
					var_refresh_exception = '''Error: '|| SQLERRM ||' ''';
				end;
	        END IF;
    	END IF;
    	-- RAISE NOTICE 'var_refresh_exception: %', var_refresh_exception;
    
    	IF (length(var_refresh_exception)>0)
    	THEN 
    	call fileService.sp_log_entry(
									null::integer,
									var_refresh_exception::text,
									var_recon_id::integer
									--var_name_table::text
									);
		ELSE
		call fileService.sp_log_entry(
									null::integer,
									'''Time stamp tracked'''::text,
									var_recon_id::integer
									--var_name_table::text
									);
		END IF;

end;
$procedure$
;
