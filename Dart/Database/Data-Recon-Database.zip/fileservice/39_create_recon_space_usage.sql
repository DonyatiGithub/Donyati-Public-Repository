drop table if exists fileservice.recon_space_usage;

create table fileservice.recon_space_usage
(
recon_id integer not null,
disk_usage varchar not null,
constraint pk_recon_space_id primary key (recon_id)
)
tablespace tbsp_meta;

ALTER TABLE IF EXISTS "fileservice".recon_space_usage OWNER to "user_dataRecon_file";

GRANT ALL ON TABLE "fileservice".recon_space_usage TO postgres;
GRANT DELETE, UPDATE, INSERT, SELECT ON TABLE "fileservice".recon_space_usage TO "user_dataRecon_file";