CREATE OR REPLACE FUNCTION fileservice.f_check_get_app_details(recon_app_id integer, journal_entry boolean DEFAULT false)
 RETURNS record
 LANGUAGE plpgsql
AS $function$
declare
var_app_id integer := recon_app_id;
var_je boolean := journal_entry;
var_table_rec RECORD;
begin
	if
		exists(select count(*) from fileservice.recon_applications rd where rd.recon_app_id = var_app_id)
	then
		/*
		 * Check if table name is required for Journal Entries
		 */
		if (var_je)
		then
			select concat('je_',r.recon_id,'_',var_app_id) as table_name, r.recon_id::integer as rec_id 
			into var_table_rec
			from fileservice.recon r 
			where (r.app1_id = var_app_id
			or r.app2_id = var_app_id)
			and not r.is_deleted ;
		else
			select concat('app_',r.recon_id,'_',var_app_id) as table_name, r.recon_id::integer as rec_id 
			into var_table_rec
			from fileservice.recon r 
			where (r.app1_id = var_app_id
			or r.app2_id = var_app_id)
			and not r.is_deleted ;
		end if;	
	end if;
return var_table_rec;
end;
$function$
;

-- Permissions

ALTER FUNCTION fileservice.f_check_get_app_details(int4, bool) OWNER TO "user_dataRecon_file";
GRANT ALL ON FUNCTION fileservice.f_check_get_app_details(int4, bool) TO public;
GRANT ALL ON FUNCTION fileservice.f_check_get_app_details(int4, bool) TO postgres;
GRANT ALL ON FUNCTION fileservice.f_check_get_app_details(int4, bool) TO "user_dataRecon_file";
