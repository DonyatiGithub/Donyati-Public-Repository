-- Table: fileservice.track_file_load_status

DROP TABLE IF EXISTS fileservice.recon_xml;

CREATE TABLE fileservice.recon_xml(
xml_id int default nextval('fileservice.recon_table_skey'::regclass),
xml_data varchar
)
TABLESPACE tbsp_meta;

ALTER TABLE fileservice.recon_xml OWNER to "user_dataRecon_file";
GRANT ALL ON TABLE fileservice.track_file_load_status TO postgres;
GRANT DELETE, UPDATE, INSERT, SELECT ON TABLE fileservice.track_file_load_status TO "user_dataRecon_file";