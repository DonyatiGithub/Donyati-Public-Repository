-- SEQUENCE: fileservice.recon_comments_id_seq

DROP SEQUENCE IF EXISTS fileservice.recon_comments_id_seq CASCADE;

CREATE SEQUENCE fileservice.recon_comments_id_seq
    INCREMENT 1
    START 1
    MINVALUE 1
    MAXVALUE 9223372036854775807
    CACHE 1;

ALTER SEQUENCE fileservice.recon_comments_id_seq
    OWNER TO "user_dataRecon_file";

GRANT ALL ON SEQUENCE fileservice.recon_comments_id_seq TO postgres;

GRANT ALL ON SEQUENCE fileservice.recon_comments_id_seq TO "user_dataRecon_file";

-- Table: fileservice.recon_comments

DROP TABLE IF EXISTS fileservice.recon_comments CASCADE;

CREATE TABLE fileservice.recon_comments
(
    id bigint NOT NULL DEFAULT nextval('fileservice.recon_comments_id_seq'::regclass),
    recon_id bigint,
    recon_app_id bigint,
    dimensions_id bigint,
    comment character varying COLLATE pg_catalog."default",
    CONSTRAINT pk_recon_comments_id PRIMARY KEY (id)
        USING INDEX TABLESPACE tbsp_meta
)

TABLESPACE tbsp_meta;

ALTER TABLE fileservice.recon_comments
    OWNER to "user_dataRecon_file";

GRANT ALL ON TABLE fileservice.recon_comments TO postgres;

GRANT DELETE, UPDATE, INSERT, SELECT ON TABLE fileservice.recon_comments TO "user_dataRecon_file";