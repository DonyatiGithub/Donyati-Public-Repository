-- SEQUENCE: fileservice.recon_bridge_mapping_id_seq

DROP SEQUENCE IF EXISTS fileservice.recon_bridge_mapping_id_seq cascade;

CREATE SEQUENCE fileservice.recon_bridge_mapping_id_seq
    INCREMENT 1
    START 1
    MINVALUE 1
    MAXVALUE 9223372036854775807
    CACHE 1;

ALTER SEQUENCE fileservice.recon_bridge_mapping_id_seq
    OWNER TO "user_dataRecon_file";

GRANT ALL ON SEQUENCE fileservice.recon_bridge_mapping_id_seq TO postgres;

GRANT ALL ON SEQUENCE fileservice.recon_bridge_mapping_id_seq TO "user_dataRecon_file";


-- Table: fileservice.recon_bridge_mapping

DROP TABLE  IF EXISTS fileservice.recon_bridge_mapping cascade;

CREATE TABLE IF NOT EXISTS fileservice.recon_bridge_mapping
(
	bridge_id bigint NOT NULL DEFAULT nextval('fileservice.recon_bridge_mapping_id_seq'::regclass),
	recon_id int8 NULL,
	app_id int8 NULL,
	dim_id int8 NULL,
	flip_sign bool NULL default false,
	app_type varchar NULL,
	source_member varchar NULL,
	bridge_member varchar NULL,
	dim_comment varchar NULL,
	is_deleted bool NULL default false,
	bridge_comment varchar NULL,
	is_invalid bool NULL default false,
	je_comment varchar NULL,
	CONSTRAINT pk_recon_bridge_mapping PRIMARY KEY (bridge_id)
)

TABLESPACE tbsp_meta;

ALTER TABLE fileservice.recon_bridge_mapping
    OWNER to "user_dataRecon_file";

GRANT ALL ON TABLE fileservice.recon_bridge_mapping TO postgres;

GRANT DELETE, UPDATE, INSERT, SELECT ON TABLE fileservice.recon_bridge_mapping TO "user_dataRecon_file";