drop procedure if exists fileservice.sp_replicate_recon(source_recon_id integer, target_recon_id integer, user_name varchar);

CREATE OR REPLACE PROCEDURE fileservice.sp_replicate_recon(source_recon_id integer, target_recon_id integer, user_name varchar)
 LANGUAGE plpgsql
AS $procedure$
DECLARE

s_schema_name text := 'fileservice';

var_source_recon_id integer := source_recon_id;
var_target_recon_id integer := target_recon_id;
var_user_name varchar := user_name;

var_rt_record record;

v_src_app1_id integer := 0;
v_src_app2_id integer := 0;
v_app1_id integer := 0;
v_app2_id integer := 0;
v_query varchar := '';

BEGIN
	/*
	 * Steps of Execution:
	 * 
	 * 1) Check if recon exists
	 * 2) Copy metadata to same table with new recon_id, app_id, dim_id etc.
	 * 3) Copy data tables and views, i.e. app_, je_, view_, bridge_, bridgesync_, report_ etc.
	 * 
	 */
	

	/* 
	 * Check if the source recon exists in the recon table
	 */
	if
		exists(select 1 from fileservice.recon r where r.recon_id=var_source_recon_id and not is_deleted)
		then
			select r.app1_id, r.app2_id
			into v_app1_id, v_app2_id
			from fileservice.recon r
			where r.recon_id = var_source_recon_id
			and not r.is_deleted
			;
			
		else 
			-- Log Script
			call fileService.sp_log_entry(
									null::integer,
									'''ERROR: Source recon does not exist'''::text,
									var_source_recon_id::integer
									);
			return;		
	end if;

	/* 
	 * Check if the target recon exists in the recon table
	 */
	if
		exists(select 1 from fileservice.recon r where r.recon_id=var_target_recon_id and not is_deleted)
		then
			select r.app1_id, r.app2_id
			into v_app1_id, v_app2_id
			from fileservice.recon r
			where r.recon_id = var_target_recon_id
			and not r.is_deleted
			;
			
		else 
			-- Log Script
			call fileService.sp_log_entry(
									null::integer,
									'''ERROR: Target recon does not exist'''::text,
									var_target_recon_id::integer
									);
			return;		
	end if;

	
	/*
	 * Create query
	 * 
	 */
--	Duplicate Recon Applications
	v_query = ' select app_name, import_type, import_delimiter,currency_symbol, currency_delimiter, has_header, url, "cube",username, "password", '||var_target_recon_id||' as recon_id';
	v_query = v_query||' , false as is_deleted from '||s_schema_name||'.recon_applications where recon_id='||var_source_recon_id||' and not is_deleted order by app_name::int';

	v_query = 'insert into '||s_schema_name||'.recon_applications (app_name, import_type, import_delimiter,currency_symbol, currency_delimiter, has_header, url, "cube",username, "password",recon_id, is_deleted)'||v_query;

	begin
	    execute v_query;
	exception
	    when others then
		call fileservice.sp_log_entry(
			null::integer, 
			'''Error: '|| SQLERRM ||' ''', 
			var_target_recon_id::integer,
			null::text
		);
	end;


--	Update recon table with new app IDs
	select recon_app_id
	into v_app1_id
	from fileservice.recon_applications ra
	where ra.recon_id = var_target_recon_id
	and ra.app_name = '0';

	select recon_app_id
	into v_app2_id
	from fileservice.recon_applications ra
	where ra.recon_id = var_target_recon_id
	and ra.app_name = '1';

	update fileservice.recon
	set app1_id = v_app1_id,
	app2_id = v_app2_id
	where recon_id = var_target_recon_id;


--	Duplicate Recon Dimensions
	v_query = 'select turn_on_define_order,dimension,dim_in_file,type_field,top_member,app_type,is_active,in_recon, false as is_deleted, '||var_target_recon_id||' as recon_id';
	v_query = v_query||', case when app_type = ''0'' then '||v_app1_id||' else '||v_app2_id||' end as recon_app_id from '||s_schema_name||'.recon_dimensions where recon_id='||var_source_recon_id;
	v_query = v_query||' and not is_deleted order by recon_app_id,dimensions_id';

	v_query = 'insert into '||s_schema_name||'.recon_dimensions(turn_on_define_order, dimension, dim_in_file, type_field, top_member, app_type, is_active, in_recon, is_deleted, recon_id, recon_app_id) '||v_query;

	begin
	    execute v_query;
	exception
	    when others then
		call fileservice.sp_log_entry(
			null::integer, 
			'''Error: '|| SQLERRM ||' ''', 
			var_target_recon_id::integer,
			null::text
		);
	end;


--	Duplicate Recon Bridge Mapping
	v_query = 'select 
	rbm.flip_sign
	,rbm.app_type
	,rbm.source_member
	,rbm.bridge_member
	,rbm.dim_comment
	,rbm.bridge_comment
	,rbm.is_invalid
	,rbm.je_comment
	,rd.dimensions_id
	,rd.recon_app_id
	,'||var_target_recon_id||' as recon_id
from '||s_schema_name||'.recon_bridge_mapping rbm
inner join (
	select rd_o.dimensions_id as o_dim_id, rd_o.dimension, rd_o.app_type as o_app_type, rd_n.recon_app_id, rd_n.dimensions_id 
	from '||s_schema_name||'.recon_dimensions rd_o
	inner join '||s_schema_name||'.recon_dimensions rd_n
	on rd_o.dimension = rd_n.dimension
	and rd_o.app_type = rd_n.app_type 
	and rd_o.turn_on_define_order = rd_n .turn_on_define_order 
	where rd_o.recon_id = '||var_source_recon_id||'
	and rd_n.recon_id = '||var_target_recon_id||'
	and not rd_o.is_deleted
	and not rd_n.is_deleted
	order by rd_n.turn_on_define_order::int, rd_n.recon_app_id 
) rd
on rbm.dim_id = rd.o_dim_id
and rbm.app_type = rd.o_app_type
where rbm.recon_id = '||var_source_recon_id||'
and not rbm.is_deleted';

	v_query = 'insert into '||s_schema_name||'.recon_bridge_mapping (flip_sign, app_type, source_member, bridge_member, dim_comment, bridge_comment, is_invalid, je_comment, dim_id, app_id, recon_id) '||v_query;

	begin
	    execute v_query;
	exception
	    when others then
		call fileservice.sp_log_entry(
			null::integer, 
			'''Error: '|| SQLERRM ||' ''', 
			var_target_recon_id::integer,
			null::text
		);
	end;

--	Duplicate Recon Transformation
	v_query = 'select 
		rt.tgt_concat_dimid
		,rt.tgt_concat_dimname
		,rt.bridge_concat_dim_name
		,rt.concat_delimiter
		,rt.apply_all_members
		,'||var_target_recon_id||' as recon_id
		, rd.recon_app_id as app_id,
		rd.dimensions_id
	from '||s_schema_name||'.recon_transformation rt
	inner join (
		select rd_o.dimensions_id as o_dim_id, rd_o.dimension, rd_o.recon_app_id as o_recon_app_id, rd_n.recon_app_id, rd_n.dimensions_id 
		from '||s_schema_name||'.recon_dimensions rd_o
		inner join '||s_schema_name||'.recon_dimensions rd_n
		on rd_o.dimension = rd_n.dimension
		and rd_o.app_type = rd_n.app_type 
		and rd_o.turn_on_define_order = rd_n .turn_on_define_order 
		where rd_o.recon_id = '||var_source_recon_id||'
		and rd_n.recon_id = '||var_target_recon_id||'
		and not rd_o.is_deleted
		and not rd_n.is_deleted
		order by rd_n.turn_on_define_order::int, rd_n.recon_app_id 
	) rd
	on rt.dim_id = rd.o_dim_id
	and rt.app_id = rd.o_recon_app_id
	where rt.recon_id = '||var_source_recon_id;

	v_query = 'insert into '||s_schema_name||'.recon_transformation (tgt_concat_dimid, tgt_concat_dimname,bridge_concat_dim_name,concat_delimiter,apply_all_members,recon_id,app_id,dim_id) '||v_query;

	begin
	    execute v_query;
	exception
	    when others then
		call fileservice.sp_log_entry(
			null::integer, 
			'''Error: '|| SQLERRM ||' ''', 
			var_target_recon_id::integer,
			null::text
		);
	end;

-- Correct the tgt_concat_dimid in recon_transformation table
	for var_rt_record in 
		select id, string_agg(concat_id::text,'-') as tgt_concat_dimid, string_agg(dim_name,'-') as tgt_concat_dimname
		from (
			select rt.*, rt.tgt_concat_dimid, rd.dimensions_id as concat_id
			from (
				select rtx.id , rtx.app_id, rtx.tgt_concat_dimid,
				unnest(string_to_array(rtx.tgt_concat_dimname,'-')) as dim_name,
				nextval('fileservice.recon_table_skey'::regclass) as seq,
				rtx.dim_id,
				rtx.recon_id
				from fileservice.recon_transformation rtx 
				where rtx.recon_id = var_target_recon_id
				and rtx.tgt_concat_dimname is not null
			) rt
			inner join fileservice.recon_dimensions rd 
			on rd.recon_id = rt.recon_id
			and rd.dimension = rt.dim_name
			and rd.recon_app_id = rt.app_id
			order by rt.seq
		) q
		group by id
	loop 
		v_query = 'update '||s_schema_name||'.recon_transformation set tgt_concat_dimid = '''||var_rt_record.tgt_concat_dimid||''' where recon_id = '||var_target_recon_id||' and id = '||var_rt_record.id||';';

		execute v_query;
	end loop;
	

--	Recon Transformation Override

	v_query = 'select 
		rt_n.recon_id
		,rt_o.recon_app_id
		,rt_n.id 
		,rto.source_sync 
		,rto.target_sync 
		,rto.flip_sign
	from '||s_schema_name||'.recon_transformation_override rto
	inner join (
		select rtx.recon_id, rtx.app_id, rtx.id, rd.dimension, rd.recon_app_id
		from '||s_schema_name||'.recon_transformation rtx
		inner join (
			select rd_o.dimensions_id as o_dim_id, rd_o.dimension, rd_o.recon_app_id as o_recon_app_id, rd_n.recon_app_id, rd_n.dimensions_id 
			from '||s_schema_name||'.recon_dimensions rd_o
			inner join '||s_schema_name||'.recon_dimensions rd_n
			on rd_o.dimension = rd_n.dimension
			and rd_o.app_type = rd_n.app_type 
			and rd_o.turn_on_define_order = rd_n .turn_on_define_order 
			where rd_o.recon_id = '||var_source_recon_id||'
			and rd_n.recon_id = '||var_target_recon_id||'
			and not rd_o.is_deleted
			and not rd_n.is_deleted
			order by rd_n.turn_on_define_order::int, rd_n.recon_app_id 
		) rd 
		on rtx.dim_id = rd.o_dim_id 
		and rtx.app_id = rd.o_recon_app_id  
		where rtx.recon_id = '||var_source_recon_id||'
		and rtx.tgt_concat_dimname is not null
	) rt_o 
	on rto.recon_id = rt_o.recon_id 
	and rto.app_id = rt_o.app_id 
	and rto.tfn_id = rt_o.id 
	inner join (
		select rtx.recon_id, rtx.app_id, rtx.id, rd.dimension, rd.recon_app_id
		from '||s_schema_name||'.recon_transformation rtx
		inner join recon_dimensions rd 
		on rtx.dim_id = rd.dimensions_id  
		and rtx.app_id = rd.recon_app_id  
		where rtx.recon_id = '||var_target_recon_id||'
		and rtx.tgt_concat_dimname is not null
	) rt_n
	on rt_o.recon_app_id = rt_n.app_id 
	and rt_o.dimension = rt_n.dimension
	where rto.recon_id = '||var_source_recon_id;

	v_query = 'insert into '||s_schema_name||'.recon_transformation_override (recon_id,app_id,tfn_id,source_sync,target_sync,flip_sign) '||v_query;

	begin
	    execute v_query;
	exception
	    when others then
		call fileservice.sp_log_entry(
			null::integer, 
			'''Error: '|| SQLERRM ||' ''', 
			var_target_recon_id::integer,
			null::text
		);
	end;

-- Get source app ids
	select recon_app_id
	into v_src_app1_id
	from fileservice.recon_applications ra
	where ra.recon_id = var_source_recon_id
	and ra.app_name = '0';

	select recon_app_id
	into v_src_app2_id
	from fileservice.recon_applications ra
	where ra.recon_id = var_source_recon_id
	and ra.app_name = '1';

--	Log Script
	call fileService.sp_log_entry(
								null::integer,
								'''Metadata for recon '|| var_source_recon_id ||' duplicated to '|| var_target_recon_id ||'.'''::text,
								var_target_recon_id::integer
								);

/*
 * Copy tables and views from source recon to target recon
 * 
 */

	for var_rt_record in
	select 
	--table_schema, 
	table_name as src_table, 
	--table_type,
	case 
		when table_name like 'app%'
		then 
			case
				when t.table_name like '%_'||v_src_app1_id
				then 'drop'|| case when t.table_name like 'view_%' then ' view ' else ' table ' end || 'if exists ' ||t.table_schema|| '.app_'||var_target_recon_id||'_'||v_app1_id||' cascade; create table '||t.table_schema||'.app_'||var_target_recon_id||'_'||v_app1_id||' as select * from '||t.table_schema||'.'||t.table_name||';'
				when t.table_name like '%_'||v_src_app2_id
				then 'drop'|| case when t.table_name like 'view_%' then ' view ' else ' table ' end || 'if exists ' ||t.table_schema|| '.app_'||var_target_recon_id||'_'||v_app2_id||' cascade; create table '||t.table_schema||'.app_'||var_target_recon_id||'_'||v_app2_id||' as select * from '||t.table_schema||'.'||t.table_name||';'
			end
		when t.table_name like 'je%' 
		then 
			case
				when t.table_name like '%_'||v_src_app1_id
				then 'drop'|| case when t.table_name like 'view_%' then ' view ' else ' table ' end || 'if exists ' ||t.table_schema|| '.je_'||var_target_recon_id||'_'||v_app1_id||' cascade; create table '||t.table_schema||'.je_'||var_target_recon_id||'_'||v_app1_id||' tablespace tbsp_data as select * from '||t.table_schema||'.'||t.table_name||';'
				when t.table_name like '%_'||v_src_app2_id
				then 'drop'|| case when t.table_name like 'view_%' then ' view ' else ' table ' end || 'if exists ' ||t.table_schema|| '.je_'||var_target_recon_id||'_'||v_app2_id||' cascade; create table '||t.table_schema||'.je_'||var_target_recon_id||'_'||v_app2_id||' tablespace tbsp_data as select * from '||t.table_schema||'.'||t.table_name||';'
			end
--		when t.table_name like 'view_je_%' 
--		then 'call '||t.table_schema||'.sp_create_recon_app_view('||var_target_recon_id||',true::boolean);'
--		when t.table_name like 'view_%' 
--		then 'call '||t.table_schema||'.sp_create_recon_app_view('||var_target_recon_id||');'
		when t.table_name like 'bridgesync_%' 
		then 'drop'|| case when t.table_name like 'view_%' then ' view ' else ' table ' end || 'if exists ' ||t.table_schema|| '.bridgesync_'||var_target_recon_id||' cascade; create table '||t.table_schema||'.bridgesync_'||var_target_recon_id||' tablespace tbsp_data as select * from '||t.table_schema||'.'||t.table_name||';'
		when t.table_name like 'bridge_%' 
		then 'drop'|| case when t.table_name like 'view_%' then ' view ' else ' table ' end || 'if exists ' ||t.table_schema|| '.bridge_'||var_target_recon_id||' cascade; create table '||t.table_schema||'.bridge_'||var_target_recon_id||' tablespace tbsp_data as select * from '||t.table_schema||'.'||t.table_name||';'
		when t.table_name like 'report_je%' 
		then 'drop'|| case when t.table_name like 'view_%' then ' view ' else ' table ' end || 'if exists ' ||t.table_schema|| '.report_je_'||var_target_recon_id||' cascade; create table '||t.table_schema||'.report_je_'||var_target_recon_id||' tablespace tbsp_data as select * from '||t.table_schema||'.'||t.table_name||';'
		when t.table_name like 'report_%' 
		then 'drop'|| case when t.table_name like 'view_%' then ' view ' else ' table ' end || 'if exists ' ||t.table_schema|| '.report_'||var_target_recon_id||' cascade; create table '||t.table_schema||'.report_'||var_target_recon_id||' tablespace tbsp_data as select * from '||t.table_schema||'.'||t.table_name||';'
		when t.table_name like 'final_report_%' 
		then 'drop'|| case when t.table_name like 'view_%' then ' view ' else ' table ' end || 'if exists ' ||t.table_schema|| '.final_report_'||var_target_recon_id||' cascade; create table '||t.table_schema||'.final_report_'||var_target_recon_id||' tablespace tbsp_data as select * from '||t.table_schema||'.'||t.table_name||';'
	end as query
	from information_schema."tables" t
	where table_schema = 'fileservice'
	and table_name in (
	--Run Import
		'app_'||var_source_recon_id||'_'||v_src_app1_id,'app_'||var_source_recon_id||'_'||v_src_app2_id,
		'je_'||var_source_recon_id||'_'||v_src_app1_id,'je_'||var_source_recon_id||'_'||v_src_app2_id,
--		'view_'||var_source_recon_id,'view_je_'||var_source_recon_id,
	--Bridge
		'bridge_'||var_source_recon_id,'bridge_je_'||var_source_recon_id,
--		'view_bridge_'||var_source_recon_id,'view_bridge_je_'||var_source_recon_id,
--		'view_bridge_'||var_source_recon_id||'_kickout','view_bridge_je_'||var_source_recon_id||'_kickout',
	--Bridgesync
		'bridgesync_'||var_source_recon_id,
	--Report
		'report_'||var_source_recon_id,'report_je_'||var_source_recon_id,'final_report_'||var_source_recon_id
	)
	order by t.table_type 
	loop 
		begin 
--			raise notice '%',var_rt_record.query;	
			execute var_rt_record.query;
			commit;
		end;
	end loop;

--Re-create the app and je views
	select count(*)
	into v_query
	from information_schema.tables where table_schema=s_schema_name and table_name like 'app_'||var_target_recon_id||'_%';

	if v_query='2'
	then
		call fileservice.sp_create_recon_app_view(var_target_recon_id);
	end if;


	select count(*)
	into v_query
	from information_schema.tables where table_schema=s_schema_name and table_name like 'je_'||var_target_recon_id||'_%';

	if v_query='2'
	then
		call fileservice.sp_create_recon_app_view(var_target_recon_id, true); 
	end if;

--	Log Script
	call fileService.sp_log_entry(
								null::integer,
								'''Recon '|| var_source_recon_id ||' duplicated to '|| var_target_recon_id ||'.'''::text,
								var_target_recon_id::integer
								);

	update fileservice.recon
	set status = 'Copied',
	created_by = var_user_name,
	created_date = now()::timestamp
	where recon_id = var_target_recon_id;

end;
$procedure$
;

-- Permissions

ALTER PROCEDURE fileservice.sp_replicate_recon(int4,int4,varchar) OWNER TO "user_dataRecon_file";
GRANT ALL ON PROCEDURE fileservice.sp_replicate_recon(int4,int4,varchar) TO public;
GRANT ALL ON PROCEDURE fileservice.sp_replicate_recon(int4,int4,varchar) TO postgres;
GRANT ALL ON PROCEDURE fileservice.sp_replicate_recon(int4,int4,varchar) TO "user_dataRecon_file";
