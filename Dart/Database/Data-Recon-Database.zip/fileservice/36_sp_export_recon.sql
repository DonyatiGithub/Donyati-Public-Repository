CREATE OR REPLACE PROCEDURE fileservice.sp_export_recon(recon_id integer, out_location varchar)
 LANGUAGE plpgsql
AS $procedure$
DECLARE

s_schema_name text := 'fileservice';
v_xml_nulls boolean := TRUE;
v_xml_table_forest boolean := FALSE;
v_sequence bigint := 9223372036854775807;

v_file_location varchar := out_location;
var_recon_id integer := recon_id;
v_app1_id integer := 0;
v_app2_id integer := 0;
v_query varchar := '';

BEGIN
	/*
	 * Steps of Execution:
	 * 
	 * 1) Check if recon exists
	 * 2) Reset surrogate key sequence
	 * 3) Recreate/ truncate recon_xml table
	 * 4) Create query for export
	 * 5) Write XML query output to table
	 * 6) Export table to file
	 * 
	 */
	

	/* 
	 * Check if the recon exists in the recon table
	 */
	if
		exists(select 1 from fileservice.recon r where r.recon_id=var_recon_id)
		then
			select r.app1_id, r.app2_id
			into v_app1_id, v_app2_id
			from fileservice.recon r
			where r.recon_id = var_recon_id
			and not r.is_deleted
			;
			
		else 
			-- Log Script
			call fileService.sp_log_entry(
									var_app_id::integer,
									'''ERROR: Recon does not exist'''::text
									);
			return;		
	end if;

	
	/*
	 * Reset surrogate key sequence
	 * Set to max possible value so the sequence cycles back
	 * 
	 */
	begin
	    execute 'select setval(''fileservice.recon_table_skey''::regclass,'||v_sequence||')';
	exception
	    when others then
		call fileservice.sp_log_entry(
			null::integer,
			'''Error: '|| SQLERRM ||' ''',
			var_recon_id::integer,
			null::text
		);
	end;


	/*
	 * Empty recon_xml table
	 * 
	 */
	delete from fileservice.recon_xml;
	
	/*
	 * Create query
	 * 
	 */
--	Expot Recon
	v_query = 'insert into '||s_schema_name||'.recon_xml (xml_data) select xmlelement(name recon,xmlforest("name" ,variance_threshold ,description,status))::text from '||s_schema_name||'.recon where recon_id='||var_recon_id;
	begin
	    execute v_query;
    exception
	    when others 
		then
		call fileservice.sp_log_entry(
			null::integer,
			'''Error: '|| SQLERRM ||' ''',
			var_recon_id::integer,
			null::text
		);
	end;

--	Export Recon Applications
	v_query = 'select xmlelement(name recon_application, xmlforest(app_name, import_type, import_delimiter,currency_symbol, currency_delimiter, has_header, url, "cube",username, "password"))::text ';
	v_query = v_query || 'from '||s_schema_name||'.recon_applications where recon_id='||var_recon_id||' and not is_deleted';

	v_query = 'insert into '||s_schema_name||'.recon_xml (xml_data) '||v_query;
	begin 
	    execute v_query;
	exception
	    when others 
		then
		call fileservice.sp_log_entry(
			null::integer,
			'''Error: '|| SQLERRM ||' ''',
			var_recon_id::integer,
			null::text
		);
	end;

--	Recon Dimensions
	v_query = 'select xmlelement(name recon_dimensions, xmlforest(turn_on_define_order,dimension,dim_in_file,type_field,top_member,app_type,is_active,in_recon))::text
	from '||s_schema_name||'.recon_dimensions
	where recon_id='||var_recon_id||'
	and not is_deleted 
	order by recon_app_id,dimensions_id';
	v_query = 'insert into '||s_schema_name||'.recon_xml (xml_data) '||v_query;
	
	begin
	    execute v_query;
	exception  
	    when others 
		then
		call fileservice.sp_log_entry(
			null::integer,
			'''Error: '|| SQLERRM ||' ''',
			var_recon_id::integer,
			null::text
		);
	end;

	v_query = '';
--	Recon Bridge Mapping
	v_query = 'select 
	xmlelement(
		name recon_bridge_mapping,
		xmlforest(
		rbm.flip_sign
		,rbm.app_type
		,rbm.source_member
		,rbm.bridge_member
		,rbm.dim_comment
		,rbm.bridge_comment
		,rbm.is_invalid
		,rbm.je_comment
		,rd.dimension 
		)
	)
	from fileservice.recon_bridge_mapping rbm
	inner join fileservice.recon_dimensions rd
	on rd.recon_id = rbm.recon_id 
	and rd.recon_app_id = rbm.app_id 
	and rd.dimensions_id = rbm.dim_id 
	and not rbm.is_deleted
	where rd.recon_id='||var_recon_id||'
	and not rd.is_deleted 
	order by rbm.app_type::integer, rbm.dim_id, rbm.bridge_id';
	v_query = 'insert into '||s_schema_name||'.recon_xml (xml_data) '||v_query;
--raise notice '%',v_query;
    begin
	    execute v_query;
	exception
	    when others 
		then
		call fileservice.sp_log_entry(
			null::integer,
			'''Error: '|| SQLERRM ||' ''',
			var_recon_id::integer,
			null::text
		);
	end;
	  

--	Recon Transformation
	v_query = 'select 
	xmlelement(
		name recon_transformation,
		xmlforest(
		rt.tgt_concat_dimid
		,rt.tgt_concat_dimname
		,rt.bridge_concat_dim_name
		,rt.concat_delimiter
		,rt.apply_all_members
		,case when app_id%2=0 then ''1'' else ''0'' end as app_type
		,rd.dimension 
		)
	)
	from fileservice.recon_transformation rt
	inner join fileservice.recon_dimensions rd
	on rd.recon_id = rt.recon_id 
	and rd.recon_app_id = rt.app_id 
	and rd.dimensions_id = rt.dim_id 
	and not rd.is_deleted
	where rt.recon_id='||var_recon_id||'
	order by rt.dim_id, rt.app_id';
	v_query = 'insert into '||s_schema_name||'.recon_xml (xml_data) '||v_query;
--raise notice '%',v_query;
    begin
	    execute v_query;
	exception
	    when others 
		then
		call fileservice.sp_log_entry(
			null::integer,
			'''Error: '|| SQLERRM ||' ''',
			var_recon_id::integer,
			null::text
		);
	end;


--	Recon Transformation Override
	v_query = 'select 
	xmlelement(
		name recon_transformation_override,
		xmlforest(
		rto.source_sync
		,rto.target_sync
		,rto.flip_sign
		,case when rt.app_id%2=0 then ''1'' else ''0'' end as app_type
		,rd.dimension 
		)
	)
	from fileservice.recon_transformation rt
	inner join fileservice.recon_transformation_override rto 
	on rt.id = rto.tfn_id 
	inner join fileservice.recon_dimensions rd
	on rd.recon_id = rt.recon_id 
	and rd.recon_app_id = rt.app_id 
	and rd.dimensions_id = rt.dim_id 
	and not rd.is_deleted
	where rt.recon_id='||var_recon_id||'
	order by rt.dim_id, rt.app_id';
	v_query = 'insert into '||s_schema_name||'.recon_xml (xml_data) '||v_query;
--raise notice '%',v_query;
    begin
	    execute v_query;
	exception
	    when others 
		then
		call fileservice.sp_log_entry(
			null::integer,
			'''Error: '|| SQLERRM ||' ''',
			var_recon_id::integer,
			null::text
		);
	end;


	/*
	 * Export table to file
	 * 
	 */
	begin
		execute 'copy (
			select xml_data
			from fileservice.recon_xml tx
			order by xml_id
		)
		to '''||v_file_location||'recon.xml'' (encoding ''UTF8'')';
	exception
	    when others then
		call fileservice.sp_log_entry(
			null::integer,
			'''Error: '|| SQLERRM ||' ''',
			var_recon_id::integer,
			null::text
		);
	end;
		


	--	Log Script
	call fileService.sp_log_entry(
								null::integer,
								'''Report report_'|| var_recon_id || ' without variance created'''::text,
								var_recon_id::integer,
								'report_'||var_recon_id::text
								);

end;
$procedure$
;

-- Permissions

ALTER PROCEDURE fileservice.sp_export_recon(int4,varchar) OWNER TO "user_dataRecon_file";
GRANT ALL ON PROCEDURE fileservice.sp_export_recon(int4,varchar) TO public;
GRANT ALL ON PROCEDURE fileservice.sp_export_recon(int4,varchar) TO postgres;
GRANT ALL ON PROCEDURE fileservice.sp_export_recon(int4,varchar) TO "user_dataRecon_file";
