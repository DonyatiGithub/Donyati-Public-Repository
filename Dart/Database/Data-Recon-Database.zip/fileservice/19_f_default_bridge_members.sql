CREATE OR REPLACE FUNCTION fileservice.f_default_bridge_members(recon_id integer)
 RETURNS integer
 LANGUAGE plpgsql
AS $function$
declare
var_recon_id integer := recon_id;
var_app_id Record;
var_dim_id integer;
var_table_rec Record;
var_col_name Record;
s_schema_name text := 'fileservice';
var_query text := '';
var_insert_query text := '';
BEGIN
	/*
	 * Check if recon is not signed-off
	 */	
	if
		not exists(SELECT 1 FROM fileservice.recon r WHERE r.recon_id = var_recon_id AND NOT r.sign_off)
		then 
			-- Log Script
			call fileService.sp_log_entry(
									NULL::integer,
									'''ERROR: Recon is signed-off'''::text,
									var_recon_id,
									NULL::text
									);
			return 1;		
	end if;
	
	/*
	 * Check if the given recon_id has active applications
	 */
	if
		exists(select rd.recon_id from fileservice.recon_applications rd where rd.recon_id = var_recon_id and not is_deleted)
	then
		/*
		 * Soft delete all the existing recon_bridge_members for given recon_id
		 */
		update fileservice.recon_bridge_mapping rbm
		set is_deleted = true 
		where rbm.recon_id =var_recon_id;
		/*
		 * Retrieve active recon_app_id
		 */
		for var_app_id in
			select ra.recon_app_id, ra.app_name
			from fileservice.recon_applications ra
			where ra.recon_id = var_recon_id
			and not ra.is_deleted
		loop 
			/*
			 * For each app_id retrieve column_names
			 */
--			raise notice '%',var_app_id;
			for var_table_rec in 
				select column_name, 'app_'||var_recon_id||'_'||var_app_id.recon_app_id as var_table_name
				from information_schema.columns
				where table_schema=s_schema_name
				and column_name not in ('app_id', 'AMOUNT','file_name','file_id','record_id')
				and table_name='app_'||var_recon_id||'_'||var_app_id.recon_app_id---------
			loop 
--				raise notice '%---%', var_table_rec.var_table_name, var_table_rec.column_name;
--				raise notice '%', var_query;
				/*
				 * Get dimension id for the column_name
				 */
				select rd.dimensions_id
				into var_dim_id
				from fileservice.recon_dimensions rd
				where rd.recon_id = var_recon_id
				and rd.recon_app_id = var_app_id.recon_app_id
				and lower(dimension) = lower(var_table_rec.column_name);
			
				/*
				 * For each column name, prepare 'select distinct from table' query
				 */
				var_query = 'select distinct "'||var_table_rec.column_name||'" as col_name from '||s_schema_name||'.'||var_table_rec.var_table_name||';';
				for var_col_name in 
					execute var_query
				loop
					/*
					 * Insert source/bridge member if value does not exist
					 */
					if not exists(
						select rbm.recon_id
						from fileservice.recon_bridge_mapping rbm
						where rbm.recon_id=var_recon_id 
						and rbm.app_id=var_app_id.recon_app_id 
						and COALESCE(rbm.source_member,'null') = COALESCE(var_col_name.col_name,'null')
						and rbm.app_type <> var_app_id.app_name
						and not rbm.is_deleted
					)
					then
					var_insert_query = 'INSERT INTO fileservice.recon_bridge_mapping (recon_id, app_id, dim_id, flip_sign, app_type, source_member, bridge_member, is_deleted, is_invalid)';
					var_insert_query = var_insert_query||E'\nVALUES('||var_recon_id||','||var_app_id.recon_app_id||', '||var_dim_id||', false,'''||var_app_id.app_name||''','''||coalesce(var_col_name.col_name,'null')||''', '''||coalesce(var_col_name.col_name,'null')||''', false, false);';
--					raise notice '%', var_insert_query;
					execute var_insert_query;
					end if;
				end loop;	
			end loop;
		
		end loop;
	return 0;
	end if;
return 1;
end;
$function$
;

-- Permissions

ALTER FUNCTION fileservice.f_default_bridge_members(int4) OWNER TO "user_dataRecon_file";
GRANT ALL ON FUNCTION fileservice.f_default_bridge_members(int4) TO public;
GRANT ALL ON FUNCTION fileservice.f_default_bridge_members(int4) TO postgres;
GRANT ALL ON FUNCTION fileservice.f_default_bridge_members(int4) TO "user_dataRecon_file";
