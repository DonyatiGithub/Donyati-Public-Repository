DROP EXTENSION IF EXISTS tablefunc;

CREATE EXTENSION tablefunc 
	SCHEMA "fileservice";
