drop table if exists admin."direct_connect";

create table admin."direct_connect"(id character varying,
app_name character varying,
import_type int,
dc_username character varying,
dc_password bytea,
dc_url character varying,
tag bytea,
nonce bytea,
email character varying,
tenant_id character varying,
osname character varying,
ebase_server character varying,
ebase_uname character varying,
ebase_password bytea,
ebaseapp_name character varying,
ebasedb_name character varying,
ebaseproservicesurl character varying
)
tablespace tbsp_meta;

ALTER table admin."direct_connect" owner to "user_dataRecon_admin";