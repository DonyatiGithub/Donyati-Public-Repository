**Pre-requisites for running the script:**
1) Postgresql 13 or newer should be installed in Windows/Linux/WSL ubuntu. Follow the instructions on 'https://www.postgresql.org/docs/current/installation.html' for steps to install postgresql.
2) .pgpass and .pgservice files:
    a) For windows, environment variables should have path to file
    b) For Linux/WSL, files should be in user home folder, or environment variables should be set
3) From scripts.txt file remove any unwanted/ unchanged scripts. All files mentioned here will be executed by the run_scripts.(bat/sh) scripts.
4) scripts_master_copy.txt has all .sql file names. Edit this only if .sql files are added or removed from project. This can be copied to scripts.txt to re-create/ create fresh db

**Steps of execution:**
1) Clone repository/ pull latest code to local system
2) Ensure postgres is running on local system
3) Run script:
    a) For windows, double click on run_scripts.bat file
    b) Fow Linux/WSL, in terminal run "bash run_scripts.sh"
