CREATE OR REPLACE PROCEDURE admin.sp_adduser(userid character varying, name character varying, useremail character varying, password character varying)
 LANGUAGE plpgsql
AS $procedure$  
BEGIN 
   
   IF EXISTS (SELECT email FROM admin."InviteDetails"
              WHERE  email = UserEmail
          ) THEN
   	INSERT INTO admin."UserDetails" (id,name,email,role,"group",access_type,password,is_active) VALUES   
    (UserId,Name,
	 UserEmail,
	 (SELECT role FROM admin."InviteDetails" WHERE email=UserEmail),
	 (SELECT "group" FROM admin."InviteDetails" WHERE email=UserEmail),
	 (SELECT access_Type FROM admin."InviteDetails" WHERE email=UserEmail),
	 Password, true
	);
	
   	DELETE FROM admin."InviteDetails" where email=UserEmail;
	
   ELSE
    RAISE EXCEPTION 'User invite not found!';
   END IF;
	
END  
$procedure$
;

-- Permissions

ALTER PROCEDURE "admin".sp_adduser(varchar, varchar, varchar, varchar) OWNER TO "user_dataRecon_admin";
GRANT ALL ON PROCEDURE "admin".sp_adduser(varchar, varchar, varchar, varchar) TO postgres;
