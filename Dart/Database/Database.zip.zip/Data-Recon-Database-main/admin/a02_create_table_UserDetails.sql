--- User Details Table

-- Table: public.UserDetails

DROP TABLE IF EXISTS public."UserDetails";

CREATE TABLE IF NOT EXISTS admin."UserDetails"
(
    id character varying(50) COLLATE pg_catalog."default" NOT NULL,
    name character varying(50) COLLATE pg_catalog."default",
    email character varying(50) COLLATE pg_catalog."default",
    role character varying(50) COLLATE pg_catalog."default",
    "group" character varying(50) COLLATE pg_catalog."default",
    access_type jsonb,
    password character varying(100) COLLATE pg_catalog."default",
    last_logged_in character varying(100) COLLATE pg_catalog."default",
    is_active boolean,
    CONSTRAINT "UserDetails_pkey" PRIMARY KEY (id)
)
TABLESPACE tbsp_meta;

ALTER TABLE IF EXISTS admin."UserDetails"
    OWNER to "user_dataRecon_admin";


--- *** ----
