#!/bin/bash

port=15432;
hostnm=localhost;
usernm=postgres;
dbname=db_dataRecon;
filename="scripts.txt";

mkdir -p logs/create_db;
mkdir -p logs/admin;
mkdir -p logs/fileservice;

psql -p $port -h $hostnm -U $usernm -f "./create_db/01_create_tablespace.sql" -f "./create_db/02_create_database_dataRecon.sql" -L "./logs/create_db/create_db.log" ;
psql -p $port -h $hostnm -U $usernm -d $dbname -f "./create_db/03_create_schema.sql" -f "./create_db/04_create_db_users_dataRecon.sql" -f "./create_db/05_create_extension_tablefunc.sql" -L "./logs/create_db/create_schema_user.log" ;

while read -r line; 
do 
    line="$( echo -e "$line" | tr '\\' '/' | tr '\r' ' ' )";
    echo "Running sql: "$line; 
    file=${line#".\\"};
    file=${file: 0:-5};
    touch logs/${file}.log;
    psql -p $port -h $hostnm -U $usernm -d $dbname --file=$line -L logs/${file}.log;
done < scripts.txt

exit 0;