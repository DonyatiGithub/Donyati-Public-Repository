
CREATE TABLE IF NOT EXISTS fileservice.global_variables (
    global_var_id SERIAL PRIMARY KEY,
    global_variable_name varchar(320),
    description VARCHAR(320),
    created_by VARCHAR(320),
    created_at TIMESTAMP
  )
TABLESPACE tbsp_meta;


ALTER TABLE IF EXISTS fileservice.global_variables OWNER to "user_dataRecon_file";

GRANT ALL ON TABLE fileservice.global_variables TO postgres;
GRANT DELETE, UPDATE, INSERT, SELECT ON TABLE fileservice.global_variables TO "user_dataRecon_file";




-- Table: fileservice.global_recon_applications

DROP TABLE  IF EXISTS fileservice.global_recon_applications cascade;
CREATE TABLE fileservice.global_recon_applications (
	gloabl_recon_app_id SERIAL PRIMARY KEY,
	global_var_id int8 NULL,
	app_name varchar NULL,
	import_type varchar NULL,
	import_delimiter varchar NULL,
	currency_symbol varchar NULL,
	currency_delimiter varchar NULL,
	has_header bool NULL,
	url varchar NULL,
	"cube" varchar NULL,
	username varchar NULL,
	"password" varchar NULL,
	filename varchar NULL,
	is_deleted bool NULL DEFAULT false,
	mdxquery character varying,
    CONSTRAINT fk_permission_group_map_permission_group
      FOREIGN KEY(global_var_id)
          REFERENCES fileservice.global_variables(global_var_id)
          ON DELETE CASCADE
)
TABLESPACE tbsp_meta;

ALTER TABLE IF EXISTS fileservice.global_recon_applications
    OWNER to "user_dataRecon_file";

GRANT ALL ON TABLE fileservice.global_recon_applications TO postgres;
GRANT DELETE, UPDATE, INSERT, SELECT ON TABLE fileservice.global_recon_applications TO "user_dataRecon_file";



CREATE TABLE IF NOT EXISTS fileservice.global_recon_dimensions
(
    global_dimensions_id SERIAL PRIMARY KEY,
	global_var_id int8 NULL,
	turn_on_define_order varchar NULL,
	dimension varchar NULL,
	dim_in_file varchar NULL,
	type_field varchar NULL,
	top_member varchar NULL,
	app_type varchar NULL,
	is_active bool NULL default false,
	CONSTRAINT fk_permission_group_map_permission_group
      FOREIGN KEY(global_var_id)
          REFERENCES fileservice.global_variables(global_var_id)
          ON DELETE CASCADE
)

TABLESPACE tbsp_meta;

ALTER TABLE fileservice.global_recon_dimensions
    OWNER to "user_dataRecon_file";

GRANT ALL ON TABLE fileservice.global_recon_dimensions TO postgres;

GRANT DELETE, UPDATE, INSERT, SELECT ON TABLE fileservice.global_recon_dimensions TO "user_dataRecon_file";



ALTER TABLE fileservice.recon ADD COLUMN global_var_id int8 DEFAULT NULL ;