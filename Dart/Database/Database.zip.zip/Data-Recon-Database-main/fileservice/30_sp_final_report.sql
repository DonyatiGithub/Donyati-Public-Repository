--drop procedure fileservice.sp_final_report(integer, bool);
CREATE OR REPLACE PROCEDURE fileservice.sp_final_report(recon_id integer, je boolean)
 LANGUAGE plpgsql
AS $procedure$
declare
var_recon_id integer := recon_id;
var_je boolean := je;
var_je_text text := 'false';
s_schema_name text := 'fileservice';
var_cols text :='';
var_query text := '';
var_join text := '';
v_dim text;
var_dim text[];
begin
	
	if
		exists (select 1 from fileservice.recon_dimensions rd where rd.recon_id = var_recon_id and in_recon and is_active and rd.turn_on_define_order not in ('0','1','2'))
	then
		select array_agg(dim_name)
		into var_dim
		from (
		select
			'bridgesync-'||rd1.dimension||'-'||rd2.dimension||'' as dim_name
		from
			fileservice.recon r
		inner join fileservice.recon_dimensions rd1
		on
			rd1.recon_id = r.recon_id
			and rd1.recon_app_id = r.app1_id
			and not rd1.is_deleted
			and rd1.is_active
			and (rd1.turn_on_define_order in ('0', '1', '2')
				or rd1.in_recon)
		inner join fileservice.recon_dimensions rd2
		on
			rd2.recon_id = r.recon_id
			and rd2.recon_app_id = r.app2_id
			and not rd2.is_deleted
			and rd2.is_active
			and (rd2.turn_on_define_order in ('0', '1', '2')
				or rd2.in_recon)
			and rd1.turn_on_define_order = rd2.turn_on_define_order
		where
			r.recon_id = var_recon_id-------------------------------------------------------------------------------------------------------------------
			and rd1.dimension <> 'AMOUNT'
		) q;
	else
		select array_agg(dim_name)
		into var_dim
		from (
		select
			'bridgesync-'||rd1.dimension||'-'||rd2.dimension||'' as dim_name
		from fileservice.recon r 
		inner join fileservice.recon_dimensions rd1
		on rd1.recon_id = r.recon_id 
		and rd1.recon_app_id = r.app1_id 
		and rd1.is_active
		and not rd1.is_deleted 
		inner join fileservice.recon_dimensions rd2
		on rd2.recon_id = r.recon_id 
		and rd2.recon_app_id = r.app2_id 
		and rd2.is_active
		and not rd2.is_deleted 
		and rd1.turn_on_define_order = rd2.turn_on_define_order
		where
			r.recon_id = var_recon_id-------------------------------------------------------------------------------------------------------------------
			and rd1.dimension <> 'AMOUNT'
		) q;
	end if;

	
	if var_je
	then
		var_je_text = 'true';
	else
		var_je_text = 'false';
	end if;
--	raise notice '%', var_je;

	select 
	string_agg(sel_list,',') as sel_list,
	string_agg(sel_list,',') as int_to_text,
	string_agg(case when column_name=dim_name then 'r."'||column_name||'"=rj."'||dim_name||'"' end,' and ') as join_list,
	string_agg('"'||yp||'"','+') as year_period
	into var_query,var_cols, var_join, v_dim
	from (
		select
			c.column_name,
			rd.dim_name,
			case
				when (rd.dim_name is null) and c.column_name not in ('je-comment','bridge-comment','grand_abs_total')
				then c.column_name
			end as yp,
			case 
				when var_je_text::boolean
				then 
					case
						when (c.column_name=rd.dim_name) 
						then concat('coalesce(r."',c.column_name,'", rj."',column_name,'") as "',column_name,'"')
						when c.column_name = 'bridge-comment'
						then concat('coalesce(r."bridge-comment", rj."bridge-comment") as "bridge-comment"')
						when c.column_name = 'je-comment'
						then concat('coalesce(  rj."je-comment" ,r."je-comment") as "je-comment"')
						when c.column_name='grand_abs_total'
						then null -- Move the grand abs total logic to an outer query 'coalesce(r."grand_abs_total",''0.00'')::decimal+coalesce(rj."grand_abs_total",''0.00'')::decimal as "grand_abs_total"'
						else concat('(coalesce(r."'||c.column_name||'",0.00)::numeric +  coalesce(rj."'||c.column_name||'",0.00)::numeric) as "'||c.column_name||'"')
					end
				else
					case
						when (c.column_name=rd.dim_name) 
						then 'r."'||c.column_name||'" as "'||column_name||'"'
						when c.column_name = 'bridge-comment'
						then 'r."bridge-comment" as "bridge-comment"'
						when c.column_name = 'je-comment'
						then 'r."je-comment" as "je-comment"'
						when c.column_name='grand_abs_total'
						then null -- Move the grand abs total logic to an outer query 'coalesce(r."grand_abs_total",''0.00'')::decimal+coalesce(rj."grand_abs_total",''0.00'')::decimal as "grand_abs_total"'
						else '(r."'||c.column_name||'") as "'||c.column_name||'"'
					end
			end as sel_list
		from
			information_schema."columns" c
		left join (select unnest(var_dim) as dim_name) rd
		on
			c.column_name = rd.dim_name
		where
			c.table_schema = 'fileservice'
			and c.table_name = 'report_'||var_recon_id --------------------------------------------------------------------------------------------------------------------
	) q;

	var_query = E'select \n'||var_query;
	var_query = var_query||E'\nfrom '||s_schema_name||'.report_'||var_recon_id||' r';

	if var_je
	then
		var_query = var_query||E'\nfull outer join fileservice.report_je_'||var_recon_id||' rj';
		var_query = var_query||E'\non '||var_join;
	end if;

	var_query = E'select * ,('||v_dim||E') as grand_abs_total from (\n'||var_query||E'\n)q';
--	raise notice '%',var_query;

    begin
	    execute 'drop table if exists '||s_schema_name||'.final_report_'||var_recon_id||E';\ncreate table '||s_schema_name||'.final_report_'||var_recon_id||' tablespace tbsp_data as '||var_query;
	exception
	    when others then
		call fileservice.sp_log_entry(
			null::integer, 
			'''Error: '|| SQLERRM ||' ''', 
			var_recon_id::integer, 
			null::text
		);
	end;




--raise notice '%',v_dim;
	
	--	Log Script
	call fileService.sp_log_entry(
								null::integer,
								'''Report report_'|| var_recon_id || ' without variance created'''::text,
								var_recon_id::integer,
								'report_'||var_recon_id::text
								);
							
end;
$procedure$
;

-- Permissions

ALTER PROCEDURE fileservice.sp_final_report(int4,bool) OWNER TO "user_dataRecon_file";
GRANT ALL ON PROCEDURE fileservice.sp_final_report(int4,bool) TO public;
GRANT ALL ON PROCEDURE fileservice.sp_final_report(int4,bool) TO postgres;
GRANT ALL ON PROCEDURE fileservice.sp_final_report(int4,bool) TO "user_dataRecon_file";
