CREATE OR REPLACE PROCEDURE fileservice.sp_create_dynamic_table(recon_app_id integer, journal_entry boolean DEFAULT false)
 LANGUAGE plpgsql
AS $procedure$
DECLARE
var_app_id integer := recon_app_id;
var_je boolean := journal_entry;
var_script varchar := ''; 
var_dim_name text := '';
v_dim_name_rec record;
var_table_rec record;
s_schema_name text := 'fileservice';
BEGIN
	
-- Check recon is not signed off
if
	not exists(SELECT 1 FROM fileservice.recon r WHERE r.recon_id IN (select ra.recon_id from fileservice.recon_applications ra where ra.recon_app_id=var_app_id) AND NOT r.sign_off)
	then 
		-- Log Script
		call fileService.sp_log_entry(
								var_app_id::integer,
								'''ERROR: Recon is signed-off'''::text
								);
		return;		
end if;
	
-- If the recon application id exists, then fetch it's corresponding dimensions
if
		exists(select count(*) from fileservice.recon_dimensions rd where rd.recon_app_id = var_app_id)
	then
--		raise notice '1';
	
		select concat(string_agg(dim,', '),', file_name character varying COLLATE pg_catalog."default", file_id integer')
		into var_dim_name
		from (
			select concat('"',dim,'" character varying COLLATE pg_catalog."default"') as dim
			from (
				select rd.dimension as dim
				from fileservice.recon_dimensions rd
				where rd.recon_app_id = var_app_id
				and rd.is_active
				and not rd.is_deleted
				order by rd.dimensions_id
			) q1
		) q2;
--		raise notice '%', var_dim_name;
		
	-- Preparation of the create table script
	select *
	into var_table_rec
	from f_check_get_app_details(var_app_id, var_je) as (table_name text, rec_id integer);
	
		var_script = 'Drop table if exists '||s_schema_name||'.'||var_table_rec.table_name||' cascade;';
		var_script = var_script ||' Create table if not exists '||s_schema_name||'.'||var_table_rec.table_name||' (record_id bigint NOT NULL DEFAULT nextval(''fileservice.recon_table_skey''::regclass) PRIMARY KEY, app_id integer null default '||var_app_id||', '||var_dim_name;
	
		if var_je
		then
--		raise notice 'in if';
			var_script = var_script || ', je_comment character varying COLLATE pg_catalog."default"';
		end if;
		var_script = var_script ||') TABLESPACE tbsp_data;';
		
	-- Adding permissions to the table
		var_script = var_script ||' GRANT ALL ON TABLE '||s_schema_name||'.'||var_table_rec.table_name||' TO postgres;';
		var_script = var_script ||' GRANT DELETE, UPDATE, INSERT, SELECT ON TABLE '||s_schema_name||'.'||var_table_rec.table_name||' TO "user_dataRecon_file";';
	
--		raise notice '%',var_script;
	
	-- Run create table script
	begin
	    execute var_script;
	exception
	    when others then
		call fileservice.sp_log_entry(
			var_app_id::integer,
			'''Error: '|| SQLERRM ||' ''', 
			var_table_rec.rec_id::integer, 
			var_table_rec.table_name::text 
		);
	end;

	-- Log Script
	if(var_je)
	then
		call fileService.sp_log_entry(
									var_app_id::integer,
									'''JE table created'''::text,
									var_table_rec.rec_id::integer,
									var_table_rec.table_name::text
									);
	else
		call fileService.sp_log_entry(
									var_app_id::integer,
									'''App Table created'''::text,
									var_table_rec.rec_id::integer,
									var_table_rec.table_name::text
									);	
	end if;	
end if;
END
$procedure$
;

-- Permissions

ALTER PROCEDURE fileservice.sp_create_dynamic_table(int4, bool) OWNER TO "user_dataRecon_file";
GRANT ALL ON PROCEDURE fileservice.sp_create_dynamic_table(int4, bool) TO public;
GRANT ALL ON PROCEDURE fileservice.sp_create_dynamic_table(int4, bool) TO postgres;
GRANT ALL ON PROCEDURE fileservice.sp_create_dynamic_table(int4, bool) TO "user_dataRecon_file";
