--drop PROCEDURE fileservice.sp_create_recon_run_bridge_table2;
CREATE OR REPLACE PROCEDURE fileservice.sp_create_recon_run_bridge_table2(recon_id integer, journal_entry boolean DEFAULT false)
 LANGUAGE plpgsql
AS $procedure$
declare
s_schema_name text := 'fileservice';
var_recon_id integer := recon_id;
var_je boolean := journal_entry;

var_app1_id integer := 0;
var_app2_id integer := 0;
var_app_type integer := 0;

var_name text := '';
var_name_table text := '';

var_view_script text := '';
var_script text := '';
var_script2 text := '';
var_kickout boolean := false;

var_tmstp text:= '';
var_rec_count integer := 0;
var_count integer := 0;
var_limit integer := 100000;
begin

	select now()::text into var_tmstp;
	raise notice '1: %', var_tmstp; 	
	/*
	 * if active get the individual application id that belong to the recon id
	 */
	if
		exists (select 1 from fileservice.recon r where r.recon_id=var_recon_id and r.is_deleted=false)
		then
			select r.app1_id, r.app2_id, r.recon_id as view_name
			into var_app1_id, var_app2_id, var_name
			from fileservice.recon r 
			where r.recon_id = var_recon_id
			and r.is_deleted = false;
		else
			call fileService.sp_log_entry(
				null::integer, 
				'''ERROR: Recon id '|| var_recon_id ||' does not exist''', 
				var_recon_id, 
				null::text
			);
			return;
	end if;

	/*
	 * Check if recon is not signed-off
	 */
	
	if
		not exists(SELECT 1 FROM fileservice.recon r WHERE r.recon_id = var_recon_id AND NOT r.sign_off)
		then 
			-- Log Script
			call fileService.sp_log_entry(
									NULL::integer,
									'''ERROR: Recon is signed-off'''::text,
									var_recon_id,
									NULL::text
									);
			return;		
	end if;

	/*
	 * Modify view name as per Journal Entry flag
	 */
	IF (var_je)
	THEN 
		var_name = 'je_'||var_name;
		var_name_table = var_name;
	ELSE
		var_name_table = var_name;
	END IF;

--	raise notice '%',var_name_table;
	select now()::text into var_tmstp;
	raise notice '2: %', var_tmstp;

	-- Drop the tmp table
	execute 'drop table if exists '||s_schema_name||'.bridge_'||var_name||'_tmp cascade;';

	/*
	 * Create the bridge view script
	 */
	select
	'select case when ''kickout'' in ('||string_agg(dim_name, ', ')||') then true else false end as kickout, * from '||s_schema_name||'.bridge_'||var_name||'_tmp' as stmt
	into var_view_script
	from
		(
		select 
			concat('"bridge-', rd1.dimension, '-', rd2.dimension, '"')::text as dim_name
		from fileservice.recon r
		inner join fileservice.recon_dimensions rd1
		on r.app1_id = rd1.recon_app_id
		and rd1.is_active 
		inner join fileservice.recon_dimensions rd2
		on rd1.turn_on_define_order = rd2.turn_on_define_order
		and r.app2_id = rd2.recon_app_id
		and rd2.is_active 
		inner join fileservice.recon_bridge_mapping rbm 
		on r.recon_id = rbm.recon_id
		and not rbm.is_deleted 
		and not rbm.is_invalid 
		and (rd1.dimensions_id = rbm.dim_id or rd2.dimensions_id = rbm.dim_id)
		where r.recon_id = var_recon_id-------------------------------------------------------------------------------------------------------------------------------------
		group by
			rd1.dimensions_id ,
			rd2.dimensions_id
		order by
			rd1.turn_on_define_order 
		)q1;

	select now()::text into var_tmstp;
	raise notice '3: %', var_tmstp;

	/*
	 * Run loop 2 times for var_app_type 0 and 1.
	 */
	<<app_loop>>
	loop 
		exit app_loop when var_app_type > 1;

--		select 'select record_id, app_id, '||string_agg(col,', ')||', "AMOUNT"::decimal, case when app_id%2=0 then -1 else 1 end *'||string_agg(flip_sign,'')||'*"AMOUNT"::decimal as sign_reversal_amount, file_name, file_id, '||string_agg(com,',')||case when var_je then ', je_comment' else ', '''' je_comment'end as col_list
		select 'select app_id, '||string_agg(col,', ')||', "AMOUNT"::decimal, case when app_id%2=0 then -1 else 1 end *'||string_agg(flip_sign,'')||'*"AMOUNT"::decimal as sign_reversal_amount, file_name, file_id, '||string_agg(com,',')||case when var_je then ', je_comment' else ', '''' je_comment'end as col_list
		into var_script
		from (
			select
			string_agg(src_col||', '||bridge_col,', ') as col,
			string_agg(dim_comment,'||''^''||')||'||''^''||'||string_agg(bridge_comment,'||''^''||')||' as user_comment' as com,
			string_agg(flip_sign,'*') as flip_sign
			from (
				select
				distinct
				turn_on_define_order,
				'"'||dim_name||'"' as src_col,
				'case '||string_agg(bridge_col,'') over (partition by dim_name)|| ' else ''kickout'' end as "bridge-'||dim_name_table||'"' as bridge_col,
				'case '||string_agg(dim_comment,'') over (partition by dim_name)||' else '''' end ' as dim_comment,
				'case '||string_agg(bridge_comment,'') over (partition by dim_name)||' else '''' end ' as bridge_comment,
				'case '||string_agg(flip_sign,'') over (partition by dim_name)||' else 1 end ' as flip_sign
				from(
					select 
					distinct
					turn_on_define_order
					,dim_name as dim_name
					,dim_name_table as dim_name_table
					,rbm_case_stmt1||'"'||dim_name||'"'||rbm_case_stmt2||' case '||string_agg(case_stmt_new,' ') over (partition by turn_on_define_order, rbm_case_stmt2)||' else ''kickout'' end ' as bridge_col
					,rbm_case_stmt1||'"'||dim_name||'"'||rbm_case_stmt2||' case '||string_agg(dim_comment,' ') over (partition by turn_on_define_order, rbm_case_stmt2)||' else '''' end ' as dim_comment
					,rbm_case_stmt1||'"'||dim_name||'"'||rbm_case_stmt2||' case '||string_agg(bridge_comment,' ') over (partition by turn_on_define_order, rbm_case_stmt2)||' else '''' end ' as bridge_comment
					,rbm_case_stmt1||'"'||dim_name||'"'||rbm_case_stmt2||' case '||string_agg(flip_sign,' ') over (partition by turn_on_define_order, rbm_case_stmt2)||' else 1 end ' as flip_sign
					from (
						select
							distinct
							rd.turn_on_define_order
							, dim_name as dim_name
							, dim_name_table as dim_name_table
							, rbm.app_id as app_id
							, rbm_case_stmt1
							, rbm_case_stmt2
							, dim_logic || rbm.rbm_bridge as case_stmt_new
							, dim_logic || rbm.rbm_dim_comment as dim_comment
							, dim_logic || rbm.rbm_bridge_comment as bridge_comment
							, case
								when var_je then 
									dim_logic || rbm.flip
								else 
									dim_logic || rbm.flip_n
							end as flip_sign
							from fileservice.recon r
							inner join (
								select
									case 
										when var_app_type=0-----------------------------------------------------------------------------------
										then rd1i.recon_app_id
										else rd2.recon_app_id
									end as recon_app1_id
									, case 
										when var_app_type=0-----------------------------------------------------------------------------------
										then rd2.recon_app_id
										else rd1i.recon_app_id
									end as recon_app2_id
									, rd1i.turn_on_define_order::int
									, rd1i.dimensions_id as dimensions1_id
									, rd2.dimensions_id as dimensions2_id
									, rd1i.dimension as dim_name
									, case
										when var_app_type=0-----------------------------------------------------------------------------------
										then rd1i.dimension || '-' || rd2.dimension
										else rd2.dimension || '-' || rd1i.dimension
									end as dim_name_table
									, ' when coalesce(trim(lower("' || rd1i.dimension /*|| '-' || rd2.dimension*/ || '")),''null'')=coalesce(trim(lower(''' as dim_logic
								from
									fileservice.recon_dimensions rd1i
								inner join (
									select
										rd2i.recon_app_id
										, rd2i.turn_on_define_order::int
										, rd2i.dimensions_id
										, rd2i.dimension
									from
										fileservice.recon_dimensions rd2i
									where
										rd2i.is_active
										and rd2i.turn_on_define_order <> '2'
										and rd2i.recon_id=var_recon_id----------------------------------------------------------------------------------------------
										and not rd2i.is_deleted
										and rd2i.app_type::int <> var_app_type-----------------------------------------------------------------------------------
--								and rd2i.recon_app_id = 471 
								) rd2 
								on rd1i.turn_on_define_order::int = rd2.turn_on_define_order
								where
									rd1i.is_active
									and rd1i.turn_on_define_order <> '2'
									and rd1i.recon_id=var_recon_id----------------------------------------------------------------------------------------------
									and not rd1i.is_deleted
--							and rd1i.recon_app_id = 470
									and rd1i.app_type::int = var_app_type-----------------------------------------------------------------------------------
							) rd
							on (r.app1_id = rd.recon_app1_id or r.app2_id = rd.recon_app2_id)
							inner join (
								select
									rbmi.recon_id
									, rbmi.app_id
									, rbmi.dim_id
									, rbmi.source_member || ''')),''null'') then ''' || rbmi.bridge_member || '''' as rbm_bridge
									, rbmi.source_member || ''')),''null'') then ''' || coalesce(rbmi.dim_comment, '') || '''' as rbm_dim_comment
									, rbmi.source_member || ''')),''null'') then ''' || coalesce(rbmi.bridge_comment, '') || '''' as rbm_bridge_comment
									, rbmi.source_member || ''')),''null'') and ''' || rbmi.flip_sign || '''::boolean then 1' as flip
									, rbmi.source_member || ''')),''null'') and ''' || rbmi.flip_sign || '''::boolean then -1' as flip_n
									, ' when trim(lower(left(' as rbm_case_stmt1
									,',1)))=''' || lower(left(rbmi.source_member, 1))|| ''' then ' as rbm_case_stmt2
								from
									fileservice.recon_bridge_mapping rbmi
								where
									not rbmi.is_deleted
									and not rbmi.is_invalid
									and rbmi.recon_id = var_recon_id----------------------------------------------------------------------------------------------
									and rbmi.app_type::int = var_app_type----------------------------------------------------------------------------------------------
							) rbm 
							on r.recon_id = rbm.recon_id
							and (rd.dimensions1_id = rbm.dim_id or rd.dimensions2_id = rbm.dim_id)
							and (rbm.app_id = r.app1_id or rbm.app_id = r.app2_id)
							where r.recon_id = var_recon_id----------------------------------------------------------------------------------------------
							order by turn_on_define_order
					) q1
					order by turn_on_define_order
				) q2
				order by turn_on_define_order
			) q3
		) q4;

	/*
	 * Execute the create bridge view script
	 * create the scripts without using the var_script generated query i.e. without using the from table clause.
	 */
	select now()::text into var_tmstp;
	raise notice '4-% %', var_app_type, var_tmstp; 	
	raise notice '%', var_script;
		if var_je
		then
			if var_app_type=0
			then 
				execute 'select count(*) from '||s_schema_name||'.'||var_name||'_'||var_app1_id into var_rec_count;
--				execute 'create table if not exists bridge_'||var_name||'_tmp as ('||var_script||' from '||s_schema_name||'.'||var_name||'_'||var_app1_id||' where 1=2)q2;';
			else
				execute 'select count(*) from '||s_schema_name||'.'||var_name||'_'||var_app2_id into var_rec_count;
--				execute 'create table if not exists bridge_'||var_name||'_tmp as ('||var_script||' from '||s_schema_name||'.'||var_name||'_'||var_app2_id||' where 1=2)q2;';
			end if;
		
		else
			if var_app_type=0
			then
				execute 'select count(*) from '||s_schema_name||'.app_'||var_name||'_'||var_app1_id into var_rec_count;
--				execute 'create table if not exists bridge_'||var_name||'_tmp as ('||var_script||' from '||s_schema_name||'.app_'||var_name||'_'||var_app1_id||' where 1=2);';
			else 
				execute 'select count(*) from '||s_schema_name||'.app_'||var_name||'_'||var_app2_id into var_rec_count;
--				execute 'create table if not exists bridge_'||var_name||'_tmp as ('||var_script||' from '||s_schema_name||'.app_'||var_name||'_'||var_app2_id||' where 1=2);';
			end if;		
		end if;
	
		select 'create table if not exists '||s_schema_name||'.bridge_'||var_name||'_tmp ( app_id int not null, '||string_agg('"'||dim_name||', "bridge-'||dim_name,',')||', "AMOUNT-AMOUNT" decimal, sign_reversal_amount decimal, file_name varchar NULL, file_id int NULL, user_comment varchar NULL, je_comment varchar NULL) tablespace tbsp_data;'
		into var_script2
		from (
			select ''||rd1.dimension||'-'||rd2.dimension||'" varchar NULL' as dim_name, rd1.recon_id, rd1.recon_app_id
			from fileservice.recon_dimensions rd1
			inner join (
				select rd2.turn_on_define_order,rd2.recon_id, rd2.dimension
				from fileservice.recon_dimensions rd2
				where rd2.recon_id = var_recon_id
				and rd2.app_type::int <> var_app_type
				and not rd2.is_deleted 
				and rd2.is_active 
			) rd2
			on rd1.turn_on_define_order=rd2.turn_on_define_order
			and rd1.recon_id = rd2.recon_id
			where rd1.recon_id = var_recon_id
			and rd1.turn_on_define_order <> '2'
			and not rd1.is_deleted
			and rd1.is_active
			and rd1.app_type::int = var_app_type
			order by rd1.turn_on_define_order::int
		) q
		group by q.recon_app_id;
	
--		raise notice '%', var_script2;
		execute var_script2;
	
		if var_je
		then
			if var_app_type=0
			then
				execute 'insert into '||s_schema_name||'.bridge_'||var_name||'_tmp ('||var_script||' from '||s_schema_name||'.'||var_name||'_'||var_app1_id||');';
			else
				execute 'insert into '||s_schema_name||'.bridge_'||var_name||'_tmp ('||var_script||' from '||s_schema_name||'.'||var_name||'_'||var_app2_id||');';
			end if;
		else
			if var_app_type=0
			then
				execute 'insert into '||s_schema_name||'.bridge_'||var_name||'_tmp ('||var_script||' from '||s_schema_name||'.app_'||var_name||'_'||var_app1_id||');';
			else 
				execute 'insert into '||s_schema_name||'.bridge_'||var_name||'_tmp ('||var_script||' from '||s_schema_name||'.app_'||var_name||'_'||var_app2_id||');';
			end if;
		end if;
	
		var_count = 0;
		
		select now()::text into var_tmstp;
		raise notice '5-% %', var_app_type, var_tmstp; 	
	
		var_app_type = var_app_type+1;
	
		--	 Log Script
		call fileService.sp_log_entry(
									null::integer,
									'''Bridge tmp'|| var_name ||':'|| var_app_type ||' loaded'''::text,
									var_recon_id::integer,
									var_name::text
									);

	end loop app_loop;

	/*
	 * Bridge Kickouts view
	 */

	var_view_script = 'drop view if exists '||s_schema_name||'.view_bridge_'||var_name||' cascade; create view '||s_schema_name||'.view_bridge_'||var_name||' as (select * from ('||var_view_script||') q);';
	execute var_view_script;	
	var_view_script = 'drop view if exists '||s_schema_name||'.view_bridge_'||var_name||'_kickout cascade; create view '||s_schema_name||'.view_bridge_'||var_name||'_kickout as (select * from '||s_schema_name||'.view_bridge_'||var_name||' where kickout);';
	execute var_view_script;

	var_name = 'view_bridge_'||var_name||'_kickout';

	--	 Log Script
	call fileService.sp_log_entry(
								null::integer,
								'''Bridge view '|| var_name || ' created'''::text,
								var_recon_id::integer,
								var_name::text
								);
	
	/*
	 * If no kickouts convert the bridge view into a table for further process
	 */
	execute 'select not exists (select * from fileservice.'||var_name||' limit 1);' into var_kickout;

	select now()::text into var_tmstp;
	raise notice '6: %', var_tmstp; 	

	if var_kickout
		then
		var_script = 'drop table if exists '||s_schema_name||'.bridge_'||var_name_table||' cascade;';
		var_script = var_script || ' alter table '||s_schema_name||'.bridge_'||var_name_table||'_tmp RENAME TO bridge_'||var_name_table||';';
		execute var_script;		
	
		--	 Log Script		
		call fileService.sp_log_entry(
									null::integer,
									'''Bridge table bridge_'|| var_name_table || ' created'''::text,
									var_recon_id::integer,
									var_name_table::text
									);
		
		update fileservice.recon r
		set status = 'Bridged'
		where r.recon_id = var_recon_id;
	else
	
		call fileService.sp_log_entry(
									null::integer,
									'''Kickouts exist for view view_'|| var_name_table || '.'''::text,
									var_recon_id::integer,
									var_name_table::text
									);
		
		update fileservice.recon r
		set status = 'Kickouts'
		where r.recon_id = var_recon_id;
	end if;
							
end;
$procedure$
;

-- Permissions

ALTER PROCEDURE fileservice.sp_create_recon_run_bridge_table2(int4, bool) OWNER TO "user_dataRecon_file";
GRANT ALL ON PROCEDURE fileservice.sp_create_recon_run_bridge_table2(int4, bool) TO public;
GRANT ALL ON PROCEDURE fileservice.sp_create_recon_run_bridge_table2(int4, bool) TO postgres;
GRANT ALL ON PROCEDURE fileservice.sp_create_recon_run_bridge_table2(int4, bool) TO "user_dataRecon_file";
