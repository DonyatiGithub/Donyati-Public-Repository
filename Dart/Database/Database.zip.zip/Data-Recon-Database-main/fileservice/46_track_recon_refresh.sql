-- Sequence for 'track recon refresh' Table
DROP SEQUENCE IF EXISTS fileservice.track_recon_refresh_id_seq CASCADE;
CREATE SEQUENCE fileservice.track_recon_refresh_id_seq
    INCREMENT 1
    START 1
    MINVALUE 1
    MAXVALUE 9223372036854775807
    CACHE 1;

-- Altering the sequence by changing the ownership   
ALTER SEQUENCE fileservice.track_recon_refresh_id_seq OWNER TO "user_dataRecon_file";

-- Granting 'ALL' the permissions of the sequence to the user 'postgres'
GRANT ALL ON SEQUENCE fileservice.track_recon_refresh_id_seq TO postgres;

-- Granting 'ALL' the permissions of the sequence to the 'user_dataRecon_file'
GRANT ALL ON SEQUENCE fileservice.track_recon_refresh_id_seq TO "user_dataRecon_file";

-- Table for 'update_notification'
DROP TABLE IF EXISTS fileservice.track_recon_refresh CASCADE;
CREATE TABLE IF NOT EXISTS fileservice.track_recon_refresh (
    track_id BIGINT NOT NULL DEFAULT nextval('fileservice.track_recon_refresh_id_seq'::regclass),
    
	recon_id BIGINT,
    
    -- To store the time stamp of the bridge table sp.
    bridge_timestamp TIMESTAMP WITHOUT TIME ZONE,
   
    -- To store the time stamp of the je bridge table sp.
    je_bridge_timestamp TIMESTAMP WITHOUT TIME ZONE,
    
    -- To store the time stamp of the report sp.
    report_timestamp TIMESTAMP WITHOUT TIME ZONE, 
    
    -- To store the time stamp of the report sp.
    je_report_timestamp TIMESTAMP WITHOUT TIME ZONE,
    
    -- To store the time stamp of transformation sp.
    transformation_timestamp TIMESTAMP WITHOUT TIME ZONE,
    CONSTRAINT track_id PRIMARY KEY (track_id)
) TABLESPACE tbsp_meta;

-- Altering the table by changing the ownership
ALTER TABLE fileservice.track_recon_refresh OWNER TO "user_dataRecon_file";

-- Granting 'ALL' the permissions of the table to the user 'postgres'
GRANT ALL ON TABLE fileservice.track_recon_refresh TO postgres;

-- Granting 'DELETE, UPDATE, INSERT, SELECT' permissions of the table to the 'user_dataRecon_file'
GRANT DELETE, UPDATE, INSERT, SELECT ON TABLE fileservice.track_recon_refresh TO "user_dataRecon_file";