CREATE OR REPLACE PROCEDURE fileservice.sp_import_recon(file_id integer, user_name varchar)
 LANGUAGE plpgsql
AS $procedure$
DECLARE

s_schema_name text := 'fileservice';
v_xml_nulls boolean := TRUE;
v_xml_table_forest boolean := FALSE;
v_sequence bigint := 9223372036854775807;

v_file_id integer := file_id;
var_user_name varchar := user_name;

var_recon_id integer := 0;
var_file_path varchar := '';
var_file_name varchar := '';
v_app1_id integer := 0;
v_app2_id integer := 0;
v_query varchar := '';

var_rt_record record;

BEGIN
	/*
	 * Steps of Execution:
	 * 
	 * 1) Check if file_id exists
	 * 2) Reset surrogate key sequence
	 * 3) Empty recon_xml table
	 * 4) Copy file to recon_xml table
	 * 5) Based on XML tag, insert into appropriate recon table
	 * 
	 */

	/* 
	 * Check if the recon exists in the recon table
	 */
	if
		not exists(select 1 from fileservice.track_file_load_status tfls where tfls.file_id=v_file_id)
		then
			-- Log Script
			call fileService.sp_log_entry(
									0::integer,
									'''ERROR: File ID '||v_file_id||' entry not present in table'''::text,
									0::integer,
									'no_table'::text
									);
			return;		
	end if;
	
	/*
	 * Reset surrogate key sequence
	 * Set to max possible value so the sequence cycles back
	 * 
	 */
	begin
	    execute 'select setval(''fileservice.recon_table_skey''::regclass,'||v_sequence||')';
	exception
	    when others then
		call fileservice.sp_log_entry(
			null::integer, 
			'''Error: '|| SQLERRM ||' ''', 
			var_recon_id::integer, 
			null::text
		);
	end;



	/*
	 * Empty recon_xml table
	 * 
	 */
	delete from fileservice.recon_xml;
	
	
	/*
	 * Import file to table
	 * 
	 */
	SELECT file_location, file_name 
	INTO var_file_path,var_file_name
	FROM fileservice.track_file_load_status tfls
	where tfls.file_id = v_file_id;
    
	begin
	    execute 'copy fileservice.recon_xml(xml_data) from '''||var_file_path||var_file_name||'''';
	exception
	    when others then
		call fileservice.sp_log_entry(
			null::integer, 
			'''Error: '|| SQLERRM ||' ''', 
			var_recon_id::integer, 
			null::text
		);
	end;


	--	Log Script
	call fileService.sp_log_entry(
								0::integer,
								'''File ID '||v_file_id||' imported successfully'''::text,
								0::integer,
								'recon_xml'
								);
							
	/*
	 * Based on XML tags, load data to tables
	 */
--	Recon Table
	v_query = 'insert into fileservice.recon("name",variance_threshold,description,status,is_deleted,created_by,created_date,last_modified_by,last_modified_date)';
	v_query = v_query||' select 
		unnest(xpath(''//name/text()'',xmlparse(document xml_data)))::text as "name"
		,unnest(xpath(''//variance_threshold/text()'',xmlparse(document xml_data)))::text::numeric as variance_threshold
		,unnest(xpath(''//description/text()'',xmlparse(document xml_data)))::text as description
		,(xpath(''//status/text()'',xmlparse(document xml_data)))[1]::text as status
		,false as is_deleted 
		,'''||var_user_name||''' as created_by
		,now()::timestamp as created_date
		,'''||var_user_name||''' as last_modified_by
		,now()::timestamp as last_modified_date
	from (
		select xml_data
		from fileservice.recon_xml
		where xml_data like ''<recon>%''
	) q
	returning recon_id';

--	After inserting to recon table, get the recon_id
    begin
	    execute v_query into var_recon_id;
	exception
	    when others then
		call fileservice.sp_log_entry(
			null::integer, 
			'''Error: '|| SQLERRM ||' ''', 
			var_recon_id::integer, 
			null::text
		);
	end;

	--	Log Script
	call fileService.sp_log_entry(
								null::integer,
								'''Recon ID '||var_recon_id||' imported successfully'''::text,
								var_recon_id::integer,
								'recon'
								);

	update fileservice.track_file_load_status tfls
	set recon_id = var_recon_id
	where tfls.file_id = v_file_id;
							
--	Recon Applications Table
	v_query = 'insert into fileservice.recon_applications(app_name, import_type, import_delimiter,currency_symbol, currency_delimiter, has_header, url, "cube",username, "password",recon_id)
	select 
		unnest(xpath(''//app_name/text()'',xmlparse(document xml_data)))::text as app_name
		,unnest(xpath(''//import_type/text()'',xmlparse(document xml_data)))::text::numeric as import_type
		,unnest(xpath(''//import_delimiter/text()'',xmlparse(document xml_data)))::text as import_delimiter
		,replace(unnest(xpath(''//currency_symbol/text()'',xmlparse(document xml_data)))::text,''&amp;'',''&'') as currency_symbol
		,unnest(xpath(''//currency_delimiter/text()'',xmlparse(document xml_data)))::text as currency_delimiter
		,unnest(xpath(''//has_header/text()'',xmlparse(document xml_data)))::text::boolean as has_header
		,unnest(xpath(''//url/text()'',xmlparse(document xml_data)))::text as url
		,unnest(xpath(''//cube/text()'',xmlparse(document xml_data)))::text as "cube"
		,unnest(xpath(''//username/text()'',xmlparse(document xml_data)))::text as username
		,unnest(xpath(''//password/text()'',xmlparse(document xml_data)))::text as "password"
		,'||var_recon_id||' as recon_id
	from (
		select xml_data
		from fileservice.recon_xml
		where xml_data like ''<recon_application>%''
	) q';
--	Excute the insert query
    
	begin
	    execute v_query;
    exception
	    when others then
		call fileservice.sp_log_entry(
			null::integer, 
			'''Error: '|| SQLERRM ||' ''', 
			var_recon_id::integer, 
			null::text
		);
	end;

--	Update recon table with new app IDs
	select recon_app_id
	into v_app1_id
	from fileservice.recon_applications ra
	where ra.recon_id = var_recon_id
	and ra.app_name = '0';

	select recon_app_id
	into v_app2_id
	from fileservice.recon_applications ra
	where ra.recon_id = var_recon_id
	and ra.app_name = '1';

	update fileservice.recon
	set app1_id = v_app1_id,
	app2_id = v_app2_id
	where recon_id = var_recon_id;

	--	Log Script
	call fileService.sp_log_entry(
								null::integer,
								'''Recon Application for recon id '||var_recon_id||' imported successfully'''::text,
								var_recon_id::integer,
								'recon_applications'
								);

--	Recon Dimensions
	v_query = 'insert into fileservice.recon_dimensions(turn_on_define_order, dimension, dim_in_file,type_field, app_type, is_active, in_recon, recon_id, recon_app_id)
	select
	turn_on_define_order, dimension, dim_in_file,type_field, app_type, coalesce(is_active,false) as is_active, coalesce(in_recon,false) as in_recon, recon_id, 
	case
		when app_type=''0''
		then '||v_app1_id||'
		else '||v_app2_id||'
	end as recon_app_id
	from (
		select
		unnest(xpath(''//turn_on_define_order/text()'',xmlparse(document xml_data)))::text as turn_on_define_order
		,unnest(xpath(''//dimension/text()'',xmlparse(document xml_data)))::text as dimension
		,unnest(xpath(''//dim_in_file/text()'',xmlparse(document xml_data)))::text as dim_in_file
		,unnest(xpath(''//type_field/text()'',xmlparse(document xml_data)))::text as type_field
		,unnest(xpath(''//app_type/text()'',xmlparse(document xml_data)))::text as app_type
		,unnest(xpath(''//is_active/text()'',xmlparse(document xml_data)))::text::boolean as is_active
		,unnest(xpath(''//in_recon/text()'',xmlparse(document xml_data)))::text::boolean as in_recon
		,'||var_recon_id||' as recon_id
		from (
			select xml_data
			from fileservice.recon_xml
			where xml_data like ''<recon_dimensions>%''
		) q
	) q2';
    
	begin
	    execute v_query;
	exception
	    when others then
		call fileservice.sp_log_entry(
			null::integer,
			'''Error: '|| SQLERRM ||' ''', 
			var_recon_id::integer,
			null::text
		);
	end;

	--	Log Script
	call fileService.sp_log_entry(
								null::integer,
								'''Recon dimensions imported successfully'''::text,
								var_recon_id::integer,
								'recon_dimensions'
								);

--	Recon Bridge Mapping
	v_query = 'insert into fileservice.recon_bridge_mapping(flip_sign,source_member,bridge_member,is_invalid,recon_id,app_id,app_type,dim_id,is_deleted)
	select
	coalesce(flip_sign,false) as flip_sign, source_member, bridge_member,coalesce(is_invalid,false) as is_invalid, q1.recon_id
	,case
		when q1.app_type=''0''
		then '||v_app1_id||'
		else '||v_app2_id||'
	end as app_id
	,q1.app_type
	,rd.dimensions_id as dim_id
	, FALSE as is_deleted
	from (
		select
		unnest(xpath(''//flip_sign/text()'',xmlparse(document xml_data)))::text::boolean as flip_sign
		,unnest(xpath(''//app_type/text()'',xmlparse(document xml_data)))::text as app_type
		,unnest(xpath(''//source_member/text()'',xmlparse(document xml_data)))::text as source_member
		,unnest(xpath(''//bridge_member/text()'',xmlparse(document xml_data)))::text as bridge_member
		,unnest(xpath(''//is_invalid/text()'',xmlparse(document xml_data)))::text::boolean as is_invalid
		,unnest(xpath(''//dimension/text()'',xmlparse(document xml_data)))::text as dimension
		,'||var_recon_id||' as recon_id	
		from (
			select xml_data
			from fileservice.recon_xml
			where xml_data like ''<recon_bridge_mapping>%''
		) q
	)q1
	inner join fileservice.recon_dimensions rd
	on rd.recon_id = q1.recon_id
	and rd.recon_app_id = case when q1.app_type=''0'' then '||v_app1_id||' else '||v_app2_id||' end
	and rd.dimension = q1.dimension
	and rd.app_type = q1.app_type
	and rd.is_active 
	and not coalesce(rd.is_deleted,false)
	order by source_member, dimensions_id, q1.app_type';
    
	begin
	    execute v_query;
	exception
	    when others then
		call fileservice.sp_log_entry(
			null::integer, 
			'''Error: '|| SQLERRM ||' ''', 
			var_recon_id::integer,
			null::text
		);
	end;

	--	Log Script
	call fileService.sp_log_entry(
								null::integer,
								'''Recon Bridge Mapping imported successfully'''::text,
								var_recon_id::integer,
								'recon_bridge_mapping'
								);

--	Recon Transformation
	v_query = 'insert into fileservice.recon_transformation (tgt_concat_dimid,tgt_concat_dimname,bridge_concat_dim_name,concat_delimiter,apply_all_members,recon_id,app_id,dim_id)
	select
	tgt_concat_dimid, tgt_concat_dimname, bridge_concat_dim_name,concat_delimiter,coalesce(apply_all_members,false) as apply_all_members,q1.recon_id
	,case
		when q1.app_type=''0''
		then '||v_app1_id||'
		else '||v_app2_id||'
	end as app_id
	,rd.dimensions_id as dim_id
	from (
		select
		unnest(xpath(''//tgt_concat_dimid/text()'',xmlparse(document xml_data)))::text as tgt_concat_dimid----------------------------------Need to correct the dimid that is populated here
		,replace(unnest(xpath(''//tgt_concat_dimname/text()'',xmlparse(document xml_data)))::text,''"'',''\"'') as tgt_concat_dimname
		,unnest(xpath(''//bridge_concat_dim_name/text()'',xmlparse(document xml_data)))::text as bridge_concat_dim_name
		,unnest(xpath(''//concat_delimiter/text()'',xmlparse(document xml_data)))::text as concat_delimiter
		,unnest(xpath(''//apply_all_members/text()'',xmlparse(document xml_data)))::text::boolean as apply_all_members
		,unnest(xpath(''//app_type/text()'',xmlparse(document xml_data)))::text as app_type
		,unnest(xpath(''//dimension/text()'',xmlparse(document xml_data)))::text as dimension
		,'||var_recon_id||' as recon_id	
		from (
			select xml_data
			from fileservice.recon_xml
			where xml_data like ''<recon_transformation>%''
		) q
	)q1
	inner join fileservice.recon_dimensions rd
	on rd.recon_id = q1.recon_id
	and rd.recon_app_id = case when q1.app_type=''0'' then '||v_app1_id||' else '||v_app2_id||' end
	and rd.dimension = q1.dimension
	and rd.app_type = q1.app_type
	and rd.is_active 
	and not coalesce(rd.is_deleted,false)
	order by rd.dimensions_id, q1.app_type::int';

	begin
	    execute v_query;
	exception
	    when others then
		call fileservice.sp_log_entry(
			null::integer,
			'''Error: '|| SQLERRM ||' ''', 
			var_recon_id::integer,
			null::text
		);
	end;

	--	Log Script
	call fileService.sp_log_entry(
								null::integer,
								'''Recon Tranformation imported successfully'''::text,
								var_recon_id::integer,
								'recon_transformation'
								);

--	Recon Transformation Override
	v_query = 'insert into fileservice.recon_transformation_override (source_sync,target_sync,recon_id,flip_sign,app_id,tfn_id)
	select
	source_sync, target_sync, q1.recon_id,coalesce(flip_sign,false) as flip_sign
	,case
		when q1.app_type=''0''
		then '||v_app1_id||'
		else '||v_app2_id||'
	end as app_id
	,rt.id as tfn_id
	from (
		select
		unnest(xpath(''//source_sync/text()'',xmlparse(document xml_data)))::text as source_sync
		,unnest(xpath(''//target_sync/text()'',xmlparse(document xml_data)))::text as target_sync
		,unnest(xpath(''//app_type/text()'',xmlparse(document xml_data)))::text as app_type
		,unnest(xpath(''//dimension/text()'',xmlparse(document xml_data)))::text as dimension
		,unnest(xpath(''//flip_sign/text()'',xmlparse(document xml_data)))::text::boolean as flip_sign
		,'||var_recon_id||' as recon_id	
		from (
			select xml_data
			from fileservice.recon_xml
			where xml_data like ''<recon_transformation_override>%''
		) q
	)q1
	inner join fileservice.recon_dimensions rd
	on rd.recon_id = q1.recon_id
	and rd.recon_app_id = case when q1.app_type=''0'' then '||v_app1_id||' else '||v_app2_id||' end
	and rd.dimension = q1.dimension
	and rd.app_type = q1.app_type
	and rd.is_active 
	and not coalesce(rd.is_deleted,false) 
	inner join fileservice.recon_transformation rt 
	on rt.recon_id = q1.recon_id
	and rt.app_id = case when q1.app_type=''0'' then '||v_app1_id||' else '||v_app2_id||' end
	and rt.dim_id = rd.dimensions_id 
	order by rd.dimensions_id, q1.app_type::int';

	begin
	    execute v_query;
	exception
	    when others then
		call fileservice.sp_log_entry(
			null::integer,
			'''Error: '|| SQLERRM ||' ''', 
			var_recon_id::integer,
			null::text
		);
	end;
	
	--	Log Script
	call fileService.sp_log_entry(
								null::integer,
								'''Recon Tranformation Override imported successfully'''::text,
								var_recon_id::integer,
								'recon_transformation_override'
								);

	update fileservice.track_file_load_status tfls
	set status = 'Completed'
	where tfls.file_id = v_file_id;
							
end;
$procedure$
;

-- Permissions

ALTER PROCEDURE fileservice.sp_import_recon(int4, varchar) OWNER TO "user_dataRecon_file";
GRANT ALL ON PROCEDURE fileservice.sp_import_recon(int4, varchar) TO public;
GRANT ALL ON PROCEDURE fileservice.sp_import_recon(int4, varchar) TO postgres;
GRANT ALL ON PROCEDURE fileservice.sp_import_recon(int4, varchar) TO "user_dataRecon_file";
