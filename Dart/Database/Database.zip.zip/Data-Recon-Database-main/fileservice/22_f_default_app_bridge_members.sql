-- DROP FUNCTION fileservice.f_default_app_bridge_members(int4);

CREATE OR REPLACE FUNCTION fileservice.f_default_app_bridge_members(recon_app_id integer)
 RETURNS integer
 LANGUAGE plpgsql
AS $function$
DECLARE
    var_app_id integer := recon_app_id;
    s_schema_name varchar := 'fileservice';
    var_recon_id integer;
    var_dim_id integer;
    var_table_rec RECORD;
    var_col_name RECORD;
    var_query text := '';
    var_insert_query text := '';
    var_app_id_record RECORD;
BEGIN
    /*
     * Check if the application exists. If yes, get the app details
     */
    IF NOT EXISTS(SELECT 1 FROM fileservice.recon_applications ra WHERE ra.recon_app_id = var_app_id) THEN
        -- Log Script
        CALL fileService.sp_log_entry(
            var_app_id::integer,
            '''ERROR: Application does not exist'''::text
        );
        RETURN 1;        
    END IF;

    IF NOT EXISTS(SELECT 1 FROM fileservice.recon r WHERE r.recon_id IN (SELECT ra.recon_id FROM fileservice.recon_applications ra WHERE ra.recon_app_id = var_app_id) AND NOT r.sign_off) THEN
        -- Log Script
        CALL fileService.sp_log_entry(
            var_app_id::integer,
            '''ERROR: Recon is signed-off'''::text
        );
        RETURN 1;        
    END IF;

    IF EXISTS(SELECT rd.recon_app_id FROM fileservice.recon_applications rd WHERE rd.recon_app_id = var_app_id AND NOT is_deleted) THEN
        SELECT ra.recon_app_id, ra.app_name INTO var_app_id_record FROM fileservice.recon_applications ra WHERE ra.recon_app_id = var_app_id;    
        SELECT ra.recon_id INTO var_recon_id FROM fileservice.recon_applications ra WHERE ra.recon_app_id = var_app_id;
        
        /*
         * Soft delete all the existing recon_bridge_members for given recon_id
         */
        UPDATE fileservice.recon_bridge_mapping rbm
        SET is_deleted = TRUE 
        WHERE rbm.app_id = var_app_id;

        /*
         * Retrieve active recon_app_id
         */
        FOR var_table_rec IN
            SELECT column_name, 'app_' || var_recon_id || '_' || var_app_id_record.recon_app_id AS var_table_name
            FROM information_schema.columns
            WHERE table_schema = s_schema_name
            AND column_name NOT IN ('app_id', 'AMOUNT', 'file_name', 'file_id', 'record_id')
            AND table_name = 'app_' || var_recon_id || '_' || var_app_id_record.recon_app_id
        LOOP
            /*
             * Get dimension id for the column_name
             */
            SELECT rd.dimensions_id
            INTO var_dim_id
            FROM fileservice.recon_dimensions rd
            WHERE rd.recon_id = var_recon_id
            AND rd.recon_app_id = var_app_id_record.recon_app_id
            AND lower(dimension) = lower(var_table_rec.column_name);

            /*
             * For each column name, prepare 'select distinct from table' query
             */
            var_query = 'SELECT DISTINCT "' || var_table_rec.column_name || '" AS col_name FROM ' || s_schema_name || '.' || var_table_rec.var_table_name || ';';
            FOR var_col_name IN EXECUTE var_query
            LOOP
                /*
                 * Insert source/bridge member if value does not exist
                 */
                IF NOT EXISTS(
                    SELECT rbm.recon_id
                    FROM fileservice.recon_bridge_mapping rbm
                    WHERE rbm.recon_id = var_recon_id 
                    AND rbm.app_id = var_app_id_record.recon_app_id 
                    AND COALESCE(rbm.source_member, 'null') = COALESCE(var_col_name.col_name, 'null')
                    AND rbm.app_type <> var_app_id_record.app_name
                    AND NOT rbm.is_deleted
                ) THEN
                	RAISE NOTICE 'inside main if';
                    var_insert_query = 'INSERT INTO fileservice.recon_bridge_mapping (recon_id, app_id, dim_id, flip_sign, app_type, source_member, bridge_member, is_deleted, is_invalid)';
                    var_insert_query = var_insert_query || E'\nVALUES(' || var_recon_id || ',' || var_app_id_record.recon_app_id || ', ' || var_dim_id || ', false,''' || var_app_id_record.app_name || ''',''' || COALESCE(var_col_name.col_name, 'null') || ''', ''' || COALESCE(var_col_name.col_name, 'null') || ''', false, false);';
                   -- RAISE NOTICE 'insert query === %', var_insert_query;
                    EXECUTE var_insert_query;
                END IF;
            END LOOP;    
        END LOOP;
    END IF;
    RETURN 1;
END;
$function$
;
