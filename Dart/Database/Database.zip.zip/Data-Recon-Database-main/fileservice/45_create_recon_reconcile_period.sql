-- SEQUENCE: fileservice.recon_reconcile_period_id_seq

DROP SEQUENCE  IF EXISTS fileservice.recon_reconcile_period_id_seq cascade;

CREATE SEQUENCE fileservice.recon_reconcile_period_id_seq
    INCREMENT 1
    START 1
    MINVALUE 1
    MAXVALUE 9223372036854775807
    CACHE 1;

ALTER SEQUENCE fileservice.recon_reconcile_period_id_seq
    OWNER TO "user_dataRecon_file";

GRANT ALL ON SEQUENCE fileservice.recon_reconcile_period_id_seq TO postgres;

GRANT ALL ON SEQUENCE fileservice.recon_reconcile_period_id_seq TO "user_dataRecon_file";


-- Table: fileservice.recon_reconcile_period

DROP TABLE  IF EXISTS fileservice.recon_reconcile_period cascade;
CREATE TABLE fileservice.recon_reconcile_period (
	reconcile_id bigint NOT NULL DEFAULT nextval('fileservice.recon_reconcile_period_id_seq'::regclass),
	recon_id int8 NULL,
	user_selected_period varchar NULL,
	app_1_source_period varchar NULL,
	app_2_source_period varchar NULL,

	CONSTRAINT pk_reconcile_id PRIMARY KEY (reconcile_id)
)
TABLESPACE tbsp_meta;

ALTER TABLE IF EXISTS fileservice.recon_reconcile_period
    OWNER to "user_dataRecon_file";

GRANT ALL ON TABLE fileservice.recon_reconcile_period TO postgres;
GRANT DELETE, UPDATE, INSERT, SELECT ON TABLE fileservice.recon_reconcile_period TO "user_dataRecon_file";