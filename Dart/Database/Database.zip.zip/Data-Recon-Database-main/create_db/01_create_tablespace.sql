-- Tablespace to store metadata and logs
DROP TABLESPACE IF EXISTS tbsp_meta;
CREATE TABLESPACE tbsp_meta
  OWNER postgres
  LOCATION '/media/tbsp_meta/';

ALTER TABLESPACE tbsp_meta
  OWNER TO postgres;

-- Tablespace to store the recon data
DROP TABLESPACE IF EXISTS tbsp_data;
CREATE TABLESPACE tbsp_data
  OWNER postgres
  LOCATION '/media/tbsp_data/';

ALTER TABLESPACE tbsp_data
  OWNER TO postgres;
