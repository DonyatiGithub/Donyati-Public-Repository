-- Role: "user_dataRecon_admin"
DROP ROLE IF EXISTS "user_dataRecon_admin";

CREATE ROLE "user_dataRecon_admin" WITH
  LOGIN
  NOSUPERUSER
  INHERIT
  NOCREATEDB
  NOCREATEROLE
  NOREPLICATION
  ENCRYPTED PASSWORD 'SCRAM-SHA-256$4096:5nAIHV1sDBMtciP6iglHEA==$ASuvD4YFwsOJal9KUCjIEyvVqh8rtFdhG/VK6JAZ/h0=:KscgQr+9/GYNNtayOa8JrcCxMCjcec0/s2tgpgFp5V4=';

ALTER ROLE "user_dataRecon_admin" IN DATABASE "db_dataRecon" SET search_path TO admin;

GRANT ALL ON SCHEMA admin TO "user_dataRecon_admin";

ALTER DEFAULT PRIVILEGES IN SCHEMA admin
GRANT INSERT, SELECT, UPDATE, DELETE ON TABLES TO "user_dataRecon_admin";

-- Role: "user_dataRecon_file"
DROP ROLE IF EXISTS "user_dataRecon_file";

CREATE ROLE "user_dataRecon_file" WITH
  LOGIN
  NOSUPERUSER
  INHERIT
  NOCREATEDB
  NOCREATEROLE
  NOREPLICATION
  ENCRYPTED PASSWORD 'SCRAM-SHA-256$4096:fr8J/MKTHu59UXldnVgEYw==$q1uO+obthUYPcocR7ncS1+Pq/EEE0yZCMtLoQbuBZpM=:fTgxVmrK3mvQDSo6LXMDXYJbz6Y7F7oxwc4Wj1/OM2s=';

ALTER ROLE "user_dataRecon_file" IN DATABASE "db_dataRecon" SET search_path TO fileservice;
GRANT pg_read_server_files, pg_write_server_files TO "user_dataRecon_file";

ALTER ROLE "user_dataRecon_file" IN DATABASE "db_dataRecon"
    SET search_path TO fileservice;
ALTER ROLE "user_dataRecon_admin" IN DATABASE "db_dataRecon"
    SET search_path TO admin;

GRANT CONNECT ON DATABASE "db_dataRecon" TO "user_dataRecon_admin";
GRANT CONNECT ON DATABASE "db_dataRecon" TO "user_dataRecon_file";
GRANT pg_write_server_files TO "user_dataRecon_file";
GRANT pg_read_server_files TO "user_dataRecon_file";

GRANT ALL ON DATABASE "db_dataRecon" TO postgres;

GRANT ALL ON SCHEMA fileservice TO "user_dataRecon_file";

ALTER DEFAULT PRIVILEGES IN SCHEMA fileservice
GRANT DELETE, INSERT, SELECT, UPDATE ON TABLES TO "user_dataRecon_file";

ALTER DEFAULT PRIVILEGES IN SCHEMA fileservice
GRANT ALL ON SEQUENCES TO "user_dataRecon_file";

ALTER DEFAULT PRIVILEGES IN SCHEMA fileservice
GRANT EXECUTE ON FUNCTIONS TO "user_dataRecon_file";

grant all on tablespace tbsp_data to "user_dataRecon_file";
grant all on tablespace tbsp_meta to "user_dataRecon_file";
grant all on tablespace tbsp_meta to "user_dataRecon_admin";