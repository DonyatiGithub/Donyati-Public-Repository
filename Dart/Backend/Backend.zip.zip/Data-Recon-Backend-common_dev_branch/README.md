# Data-Recon-Backend
The base concept of Data Recon Project is to provide a solution that will let the user compare and validate data of two different applications. It can be Oracle and Onestream or anything. This repository contains the project files of Data Recon Backend.

## Technologies Used

- Python
- Django
- Django Rest Framework

Pull the project from git to initialize first:
```bash
git init
git remote add origin "https://github.com/firos-donyati/Data-Recon-Backend.git"
git pull
```

Or else you can clone the project to get started:
```bash
git clone "https://github.com/firos-donyati/Data-Recon-Backend.git"
```

## Usage

Once the project has been initialized, install the required packages:
```python
pip install -r requirements.txt
cd Data_Recon_Main
python manage.py runserver
```

Whenever you make any change in the models, make the migrations:
```python
python manage.py makemigrations
python manage.py migrate
```

Create a super user in Django to get access to inbuilt admin panel:
```python
python manage.py createsuperuser
```

If you installed any additional modules, make sure you freeze the requirements:
```python
pip freeze > requirements.txt
```

## Contributing
This is a private repository, only allowed members can contribute.

## License
[MIT](https://choosealicense.com/licenses/mit/)
