from django.urls import path
from rest_framework.urlpatterns import format_suffix_patterns
from . import views


urlpatterns = [
    path('run', views.run_report, name='run_report'),
    path('run/export', views.run_report_export, name='run_report_export'),
    path('run/archive/<int:recon_id>', views.archived_files, name='archived_files'),
    path('run/dimview', views.dim_view, name='dim_view'),
    path('run/getReport/<int:recon_id>', views.getReport, name='getreport'),
    path('run/sign_off', views.sign_off_recon, name='sign_off_recon'),
    path('run/backup/<int:recon_id>', views.backup_recon_files, name='backup_files'),
    # path('run/import_backup', views.import_backup, name='import_backup'),
    path('run/copy_recon', views.create_copy_of_recon, name='create_copy_of_recon'),
    path("drill-down",views.drill_down,name="drill_down"),
    path("drill-down-export",views.drill_down_export,name="drill_down"),
    path('check/report/<int:recon_id>', views.check_report_exists, name='check_report_exists')

]

urlpatterns = format_suffix_patterns(urlpatterns)
