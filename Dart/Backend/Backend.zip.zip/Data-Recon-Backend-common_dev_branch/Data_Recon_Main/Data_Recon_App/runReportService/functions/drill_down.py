from django.db import connections


def prepare_dynamic_columns(dimension_members,upper_case=False):
    str_list=[]
    for key,value in dimension_members.items():
        
        if upper_case:
            str_value =f"upper(\"{key}\")"
            str_list.append(str_value)
        else:
            str_value= f"\"{key}\""
            str_list.append(str_value)
    return ", ".join(str_list)


def dynamic_filter_values(dimension_member_values):

    value_list = []
    for v in dimension_member_values:
        value_repr =repr(v)
        value_list.append(value_repr)
    
    final_str = "(" + ", ".join(value_list) + ")"       
    return final_str


def get_drill_down(dimension_members,members,recon_id):
    try:
        cursor = connections['Recon'].cursor()
        columns= prepare_dynamic_columns(dimension_members)
        where_clause =prepare_dynamic_columns(dimension_members,upper_case=True)
        filter_values =dynamic_filter_values(members)
        final_query  = f"""select CASE   WHEN app_name = '0' THEN 'app1' ELSE 'app2' END AS app_name ,app_id,"AMOUNT-AMOUNT",{columns},"bridgesync-YEAR-YEAR"||"bridgesync-PERIOD-PERIOD" as "TIME" ,"user_comment" from fileservice.bridgesync_{recon_id} br inner join recon_applications ra on br.app_id=ra.recon_app_id where ({where_clause},"bridgesync-YEAR-YEAR"||"bridgesync-PERIOD-PERIOD")={filter_values} order by app_id;"""

        cursor.execute(final_query)
        data = cursor.fetchall()
        columns = [col[0] for col in cursor.description]
        result = [dict(zip(columns, row)) for row in data]
        return result

    except Exception as e:
        raise e
    finally:
        if cursor:
            cursor.close()

