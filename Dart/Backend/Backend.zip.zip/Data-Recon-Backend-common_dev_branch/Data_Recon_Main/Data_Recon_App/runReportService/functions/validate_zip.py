import os

def validate_zip(file_path):
    ext = os.path.splitext(file_path)[1]  # [0] returns path+filename
    if(ext == '.zip'):
       response = {
            'status': 200,
            'message': 'File is a Zip file!'
        }
    else:
        response = {
            'status': 6002,
            'message': 'File is not a Zip file'
        }
    return response

def validate_zip_content(file_path):
    ext = os.path.splitext(file_path)[1]  # [0] returns path+filename
    valid_ext =['.txt','.zip','.csv','.xml']
    if(ext in valid_ext):
       response = {
            'status': 200,
            'message': 'File is a valid!'
        }
    else:
        response = {
            'status': 6002,
            'message': 'File is not valid'
        }
    return response    