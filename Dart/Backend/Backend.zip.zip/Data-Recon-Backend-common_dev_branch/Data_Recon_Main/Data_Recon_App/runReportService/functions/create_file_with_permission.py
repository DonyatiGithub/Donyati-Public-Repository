import os;
import subprocess

'''
<!---------- Method to do create a file and add permissions in linux ----------!>
'''
def create_file_with_permission(file_path):
    if(os.name != 'nt'):        
        file_path.replace('\\','/')
        f= open(file_path,'w')
        # print(f)
        subprocess.call(["chmod 666 " + file_path], shell=True)