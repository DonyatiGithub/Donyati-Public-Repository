import json

from .getVariance import getVariance
from ...bridgeService.functions.is_bridge_exists import is_bridge_exists
from ...utils.pgsql_conn import call_sp_params
from .get_report_view import get_report_view
from ...runImportService.functions.is_exists import is_exists
from .generateQuery import generateQuery
from ...models import Recon, TrackReconRefresh


'''
<!---------- Method to run report and get view data then
             structure and return response ----------!>
'''


def execute_report(recon_id, max_rows, page_number, colArr, sp_flag, variance_threshold):

    start_point = (page_number - 1) * max_rows
    end_point = page_number * max_rows
    variance = str(variance_threshold)
    sp_flag = sp_flag
    pagination_query = f" limit {end_point} offset {start_point} ;"
    

    # Checking if all bridge configured
    is_valid = is_bridge_exists(recon_id)

    # Update Recon table with variance amount
    # Recon.objects.filter(recon_id=recon_id).update(variance_threshold=variance)

    if is_valid['status'] == 200:
        # Calling the transformation run SP
        # Need to see if the below SP call can be put into a payload based call
        # or create another API to call it
        if sp_flag:
            report_run = call_sp_params('fileService.sp_create_report', [recon_id], 1)
            # If procedure fails, return 
            if report_run['status'] != 200:
                response_data = report_run
                return response_data

        # Get the data from tables
        colList, grpStmt, abs_total, colList2 = generateQuery(recon_id, colArr, variance)
        # print(colList)
        # print(grpStmt)

        # Initialize a null response
        null_data={
            'status':6002,
            'headers': '',
            'rows':'',
            'variance_percentage': 100,
            'variance_threshold': 0,
            'message': 'Table does not exist'
        } 

        # Check if the report table exists
        if is_exists('fileservice','report_'+str(recon_id))['rows'][0]['exists']:
            view_query = 'SELECT '+colList+' FROM fileservice.report_' + str(recon_id) + grpStmt
            view_query = 'select '+colList2+', '+ abs_total + ' as grand_abs_total from ('+view_query+')q ' + pagination_query
            report_data = get_report_view(view_query)
        else:
            report_data=json.loads(json.dumps(null_data))

        if is_exists('fileservice','report_je_'+str(recon_id))['rows'][0]['exists']:
            view_query = 'SELECT '+colList+' FROM fileservice.report_je_' + str(recon_id) + grpStmt
            view_query = 'select '+colList2+', '+ abs_total + ' as grand_abs_total from ('+view_query+')q  ' + pagination_query
            # print(view_query)
            je_data = get_report_view(view_query)
        else:
            je_data=json.loads(json.dumps(null_data))

        if is_exists('fileservice','final_report_'+str(recon_id))['rows'][0]['exists']:
            view_query = 'SELECT '+colList+' FROM fileservice.final_report_' + str(recon_id) + grpStmt
            view_query = 'select '+colList2+', '+ abs_total + ' as grand_abs_total from ('+view_query+')q  ' + pagination_query
            final_data = get_report_view(view_query)

            # Get variance percentage
            colList, grpStmt, abs_total, colList2 = generateQuery(recon_id, '*', variance)
            # Inner query to get data based on write off
            view_query = 'SELECT '+colList+' FROM fileservice.final_report_' + str(recon_id) + grpStmt
            # 1st wrapper query to calculate grand_abs_total
            view_query = 'select '+colList2+', '+ abs_total + ' as grand_abs_total from ('+view_query+')q '
            # 2nd wrapper query to get variance
            view_query = 'select count(*) rec_count, sum(case when grand_abs_total !=0 then 1 else 0 end) variance_count from ('+view_query+')q2'
            # print(view_query)
            # Get variance percentage from final report table
            variance_percentage = getVariance(view_query)
            # getVariance(view_query)
        else:
            final_data=json.loads(json.dumps(null_data))
            variance_percentage = 100
        

        report_timestamp=TrackReconRefresh.objects.filter(recon_id=recon_id).values_list('report_timestamp',flat=True)[0]
        je_report_timestamp=TrackReconRefresh.objects.filter(recon_id=recon_id).values_list('je_report_timestamp',flat=True)[0]
        formatted_report_timestamp=report_timestamp.strftime('%Y-%m-%dT%H:%M:%SZ')
        
        if je_report_timestamp: 
            je_report_timestamp=je_report_timestamp.strftime('%Y-%m-%dT%H:%M:%SZ')
        else:
            je_report_timestamp=je_report_timestamp

        response_data = {
            'status':200,
            'headers': report_data['headers'],
            'main_report':report_data['rows'],
            'je_report':je_data['rows'],
            'final_report':final_data['rows'],
            'variance_percentage': variance_percentage,
            'variance_threshold': variance,
            'message': report_data['message'],
            'report_timestamp': formatted_report_timestamp,
            'je_report_timestamp': je_report_timestamp
        }
        return response_data
    else:
        return is_valid
