import json
import zipfile
import os
from django.conf import settings
from ..functions.create_export_file import create_export_file
from ...runImportService.functions.is_exists import is_exists
from .generateQuery import generateQuery
from Data_Recon_App.runReportService.functions.getVariance import getVariance

def run_export_report(colArr, recon_id, variance, report_type):
    # print('=======================================================')
    file_data = []

    # file_data = HttpResponse(fh.read(), content_type="text/csv")
    
    file_name = ['Initial_Report.csv',
                 'JE_Report.csv',
                 'Consolidated_Report.csv']

    # Get the data from tables
    colList, grpStmt, abs_total, colList2 = generateQuery(recon_id, colArr, variance)
    # print('1: ',colList)
    # print('2: ',grpStmt)
    # print('3: ',abs_total)
    # print('4: ',colList2)

    if report_type == 'variance':
        whereCl = ' where grand_abs_total <> 0'
    elif report_type == 'no-variance':
        whereCl = ' where grand_abs_total = 0'
    else:
        whereCl = ''

    # Based on availability of table, generate the query 
    if is_exists('fileservice','report_'+str(recon_id))['rows'][0]['exists']:
        view_query = 'SELECT '+colList+' FROM fileservice.report_' + str(recon_id) + grpStmt
        view_query = 'select '+colList2+', '+ abs_total + ' as grand_abs_total from ('+view_query+')q'
        if whereCl!='':
            view_query = 'select * from ('+view_query+')q2' + whereCl
        
        view_query = view_query.replace('"','\\\"')
        # print(view_query)
        response = create_export_file(recon_id=recon_id, file=file_name[0], query=view_query,variance=variance)

        if type(response) == type({'a':'b'}):
            # print('================================================')
            # print(json.dumps(response))
            return json.dumps(response)
        file_data.append(response)
    
    
    if is_exists('fileservice','report_je_'+str(recon_id))['rows'][0]['exists']:
        view_query = 'SELECT '+colList+' FROM fileservice.report_je_' + str(recon_id) + grpStmt
        view_query = 'select '+colList2+', '+ abs_total + ' as grand_abs_total from ('+view_query+')q'
        if whereCl!='':
            view_query = 'select * from ('+view_query+')q2' + whereCl
        # print(view_query)
        view_query = view_query.replace('"','\\\"')
        response = create_export_file(recon_id=recon_id, file=file_name[1], query=view_query,variance=variance)
        # print(type(response))
        if type(response) == type({'a':'b'}):
            return json.dumps(response)
        file_data.append(response)
   
    if is_exists('fileservice','final_report_'+str(recon_id))['rows'][0]['exists']:
        view_query = 'SELECT '+colList+' FROM fileservice.final_report_' + str(recon_id) + grpStmt
        view_query = 'select '+colList2+', '+ abs_total + ' as grand_abs_total from ('+view_query+')q'
        if whereCl!='':
            view_query = 'select * from ('+view_query+')q2' + whereCl
        # print(view_query)
        view_query = view_query.replace('"','\\\"')
        response = create_export_file(recon_id=recon_id, file=file_name[2], query=view_query,variance=variance)
        # print(type(response))
        if type(response) == type({'a':'b'}):
            return json.dumps(response)
        file_data.append(response)

    # print(file_data)
    zipdir = 'Report'
    zip_filename = zipdir+'.zip'
    zpath = os.path.join(settings.MEDIA_ROOT,str(recon_id) + "/export/" +zip_filename)

    if zipfile.is_zipfile(zpath):
        os.remove(zpath)

    # # zf = zipfile.ZipFile(zpath,'a')
    # # try:
    with zipfile.ZipFile(zpath,'w') as zf:
        for file in file_data:
            zf.write(file,os.path.basename(file))
    # finally:
    #     zf.close()
    # print(file_data)
    result = {"file_location":file_data,"zip_path":os.path.basename(zpath)}
    return result
    # zip_file = open(zpath,'rb')    
    # return zip_file.read()
    