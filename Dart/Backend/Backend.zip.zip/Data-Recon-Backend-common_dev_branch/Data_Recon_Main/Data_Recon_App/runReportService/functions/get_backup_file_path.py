import os
from django.db import connections

def get_backup_file_path(recon_id):
    main_query ='SELECT file_location,file_name FROM fileservice.track_file_load_status'  \
                                                ' WHERE recon_id=' + str(recon_id)
    # print(main_query)
    cursor = connections['Recon'].cursor()
    cursor.execute(main_query)
    cursor = cursor.fetchall()
    file_location = []
    for entry in cursor:
        file_location.append(os.path.join(entry[0], entry[1]))
    # removing duplicates    
    file_location =list(set(file_location))
    return file_location
    