from datetime import datetime
from rest_framework import status
from django.http import HttpResponse
from rest_framework.decorators import permission_classes, api_view, \
    renderer_classes, parser_classes
from rest_framework.permissions import IsAuthenticated
from rest_framework.renderers import JSONRenderer
from rest_framework.response import Response
from rest_framework.parsers import MultiPartParser, FormParser
from ..models import Recon, TrackFileLoadStatus, ReconUser, ReconApplications, DCUser, OneStream
from ..utils.get_recon import get_recon
from ..utils.pgsql_conn import call_sp_params, call_query
from ..utils.store_file import store_file
from .functions.export_data import export_data
from .functions.is_import_valid import is_import_valid
from .functions.get_view_data import get_view_data
from .functions.is_exists import is_exists
from ..utils.user_permissions import is_write_permitted
from ..utils.is_signed import is_recon_signed
from django.conf import settings
from ..utils.run_export_script import run_export_script
from ..utils.generate_app_source_files import generate_app_source_files
from .functions.get_source_data import add_files_to_zip, getSourceData as getSD
from .functions.global_variable import is_global_attached
import os
import requests
import time
from django.conf import settings
from zipfile import ZipFile
import zipfile
from Crypto.Cipher import AES
import shutil
# from Crypto.SelfTest.Hash.test_cSHAKE import tag
from django.db import connections
from django.shortcuts import  redirect
import pandas as pd
import csv
from .functions.direct_connect_operations import pbcs_fccs, onestream, Essbase
from .functions.ETL import pbcs_fccs_etl
from .functions.perform_etl import perform_etl
from .functions.tag_dim import tag_dim
from ..utils.pgsql_conn import call_generic_query
from .serializers import OsnameSerializer
from .serializers import OnestreamDetailsSerializer
from .serializers import OnestreamGetSerializer
from Data_Recon_App.utils.recon_permission_check import validate_user_recon_permission
from ..utils.app_info import get_app_ids
from .functions.file_details import get_file_names
import logging
import time
from ..bridgeService.functions.get_disk_space import get_disk_space
from ..maintenanceService.functions.update_config import get_diskspace_thresh

user_logger = logging.getLogger("userlog")
# use this logger to log user log 

logger = logging.getLogger("techlog")
# use 'logger' to for general application log


@api_view(['PUT'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
@parser_classes((MultiPartParser, FormParser))
def import_source_file(request):
    # Getting the data from request

    try:
        allowed = validate_user_recon_permission(request.user.email, "write", request.data['recon_id'])
        if not allowed:
            response_data = {
                'status': 403,
                'message': 'Un-authorized action detected!'
            }
            return Response(response_data, status=status.HTTP_403_FORBIDDEN)
        
        start_time = time.time()
        log_context = {
            "recon_id": request.data['recon_id'],
            "request_id": request.request_id,
            "user_email": request.user.email,
            "request_url": request.path,
            "event_stage": 'Runimport'
        }
        logger.info(" import_source_file function execution start",extra=log_context)
        
        recon_id = request.data['recon_id']
        app_type = request.data['app_type']
        max_rows = int(request.data['max_rows'])
        page_number = int(request.data['page_number'])
        no_files = int(request.data['num_files'])
        file_type = int(request.data['file_type'])
        je = request.data['je']
        attached_flag=is_global_attached(recon_id=recon_id)
        create_table_sp= 'fileservice.sp_create_global_variables_dynamic_table' if attached_flag else 'fileService.sp_create_dynamic_table'
        load_table_sp= 'fileservice.sp_load_global_dynamic_table'if attached_flag else 'fileService.sp_load_dynamic_table'
        
        if je == "True":
            je = True
            fs_table = "je_"
        else:
            je = False
            fs_table = "app_"

        if je:
            file_obj = ["je"]
        else:
            file_obj = []
        for file in range(no_files):
            file_obj.append(request.FILES['source_file[' + str(file) + ']'])
        start_point = (page_number - 1) * max_rows
        end_point = page_number * max_rows

        if is_write_permitted(request.user.email):
            # Checking if recon exists or not deleted
            if not is_recon_signed(recon_id) : 
                if recon_id != '' and Recon.objects.filter(recon_id=recon_id, is_deleted=False).exists():

                    # Getting the app id
                    recon_data = get_recon(recon_id)
                    recon_name = recon_data['name']
                    app1_id = recon_data['app1_id']
                    app2_id = recon_data['app2_id']
                    app_id = recon_data['app1_id'] if app_type == '0' else recon_data['app2_id']
                    inverse_app_id = recon_data['app2_id'] if app_type == '0' else recon_data['app1_id']
                    
                    # for ETL processing starts ----------------
                    instance = ReconApplications.objects.filter(recon_id=recon_id, app_name=app_type)[0]
                    delimiter = instance.import_delimiter
                    has_header = 1 if instance.has_header else 0
                    # for ETL processing ends ------------------
                    
                    # Storing file
                    save_file = store_file(recon_id, file_obj)            
                    file_name, file_location = [], []            
                    for name in range(len(save_file[0])):
                        # for ETL processing starts ---------------------
                        in_filename = save_file[1][name]
                        #out_filename =in_filename.replace(save_file[0][name],'ETL_'+save_file[0][name])
                        #out_filename =in_filename.replace(save_file[0][name],'ETL_'+save_file[0][name])
                        #print(out_filename)
                        etl_response = perform_etl(in_filename,in_filename,delimiter,has_header,file_type, app_type, recon_id)
                        # print(etl_response)
                        #for ETL processing ends -----------------------
                        file_name.append(save_file[0][name])
                        file_location.append(save_file[1][name])
                        file_location[name] = (save_file[1][name]).replace(file_name[name], '')
                        # Validating all the pre-requisites
                        is_valid = is_import_valid(recon_id, app_type, save_file[1][name],etlType=file_type,is_global_variable_attached=attached_flag) if not je else is_import_valid(
                            recon_id, app_type, save_file[1][name], "je",etlType=file_type,is_global_variable_attached=attached_flag)
        
                    if is_valid['status'] == 200:
                        # Calling the dynamic table create SP
                        create_dtable = call_sp_params(create_table_sp, [app_id, je], 2)
                        table_exists = is_exists('fileservice', fs_table + str(recon_id) + '_' + str(inverse_app_id))

                        # Check if table exists for other app
                        if not table_exists['rows'][0]['exists']:
                            call_sp_params(create_table_sp, [inverse_app_id, je], 2)

                        if create_dtable['status'] == 200:
                            # Saving the file details in DB
                            for x in range(len(file_location)):
                                file_load = TrackFileLoadStatus(recon_id=recon_id, app_id=app_id,
                                                                file_location=file_location[x], file_name=file_name[x],
                                                                uploaded_by=request.user.email,is_je_file=False,file_type="app")
                                file_load.save()

                            # Calling the load data SP
                            load_data = call_sp_params(load_table_sp, [app_id, je], 2)

                            if load_data['status'] == 200:
                                create_view = call_sp_params('fileService.sp_create_recon_app_view', [recon_id, je], 2)
                                if create_view['status'] == 200:
                                    if not je:
                                        view_query = 'SELECT * FROM fileService.view_' + str(recon_id) + \
                                                    ' WHERE app_id=' + str(app_id) + ' LIMIT ' + str(end_point) + \
                                                    ' OFFSET ' + str(start_point)
                                    else:
                                        view_query = 'SELECT * FROM fileService.view_je_' + str(recon_id) + \
                                                    ' WHERE app_id=' + str(app_id) + ' LIMIT ' + str(end_point) + \
                                                    ' OFFSET ' + str(start_point)
                                    response_data = get_view_data(view_query, app1_id, app2_id)
                                else:
                                    response_data = create_view
                            else:
                                response_data = {
                                    'status': 6002,
                                    'message': 'The table did not load onto the Database, please contact your Administrator'
                                }
                        else:
                            response_data = create_dtable
                    else:
                        response_data = is_valid
                else:
                    response_data = {
                        'status': 403,
                        'message': 'No recon found with the specified id!'
                    }
            else:
                response_data = {
                        'status': 403,
                        'message': 'This Recon is Signed Off'
                    }        
        else:
            response_data = {
                'status': 6002,
                'message': 'Un-authorized action detected!'
            }
        
        
        if response_data.get("status")==200:

            if get_diskspace_thresh()!="None":
                disk_usage = get_disk_space()
                if get_diskspace_thresh() == disk_usage:
                    response_data["disk_usage"] = disk_usage 

            user_logger.info("Uploaded source file",extra=log_context)
        else:
            logger.error(response_data,extra=log_context)
        
        log_context["time_taken"]=int(time.time()-start_time)
        logger.info(" import_source_file function execution ends",extra=log_context)
        
        return Response(response_data, status=status.HTTP_200_OK)
    
    except Exception as e:
        
        log_context["variable_state"]=locals()
        logger.error(f" exception occured on  import_source_file {str(e)} ",exc_info=1,extra=log_context)
        raise e

# @api_view(['POST'])
# @permission_classes((IsAuthenticated,))
# @renderer_classes((JSONRenderer,))
# @parser_classes((MultiPartParser, FormParser))
# def process_etl(request):
#     recon_id = request.data['recon_id']
#     app_type = request.data['app_type']
#     file_type = request.data['file_type']
#     app_type = 0 if (app_type == "0" or app_type == 0) else 1
#     # no_files = int(request.data['num_files'])
#     file_obj = []
    

#     if is_write_permitted(request.user.email):
#         if not is_recon_signed(recon_id) :
#             file_obj.append(request.FILES['source_file[0]'])
#             # Retrieving job from cloud and saving the file
#             if ReconApplications.objects.filter(recon_id=recon_id, app_name=app_type).exists():
#                 instance = ReconApplications.objects.filter(recon_id=recon_id, app_name=app_type)[0]
#                 save_file = store_file(recon_id, file_obj)
#                 input_file_name =save_file[0][0]
#                 input_file_path = save_file[1][0]
#                 output_file_name =str(app_type) + '_' + file_type + '.csv'
#                 output_file_path =input_file_path.replace(input_file_name,output_file_name)
#                 delimiter = instance.import_delimiter
#                 has_header = 1 if instance.has_header else 0            
#                 response_data = perform_etl(input_file_path,output_file_path,delimiter,has_header,file_type)
#             else:
#                 response_data = {
#                     'status': 403,
#                     'message': 'No recon found with the specified id!'
#                 }
#         else:
#             response_data = {
#                     'status': 403,
#                     'message': 'This Recon is Signed Off'
#                 }        
#     else:
#         response_data = {
#             'status': 6002,
#             'message': 'Un-authorized action detected!'
#         }

#     return Response(response_data, status=status.HTTP_200_OK)


@api_view(['POST'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def get_source_data(request):
    try:
        allowed = validate_user_recon_permission(request.user.email, "read", request.data['recon_id'])
        if not allowed:
            response_data = {
                'status': 403,
                'message': 'Un-authorized action detected!'
            }
            return Response(response_data, status=status.HTTP_403_FORBIDDEN)
        
        # Getting the data from request
        log_context = {
            "recon_id": request.data['recon_id'],
            "request_id": request.request_id,
            "user_email": request.user.email,
            "request_url":request.path,
            "event_stage": 'Runimport'
        }
        logger.info(" get_source_data function execution start",extra=log_context)
        start_time = time.time()
        
        recon_id = request.data['recon_id']
        max_rows = int(request.data['max_rows'])
        page_number = int(request.data['page_number'])
        start_point = (page_number - 1) * max_rows
        end_point = page_number * max_rows

        # Checking if recon exists or not deleted
        if recon_id != '' and Recon.objects.filter(recon_id=recon_id, is_deleted=False).exists():
            recon_data = get_recon(recon_id)
            recon_name = recon_data['name']
            app1_id = recon_data['app1_id']
            app2_id = recon_data['app2_id']

            # Check if view exists
            view_exists = is_exists('fileservice', 'view_' + str(recon_id))

            # Check if table exists for other app
            if view_exists['rows'][0]['exists']:
                # Getting both apps data
                view_query = 'SELECT * FROM fileService.view_' + str(recon_id) + \
                            ' LIMIT ' + str(end_point) + \
                            ' OFFSET ' + str(start_point)
                response_data = get_view_data(view_query, app1_id, app2_id)
            else:
                response_data = {
                    'status': 200,
                    'headers': [],
                    'rows': [],
                    'message': 'No data found!'
                }

            # response_data = get_apps_data(recon_id, max_rows, page_number)
        else:
            response_data = {
                'status': 403,
                'message': 'No recon found with the specified id!'
            }
        

        if response_data.get("status")!=200:
            logger.error(response_data,extra=log_context)
        
        log_context["time_taken"]=int(time.time()-start_time)
        logger.info(" name function execution ends",extra=log_context)
        
        return Response(response_data, status=status.HTTP_200_OK)
    
    except Exception as e:
        log_context["variable_state"]=locals()
        logger.error(f" exception occured on  get_source {str(e)} ",exc_info=1,extra=log_context)
        raise e




@api_view(['POST'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def export_source_data(request):

    try:
        allowed = validate_user_recon_permission(request.user.email, "read",request.data['recon_id'] )
        if not allowed:
            response_data = {
                'status': 403,
                'message': 'Un-authorized action detected!'
            }
            return Response(response_data, status=status.HTTP_403_FORBIDDEN)
        
        start_time = time.time()
        log_context = {
            "recon_id": request.data['recon_id'],
            "request_id": request.request_id,
            "user_email": request.user.email,
            "request_url":request.path,
            "event_stage": 'Runimport'
        }
        logger.info(" export_source_data function execution start",extra=log_context)

        recon_id = request.data['recon_id']
        je_flag = request.data['je_flag']
        # if je_flag == 'false':
        # je_flag = False if je_flag == 'false' else True # commented since je_flag is already coming as boolean
        if is_write_permitted(request.user.email):
            # Checking if recon exists or not deleted
            # if not is_recon_signed(recon_id) :
                
                if recon_id != '' and Recon.objects.filter(recon_id=recon_id, is_deleted=False).exists():
                    current_time = datetime.now().time().strftime("%H:%M:%S")
                    current_date = datetime.now().strftime("%Y-%m-%d")
                    modified_date = str(current_date) + '_' + str(current_time)
                    file_name = 'Source_Data_Export.csv'
                    # export_file = export_data(recon_id, False)
                    split_file_name = []
                    offset = 10000

                    # Constructing the query
                    ini_query = "select string_agg(col, ',') from (select '\"'||rd1.dimension||'-'||rd2.dimension||'\"'" \
                                " as col from fileservice.recon_dimensions rd1 inner join fileservice.recon_dimensions" \
                                " rd2 on rd1.turn_on_define_order =rd2.turn_on_define_order and rd1.recon_id=rd2.recon_id and" \
                                " rd2.app_type ='1' where rd1.recon_id =" + str(
                        recon_id) + " and rd1.app_type ='0' and rd1.is_active and not" \
                                    " rd1.is_deleted order by rd1.type_field ::integer)q"

                    cursor = connections['Recon'].cursor()
                    cursor.execute(ini_query)
                    cursor = cursor.fetchone()
                    cursor = ','.join(map(str, cursor)).split(",")
                    headers = ""

                    for x in range(len(cursor)):
                        headers += "\\\"" + cursor[x] + "\\\""
                        if x < len(cursor) - 1:
                            headers += ","

                    if je_flag:
                        query = "select " + headers + " from fileservice.view_je_" + str(recon_id)
                        count = "select COUNT(*) from fileservice.view_je_" + str(recon_id)
                        new_cursor = connections['Recon'].cursor()
                        new_cursor.execute(count)
                        new_cursor = new_cursor.fetchone()

                    else:
                        query = "select " + headers + " from fileservice.view_" + str(recon_id)
                        count = "select COUNT(*) from fileservice.view_" + str(recon_id)
                        new_cursor = connections['Recon'].cursor()
                        new_cursor.execute(count)
                        new_cursor = new_cursor.fetchone()

                    run_times = int(new_cursor[0]) / 10000
                    for i in range(int(run_times)):
                        split_file_name.append(str(i)+file_name)
                        fquery = query + " OFFSET " + str(offset) + " LIMIT 10000"
                        run_export_script(recon_id, split_file_name[i], fquery)
                        offset = offset + 10000

                    zpath = os.path.join(settings.MEDIA_ROOT, str(recon_id) + "Source_Data_Export.zip")

                    with zipfile.ZipFile(zpath, 'w') as my_zip:
                        for file in split_file_name:
                            contentPath=os.path.join(settings.MEDIA_ROOT, str(recon_id) + "\export\\" + str(file))
                            my_zip.write(contentPath, os.path.basename(file))

                    # file_path = os.path.join(settings.MEDIA_ROOT, str(recon_id) + "/export/" + file_name)
                    # file_path = (str(file_path).replace("\\", "/"))
                
                    if os.path.exists(zpath):
                        zip_file = open(zpath, 'rb')
                        response = HttpResponse(zip_file.read(), content_type='application/zip')
                        response['Content-Disposition'] = 'attachment; filename=' + modified_date + os.path.basename(zpath)
                        response['Access-Control-Expose-Headers'] = 'Content-Disposition'
                        user_logger.info("Exported source data of the recon ",extra=log_context)
                        return  response

                    # Calling the Shell script to create a csv file
                    # run_export_script(recon_id, file_name, query)
                    #
                    # file_path = os.path.join(settings.MEDIA_ROOT, str(recon_id) + "/export/" + file_name)
                    # file_path = (str(file_path).replace("\\", "/"))
                    # if os.path.exists(file_path):
                    #     with open(file_path, 'rb') as fh:
                    #         response = HttpResponse(fh.read(), content_type="text/csv")
                    #         response['Content-Disposition'] = 'inline; filename=' + modified_date + os.path.basename(file_path)
                    #         response['Access-Control-Expose-Headers'] = 'Content-Disposition'
                    #         return response
                    else:
                        response = {
                            'status': 6002,
                            'message': 'File Not Found'
                        }

                    # Setting the download response
                    # response_data = HttpResponse(export_file.getvalue(), content_type='text/csv')
                    # response_data['Content-Disposition'] = 'attachment; filename=' + file_name
                    # response_data['Access-Control-Expose-Headers'] = 'Content-Disposition'
                    # return response_data
                else:
                    response = {
                        'status': 403,
                        'message': 'No recon found with the specified id!'
                    }
            # else:
            #     response = {
            #             'status': 403,
            #             'message': 'This Recon is Signed Off'
            #         }        
        else:
            response = {
                'status': 6002,
                'message': 'Un-authorized action detected!'
            }

        if response.get("status")!=200:
            logger.error(response,extra=log_context)
        
        log_context["time_taken"]=int(time.time()-start_time)
        logger.info(" export_source_data function execution ends",extra=log_context)
        return Response(response, status=status.HTTP_200_OK)
    
    except Exception as e:
        log_context["variable_state"]=locals()
        logger.error(f" exception occured on  export_source_data {str(e)} ",exc_info=1,extra=log_context)
        raise e

'''
<!---------- Method to export the source data as a zip file &
             return data as a response ----------!>
'''
@api_view(['GET'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def get_source_data_zip(request):
    
    try:
        allowed = validate_user_recon_permission(request.user.email, "read", request.GET.get('recon_id'))
        if not allowed:
            response_data = {
                'status': 403,
                'message': 'Un-authorized action detected!'
            }
            return Response(response_data, status=status.HTTP_403_FORBIDDEN)

        start_time = time.time()
        log_context = {
            "recon_id": request.GET.get('recon_id'),
            "request_id": request.request_id,
            "user_email": request.user.email,
            "request_url":request.path,
            "event_stage": 'Runimport'
        }
        logger.info(" get_source_data_zip function execution start",extra=log_context)
        
        recon_id=request.GET.get('recon_id')
        je_flag=request.GET.get('je_flag')
        je_flag = True if je_flag == 'true' else False
        
        if is_write_permitted(request.user.email):
            # if not is_recon_signed(recon_id) :
                if recon_id != '' and Recon.objects.filter(recon_id=recon_id, is_deleted=False).exists():
                    current_time = datetime.now().time().strftime("%H:%M:%S")
                    current_date = datetime.now().strftime("%Y-%m-%d")
                    # modified_date = str(current_date) + '_' + str(current_time)
                    file_name = 'Source_Data_Export.csv'            
                    # single app Query 
                    single_query_app1 ="""select
                            string_agg('"'||dimension||'"',',')||',"file_name" from fileservice.'||
                            'app_'||recon_id||'_'||recon_app_id||';' as query
                            from (
                                select turn_on_define_order, dimension, recon_id, recon_app_id
                                from fileservice.recon_dimensions rd
                                where rd.recon_id = """+str(recon_id)+"""
                                and rd.app_type = '0'
                                and not rd.is_deleted
                                and rd.is_active
                                order by recon_id, recon_app_id, turn_on_define_order::int
                                ) q
                            group by recon_id, recon_app_id;"""  
                    # getting query for app 2
                    single_query_app2 =single_query_app1.replace("'0'","'1'")
                    # generating app1 source file in export folder under the name App1(second argument)
                    app1_files =generate_app_source_files(recon_id,'App1',single_query_app1,je_flag,file_name)
                    # generating app2 source file in export folder under the name App2(second argument)
                    app2_files = generate_app_source_files(recon_id,'App2',single_query_app2,je_flag,file_name)
                    # creating a zip with export files
                    zipfile_name=str(recon_id)+'_'+ "Source_Data_Export.zip"
                    zpath = os.path.join(settings.MEDIA_ROOT, zipfile_name)
                    with zipfile.ZipFile(zpath, 'w') as zip_file:
                        # Add files to the first folder
                        add_files_to_zip(zip_file, 'App1', app1_files)
                        # Add files to the second folder
                        add_files_to_zip(zip_file, 'App2', app2_files)

                    
                    if os.path.exists(zpath):
                        response = HttpResponse(getSD(recon_id))
                        response['Content-Disposition'] = f'attachment; filename= {str(recon_id)}_Source_Data_Export.zip'
                        response['Access-Control-Expose-Headers'] = 'Content-Disposition'
                        user_logger.info("Exporting the source data",extra=log_context)

                        return response
                    else:
                        response = {
                            'status': 6002,
                            'message': 'File Not Found'
                        }
                else:
                    response = {
                        'status': 403,
                        'message': 'No recon found with the specified id!'
                    }
            # else:
            #     response = {
            #             'status': 403,
            #             'message': 'This Recon is Signed Off'
            #         }
        else:
            response = {
                'status': 6002,
                'message': 'Un-authorized action detected!'
            }
        
        if response.get("status")!=200:
            logger.error(response,extra=log_context)


        log_context["time_taken"]=int(time.time()-start_time)
        logger.info(" get_source_data_zip function get_source_data_zip ends",extra=log_context)
        
        return Response(response, status=status.HTTP_200_OK)
    
    except Exception as e:
       
        log_context["variable_state"]=locals()
        logger.error(f" exception occured on  get_source_data_zip {str(e)} ",exc_info=1,extra=log_context)
        raise e


@api_view(['PUT'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
@parser_classes((MultiPartParser, FormParser))
def import_je_file(request):
    # Getting the data from request
    try:
        allowed = validate_user_recon_permission(request.user.email, "write",request.data['recon_id'] )
        if not allowed:
            response_data = {
                'status': 403,
                'message': 'Un-authorized action detected!'
            }
            return Response(response_data, status=status.HTTP_403_FORBIDDEN)
        
        start_time = time.time()
        log_context = {
            "recon_id": request.data['recon_id'],
            "request_id": request.request_id,
            "user_email": request.user.email,
            "request_url": request.path,
            "event_stage": 'Runimport'
        }
        
        recon_id = request.data['recon_id']
        app_type = request.data['app_type']
        max_rows = int(request.data['max_rows'])
        page_number = int(request.data['page_number'])
        no_files = int(request.data['num_files'])
        file_obj = ["je"]
        for file in range(no_files):
            file_obj.append(request.FILES['source_file[' + str(file) + ']'])
        start_point = (page_number - 1) * max_rows
        end_point = page_number * max_rows

        if is_write_permitted(request.user.email):
            if not is_recon_signed(recon_id) :
                # Checking if recon exists or not deleted
                if recon_id != '' and Recon.objects.filter(recon_id=recon_id, is_deleted=False).exists():

                    # Getting the app id
                    recon_data = get_recon(recon_id)
                    recon_name = recon_data['name']
                    app1_id = recon_data['app1_id']
                    app2_id = recon_data['app2_id']
                    app_id = recon_data['app1_id'] if app_type == '0' else recon_data['app2_id']
                    inverse_app_id = recon_data['app2_id'] if app_type == '0' else recon_data['app1_id']

                    # Storing file
                    save_file = store_file(recon_id, file_obj)
                    file_name, file_location = [], []
                    for name in range(len(save_file[0])):
                        file_name.append(save_file[0][name])
                        file_location.append(save_file[1][name])
                        file_location[name] = (save_file[1][name]).replace(file_name[name], '')
                        # Validating all the pre-requisites
                        is_valid = is_import_valid(recon_id, app_type, save_file[1][name], "je")

                    if is_valid['status'] == 200:
                        # setting initial status as 200
                        # table is created only if it does not exist
                        create_dtable = {'status': 200, 'message': 'Initialised'}
                        table_exists = is_exists('fileservice', 'je_' + str(recon_id) + '_' + str(app_id))
                        if not table_exists['rows'][0]['exists']:
                            # Calling the dynamic table create SP
                            create_dtable = call_sp_params('fileService.sp_create_dynamic_table', [app_id, True], 2)
                        table_exists = is_exists('fileservice', 'je_' + str(recon_id) + '_' + str(inverse_app_id))

                        # Check if table exists for other app
                        if not table_exists['rows'][0]['exists']:
                            call_sp_params('fileService.sp_create_dynamic_table', [inverse_app_id, True], 2)

                        if create_dtable['status'] == 200:
                            # Saving the file details in DB
                            for x in range(len(file_location)):
                                file_load = TrackFileLoadStatus(recon_id=recon_id, app_id=app_id,
                                                                file_location=file_location[x], file_name=file_name[x],
                                                                uploaded_by=request.user.email,is_je_file=True,file_type="app")
                                file_load.save()

                            # Calling the load data SP
                            load_data = call_sp_params('fileService.sp_load_dynamic_table', [app_id, True], 2)

                            if load_data['status'] == 200:
                                view_exist = is_exists('fileservice', 'view_je_' + str(recon_id))
                                if not view_exist['rows'][0]['exists']:                            
                                    create_view = call_sp_params('fileService.sp_create_recon_app_view', [recon_id, True], 2)                        
                                    if create_view['status'] == 200:
                                        view_query = 'SELECT * FROM fileService.view_je_' + str(recon_id) + \
                                                ' WHERE app_id=' + str(app_id) + ' LIMIT ' + str(end_point) + \
                                                ' OFFSET ' + str(start_point)
                                        response_data = get_view_data(view_query, app1_id, app2_id)
                                    else:
                                        response_data = create_view
                                else:                            
                                    view_query = 'SELECT * FROM fileService.view_je_' + str(recon_id) + \
                                                ' WHERE app_id=' + str(app_id) + ' LIMIT ' + str(end_point) + \
                                                ' OFFSET ' + str(start_point)
                                    response_data = get_view_data(view_query, app1_id, app2_id)

                        else:
                            response_data = create_dtable
                    else:
                        response_data = is_valid

                    # Getting the source file data
                    # response_data = get_data(file_path, recon_id, app_type,
                    #                          file_name, max_rows, page_number)

                else:
                    response_data = {
                        'status': 403,
                        'message': 'No recon found with the specified id!'
                    }
            else:
                response_data = {
                        'status': 403,
                        'message': 'This Recon is Signed Off'
                    }        
        else:
            response_data = {
                'status': 6002,
                'message': 'Un-authorized action detected!'
            }

        if response_data.get("status")==200:
            if get_diskspace_thresh()!="None":
                disk_usage = get_disk_space()
                if get_diskspace_thresh() == disk_usage:
                    response_data["disk_usage"] = disk_usage
            
            user_logger.info("Imported journal entry via files",extra=log_context)
        else:
            logger.error(response_data,extra=log_context)
        

        log_context["time_taken"]=int(time.time()-start_time)
        logger.info(" name function execution ends",extra=log_context)
        
        return Response(response_data, status=status.HTTP_200_OK)
    
    except Exception as e:
        log_context["variable_state"]=locals()
        logger.error(f" exception occured on  import_je_file {str(e)} ",exc_info=1,extra=log_context)
        raise e


@api_view(['POST'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def get_je_data(request):
    # Getting the data from request
    try:
        allowed = validate_user_recon_permission(request.user.email, "read",request.data['recon_id'] )
        if not allowed:
            response_data = {
                'status': 403,
                'message': 'Un-authorized action detected!'
            }
            return Response(response_data, status=status.HTTP_403_FORBIDDEN)
        
        start_time = time.time()
        log_context = {
            "recon_id": request.data['recon_id'],
            "request_id": request.request_id,
            "user_email": request.user.email,
            "request_url": request.path,
            "event_stage": 'Runimport'
        }
        logger.info(" get_je_data function execution start",extra=log_context)
        
        recon_id = request.data['recon_id']
        max_rows = int(request.data['max_rows'])
        page_number = int(request.data['page_number'])
        start_point = (page_number - 1) * max_rows
        end_point = page_number * max_rows

        # Checking if recon exists or not deleted
        if recon_id != '' and Recon.objects.filter(recon_id=recon_id, is_deleted=False).exists():
            recon_data = get_recon(recon_id)
            recon_name = recon_data['name']
            app1_id = recon_data['app1_id']
            app2_id = recon_data['app2_id']

            # Check if view exists
            view_exists = is_exists('fileservice', 'view_je_' + str(recon_id))

            # Check if table exists for other app
            if view_exists['rows'][0]['exists']:
                # Getting both apps data
                view_query = 'SELECT * FROM fileService.view_je_' + str(recon_id) + \
                            ' LIMIT ' + str(end_point) + \
                            ' OFFSET ' + str(start_point)
                response_data = get_view_data(view_query, app1_id, app2_id)
            else:
                response_data = {
                    'status': 200,
                    'headers': [],
                    'rows': [],
                    'message': 'No data found!'
                }

            # response_data = get_apps_data(recon_id, max_rows, page_number)
        else:
            response_data = {
                'status': 403,
                'message': 'No recon found with the specified id!'
            }

        if response_data.get("status")!=200:
            logger.error(response_data,extra=log_context)
        
        log_context["time_taken"]=int(time.time()-start_time)
        logger.info(" get_je_data function execution ends",extra=log_context)
        
        return Response(response_data, status=status.HTTP_200_OK)
    
    except Exception as e:

        log_context["variable_state"]=locals()
        logger.error(f" exception occured on  get_je_data {str(e)} ",exc_info=1,extra=log_context)
        raise e


@api_view(['GET'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def export_je_data(request, recon_id):
    try:
        allowed = validate_user_recon_permission(request.user.email, "read",recon_id )
        if not allowed:
            response_data = {
                'status': 403,
                'message': 'Un-authorized action detected!'
            }
            return Response(response_data, status=status.HTTP_403_FORBIDDEN)
        
        start_time= time.time()
        log_context = {
            "recon_id": recon_id,
            "request_id": request.request_id,
            "user_email": request.user.email,
            "request_url":request.path,
            "event_stage": 'Runimport'
        }
        user_logger.info("Exported journal entry",extra=log_context)
        if is_write_permitted(request.user.email):
            if not is_recon_signed(recon_id) :
                # Checking if recon exists or not deleted
                if recon_id != '' and Recon.objects.filter(recon_id=recon_id, is_deleted=False).exists():
                    current_time = datetime.now().time().strftime("%H:%M:%S")
                    current_date = datetime.now().strftime("%Y-%m-%d")
                    modified_date = str(current_date) + '_' + str(current_time)
                    file_name = 'JE_Source_Data_Export.csv'
                    # export_file = export_data(recon_id, True)

                    # Calling the Shell script to create a csv file

                    query = "select string_agg('"'||c.column_name||'"' ,',')from information_schema.\"columns\" c where c.table_schema ='fileservice'and c.table_name = 'view_89'and c.column_name not in ('app_id','file_name','file_id');"

                    query = "select * from fileservice.view_je_" + str(recon_id)
                    run_export_script(recon_id, file_name, query)

                    file_path = os.path.join(settings.MEDIA_ROOT, str(recon_id) + "/export/" + file_name)
                    file_path = (str(file_path).replace("\\", "/"))
                    if os.path.exists(file_path):
                        with open(file_path, 'rb') as fh:
                            response = HttpResponse(fh.read(), content_type="text/csv")
                            response['Content-Disposition'] = 'inline; filename=' + os.path.basename(modified_date + file_path)
                            return response
                    else:
                        response = {
                            'status': 6002,
                            'message': 'File Not Found'
                        }
                else:
                    response = {
                        'status': 403,
                        'message': 'No recon found with the specified id!'
                    }
            else:
                response = {
                        'status': 403,
                        'message': 'This Recon is Signed Off'
                    }        
        else:
            response = {
                'status': 6002,
                'message': 'Un-authorized action detected!'
            }
        
        if response.get("status")==200:
            user_logger.info("Exported journal entry",extra=log_context)
        else:
            logger.error(response,extra=log_context)


        log_context["time_taken"]=int(time.time()-start_time)
        logger.info(" name function export_je_data ends",extra=log_context)
        return Response(response, status=status.HTTP_200_OK)
    
    except Exception as e:
         log_context["variable_state"]=locals()
         logger.error(f" exception occured on  export_je_data {str(e)} ",exc_info=1,extra=log_context)
         raise e

    # Setting the download response
    #     response_data = HttpResponse(export_file.getvalue(), content_type='text/csv')
    #     response_data['Content-Disposition'] = 'attachment; filename=' + file_name
    #     response_data['Access-Control-Expose-Headers'] = 'Content-Disposition'
    #     return response_data
    # else:
    #     response_data = {
    #         'status': 403,
    #         'message': 'No recon found with the specified id!'
    #     }
    # else:
    #     response_data = {
    #         'status': 6002,
    #         'message': 'Un-authorized action detected!'
    #     }
    # return Response(response_data, status=status.HTTP_200_OK)


@api_view(['POST'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def direct_connect(request):
    try:
        allowed = validate_user_recon_permission(request.user.email, "write",request.data['recon_id'] )
        if not allowed:
            response_data = {
                'status': 403,
                'message': 'Un-authorized action detected!'
            }
            return Response(response_data, status=status.HTTP_403_FORBIDDEN)
        
        start_time = time.time()
        log_context = {
            "recon_id": request.data['recon_id'],
            "request_id": request.request_id,
            "user_email": request.user.email,
            "request_url": request.path,
        }
        logger.info(" direct_connect function execution start",extra=log_context)
        
        
        recon_id = request.data['recon_id']
        app_type = request.data['appType']
        app_type = 0 if app_type == "0" or app_type == 0 else 1

        if is_write_permitted(request.user.email):
            if not is_recon_signed(recon_id):
                # Retrieving job from cloud and saving the file
                instance = ReconApplications.objects.filter(recon_id=recon_id, app_name=app_type)
                if int(instance[0].import_type) == 1:
                    res = pbcs_fccs(request)
                elif int(instance[0].import_type) == 2:
                    res = pbcs_fccs(request)
                elif int(instance[0].import_type) == 3:
                    res = onestream(request)
                elif int(instance[0].import_type) == 4:
                    res = "Undefined for HFM"  # HFM
                elif int(instance[0].import_type) == 5:
                    res = Essbase(request)  # Essbase
                else:
                    res = {
                        'status': 6002,
                        'message': 'Unsupported import type selected'
                    }
                # etl = []

                if type(res) is list:
                    for i in range(len(res[0])):
                        file_name = res[0][i]

                        # Performing pbcs/fccs ETL
                        etl = (pbcs_fccs_etl(recon_id, file_name))

                    response_data = {
                        'status': 200,
                        'headers': etl,
                        'files': res[0],
                    }
                else:
                    response_data = res
            else:
                response_data = {
                        'status': 403,
                        'message': 'This Recon is Signed Off'
                    }        
        else:
            response_data = {
                'status': 6002,
                'message': 'Un-authorized action detected!'
            }
        
        if response_data.get("status")==200:
            user_logger.info("Imported the source data via direct connect",extra=log_context)
        else:
            logger.error(response_data,extra=log_context)
        
        
        return Response(response_data, status=status.HTTP_200_OK)
    
    except Exception as e:

        log_context["variable_state"]=locals()
        logger.error(f" exception occured on  direct_connect {str(e)} ",exc_info=1,extra=log_context)
        raise e


@api_view(['POST'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def dim_tag(request):
    allowed = validate_user_recon_permission(request.user.email, "write",request.data['recon_id'] )
    if not allowed:
        response_data = {
            'status': 403,
            'message': 'Un-authorized action detected!'
        }
        return Response(response_data, status=status.HTTP_403_FORBIDDEN)
    
    recon_id = request.data['recon_id']
    app_type = request.data['appType']

    max_rows = int(request.data['max_rows'])
    page_number = int(request.data['page_number'])
    start_point = (page_number - 1) * max_rows
    end_point = page_number * max_rows

    recon_data = get_recon(recon_id)
    recon_name = recon_data['name']
    app1_id = recon_data['app1_id']
    app2_id = recon_data['app2_id']
    app_id = recon_data['app1_id'] if app_type == '0' else recon_data['app2_id']
    inverse_app_id = recon_data['app2_id'] if app_type == '0' else recon_data['app1_id']

    if is_write_permitted(request.user.email):
        if not is_recon_signed(recon_id) :        
            file_names = request.data['files']
            headers = request.data['headers']

            for i in range(len(file_names)):
                file = file_names[i]
                filepath = str(settings.MEDIA_ROOT + "/" + str(recon_id) + "/" + file)
                file_location = filepath.replace(file, '')

                # Tagging headers to dimensions
                tag_dim(recon_id, filepath, headers, app_type)

                # Validating all the pre-requisites
                is_valid = is_import_valid(recon_id, app_type, filepath)

                if is_valid['status'] == 200:
                    # Calling the dynamic table create SP
                    create_dtable = call_sp_params('fileService.sp_create_dynamic_table', [app_id, False], 2)
                    table_exists = is_exists('fileservice', 'app_' + str(recon_id) + '_' + str(inverse_app_id))

                    # Check if table exists for other app
                    if not table_exists['rows'][0]['exists']:
                        call_sp_params('fileService.sp_create_dynamic_table', [inverse_app_id, False], 2)

                    if create_dtable['status'] == 200:
                        # Saving the file details in DB
                        file_load = TrackFileLoadStatus(recon_id=recon_id, app_id=app_id,
                                                        file_location=file_location, file_name=file,
                                                        uploaded_by=request.user.email,is_je_file=False,file_type="app")
                        file_load.save()

                        # Calling the load data SP
                        load_data = call_sp_params('fileService.sp_load_dynamic_table', [app_id, False], 2)

                        if load_data['status'] == 200:
                            create_view = call_sp_params('fileService.sp_create_recon_app_view', [recon_id, False], 2)
                            if create_view['status'] == 200:
                                view_query = 'SELECT * FROM fileService.view_' + str(recon_id) + \
                                            ' WHERE app_id=' + str(app_id) + ' LIMIT ' + str(end_point) + \
                                            ' OFFSET ' + str(start_point)
                                response_data = get_view_data(view_query, app1_id, app2_id)
                            else:
                                response_data = create_view
                        else:
                            response_data = load_data
                    else:
                        response_data = create_dtable
                else:
                    response_data = is_valid
        else:
            response_data = {
                    'status': 403,
                    'message': 'This Recon is Signed Off'
                }            
    else:
        response_data = {
            'status': 6002,
            'message': 'Un-authorized action detected!'
        }

    return Response(response_data, status=status.HTTP_200_OK)



@api_view(['PUT'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def je_update(request):
    # Getting the data from request
    try:
        allowed = validate_user_recon_permission(request.user.email, "write",request.data['recon_id'] )
        if not allowed:
            response_data = {
                'status': 403,
                'message': 'Un-authorized action detected!'
            }
            return Response(response_data, status=status.HTTP_403_FORBIDDEN)
        
        start_time = time.time()
        log_context = {
            "recon_id": request.data['recon_id'],
            "request_id": request.request_id,
            "user_email": request.user.email,
            "request_url": request.path,
            "event_stage": 'Runimport'
        }
        logger.info(" je_update function execution start",extra=log_context)
        
        recon_id = request.data['recon_id']
        app_type = str(request.data['app_type'])
        new_rows = request.data['rows']
        record_id = request.data['record_id'] if request.data['record_id'] != '' else 0
        # Checking if recon exists or not deleted
        if recon_id != '' and Recon.objects.filter(recon_id=recon_id, is_deleted=False).exists():
            recon_data = get_recon(recon_id)
            app_id = recon_data['app1_id'] if app_type == '0' else recon_data['app2_id']
            inverse_app_id = recon_data['app2_id'] if app_type == '0' else recon_data['app1_id']

            if is_write_permitted(request.user.email):
                if not is_recon_signed(recon_id) :
                    je_table_name = 'je_' + str(recon_id) + '_' + str(app_id)
                    row_headers = ['app_id']
                    row_headers.extend(list(new_rows.keys()))
                    row_headers = '","'.join(row_headers)
                    row_headers = '"' + row_headers + '"'

                    row_values = [app_id]
                    row_values.extend(list(new_rows.values()))
                    row_values = [str(x) for x in row_values]
                    row_values = "','".join(row_values)
                    row_values = "'" + row_values + "'"

                    # print(row_headers)
                    
                    # Check if table exists je for app
                    table_exists = is_exists('fileservice', 'je_' + str(recon_id) + '_' + str(app_id))            
                    if not table_exists['rows'][0]['exists']:
                        call_sp_params('fileService.sp_create_dynamic_table', [app_id, True], 2)
                    # Check if table exists je for inverse app    
                    table_exists2 = is_exists('fileservice', 'je_' + str(recon_id) + '_' + str(inverse_app_id))
                    if not table_exists2['rows'][0]['exists']:
                        call_sp_params('fileService.sp_create_dynamic_table', [inverse_app_id, True], 2)

                    # creating view since get api used view_je_<recon_id>
                    view_exists = is_exists('fileservice', 'view_je_' + str(recon_id))    
                    if not view_exists['rows'][0]['exists']:
                        create_view = call_sp_params('fileService.sp_create_recon_app_view', [recon_id, True], 2)  
                    
                    # Check if rec_id exists in the table or not
                    check_query = f"SELECT * FROM fileservice.{je_table_name} WHERE record_id={record_id}"
                    check_result = call_query(check_query)


                    if check_result['status'] == 200 and len(check_result['rows']) > 0:
                        # Update the row if rec_id exists
                        object_query = f"UPDATE fileservice.{je_table_name} SET "
                        for key, value in new_rows.items():
                            object_query += f"\"{key}\"='{value}',"
                        object_query = object_query[:-1]
                        object_query += f" WHERE record_id={record_id}"
                        exec_query = call_generic_query(object_query)
                        # print(object_query)
                        # adding record id and app type to the object
                        new_rows['record_id']=record_id
                        new_rows['app_type']=app_type
                        if exec_query['status'] == 200:
                            response_data = {
                                'status': 200,
                                'message': 'JE row updated successfully!',
                                'row':new_rows,
                            }
                        else:
                            response_data = exec_query

                    else:
                        # Remove record_id from row_headers
                        # if row_headers.__contains__('record_id'):
                        #     print(row_headers.index())

                        # Insert a new row if rec_id does not exist
                        object_query = 'INSERT INTO fileservice.{table_name}({row_headers}) VALUES({row_values})'
                        object_query = object_query.format(table_name=je_table_name, row_headers=row_headers,
                                                        row_values=row_values)
                        exec_query = call_generic_query(object_query)                                                
                        if exec_query['status'] == 200:
                            last_query  = f"SELECT {str(row_headers)},\"record_id\" FROM fileservice.{je_table_name} ORDER BY record_id DESC"
                            last_result = call_query(last_query)
                            updated_row =last_result['rows'][0]
                            updated_row['app_type']=app_type
                            if(len(last_result['rows']) > 0):
                                response_data = {
                                    'status': 200,
                                    'message': 'JE row added successfully!',
                                    'row':updated_row
                                }
                            else :
                                response_data = {
                                    'status': 6002,
                                    'message': 'Unable to fetch the inserted row'
                                }   
                        else:
                            response_data = exec_query
                else:
                    response_data = {
                        'status': 403,
                        'message': 'This Recon is Signed Off'
                    }
            else:
                response_data = {
                    'status': 6002,
                    'message': 'Un-authorized action detected!'
                }
        else:
            response_data = {
                'status': 403,
                'message': 'No recon found with the specified id!'
            }


        log_context["time_taken"]=int(time.time()-start_time)
        logger.info(" je_update function execution ends",extra=log_context)
        
        if response_data.get("status")==200:
            user_logger.info("Updating the journal entry",extra=log_context)

        logger.error(response_data,extra=log_context)

        return Response(response_data, status=status.HTTP_200_OK)
    
    except Exception as e:
        log_context["variable_state"]=locals()
        logger.error(f" exception occured on  je_update {str(e)} ",exc_info=1,extra=log_context)
        raise e

@api_view(['DELETE'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def je_delete(request):

    try:
        allowed = validate_user_recon_permission(request.user.email, "delete", request.data['recon_id'])
        if not allowed:
            response_data = {
                'status': 403,
                'message': 'Un-authorized action detected!'
            }
            return Response(response_data, status=status.HTTP_403_FORBIDDEN)
        
        # Getting the data from request
        recon_id = request.data['recon_id']
        app_type = request.data['app_type']
        record_id = request.data['record_id']
        start_time = time.time()
        log_context = {
            "recon_id": request.data['recon_id'],
            "request_id": request.request_id,
            "user_email": request.user.email,
            "request_url": request.path,
            "event_stage": 'Runimport'
        }
        logger.info(" je_delete function execution start",extra=log_context)
        
        # Checking if recon exists or not deleted
        if recon_id != '' and Recon.objects.filter(recon_id=recon_id, is_deleted=False).exists():
            recon_data = get_recon(recon_id)
            app_id = recon_data['app1_id'] if app_type == '0' else recon_data['app2_id']

            if is_write_permitted(request.user.email):
                if not is_recon_signed(recon_id) :
                    je_table_name = 'je_' + str(recon_id) + '_' + str(app_id)
                    object_query = f"DELETE FROM fileservice.{je_table_name} WHERE record_id = '{record_id}'"
                    object_query = object_query.format(table_name=je_table_name,record_id=record_id)
                    exec_query = call_generic_query(object_query)

                    if exec_query['status'] == 200:
                        response_data = {
                            'status': 200,
                            'message': 'JE rows Deleted successfully!'
                        }
                    else:
                        response_data = exec_query
                else:
                    response_data = {
                        'status': 403,
                        'message': 'This Recon is Signed Off'
                    }        
            else:
                response_data = {
                    'status': 6002,
                    'message': 'Un-authorized action detected!'
                }
        else:
            response_data = {
                'status': 403,
                'message': 'No recon found with the specified id!'
            }
        
        if response_data.get("status")==200:
            user_logger.info("Delted journal entry record",extra=log_context)

        logger.error(response_data,extra=log_context)

        log_context["time_taken"]=int(time.time()-start_time)
        logger.info(" je_delete function execution ends",extra=log_context)
        return Response(response_data, status=status.HTTP_200_OK)
    
    except Exception as e:
        log_context["variable_state"]=locals()
        logger.error(f" exception occured on  je_delete {str(e)} ",exc_info=1,extra=log_context)
        raise e


@api_view(['GET'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def osname(request):
    email = request.user.email
    instance = ReconUser.objects.filter(email=email)
    instance = instance[0]
    if instance.onestream:
        admin_tag = instance.admin_tag
        onestream_instance = DCUser.objects.filter(email=admin_tag)
        serializer = OsnameSerializer(onestream_instance, many=True)
        response_data = {
            'status': 200,
            'data': serializer.data
        }
    return Response(response_data, status=status.HTTP_200_OK)


@api_view(['POST'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def onestream_details(request):
    try:
        allowed = validate_user_recon_permission(request.user.email, "write", request.data['recon_id'])
        if not allowed:
            response_data = {
                'status': 403,
                'message': 'Un-authorized action detected!'
            }
            return Response(response_data, status=status.HTTP_403_FORBIDDEN)
        
        start_time = time.time()
        log_context = {
            "recon_id": request.data['recon_id'],
            "request_id": request.request_id,
            "user_email": request.user.email,
            "request_url": request.path,
        }
        logger.info(" onestream_details function execution start",extra=log_context)
       
        recon_id = request.data['recon_id']
        email = request.data['email']
        # app_type = request.data['appType']
        # os_name = request.data['osname']
        # application_name = request.data['application_name']
        # cube_name = request.data['cube_name']
        # dimensions = request.data['dimensions']
        # max_rows = int(request.data['max_rows'])
        # page_number = int(request.data['page_number'])

        if is_write_permitted(request.user.email):
            if not is_recon_signed(recon_id):
                serialized = OnestreamDetailsSerializer(data=request.data)
                if serialized.is_valid():
                    # new_onestream_details = OneStream(recon_id=recon_id, email=email, appType=app_type, osname=os_name,
                    #                                   application_name=application_name, cube_name=cube_name,
                    #                                   dimensions=dimensions)
                    #new_onestream_details.save()
                    serialized.save()
                    response_data = {
                        'status': 200,
                        'data': serialized.data,
                        'message': 'details saved successfully!'
                    }
                    return Response(response_data, status=status.HTTP_200_OK)
                else:
                    response_data = {
                        'status': 403,
                        'message': 'The serializer invalid'
                    }
            else:
                response_data = {
                    'status': 403,
                    'message': 'This Recon is Signed Off'
                }
        else:
            response_data = {
                'status': 6002,
                'message': 'Un-authorized action detected!'
        }
            

        if response_data.get("status")==200:
            user_logger.info("User saved detail regarding onestream",extra=log_context)
        else:
            logger.error(response_data,extra=log_context)

        log_context["time_taken"]=int(time.time()-start_time)
        logger.info(" one_Stream_details function execution ends",extra=log_context)

        return Response(response_data, status=status.HTTP_200_OK)
    
    except Exception as e:
        log_context["variable_state"]=locals()
        logger.error(f" exception occured on  one_stream_details {str(e)} ",exc_info=1,extra=log_context)
        raise e


@api_view(['GET'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def getOnestream_details(request,recon_id):

    try:
        allowed = validate_user_recon_permission(request.user.email, "read",recon_id )
        if not allowed:
            response_data = {
                'status': 403,
                'message': 'Un-authorized action detected!'
            }
            return Response(response_data, status=status.HTTP_403_FORBIDDEN)
        
        start_time = time.time()
        log_context = {
                "recon_id": recon_id,
                "request_id": request.request_id,
                "user_email": request.user.email,
                "request_url": request.path,
            }
        logger.info(" getonestreamdetails function execution start",extra=log_context)
        # print(recon_id,"reconid")
        if recon_id != '' and Recon.objects.filter(recon_id=recon_id, is_deleted=False).exists():
            instance = OneStream.objects.filter(recon_id=recon_id)
            # filter(recon_id=recon_id)
            #print(instance[0].recon_id)
            # print(str(instance.recon_id))
            #instance = instance[0]
            #print(str(instance[0]),"instance")
            serialized = OnestreamGetSerializer(instance,many=True)
            # print(serialized)
            response_data = {
                'status': 200,
                'data': serialized.data,
            }
        else:
            response_data = {
                'status': 403,
                'message': 'No recon found with the specified id!'
            }

        if response_data.get("status")!=200:
            logger.error(response_data,extra=log_context)
        
        log_context["time_taken"]=int(time.time()-start_time)
        logger.info(" get_onstream detaiks function execution ends",extra=log_context)
        
        return Response(response_data, status=status.HTTP_200_OK)
    
    except Exception as e:

        log_context["variable_state"]=locals()
        logger.error(f" exception occured on  getonestream details {str(e)} ",exc_info=1,extra=log_context)
        raise e
    

    
@api_view(['GET'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def file_details(request,recon_id):

    try:
        start_time = time.time()
        log_context = {
                "recon_id": recon_id,
                "request_id": request.request_id,
                "user_email": request.user.email,
                "request_url": request.path,
                "event_stage": 'Runimport'
            }
        logger.info(" file_details function execution start",extra=log_context)
        app1_id,app2_id=get_app_ids(recon_id)
        
        app1_file,app1_je_file=get_file_names(app1_id)

        app2_file,app2_je_file=get_file_names(app2_id)

        response_data={
            "status":200,
            "app1_file_details":app1_file,
            "app2_file_details":app2_file,
            "app1_je_file_details":app1_je_file,
            "app2_je_file_details":app2_je_file
        }

        
        
        
        log_context["time_taken"]=int(time.time()-start_time)
        logger.info(" file_details  function execution ends",extra=log_context)
        
        return Response(response_data, status=status.HTTP_200_OK)
    
    except Exception as e:

        log_context["variable_state"]=locals()
        logger.error(f" exception occured on  file_details  {str(e)} ",exc_info=1,extra=log_context)
        raise e