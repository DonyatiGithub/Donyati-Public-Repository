from ...models import ReconUser, ReconApplications, OneStream_conn, ReconDimensions
from django.conf import settings
from Crypto.Cipher import AES
from zipfile import ZipFile
import zipfile
from ...utils.user_permissions import is_write_permitted
import requests
import time
import os
import pandas as pd
import json
from pandas import json_normalize
from ..serializers import DimensionNameSerializer
from .upload_file_to_db import upload_to_db
import datetime
from .EssbaseDataRecon import CustomTabDelimetedReportMDX

def pbcs_fccs(request):
    email = request.data['email']
    recon_id = request.data['recon_id']
    app_type = request.data['appType']
    app_type = 0 if app_type == 0 else 1
    dc_jobname = request.data['jobname']

    app_instance = ReconApplications.objects.filter(recon_id=recon_id, app_name=app_type)[0]
    delimiter = app_instance.import_delimiter

    instance = ReconUser.objects.filter(email=email)
    instance = instance[0]
    # dc_url = instance.DC_Url
    dc_username = instance.DC_Username

    instance_url = ReconApplications.objects.filter(recon_id=recon_id, app_name=app_type)
    instance_url = instance_url[0]
    dc_url = instance_url.url

    key = b"\xf82\xea\xaap@\n'Yw\x10B\xd8b\xac\xc6"

    instance = ReconUser.objects.filter(email=email)[0]

    dc_password = bytes(instance.DC_Password)

    tag = bytes(instance.tag)

    nonce = bytes(instance.nonce)

    cipher = AES.new(key, AES.MODE_EAX, nonce)
    plaintext = cipher.decrypt_and_verify(dc_password, tag)

    dc_password = plaintext.decode()

    params = {
        "jobType": "EXPORT_DATA", "jobName": dc_jobname,
        "parameters": {
            "ExportFileName": "Direct_Connect_ExportData.zip"
        }
    }

    # Getting the app name for the Hyperion platform
    dc_appname = requests.get(dc_url + "/HyperionPlanning/rest/v3/applications",
                              auth=(dc_username, dc_password))
    dc_appname = dc_appname.json()
    dc_appname = dc_appname['items']
    dc_appname = dc_appname[0]['name']

    # Getting the job details from the platform
    dc_response = requests.get(dc_url + "/HyperionPlanning/rest/v3/applications/" + dc_appname + "/jobdefinitions",
                               auth=(dc_username, dc_password))

    dc_obj = dc_response.json()
    dc_obj = dc_obj['items']
    job_exists = False
    for i in dc_obj:
        if i['jobName'] == dc_jobname:
            job_exists = True

    # Prepping the job to be exported from the cloud
    if job_exists:
        export_obj = requests.post(dc_url + "/HyperionPlanning/rest/v3/applications/" + dc_appname + "/jobs",
                                   auth=(dc_username, dc_password), json=params)
        export_obj = export_obj.json()
        job_id = export_obj['jobId']

        time.sleep(7)

        # Downloading the export file from the cloud
        dc_file = requests.get(
            dc_url + "/interop/rest/11.1.2.3.600/applicationsnapshots/" + dc_jobname + ".zip/contents",
            auth=(dc_username, dc_password))

        # Creating the folder if the folder doesn't exist
        folder_path = os.path.join(settings.MEDIA_ROOT, str(recon_id))
        if not os.path.exists(folder_path):
            os.makedirs(folder_path)

        # Saving as a zip file
        with open(settings.MEDIA_ROOT + "/" + str(recon_id) + "/" + dc_jobname + ".zip", 'wb') as fd:
            for chunk in dc_file.iter_content():
                fd.write(chunk)

        zipfilepath = settings.MEDIA_ROOT + "/" + str(recon_id) + "/" + dc_jobname + ".zip"
        cont = zipfile.ZipFile(zipfilepath)
        cont = cont.namelist()
        file_name = []
        filepath = []
        for file in cont:
            file_name.append(file)
            filepath.append(str(settings.MEDIA_ROOT + "/" + str(recon_id) + "/" + file))

            with ZipFile(settings.MEDIA_ROOT + "/" + str(recon_id) + "/" + dc_jobname + ".zip", 'r') as zObject:
                # Extracting all the members of the zip
                # into a specific location.
                zObject.extractall(
                    path=settings.MEDIA_ROOT + "/" + str(recon_id))

        file_location = filepath[0].replace(cont[0], '')
        response_data = [file_name, file_location, filepath]
    else:
        response_data = {
            'status': 6002,
            'message': 'Please Enter A Valid Job Name'
        }

    return response_data


def onestream(request):
    email = request.data['email']
    recon_id = request.data['recon_id']
    app_type = request.data['appType']
    osname = request.data['osname']
    app_type = 0 if app_type == "0" else 1

    onestream_instance = OneStream_conn.objects.filter(email=email)
    onestream_instance = onestream_instance[0]
    onestream_url = onestream_instance.os_url
    pat = onestream_instance.pat

    key = b"\xf82\xea\xaap@\n'Yw\x10B\xd8b\xac\xc6"

    tag = bytes(onestream_instance.tag)

    nonce = bytes(onestream_instance.nonce)

    cipher = AES.new(key, AES.MODE_EAX, nonce)
    plaintext = cipher.decrypt_and_verify(pat, tag)

    pat = plaintext.decode()

    application_name = request.data['application_name']

    cube_name = request.data['cube_name']
    custom_subs = 'RecCube=' + cube_name
    dimensions = request.data['dimensions']

    # copying year and period value into variable to combine into time and send it via API
    Year = dimensions['year']
    Period = dimensions['period']

    # dropping the objects year and period
    dimensions.pop('year')
    dimensions.pop('period')

    # grouping year and period to send through API
    TIME = Year + Period
    dimensions['TIME'] = TIME
    for key, value in dimensions.items():
        key = 'Rec' + key + '='
        custom_subs += ',' + key + value

    params = {
        'BaseWebServerUrl': onestream_instance.dc_url+"/OneStreamWeb",
        'ApplicationName': application_name,
        'AdapterName': 'DataRecon',
        'ResultDataTableName': 'ResultsTable',
        'IsSystemLevel': 'False',
        'CustomSubstVarsAsCommaSeparatedPairs': custom_subs
    }

    headers = {
        'Authorization': 'Bearer ' + pat,
        'Content-Type': 'application/json'
    }

    extracted_data = requests.post(
        onestream_url + "/OneStreamApi/api/DataProvider/GetAdoDataSetForAdapter?api-version=5.2.0",
        headers=headers, json=params)
    # converting the json into a dataframe
    if extracted_data.status_code == 200:
        data = json.loads(extracted_data.text)
        df_onestream = json_normalize(data['ResultsTable'])

        # Extract the year and period substrings from the time column
        df_onestream['year'] = df_onestream['Time'].str.slice(stop=4)
        df_onestream['period'] = df_onestream['Time'].str.slice(start=4)

        # dropping the time column
        df_onestream.drop('Time', axis=1, inplace=True)

        # capitalizing the headers
        df_onestream.columns = df_onestream.columns.str.upper()
        headers = list(df_onestream.columns)

        app_instance = ReconDimensions.objects.filter(is_deleted=False, recon_id=recon_id, app_type=app_type,
                                                      dim_in_file='YES', is_active=True)
        app_serialized = DimensionNameSerializer(app_instance, many=True)

        for dim in app_serialized.data:
            dim['type_field'] = int(dim['type_field'])  # Converting type_field to integer

        srt = sorted(app_serialized.data,
                     key=lambda x: x['type_field'])  # sorting ordered dictionary based on the type_field value

        ordered_dimensions = [x['dimension'] for x in srt]
        diff_dim = set(headers) - set(ordered_dimensions)

        for dim in diff_dim:
            df_onestream.drop(dim, axis=1, inplace=True)

        df = df_onestream.loc[:, ordered_dimensions]

        file_name = str(recon_id) + str(datetime.datetime.now().timestamp()) + 'OneStream_Extract.csv'

        file_path = str(settings.MEDIA_ROOT + "/" + str(recon_id) + "/"+file_name)

        if not os.path.exists(os.path.dirname(file_path)):
            os.makedirs(os.path.dirname(file_path))

        df.to_csv(file_path, index=False)

        file_names = [file_name]

        response_data = upload_to_db(request, file_names)
    else:
        response_data = {
            'status': 6002,
            'message': 'Please make the right selections'
        }

    return response_data


def Essbase(request):
    recon_id = request.data['recon_id']
    EssbaseServerName = request.data['EssbaseServerName']
    email = request.data['email']
    app_type = request.data['appType']
    app_type = 0 if app_type == "0" else 1

    mdx_instance = ReconApplications.objects.filter(recon_id=recon_id, app_name=app_type)
    mdx_instance = mdx_instance[0]
    mdxquery = mdx_instance.mdxquery

    instance = DCUser.objects.filter(email=email, ebase_server=EssbaseServerName)
    instance = instance[0]

    # Essbase Creds from db
    EssbaseServerName = instance.ebase_server
    EssbaseProviderServicesURL = instance.ebaseproservicesurl
    EssbaseUserName = instance.ebase_uname
    EssbaseApplicationName = instance.ebaseapp_name
    EssbaseDatabaseName = instance.ebasedb_name
    EssbasePassword = instance.ebase_password
    Essnonce = instance.nonce
    Esstag = instance.tag

    # Decrypting password
    key = b"\xf82\xea\xaap@\n'Yw\x10B\xd8b\xac\xc6"
    tag = bytes(Esstag)
    nonce = bytes(Essnonce)
    cipher = AES.new(key, AES.MODE_EAX, nonce)
    plaintext = cipher.decrypt_and_verify(EssbasePassword, tag)
    ess_pwd = plaintext.decode()

    Py4jServerName = "127.0.0.1"
    Py4jPortNumber = 25333

    # OutputFilePath = "./essout.txt"

    # OutputFilePath = settings.MEDIA_ROOT + "/" + str(recon_id) + "/essout.txt"

    file_name = str(recon_id) + str(datetime.datetime.now().timestamp()) + 'essout.txt'

    file_path = str(settings.MEDIA_ROOT + "/" + str(recon_id) + "/" + file_name)

    if not os.path.exists(os.path.dirname(file_path)):
        os.makedirs(os.path.dirname(file_path))

    CustomTabDelimetedReportMDX(mdxquery, EssbaseServerName, EssbaseProviderServicesURL, Py4jServerName, Py4jPortNumber, EssbaseUserName, ess_pwd, EssbaseApplicationName, EssbaseDatabaseName, file_path)

    with open(file_path, 'r') as input_file:
        lines = input_file.readlines()
    header = lines[0].strip().replace('\t', ',')
    data_rows = [line.strip().replace('\t', ',') for line in lines[1:]]
    with open(file_path, 'w') as output_file:
        output_file.write(header + '\n')
        output_file.write('\n'.join(data_rows))

    file_names = [file_name]

    response_data = upload_to_db(request, file_names)

    return response_data