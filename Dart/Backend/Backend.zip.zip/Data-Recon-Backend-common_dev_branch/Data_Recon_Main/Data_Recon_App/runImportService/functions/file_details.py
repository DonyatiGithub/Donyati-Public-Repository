from ...models import TrackFileLoadStatus



def get_file_names(app_id):
    
    file_data_list=[]
    file_data_je_list=[]
    file_datas=TrackFileLoadStatus.objects.filter(app_id=app_id,file_type="app").order_by('-created_date')
    for file_data in file_datas:

        file_detail={}
        file_detail["file_id"]=file_data.file_id
        file_detail["file"]=file_data.file_name[file_data.file_name.find("_",file_data.file_name.find("_")+1)+1:]
        file_detail["status"]=file_data.status
        file_detail["time_stamp"]=file_data.created_date.strftime('%Y-%m-%dT%H:%M:%SZ')
        file_detail["uploaded_by"]=file_data.uploaded_by

        if not file_data.is_je_file:
            file_data_list.append(file_detail)
        else:
            file_data_je_list.append(file_detail)

    return file_data_list,file_data_je_list
    
