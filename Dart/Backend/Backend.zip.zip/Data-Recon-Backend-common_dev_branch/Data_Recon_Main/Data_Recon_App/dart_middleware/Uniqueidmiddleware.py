import uuid

class UUIDMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        # 1. Generate a new UUID.
        request.request_id = str(uuid.uuid4())

        response = self.get_response(request)

        # 2. Add the UUID to the response header.
        response['request_id'] = request.request_id

        return response
