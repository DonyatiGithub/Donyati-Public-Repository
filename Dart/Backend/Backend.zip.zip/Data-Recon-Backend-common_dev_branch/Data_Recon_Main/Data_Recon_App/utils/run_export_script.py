from django.conf import settings
import subprocess
import shlex
import os
import csv


def run_export_script(recon_id, file_name, query,variance=None, variance_percentage=None):

    # creating the folder if it does not exist
    folder_path = os.path.join(settings.MEDIA_ROOT, str(recon_id))
    if not os.path.exists(folder_path):
        os.makedirs(folder_path)

    export_path = folder_path + "/export"
    if not os.path.exists(export_path):
        os.makedirs(export_path)


    if variance is not None or variance_percentage is not None:
            file_location=os.path.join(settings.MEDIA_ROOT,str(recon_id)+'/export/'+file_name)
            with open(file_location, mode='w') as employee_file:
                    variance_writer = csv.writer(employee_file, delimiter=',', quotechar='"', quoting=csv.QUOTE_MINIMAL)

                    variance_writer.writerow([f'variance_threshold = {variance}'])
                    variance_writer.writerow([f'variance_percentage = {variance_percentage}'])

    # print(os.name)
    if os.name=='nt':
        # print('Windows')
        if variance is not None:
            args_in = shlex.split('psql -U user_dataRecon_file -d db_dataRecon -c "copy ('+query+') to STDOUT '+ f' with delimiter \',\' NULL \'\' csv HEADER" >> {file_location}')
            # Calling the Shell script
            subprocess.run(args_in,shell=True,capture_output=False)

        else:
            args_in = shlex.split('psql -U user_dataRecon_file -d db_dataRecon -c "copy ('+query+') to \''+os.path.join(settings.MEDIA_ROOT,str(recon_id)+'\\export\\'+file_name)+'\' with delimiter \',\' NULL \'\' csv HEADER"')
            # Calling the Shell script
            subprocess.run(args_in,shell=True,capture_output=False)
    else:
        # print('Not Windows')
        #query = query.replace('"','\\\"')
        # Changing the permissions for the file
        subprocess.call(["chmod 777 " + settings.MEDIA_ROOT + "/" + str(recon_id) + "/export"], shell=True)
        # Calling the Shell script
        # p = subprocess.Popen([settings.MEDIA_ROOT + '/run_all_scripts.sh -u postgres -f '+ settings.MEDIA_ROOT + str(recon_id) + '/export/' + file_name + ' -e -q "' + str(query) + '"'], shell=True)
        
        if variance is not None or variance_percentage is not None:
            p = subprocess.Popen(['psql -h localhost -p 5432 -U user_dataRecon_file -d db_dataRecon -c "\copy ('+query+') to STDOUT '+f' with delimiter \',\' NULL \'\' csv HEADER" >> {file_location}'], shell=True)
            p.wait()        
        else:
            p = subprocess.Popen(['psql -h localhost -p 5432 -U user_dataRecon_file -d db_dataRecon -c "\copy ('+query+') to \''+os.path.join(settings.MEDIA_ROOT,str(recon_id)+'/export/'+file_name)+'\' with delimiter \',\' NULL \'\' csv HEADER"'], shell=True)
            p.wait()
    
    # print('Success') if p==0 else print('Failed')





def group_export_script(file_name, query):

    folder_path = os.path.join(settings.MEDIA_ROOT, "groups", "export")
    if not os.path.exists(folder_path):
        os.makedirs(folder_path)

    # print(os.name)
    if os.name=='nt':
        # print('Windows')
        args_in = shlex.split('psql -U user_dataRecon_file -d db_dataRecon -c "copy ('+query+') to \''+os.path.join(settings.MEDIA_ROOT+'\\groups\\'+'\\export\\'+file_name)+'\' with delimiter \',\' NULL \'\' csv HEADER"')
        # Calling the Shell script
        subprocess.run(args_in,shell=True,capture_output=False)
    else:
        subprocess.call(["chmod 777 " + settings.MEDIA_ROOT + "/" + "/group"+"/export"], shell=True)

        p = subprocess.Popen(['psql -h localhost -p 5432 -U user_dataRecon_file -d db_dataRecon -c "\copy ('+query+') to \''+os.path.join(settings.MEDIA_ROOT+'/groups/'+'/export/'+file_name)+'\' with delimiter \',\' NULL \'\' csv HEADER"'], shell=True)

        
        
        
def dimension_export_script(global_var_id, file_name, query):

    # creating the folder if it does not exist
    folder_path = os.path.join(settings.MEDIA_ROOT, f"Global_Variable_{global_var_id}")
    if not os.path.exists(folder_path):
        os.makedirs(folder_path)

    export_path = folder_path + "/export"
    if not os.path.exists(export_path):
        os.makedirs(export_path)
        
    if os.name=='nt':
        # print('Windows')
        args_in = shlex.split('psql -U user_dataRecon_file -d db_dataRecon -c "copy ('+query+') to \''+os.path.join(settings.MEDIA_ROOT,str(recon_id)+'\\export\\'+file_name)+'\' with delimiter \',\' NULL \'\' csv HEADER"')
        # Calling the Shell script
        subprocess.run(args_in,shell=True,capture_output=False)
    else:
        # print('Not Windows')
        subprocess.call(["chmod 777 " + settings.MEDIA_ROOT + "/" + f"Global_Variable_{global_var_id}" + "/export"], shell=True)
        
        p = subprocess.Popen(['psql -h localhost -p 5432 -U user_dataRecon_file -d db_dataRecon -c "\copy ('+query+') to \''+os.path.join(settings.MEDIA_ROOT, f"Global_Variable_{global_var_id}" +'/export/'+file_name)+'\' with delimiter \',\' NULL \'\' csv HEADER"'], shell=True)
        p.wait()
    