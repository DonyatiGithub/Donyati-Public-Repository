from Data_Recon_App.models import UserReconPermission,Recon,ReconUser
from .user_permissions import is_admin
from ..models import GlobalVariable

def validate_user_recon_permission(email,permission,recon_id):
    
    owner=Recon.objects.filter(created_by=email,recon_id=recon_id).exists()
    user_perm=UserReconPermission.objects.filter(user_email=email,permission_name=permission,recon_id=recon_id).exists()
    admin=is_admin(email)

    allow=owner or user_perm or admin

    return allow


def check_globalvariable_owner(email,global_var_id):
    owner = GlobalVariable.objects.filter(created_by=email,global_var_id=global_var_id).exists()

    return owner