from ..models import Recon
def is_recon_signed(recon_id):
    recon_instance = Recon.objects.filter(recon_id=recon_id, is_deleted=False)[0]
    is_sign = recon_instance.sign_off  
    # return False
    return is_sign