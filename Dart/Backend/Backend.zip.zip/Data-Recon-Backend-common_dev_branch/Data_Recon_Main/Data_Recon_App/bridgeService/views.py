import copy
import csv
from datetime import datetime
import os
from django.http import HttpResponse
from rest_framework import status
from rest_framework.decorators import permission_classes, api_view, renderer_classes, parser_classes
from rest_framework.permissions import IsAuthenticated
from rest_framework.renderers import JSONRenderer
from rest_framework.response import Response
from .. utils.run_export_script import run_export_script
from .. models import ReconDimensions, Recon, ReconBridgeMapping,TrackFileLoadStatus
from .serializers import DimensionNameSerializer, BridgeGetSerializer
from rest_framework.parsers import MultiPartParser, FormParser
from .. utils.store_file import store_file
from django.db import connections
from .functions.get_import_data import get_dim_id, get_formated_bridge_data, get_import_data,bridge_data_from_query
from .functions.convert_bridge import convert_bridge
from .functions.save_bridge import save_bridge,save_bridge_import
from .functions.get_bridge_data import get_bridge_data
from .functions.get_export_data import get_export_data, get_comment_export_data, \
    get_kick_out_export_data, get_run_bridge_export_data
from .functions.add_bridge_id import add_bridge_id, add_comment_bridge_id
from .functions.get_import_comments import get_import_comments
from .functions.update_comments import update_comments
from .functions.get_comments import get_comments
from .. utils.get_recon import get_recon
from .. utils.pgsql_conn import call_sp_params
from .functions.get_view_data import get_view_data, get_kick_out_view_data
from .functions.get_import_kick_outs import get_import_kick_outs
from .functions.update_outs import update_outs
from .functions.is_bridge_exists import is_bridge_exists
from .functions.is_valid_file import is_valid_file
from ..runImportService.functions.is_exists import is_exists
from django.conf import settings
from ..utils.user_permissions import is_write_permitted
from ..utils.is_signed import is_recon_signed
import pandas as pd
from .functions.add_dim_name import add_dim_name
from ..utils.export_query import bridge_query, comment_query, bridge_kick_out_query, run_bridge_export_query
from .functions.fetch_bridge_data import fetch_bridge_data
from Data_Recon_App.utils.recon_permission_check import validate_user_recon_permission
from ..utils.app_info import get_app_ids
from .functions.file_info import bridge_file_info
import logging
import time
from ..utils.user_permission_decorator import check_user_write_access
from .functions.default_kickout import update_default_outs
from .functions.get_disk_space import get_disk_space

user_logger = logging.getLogger("userlog")
# use this user_logger to log user log 
logger = logging.getLogger("techlog")
# use 'logger' to for general application log

@api_view(['GET'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def dimension_names_list(request, recon_id):
    try:
        allowed = validate_user_recon_permission(request.user.email, "read",recon_id )
        if not allowed:
            response_data = {
                'status': 403,
                'message': 'Un-authorized action detected!'
            }
            return Response(response_data, status=status.HTTP_403_FORBIDDEN)
        
        start_time = time.time()
        log_context = {
            "recon_id": recon_id,
            "request_id": request.request_id,
            "user_email": request.user.email,
            "request_url": request.path,
            "event_stage": 'Bridgemembers'
        }
        logger.info("Dimension_names_list function execution start",extra=log_context)

        if recon_id != '' and Recon.objects.filter(recon_id=recon_id, is_deleted=False).exists():
            app_01_instance = ReconDimensions.objects.filter(is_deleted=False, recon_id=recon_id, app_type='0', is_active=True).order_by('dimensions_id','turn_on_define_order')
            app_01_serialized = DimensionNameSerializer(app_01_instance, many=True)
            
            app_02_instance = ReconDimensions.objects.filter(is_deleted=False, recon_id=recon_id, app_type='1', is_active=True).order_by('dimensions_id','turn_on_define_order')
            app_02_serialized = DimensionNameSerializer(app_02_instance, many=True)
            response_data = {
                'status': 200,
                'recon_id': recon_id,
                'app_01_dimension': app_01_serialized.data,
                'app_02_dimension': app_02_serialized.data,
            }
        else:
            response_data = {
                'status': 403,
                'message': 'No recon found with the specified id!'
            }

        if response_data.get("status")!=200:
            logger.error(response_data,extra=log_context)

        log_context["time_taken"]=int(time.time()-start_time)
        logger.info("Dimension_names_list function execution ends",extra=log_context)

        return Response(response_data, status=status.HTTP_200_OK)

    except Exception as e:
        log_context["variable_state"]=locals()
        logger.error(f" Exception occured in Dimension_names_list : {str(e)}",exc_info=1,extra=log_context)
        raise e



@api_view(['GET'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def bridge_list(request, recon_id):
    try:
        allowed = validate_user_recon_permission(request.user.email, "read",recon_id )
        if not allowed:
            response_data = {
                'status': 403,
                'message': 'Un-authorized action detected!'
            }
            return Response(response_data, status=status.HTTP_403_FORBIDDEN)
        
        start_time = time.time()
        log_context = {
            "recon_id": recon_id,
            "request_id": request.request_id,
            "user_email": request.user.email,
            "request_url": request.path,
            "event_stage": 'Bridgemembers'
        }
        logger.info("Bridge_list function execution start",extra=log_context)

        if recon_id != '' and Recon.objects.filter(recon_id=recon_id, is_deleted=False).exists():
            base_data = get_bridge_data(recon_id, '01', 'full')
            response_data = add_dim_name(recon_id, base_data)
        else:
            response_data = {
                'status': 403,
                'message': 'No recon found with the specified id!'
            }
        
        if response_data.get("status")!=200:
            logger.error(response_data,extra=log_context)

        log_context["time_taken"]=int(time.time()-start_time)
        logger.info("Bridge_list function execution ends",extra=log_context)

        return Response(response_data, status=status.HTTP_200_OK)

    except Exception as e:
        log_context["variable_state"]=locals()
        logger.error(f" Exception occured in bridge_list : {str(e)}",exc_info=1,extra=log_context)
        raise e


@api_view(['PUT'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def bridge_update(request):
    try:
        allowed = validate_user_recon_permission(request.user.email, "write", request.data['recon_id'])
        if not allowed:
            response_data = {
                'status': 403,
                'message': 'Un-authorized action detected!'
            }
            return Response(response_data, status=status.HTTP_403_FORBIDDEN)
        
        start_time = time.time()
        log_context = {
            "recon_id": request.data['recon_id'],
            "request_id": request.request_id,
            "user_email": request.user.email,
            "request_url": request.path,
            "event_stage": 'Bridgemembers'
        }
        logger.info("Bridge_update function execution start",extra=log_context)

        # Getting the data from request
        recon_id = request.data['recon_id']
        app_type = request.data['app_type']
        bridge_data = request.data

        if is_write_permitted(request.user.email):
            if not is_recon_signed(recon_id) :
                if recon_id != '' and Recon.objects.filter(recon_id=recon_id, is_deleted=False).exists():
                    # adding dim_id for new entry scenario
                    formated_data = get_formated_bridge_data(recon_id,app_type,bridge_data)
                    save_data = save_bridge(formated_data)
                    if save_data['status'] == 6002:
                        response_data = save_data
                    else:
                        base_data = get_bridge_data(recon_id, app_type, 'partial')
                        response_data = add_dim_name(recon_id, base_data)

                else:
                    response_data = {
                        'status': 403,
                        'message': 'No recon found with the specified id!'
                    }
            else:
                response_data = {
                        'status': 403,
                        'message': 'This Recon is Signed Off'
                    }
        else:
            response_data = {
                'status': 6002,
                'message': 'Un-authorized action detected!'
            }

        if response_data.get("status")==200:
            user_logger.info("Updated the bridge",extra=log_context)
        
        else:
            logger.error(response_data,extra=log_context)

        log_context["time_taken"]=int(time.time()-start_time)
        logger.info("Bridge_update function execution ends",extra=log_context)

        return Response(response_data, status=status.HTTP_200_OK)

    except Exception as e:
        log_context["variable_state"]=locals()
        logger.error(f" Exception occured in Bridge_update : {str(e)}",exc_info=1,extra=log_context)
        raise e



@api_view(['PUT'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
@parser_classes((MultiPartParser, FormParser))
def import_bridge(request):
    try:
        allowed = validate_user_recon_permission(request.user.email, "write", request.data['recon_id'])
        if not allowed:
            response_data = {
                'status': 403,
                'message': 'Un-authorized action detected!'
            }
            return Response(response_data, status=status.HTTP_403_FORBIDDEN)
        
        start_time = time.time()
        log_context = {
            "recon_id": request.data['recon_id'],
            "request_id": request.request_id,
            "user_email": request.user.email,
            "request_url": request.path,
            "event_stage": 'Bridgemembers'
        }
        logger.info("Import_bridge function execution start",extra=log_context)


        # Getting the data from request
        recon_id = request.data['recon_id']
        app_type = request.data['app_type']
        file_obj = request.FILES['bridge_file']

        if is_write_permitted(request.user.email):
            if not is_recon_signed(recon_id) :
                if recon_id != '' and Recon.objects.filter(recon_id=recon_id, is_deleted=False).exists():
                    # Storing file
                    save_file = store_file(recon_id, file_obj)
                    file_path = save_file[1]

                    is_valid = is_valid_file(file_path)
                    if is_valid['status'] == 200:
                        # Get the imported file data
                        file_data = get_import_data(recon_id, app_type, file_path)
                        response_data = copy.deepcopy(file_data)

                        # Saving the bridge info
                        if file_data['status'] == 200:
                            bridge_data = convert_bridge(file_data)
                            save_data = save_bridge(bridge_data)

                            if save_data['status'] == 6002:
                                response_data = save_data
                            else:
                                response_data = add_bridge_id(response_data)
                                # base_data = get_bridge_data(recon_id, app_type, 'F')
                                response_data = add_dim_name(recon_id, response_data)

                    else:
                        response_data = is_valid
                else:
                    response_data = {
                        'status': 403,
                        'message': 'No recon found with the specified id!'
                    }
            else:
                response_data = {
                        'status': 403,
                        'message': 'This Recon is Signed Off'
                    }
        else:
            response_data = {
                'status': 6002,
                'message': 'Un-authorized action detected!'
            }

        if response_data.get("status")==200:
            user_logger.info("Imported the bridge",extra=log_context)
        
        else:
            logger.error(response_data,extra=log_context)
        
        log_context["time_taken"]=int(time.time()-start_time)
        logger.info(" Import_bridge function execution ends",extra=log_context)

        return Response(response_data, status=status.HTTP_200_OK)

    except Exception as e:
        log_context["variable_state"]=locals()
        logger.error(f" Exception occured in Import_bridge : {str(e)}",exc_info=1,extra=log_context)
        raise e

'''
<!---------- Method to import or update bridges from json data
             and return a response ----------!>
'''
# @api_view(['PUT'])
# @permission_classes((IsAuthenticated,))
# @renderer_classes((JSONRenderer,))
# def import_single_bridge(request):
#     # Getting the data from request
#     data_object = request.data
#     recon_id = data_object['recon_id']
#     app_type = data_object['app_type']
    
    

#     if is_write_permitted(request.user.email):
#         if recon_id != '' and Recon.objects.filter(recon_id=recon_id, is_deleted=False).exists():
            
#             # getting updated file data from data_object
#             file_data = get_formated_file_data(recon_id,app_type,data_object)
#             response_data = copy.deepcopy(file_data)

#             # Saving/update the bridge info
#             # print('file'+str(file_data))
#             bridge_data = convert_bridge(file_data)
#             # print('bridge'+str(bridge_data))
#             save_data = save_bridge(bridge_data)

#             if save_data['status'] == 6002:
#                 response_data = save_data
#             else:
#                 response_data = add_bridge_id(response_data)
#                 response_data = add_dim_name(recon_id, response_data)
 
#         else:
#             response_data = {
#                 'status': 403,
#                 'message': 'No recon found with the specified id!'
#             }
#     else:
#         response_data = {
#             'status': 6002,
#             'message': 'Un-authorized action detected!'
#         }
#     return Response(response_data, status=status.HTTP_200_OK)

@api_view(['DELETE'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def delete_bridge(request):
    try:
        allowed = validate_user_recon_permission(request.user.email, "delete", request.data['recon_id'])
        if not allowed:
            response_data = {
                'status': 403,
                'message': 'Un-authorized action detected!'
            }
            return Response(response_data, status=status.HTTP_403_FORBIDDEN)
        start_time = time.time()
        log_context = {
            "recon_id": request.data['recon_id'],
            "request_id": request.request_id,
            "user_email": request.user.email,
            "request_url": request.path,
            "event_stage": 'Bridgemembers'
        }
        logger.info("Delete_bridge function execution start",extra=log_context)

        recon_id = request.data['recon_id']
        bridge_id = request.data['bridge_id']

        if is_write_permitted(request.user.email):
            if not is_recon_signed(recon_id) :
                for bridge in bridge_id:
                    if ReconBridgeMapping.objects.filter(recon_id=recon_id, bridge_id=bridge, app_type='0').exists():
                        instance = ReconBridgeMapping.objects.filter(recon_id=recon_id, bridge_id=bridge)
                        bridge_member = instance[0].bridge_member
                        instance = ReconBridgeMapping.objects.filter(recon_id=recon_id, bridge_member=bridge_member)
                        instance.delete()

                        response_data = {
                            'status': 200,
                            'message': 'Bridge deleted successfully!'
                        }
                    else:
                        response_data = {
                            'status': 403,
                            'message': 'No recon found with the specified id!'
                        }
            else:
                response_data = {
                        'status': 403,
                        'message': 'This Recon is Signed Off'
                    }
        else:
            response_data = {
                'status': 6002,
                'message': 'Un-authorized action detected!'
            }

        if response_data.get("status")==200:
            user_logger.info("Deleted the bridge",extra=log_context)
        
        else:
            logger.error(response_data,extra=log_context)

        log_context["time_taken"]=int(time.time()-start_time)
        logger.info(" Delete_bridge function execution ends",extra=log_context)

        return Response(response_data, status=status.HTTP_200_OK)

    except Exception as e:
        log_context["variable_state"]=locals()
        logger.error(f" Exception occured in Delete_bridge : {str(e)}",exc_info=1,extra=log_context)
        raise e


@api_view(['POST'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def export_bridge(request):
    try:
        allowed = validate_user_recon_permission(request.user.email, "read",request.data['recon_id'] )
        if not allowed:
            response_data = {
                'status': 403,
                'message': 'Un-authorized action detected!'
            }
            return Response(response_data, status=status.HTTP_403_FORBIDDEN)
        
        start_time = time.time()
        log_context = {
            "recon_id": request.data['recon_id'],
            "request_id": request.request_id,
            "user_email": request.user.email,
            "request_url": request.path,
            "event_stage": 'Bridgemembers'
        }
        logger.info("Export_bridge function execution start",extra=log_context)

        recon_id = request.data['recon_id']
        app_type = request.data['app_type']

        if is_write_permitted(request.user.email):
            # if not is_recon_signed(recon_id) :
                if recon_id != '' and Recon.objects.filter(recon_id=recon_id, is_deleted=False).exists():
                    app_key = 'App1' if app_type == '0' else 'App2'
                    current_time = datetime.now().time().strftime("%H:%M:%S")
                    current_date = datetime.now().strftime("%Y-%m-%d")
                    modified_date = str(current_date) + '_' + str(current_time)
                    file_name = app_key + '_Bridge_Export.csv'
                    # export_file = get_export_data(recon_id, app_type)

                    # Calling functions for query
                    query = bridge_query(recon_id, app_type)

                    # Calling the Shell script to create a csv file
                    run_export_script(recon_id, file_name, query)

                    file_path = os.path.join(settings.MEDIA_ROOT, str(recon_id) + "/export/" + file_name)
                    file_path = (str(file_path).replace("\\", "/"))

                    if os.path.exists(file_path):
                        with open(file_path, 'rb') as fh:
                            response_data = HttpResponse(fh.read(), content_type="text/csv")
                            response_data['Content-Disposition'] = 'inline; filename=' + modified_date + os.path.basename(file_path)
                            response_data['Access-Control-Expose-Headers'] = 'Content-Disposition'

                            user_logger.info("Exported the bridge ",extra=log_context)
                            log_context["time_taken"]=int(time.time()-start_time)
                            logger.info(" Export_bridge function execution ends",extra=log_context)

                            return response_data
                    else:
                        response_data = {
                            'status': 6002,
                            'message': "File Not Found"
                        }

                else:
                    response_data = {
                        'status': 403,
                        'message': 'No recon found with the specified id!'
                    }
            # else:
            #     response_data = {
            #             'status': 403,
            #             'message': 'This Recon is Signed Off'
            #     }

        else:
            response_data = {
                'status': 6002,
                'message': 'Un-authorized action detected!'
            }

        if response_data.get("status")!=200:
            logger.error(response_data,extra=log_context)

        log_context["time_taken"]=int(time.time()-start_time)
        logger.info(" Export_bridge function execution ends",extra=log_context)

        return Response(response_data, status=status.HTTP_200_OK)

    except Exception as e:
        log_context["variable_state"]=locals()
        logger.error(f" Exception occured in Export_bridge : {str(e)}",exc_info=1,extra=log_context)
        raise e



@api_view(['PUT'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
@parser_classes((MultiPartParser, FormParser))
def import_comments(request):
    try:
        allowed = validate_user_recon_permission(request.user.email, "write", request.data['recon_id'])
        if not allowed:
            response_data = {
                'status': 403,
                'message': 'Un-authorized action detected!'
            }
            return Response(response_data, status=status.HTTP_403_FORBIDDEN)
        
        start_time = time.time()
        log_context = {
            "recon_id": request.data['recon_id'],
            "request_id": request.request_id,
            "user_email": request.user.email,
            "request_url": request.path,
            "event_stage": 'Bridgemembers'
        }
        logger.info("Import_comments function execution start",extra=log_context)

        # Getting the data from request
        recon_id = request.data['recon_id']
        file_obj = request.FILES['comments_file']

        if is_write_permitted(request.user.email):
            if not is_recon_signed(recon_id) :
                if recon_id != '' and Recon.objects.filter(recon_id=recon_id, is_deleted=False).exists():
                    # Storing file
                    save_file = store_file(recon_id, file_obj)
                    file_path = save_file[1]

                    is_valid = is_valid_file(file_path)
                    if is_valid['status'] == 200:
                        # Getting file data
                        response_data = get_import_comments(recon_id, file_path, False)
                        response_data = add_comment_bridge_id(response_data)
                    else:
                        response_data = is_valid
                else:
                    response_data = {
                        'status': 403,
                        'message': 'No recon found with the specified id!'
                    }
            else:
                response_data = {
                        'status': 403,
                        'message': 'This Recon is Signed Off'
                }
        else:
            response_data = {
                'status': 6002,
                'message': 'Un-authorized action detected!'
            }

        if response_data.get("status")==200:
            user_logger.info("Imported the comments",extra=log_context)
        
        else:
            logger.error(response_data,extra=log_context)

        log_context["time_taken"]=int(time.time()-start_time)
        logger.info(" Import_comments function execution ends",extra=log_context)

        return Response(response_data, status=status.HTTP_200_OK)

    except Exception as e:
        log_context["variable_state"]=locals()
        logger.error(f" Exception occured in Import_comments : {str(e)}",exc_info=1,extra=log_context)
        raise e




@api_view(['PUT'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def comments_update(request):
    try:
        allowed = validate_user_recon_permission(request.user.email, "write",request.data['recon_id'] )
        if not allowed:
            response_data = {
                'status': 403,
                'message': 'Un-authorized action detected!'
            }
            return Response(response_data, status=status.HTTP_403_FORBIDDEN)
        
        start_time = time.time()
        log_context = {
            "recon_id": request.data['recon_id'],
            "request_id": request.request_id,
            "user_email": request.user.email,
            "request_url": request.path,
            "event_stage": 'Bridgemembers'
        }
        logger.info("Comments_update function execution start",extra=log_context)

        # Getting the data from request
        recon_id = request.data['recon_id']
        comment_data = request.data['rows']

        if is_write_permitted(request.user.email):
            if not is_recon_signed(recon_id) :
                if recon_id != '' and Recon.objects.filter(recon_id=recon_id, is_deleted=False).exists():
                    response_data = update_comments(recon_id, comment_data, False)
                else:
                    response_data = {
                        'status': 403,
                        'message': 'No recon found with the specified id!'
                    }
            else:
                response_data = {
                        'status': 403,
                        'message': 'This Recon is Signed Off'
                }
        else:
            response_data = {
            'status': 6002,
            'message': 'Un-authorized action detected!'
            }
        
        if response_data.get("status")==200:
            user_logger.info("Updated the comments",extra=log_context)
        
        else:
            logger.error(response_data,extra=log_context)

        log_context["time_taken"]=int(time.time()-start_time)
        logger.info(" Comments_update function execution ends",extra=log_context)

        return Response(response_data, status=status.HTTP_200_OK)

    except Exception as e:
        log_context["variable_state"]=locals()
        logger.error(f" Exception occured in Comments_update : {str(e)}",exc_info=1,extra=log_context)
        raise e


@api_view(['GET'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def comments_list(request, recon_id):
    try:
        allowed = validate_user_recon_permission(request.user.email, "read", recon_id)
        if not allowed:
            response_data = {
                'status': 403,
                'message': 'Un-authorized action detected!'
            }
            return Response(response_data, status=status.HTTP_403_FORBIDDEN)
        
        start_time = time.time()
        log_context = {
            "recon_id": recon_id,
            "request_id": request.request_id,
            "user_email": request.user.email,
            "request_url": request.path,
            "event_stage": 'Bridgemembers'
        }
        logger.info("Comments_list function execution start",extra=log_context)

        if recon_id != '' and Recon.objects.filter(recon_id=recon_id, is_deleted=False).exists():
            response_data = get_comments(recon_id, False)
        else:
            response_data = {
                'status': 403,
                'message': 'No recon found with the specified id!'
            }
        
        if response_data.get("status")!=200:
            logger.error(response_data,extra=log_context)

        log_context["time_taken"]=int(time.time()-start_time)
        logger.info(" Comments_list function execution ends",extra=log_context)

        return Response(response_data, status=status.HTTP_200_OK)

    except Exception as e:
        log_context["variable_state"]=locals()
        logger.error(f" Exception occured in Comments_list : {str(e)}",exc_info=1,extra=log_context)
        raise e



@api_view(['DELETE'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def delete_comment(request):
    try:
        allowed = validate_user_recon_permission(request.user.email, "delete",request.data['recon_id'] )
        if not allowed:
            response_data = {
                'status': 403,
                'message': 'Un-authorized action detected!'
            }
            return Response(response_data, status=status.HTTP_403_FORBIDDEN)
        
        start_time = time.time()
        log_context = {
            "recon_id": request.data['recon_id'],
            "request_id": request.request_id,
            "user_email": request.user.email,
            "request_url": request.path,
            "event_stage": 'Bridgemembers'
        }
        logger.info("Delete_comment function execution start",extra=log_context)

        recon_id = request.data['recon_id']
        bridge_id = request.data['bridge_id']
        app_type = request.data['app_type']

        if is_write_permitted(request.user.email):
            if not is_recon_signed(recon_id) :
                if recon_id != '' and Recon.objects.filter(recon_id=recon_id, is_deleted=False).exists():
                    instance = ReconBridgeMapping.objects.filter(recon_id=recon_id, bridge_id=bridge_id)[0]
                    if not app_type == '2':
                        instance.dim_comment = None
                    else:
                        instance.bridge_comment = None
                    instance.save()

                    response_data = {
                        'status': 200,
                        'message': 'Comment deleted successfully!'
                    }
                else:
                    response_data = {
                        'status': 403,
                        'message': 'No recon found with the specified id!'
                    }
            else:
                response_data = {
                        'status': 403,
                        'message': 'This Recon is Signed Off'
                }
        else:
            response_data = {
                'status': 6002,
                'message': 'Un-authorized action detected!'
            }
        
        if response_data.get("status")==200:
            user_logger.info("Deleted the comment",extra=log_context)
        
        else:
            logger.error(response_data,extra=log_context)

        log_context["time_taken"]=int(time.time()-start_time)
        logger.info(" Delete_comment function execution ends",extra=log_context)

        return Response(response_data, status=status.HTTP_200_OK)

    except Exception as e:
        log_context["variable_state"]=locals()
        logger.error(f" Exception occured in Delete_comment : {str(e)}",exc_info=1,extra=log_context)
        raise e


@api_view(['GET'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def comments_export(request, recon_id):
    try:
        allowed = validate_user_recon_permission(request.user.email, "read", recon_id )
        if not allowed:
            response_data = {
                'status': 403,
                'message': 'Un-authorized action detected!'
            }
            return Response(response_data, status=status.HTTP_403_FORBIDDEN)
        
        start_time = time.time()
        log_context = {
            "recon_id": recon_id,
            "request_id": request.request_id,
            "user_email": request.user.email,
            "request_url": request.path,
            "event_stage": 'Bridgemembers'
        }
        logger.info("Comments_export function execution start",extra=log_context)


        if recon_id != '' and Recon.objects.filter(recon_id=recon_id, is_deleted=False).exists():
            current_time = datetime.now().time().strftime("%H:%M:%S")
            current_date = datetime.now().strftime("%Y-%m-%d")
            modified_date = str(current_date) + '_' + str(current_time)
            file_name = 'Bridge_Comments_Export.csv'
            # export_file = get_comment_export_data(recon_id, False)

            # Calling function for export query
            query = comment_query(recon_id)

            # Calling the Shell script to create a csv file
            run_export_script(recon_id, file_name, query)

            file_path = os.path.join(settings.MEDIA_ROOT, str(recon_id) + "/export/" + file_name)
            file_path = (str(file_path).replace("\\", "/"))

            if os.path.exists(file_path):
                with open(file_path, 'rb') as fh:
                    response_data = HttpResponse(fh.read(), content_type="text/csv")
                    response_data['Content-Disposition'] = 'inline; filename=' + modified_date + os.path.basename(file_path)
                    response_data['Access-Control-Expose-Headers'] = 'Content-Disposition'

                    user_logger.info("Exported the comments ",extra=log_context)
                    log_context["time_taken"]=int(time.time()-start_time)
                    logger.info(" Comments_export function execution ends",extra=log_context)

                    return response_data
            else:
                response_data = {
                    'status': 6002,
                    'message': 'File Not Found'
                }

            # Setting the download response
            # response_data = HttpResponse(export_file.getvalue(), content_type='text/csv')
            # response_data['Content-Disposition'] = 'attachment; filename=' + file_name
            # response_data['Access-Control-Expose-Headers'] = 'Content-Disposition'
            # return response_data
        else:
            response_data = {
                'status': 403,
                'message': 'No recon found with the specified id!'
            }
        
        if response_data.get("status")!=200:
            logger.error(response_data,extra=log_context)

        log_context["time_taken"]=int(time.time()-start_time)
        logger.info(" Comments_export function execution ends",extra=log_context)

        return Response(response_data, status=status.HTTP_200_OK)

    except Exception as e:
        log_context["variable_state"]=locals()
        logger.error(f" Exception occured in Comments_export : {str(e)}",exc_info=1,extra=log_context)
        raise e


@api_view(['POST'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def run_bridge(request):
    try:
        if request.data['sp_flag']:
            allowed = validate_user_recon_permission(request.user.email, "execute", request.data['recon_id'])
        else:
            allowed = validate_user_recon_permission(request.user.email, "read", request.data['recon_id'])
        if not allowed:
            response_data = {
                'status': 403,
                'message': 'Un-authorized action detected!'
            }
            return Response(response_data, status=status.HTTP_403_FORBIDDEN)
        
        start_time = time.time()
        log_context = {
            "recon_id": request.data['recon_id'],
            "request_id": request.request_id,
            "user_email": request.user.email,
            "request_url": request.path,
            "event_stage": 'Bridgemembers'
        }
        

        # Getting the data from request
        recon_id = request.data['recon_id']
        je_flag = request.data['je_flag']
        max_rows = int(request.data['max_rows'])
        page_number = int(request.data['page_number'])
        start_point = (page_number - 1) * max_rows
        end_point = page_number * max_rows
        
        if (request.data['sp_flag']):
            sp_flag = request.data['sp_flag']
        else:
            sp_flag = False
        
        logger.info(f"Run_bridge function execution start sp_flag:{sp_flag} je_flag:{je_flag}",extra=log_context)
        
        # Checking if recon exists or not deleted
        if recon_id != '' and Recon.objects.filter(recon_id=recon_id, is_deleted=False).exists():
            recon_data = get_recon(recon_id)
            recon_name = recon_data['name']
            app1_id = recon_data['app1_id']
            app2_id = recon_data['app2_id']

            # Check if view exists
            if(je_flag):
                view_exists = is_exists('fileservice', 'view_je_' + str(recon_id))
            else:
                view_exists = is_exists('fileservice', 'view_' + str(recon_id))


            if view_exists['rows'][0]['exists']:
                # Checking if all bridge configured
                is_valid = is_bridge_exists(recon_id)

                if is_valid['status'] == 200:
                    # Calling the bridge run SP


                    if not sp_flag:
                        
                        response_data = fetch_bridge_data(recon_id,je_flag,start_point,end_point)

                        log_context["time_taken"]=int(time.time()-start_time)
                        logger.info(f"Run_bridge function execution ends sp_flag:{sp_flag} je_flag:{je_flag}",extra=log_context)

                        return Response(response_data, status=status.HTTP_200_OK)



                    if sp_flag:
                        bridge_run = call_sp_params('fileService.sp_create_recon_run_bridge_table', [recon_id,je_flag], 2)
                        if bridge_run['status'] != 200:
                            response_data = bridge_run
                            logger.error(response_data,extra=log_context)
                            return response_data

                    if bridge_run['status'] == 200:
                          
                        response_data = fetch_bridge_data(recon_id,je_flag,start_point,end_point)

                    else:
                        response_data = bridge_run
                else:
                    response_data = is_valid
            else:
                if not (je_flag):
                    response_data = {
                        'status': 6002,
                        'message': 'Please upload source file!'
                    }
                else:
                    response_data = {
                        'status': 200,
                        'message': ''
                    }
        else:
            response_data = {

                'status': 403,
                'message': 'No recon found with the specified id!'

            }


        if response_data.get("status")!=200 :
            logging.error(response_data,extra=log_context)

        else:
            user_logger.info("Bridge run sucessfully")


        log_context["time_taken"]=int(time.time()-start_time)
        logger.info(f"Run_bridge function execution ends sp_flag:{sp_flag} je_flag:{je_flag}",extra=log_context)

        return Response(response_data, status=status.HTTP_200_OK)

    except Exception as e:
        log_context["variable_state"]=locals()
        logger.error(f" Exception occured in Run_bridge : {str(e)}",exc_info=1,extra=log_context)
        raise e




@api_view(['POST'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def get_kick_outs(request):
    try:
        allowed = validate_user_recon_permission(request.user.email, "read", request.data['recon_id'])
        if not allowed:
            response_data = {
                'status': 403,
                'message': 'Un-authorized action detected!'
            }
            return Response(response_data, status=status.HTTP_403_FORBIDDEN)
        
        start_time = time.time()
        log_context = {
            "recon_id": request.data['recon_id'],
            "request_id": request.request_id,
            "user_email": request.user.email,
            "request_url": request.path,
            "event_stage": 'Bridgemembers'
        }
        logger.info("Get_kick_outs function execution start",extra=log_context)

        # Getting the data from request
        recon_id = request.data['recon_id']
        je_flag = request.data['je_flag']

        # Checking if recon exists or not deleted
        if recon_id != '' and Recon.objects.filter(recon_id=recon_id, is_deleted=False).exists():
            recon_data = get_recon(recon_id)
            recon_name = recon_data['name']
            app1_id = recon_data['app1_id']
            app2_id = recon_data['app2_id']

            if (je_flag):
                kickout_exists=is_exists("fileservice",f"view_bridge_je_{recon_id}_kickout")

            else:
                kickout_exists=is_exists("fileservice",f"view_bridge_{recon_id}_kickout")

            if kickout_exists['rows'][0]['exists']:
            # Getting both apps data
                if(je_flag):
                    view_query = 'SELECT * FROM fileservice.view_bridge_je_' + str(recon_id) + \
                                '_kickout'

                else:
                    view_query = 'SELECT * FROM fileservice.view_bridge_' + str(recon_id) + \
                                '_kickout'
                response_data = get_kick_out_view_data(view_query, app1_id, app2_id)
            
            else:
                response_data={
                    "status":200,
                    "message":"kickout does not exists"
                }
                logger.info("there is no kickout exists",extra=log_context)

        else:
            response_data = {
                'status': 403,
                'message': 'No recon found with the specified id!'
            }
        
        if response_data.get("status")!=200:
            logger.error(response_data,extra=log_context)

        log_context["time_taken"]=int(time.time()-start_time)
        logger.info("Get_kick_outs function execution ends",extra=log_context)

        return Response(response_data, status=status.HTTP_200_OK)

    except Exception as e:
        log_context["variable_state"]=locals()
        logger.error(f" Exception occured in Get_kick_outs : {str(e)}",exc_info=1,extra=log_context)
        raise e




@api_view(['PUT'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def update_kick_outs(request):
    try:
        allowed = validate_user_recon_permission(request.user.email, "write",request.data['recon_id'] )
        if not allowed:
            response_data = {
                'status': 403,
                'message': 'Un-authorized action detected!'
            }
            return Response(response_data, status=status.HTTP_403_FORBIDDEN)
        
        start_time = time.time()
        log_context = {
            "recon_id": request.data['recon_id'],
            "request_id": request.request_id,
            "user_email": request.user.email,
            "request_url": request.path,
            "event_stage": 'Bridgemembers'
        }
        logger.info("Update_kick_outs function execution start",extra=log_context)
           
        # Getting the data from request
        recon_id = request.data['recon_id']
        kick_out_rows = request.data['rows']

        if is_write_permitted(request.user.email):
            if not is_recon_signed(recon_id) :
                # Checking if recon exists or not deleted
                if recon_id != '' and Recon.objects.filter(recon_id=recon_id, is_deleted=False).exists():
                    response_data = update_outs(recon_id, kick_out_rows)
                else:
                    response_data = {
                        'status': 403,
                        'message': 'No recon found with the specified id!'
                    }
            else:
                response_data = {
                        'status': 403,
                        'message': 'This Recon is Signed Off'
                }
        else:
            response_data = {
            'status': 6002,
            'message': 'Un-authorized action detected!'
            }

        if response_data.get("status")==200:
            user_logger.info("Updated the kickouts",extra=log_context)
        
        else:
            logger.error(response_data,extra=log_context)

        log_context["time_taken"]=int(time.time()-start_time)
        logger.info("Update_kick_outs function execution ends",extra=log_context)

        return Response(response_data, status=status.HTTP_200_OK)

    except Exception as e:
        log_context["variable_state"]=locals()
        logger.error(f" Exception occured in Update_kick_outs : {str(e)}",exc_info=1,extra=log_context)
        raise e




@api_view(['POST'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def kick_out_export(request):
    try:
        allowed = validate_user_recon_permission(request.user.email, "read",request.data['recon_id'] )
        if not allowed:
            response_data = {
                'status': 403,
                'message': 'Un-authorized action detected!'
            }
            return Response(response_data, status=status.HTTP_403_FORBIDDEN)
        
        start_time = time.time()
        log_context = {
            "recon_id": request.data['recon_id'],
            "request_id": request.request_id,
            "user_email": request.user.email,
            "request_url": request.path,
            "event_stage": 'Bridgemembers'
        }
        logger.info("kick_out_export function execution start",extra=log_context)

        recon_id = request.data['recon_id']
        je_flag = request.data['je_flag']
        if is_write_permitted(request.user.email):
            # if not is_recon_signed(recon_id) :
                if recon_id != '' and Recon.objects.filter(recon_id=recon_id, is_deleted=False).exists():
                    current_time = datetime.now().time().strftime("%H:%M:%S")
                    current_date = datetime.now().strftime("%Y-%m-%d")
                    modified_date = str(current_date) + '_' + str(current_time)
                    file_name = 'Bridge_Kick_out_Export.csv'
                    recon_data = get_recon(recon_id)
                    recon_name = recon_data['name']
                    app1_id = recon_data['app1_id']
                    app2_id = recon_data['app2_id']
                    # export_file = get_kick_out_export_data(recon_id)

                    # Calling function for export query
                    query = bridge_kick_out_query(recon_id, je_flag)
                    response_data = get_kick_out_view_data(query, app1_id, app2_id)
                    if response_data.get("status")!=200:
                        return response_data
                    
                    

                    if je_flag:
                        file_name = "JE_" + file_name
                    else:
                        pass
                    file_path = os.path.join(settings.MEDIA_ROOT, str(recon_id) + "export" + file_name)
                    dataframe = pd.DataFrame(data=response_data["rows"])
                    # file_path=os.path.join(settings.MEDIA_ROOT,recon_id,file_name)
                    dataframe.to_csv(file_path,index=False)
                    # file_path = (str(file_path).replace("\\", "/"))

                    if os.path.exists(file_path):
                        with open(file_path, 'rb') as fh:
                            response_data = HttpResponse(fh.read(), content_type="text/csv")
                            response_data['Content-Disposition'] = 'inline; filename=' + modified_date + os.path.basename(file_path)
                            response_data['Access-Control-Expose-Headers'] = 'Content-Disposition'

                            user_logger.info("Exported the kickout ",extra=log_context)
                            log_context["time_taken"]=int(time.time()-start_time)
                            logger.info(" kick_out_export function execution ends",extra=log_context)

                            return response_data

                    else:
                        response_data = {
                            'status': 6002,
                            'message': 'File Not Found'
                        }

                    # Setting the download response
                    # response_data = HttpResponse(export_file.getvalue(), content_type='text/csv')
                    # response_data['Content-Disposition'] = 'attachment; filename=' + file_name
                    # response_data['Access-Control-Expose-Headers'] = 'Content-Disposition'
                    # return response_data
                else:
                    response_data = {
                        'status': 403,
                        'message': 'No recon found with the specified id!'
                    }
            # else:
            #     response_data = {
            #             'status': 403,
            #             'message': 'This Recon is Signed Off'
            #         }
        else:
            response_data = {
                'status': 6002,
                'message': 'Un-authorized action detected!'
            }

        if response_data.get("status")!=200:
            logger.error(response_data,extra=log_context)

        log_context["time_taken"]=int(time.time()-start_time)
        logger.info(" kick_out_export function execution ends",extra=log_context)

        return Response(response_data, status=status.HTTP_200_OK)

    except Exception as e:
        log_context["variable_state"]=locals()
        logger.error(f" Exception occured in kick_out_export : {str(e)}",exc_info=1,extra=log_context)
        raise e



@api_view(['PUT'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
@parser_classes((MultiPartParser, FormParser))
def import_kick_outs(request):
    try:
        allowed = validate_user_recon_permission(request.user.email, "write",request.data['recon_id'] )
        if not allowed:
            response_data = {
                'status': 403,
                'message': 'Un-authorized action detected!'
            }
            return Response(response_data, status=status.HTTP_403_FORBIDDEN)
        
        start_time = time.time()
        log_context = {
            "recon_id": request.data['recon_id'],
            "request_id": request.request_id,
            "user_email": request.user.email,
            "request_url": request.path,
            "event_stage": 'Bridgemembers'
        }
        logger.info("Import_kick_outs function execution start",extra=log_context)

        # Getting the data from request
        recon_id = request.data['recon_id']
        file_obj = request.FILES['kick_out_file']

        if is_write_permitted(request.user.email):
            if not is_recon_signed(recon_id) :
                if recon_id != '' and Recon.objects.filter(recon_id=recon_id, is_deleted=False).exists():
                    # Storing file
                    save_file = store_file(recon_id, file_obj)
                    file_path = save_file[1]

                    is_valid = is_valid_file(file_path)
                    if is_valid['status'] == 200:
                        # Getting file data
                        response_data = get_import_kick_outs(recon_id, file_path)
                    else:
                        response_data = is_valid
                else:
                    response_data = {
                        'status': 403,
                        'message': 'No recon found with the specified id!'
                    }
            else:
                response_data = {
                        'status': 403,
                        'message': 'This Recon is Signed Off'
                }
        else:
            response_data = {
            'status': 6002,
            'message': 'Un-authorized action detected!'
            }
        
        if response_data.get("status")==200:
            user_logger.info("Imported the Kickout",extra=log_context)

        else:
            logger.error(response_data,extra=log_context)

        log_context["time_taken"]=int(time.time()-start_time)
        logger.info("Import_kick_outs function execution ends",extra=log_context)

        return Response(response_data, status=status.HTTP_200_OK)

    except Exception as e:
        log_context["variable_state"]=locals()
        logger.error(f" Exception occured in Import_kick_outs : {str(e)}",exc_info=1,extra=log_context)
        raise e




@api_view(['POST'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def run_bridge_export(request):
    try:
        allowed = validate_user_recon_permission(request.user.email, "read",request.data['recon_id'] )
        if not allowed:
            response_data = {
                'status': 403,
                'message': 'Un-authorized action detected!'
            }
            return Response(response_data, status=status.HTTP_403_FORBIDDEN)
        
        start_time = time.time()
        log_context = {
            "recon_id": request.data['recon_id'],
            "request_id": request.request_id,
            "user_email": request.user.email,
            "request_url": request.path,
            "event_stage": 'Bridgemembers'
        }
        logger.info("Run_bridge_export execution start",extra=log_context)

        recon_id = request.data['recon_id']
        je_flag = request.data['je_flag']

        if is_write_permitted(request.user.email):
            # if not is_recon_signed(recon_id) :
                if recon_id != '' and Recon.objects.filter(recon_id=recon_id, is_deleted=False).exists():
                    current_time = datetime.now().time().strftime("%H:%M:%S")
                    current_date = datetime.now().strftime("%Y-%m-%d")
                    modified_date = str(current_date) + '_' + str(current_time)
                    file_name = 'Run_bridge_Export.csv'
                    # export_file = get_run_bridge_export_data(recon_id)

                    # Calling function for export query
                    query = run_bridge_export_query(recon_id, je_flag)

                    run_export_script(recon_id,file_name,query)
                    file_path = os.path.join(settings.MEDIA_ROOT, str(recon_id) + "/export/" + file_name)
                    file_path = (str(file_path).replace("\\", "/"))
                    if os.path.exists(file_path):
                        with open(file_path, 'rb') as fh:
                            response = HttpResponse(fh.read(), content_type="application/vnd.ms-excel")
                            response['Content-Disposition'] = 'inline; filename=' + modified_date + os.path.basename(file_path)
                            response['Access-Control-Expose-Headers'] = 'Content-Disposition'

                            user_logger.info("Exported the runbrige ",extra=log_context)
                            log_context["time_taken"]=int(time.time()-start_time)
                            logger.info(" Run_bridge_export function execution ends",extra=log_context)

                            return response
                    else:
                        response_data = {
                            'status': 6002,
                            'message': 'File Not Found'
                        }
                else:
                    response_data = {
                        'status': 403,
                        'message': 'No recon found with the specified id!'
                    }
            # else:
            #     response_data = {
            #             'status': 403,
            #             'message': 'This Recon is Signed Off'
            #     }

        else:
            response_data = {
            'status': 6002,
            'message': 'Un-authorized action detected!'
            }

        if response_data.get("status")!=200:
            logger.error(response_data,extra=log_context)
        
        log_context["time_taken"]=int(time.time()-start_time)
        logger.info("Run_bridge_export  function execution ends",extra=log_context)

        return Response(response_data, status=status.HTTP_200_OK)

    except Exception as e:
        log_context["variable_state"]=locals()
        logger.error(f" Exception occured in Run_bridge_export  : {str(e)}",exc_info=1,extra=log_context)
        raise e



@api_view(['PUT'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
@parser_classes((MultiPartParser, FormParser))
def import_je_comments(request):
    try:
        allowed = validate_user_recon_permission(request.user.email,"write",request.data['recon_id'] )
        if not allowed:
            response_data = {
                'status': 403,
                'message': 'Un-authorized action detected!'
            }
            return Response(response_data, status=status.HTTP_403_FORBIDDEN)
        
        start_time = time.time()
        log_context = {
            "recon_id": request.data['recon_id'],
            "request_id": request.request_id,
            "user_email": request.user.email,
            "request_url": request.path,
            "event_stage": 'Bridgemembers'
        }
        logger.info("Import_je_comments function execution start",extra=log_context)

        # Getting the data from request
        recon_id = request.data['recon_id']
        file_obj = request.FILES['comments_file']

        if is_write_permitted(request.user.email):
            if not is_recon_signed(recon_id) :
                if recon_id != '' and Recon.objects.filter(recon_id=recon_id, is_deleted=False).exists():
                    # Storing file
                    save_file = store_file(recon_id, file_obj)
                    file_path = save_file[1]

                    is_valid = is_valid_file(file_path)
                    if is_valid['status'] == 200:
                        # Getting file data
                        response_data = get_import_comments(recon_id, file_path, True)
                        response_data = add_comment_bridge_id(response_data)
                    else:
                        response_data = is_valid
                else:
                    response_data = {
                        'status': 403,
                        'message': 'No recon found with the specified id!'
                    }
            else:
                response_data = {
                        'status': 403,
                        'message': 'This Recon is Signed Off'
                }
        else:
            response_data = {
            'status': 6002,
            'message': 'Un-authorized action detected!'
            }

        if response_data.get("status")==200:
            user_logger.info("Imported the je comments",extra=log_context)

        else:
            logger.error(response_data,extra=log_context)

        log_context["time_taken"]=int(time.time()-start_time)
        logger.info("Import_je_comments function execution ends",extra=log_context)

        return Response(response_data, status=status.HTTP_200_OK)

    except Exception as e:
        log_context["variable_state"]=locals()
        logger.error(f" Exception occured in Import_je_comments : {str(e)}",exc_info=1,extra=log_context)
        raise e


@api_view(['PUT'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def je_comments_update(request):
    try:
        allowed = validate_user_recon_permission(request.user.email, "write", request.data['recon_id'])
        if not allowed:
            response_data = {
                'status': 403,
                'message': 'Un-authorized action detected!'
            }
            return Response(response_data, status=status.HTTP_403_FORBIDDEN)
        
        start_time = time.time()
        log_context = {
            "recon_id": request.data['recon_id'],
            "request_id": request.request_id,
            "user_email": request.user.email,
            "request_url": request.path,
            "event_stage": 'Bridgemembers'
        }
        logger.info("Je_comments_update function execution start",extra=log_context)

        # Getting the data from request
        recon_id = request.data['recon_id']
        comment_data = request.data['rows']

        if is_write_permitted(request.user.email):
            if not is_recon_signed(recon_id) :
                if recon_id != '' and Recon.objects.filter(recon_id=recon_id, is_deleted=False).exists():
                    response_data = update_comments(recon_id, comment_data, True)
                else:
                    response_data = {
                        'status': 403,
                        'message': 'No recon found with the specified id!'
                    }
            else:
                response_data = {
                        'status': 403,
                        'message': 'This Recon is Signed Off'
                }
        else:
            response_data = {
            'status': 6002,
            'message': 'Un-authorized action detected!'
            }

        if response_data.get("status")==200:
            user_logger.info("Updated the je comments",extra=log_context)
        
        else:
            logger.error(response_data,extra=log_context)

        log_context["time_taken"]=int(time.time()-start_time)
        logger.info(" Je_comments_update function execution ends",extra=log_context)

        return Response(response_data, status=status.HTTP_200_OK)

    except Exception as e:
        log_context["variable_state"]=locals()
        logger.error(f" Exception occured in Je_comments_update : {str(e)}",exc_info=1,extra=log_context)
        raise e



@api_view(['GET'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def je_comments_list(request, recon_id):
    try:
        allowed = validate_user_recon_permission(request.user.email, "read", recon_id)
        if not allowed:
            response_data = {
                'status': 403,
                'message': 'Un-authorized action detected!'
            }
            return Response(response_data, status=status.HTTP_403_FORBIDDEN)
        
        start_time = time.time()
        log_context = {
            "recon_id": recon_id,
            "request_id": request.request_id,
            "user_email": request.user.email,
            "request_url": request.path,
            "event_stage": 'Bridgemembers'
        }
        logger.info("Je_comments_list function execution start",extra=log_context)

        if recon_id != '' and Recon.objects.filter(recon_id=recon_id, is_deleted=False).exists():
            response_data = get_comments(recon_id, True)
        else:
            response_data = {
                'status': 403,
                'message': 'No recon found with the specified id!'
            }

        if response_data.get("status")!=200:
            logger.error(response_data,extra=log_context)

        log_context["time_taken"]=int(time.time()-start_time)
        logger.info(" Je_comments_list function execution ends",extra=log_context)

        return Response(response_data, status=status.HTTP_200_OK)

    except Exception as e:
        log_context["variable_state"]=locals()
        logger.error(f" Exception occured in Je_comments_list : {str(e)}",exc_info=1,extra=log_context)
        raise e



@api_view(['DELETE'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def delete_je_comment(request):
    try:
        allowed = validate_user_recon_permission(request.user.email, "delete", request.data['recon_id'])
        if not allowed:
            response_data = {
                'status': 403,
                'message': 'Un-authorized action detected!'
            }
            return Response(response_data, status=status.HTTP_403_FORBIDDEN)
        
        start_time = time.time()
        log_context = {
            "recon_id": request.data['recon_id'],
            "request_id": request.request_id,
            "user_email": request.user.email,
            "request_url": request.path,
            "event_stage": 'Bridgemembers'
        }
        logger.info("Delete_je_comment function execution start",extra=log_context)

        recon_id = request.data['recon_id']
        bridge_id = request.data['bridge_id']
        app_type = request.data['app_type']

        if is_write_permitted(request.user.email):
            if not is_recon_signed(recon_id) :
                if recon_id != '' and Recon.objects.filter(recon_id=recon_id, is_deleted=False).exists():
                    instance = ReconBridgeMapping.objects.filter(recon_id=recon_id, bridge_id=bridge_id)[0]
                    instance.je_comment = None
                    instance.save()

                    response_data = {
                        'status': 200,
                        'message': 'Comment deleted successfully!'
                    }
                else:
                    response_data = {
                        'status': 403,
                        'message': 'No recon found with the specified id!'
                    }
            else:
                response_data = {
                        'status': 403,
                        'message': 'This Recon is Signed Off'
                }
        else:
            response_data = {
            'status': 6002,
            'message': 'Un-authorized action detected!'
            }

        if response_data.get("status")==200:
            user_logger.info("Deleted the je comments",extra=log_context)
        
        else:
            logger.error(response_data,extra=log_context)
            
        log_context["time_taken"]=int(time.time()-start_time)
        logger.info(" Delete_je_comment function execution ends",extra=log_context)

        return Response(response_data, status=status.HTTP_200_OK)

    except Exception as e:
        log_context["variable_state"]=locals()
        logger.error(f" Exception occured in Delete_je_comment : {str(e)}",exc_info=1,extra=log_context)
        raise e


@api_view(['GET'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def je_comments_export(request, recon_id):
    try:
        allowed = validate_user_recon_permission(request.user.email, "read",recon_id )
        if not allowed:
            response_data = {
                'status': 403,
                'message': 'Un-authorized action detected!'
            }
            return Response(response_data, status=status.HTTP_403_FORBIDDEN)
        
        start_time = time.time()
        log_context = {
            "recon_id": recon_id,
            "request_id": request.request_id,
            "user_email": request.user.email,
            "request_url": request.path,
            "event_stage": 'Bridgemembers'
        }
        logger.info("Je_comments_export function execution start",extra=log_context)

        if is_write_permitted(request.user.email):
            if not is_recon_signed(recon_id) :
                if recon_id != '' and Recon.objects.filter(recon_id=recon_id, is_deleted=False).exists():
                    current_time = datetime.now().time().strftime("%H:%M:%S")
                    current_date = datetime.now().strftime("%Y-%m-%d")
                    modified_date = str(current_date) + '_' + str(current_time)
                    file_name = 'JE_Comments_Export.csv'
                    export_file = get_comment_export_data(recon_id, True)

                    # Setting the download response
                    response_data = HttpResponse(export_file.getvalue(), content_type='text/csv')
                    response_data['Content-Disposition'] = 'attachment; filename=' + file_name
                    response_data['Access-Control-Expose-Headers'] = 'Content-Disposition'

                    user_logger.info("Exported the je comments",extra=log_context)
                    log_context["time_taken"]=int(time.time()-start_time)
                    logger.info(" Je_comments_export function execution ends",extra=log_context)

                    return response_data

                else:
                    response_data = {
                        'status': 403,
                        'message': 'No recon found with the specified id!'
                    }
            else:
                response_data = {
                        'status': 403,
                        'message': 'This Recon is Signed Off'
                }
        else:
            response_data = {
            'status': 6002,
            'message': 'Un-authorized action detected!'
            }

        if response_data.get("status")!=200:
            logger.error(response_data,extra=log_context)

        log_context["time_taken"]=int(time.time()-start_time)
        logger.info(" Je_comments_export function execution ends",extra=log_context)

        return Response(response_data, status=status.HTTP_200_OK)

    except Exception as e:
        log_context["variable_state"]=locals()
        logger.error(f" Exception occured in Je_comments_export : {str(e)}",exc_info=1,extra=log_context)
        raise e


@api_view(['DELETE'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def delete_bridge(request):
    try:
        allowed = validate_user_recon_permission(request.user.email, "delete",request.data['recon_id'] )
        if not allowed:
            response_data = {
                'status': 403,
                'message': 'Un-authorized action detected!'
            }
            return Response(response_data, status=status.HTTP_403_FORBIDDEN)
        
        start_time = time.time()
        log_context = {
            "recon_id": request.data['recon_id'],
            "request_id": request.request_id,
            "user_email": request.user.email,
            "request_url": request.path,
            "event_stage": 'Bridgemembers'
        }
        logger.info("Delete_bridge function execution start",extra=log_context)

        recon_id = request.data['recon_id']
        bridge_id = request.data['bridge_id']

        if is_write_permitted(request.user.email):
            if not is_recon_signed(recon_id) :
                for bridge in bridge_id:
                    if ReconBridgeMapping.objects.filter(recon_id=recon_id, bridge_id= bridge).exists():
                        instance = ReconBridgeMapping.objects.filter(recon_id=recon_id, bridge_id=bridge)
                        instance.delete()

                        response_data = {
                            'status': 200,
                            'message': 'Bridge deleted successfully!'
                        }
                    else:
                        response_data = {
                            'status': 403,
                            'message': 'No recon found with the specified id!'
                        }
            else:
                response_data = {
                        'status': 403,
                        'message': 'This Recon is Signed Off'
                }
        else:
            response_data = {
                'status': 6002,
                'message': 'Un-authorized action detected!'
            }

        if response_data.get("status")==200:
            user_logger.info("Deleted the bridge",extra=log_context)

        else:
            logger.error(response_data,extra=log_context)

        log_context["time_taken"]=int(time.time()-start_time)
        logger.info(" Delete_bridge function execution ends",extra=log_context)

        return Response(response_data, status=status.HTTP_200_OK)

    except Exception as e:
        log_context["variable_state"]=locals()
        logger.error(f" Exception occured in Delete_bridge : {str(e)}",exc_info=1,extra=log_context)
        raise e


@api_view(['POST'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def default_function(request):
    try:
        allowed = validate_user_recon_permission(request.user.email, "write", request.data['recon_id'] )
        if not allowed:
            response_data = {
                'status': 403,
                'message': 'Un-authorized action detected!'
            }
            return Response(response_data, status=status.HTTP_403_FORBIDDEN)
        
        start_time = time.time()
        log_context = {
            "recon_id": request.data['recon_id'],
            "request_id": request.request_id,
            "user_email": request.user.email,
            "request_url": request.path,
            "event_stage": 'Bridgemembers'
        }
        logger.info("Default_function function execution start",extra=log_context)

        # Getting the data from request
        recon_id = request.data['recon_id']
        app_type = request.data['app_type']
        if app_type=="0":
            app_id = Recon.objects.filter(recon_id=recon_id).values_list('app1_id', flat=True).first()
        else:
            app_id = Recon.objects.filter(recon_id=recon_id).values_list('app2_id', flat=True).first()

        if is_write_permitted(request.user.email):
            if not is_recon_signed(recon_id) :
                # Checking if recon exists or not deleted
                if recon_id != '' and Recon.objects.filter(recon_id=recon_id, is_deleted=False).exists():
                    cursor = connections['Recon'].cursor()
                    query = 'select * from fileservice.f_default_app_bridge_members(' + str(app_id)+')'
                    # print(query)
                    cursor.execute(query)

                    response_data ={
                    'status': 200,
                    'message': "success..!"
                            }
                    
                    check_app1_app2=list(ReconBridgeMapping.objects.filter(recon_id=recon_id).values_list('app_type', flat=True).distinct())
                    
                    if check_app1_app2==['0','1'] or check_app1_app2==['1','0']:
                        response_data['call_sp'] = True
                    else:
                        response_data['call_sp'] = False

                else:
                    response_data = {

                        'status': 403,
                        'message': 'No recon found with the specified id!'

                    }
            else:
                response_data = {
                        'status': 403,
                        'message': 'This Recon is Signed Off'
                }
        else:
            response_data = {
            'status': 6002,
            'message': 'Un-authorized action detected!'
            }

        if response_data.get("status")!=200:
            logger.error(response_data,extra=log_context)
        
        user_logger.info("Defaulted to bridgemembers",extra=log_context)
        log_context["time_taken"]=int(time.time()-start_time)
        logger.info(" Default_function function execution ends",extra=log_context)

        return Response(response_data, status=status.HTTP_200_OK)
    
    except Exception as e:
        log_context["variable_state"]=locals()
        logger.error(f" Exception occured in Default_function : {str(e)}",exc_info=1,extra=log_context)
        raise e


@api_view(['PUT'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
@parser_classes((MultiPartParser, FormParser))
def import_bridge_new(request):
    try:
        allowed = validate_user_recon_permission(request.user.email, "write",request.data['recon_id'] )
        if not allowed:
            response_data = {
                'status': 403,
                'message': 'Un-authorized action detected!'
            }
            return Response(response_data, status=status.HTTP_403_FORBIDDEN)
        
        start_time = time.time()
        log_context = {
            "recon_id": request.data['recon_id'],
            "request_id": request.request_id,
            "user_email": request.user.email,
            "request_url": request.path,
            "event_stage": 'Bridgemembers'
        }
        logger.info("Import_bridge function execution start",extra=log_context)


        # Getting the data from request
        recon_id = request.data['recon_id']
        app_type = request.data['app_type']
        file_obj = request.FILES['bridge_file']
        app1_id,app2_id=get_app_ids(recon_id)
        
        if request.data['merge'] == 'true':
            merge = True
        else:
            merge = False

        if is_write_permitted(request.user.email):
            if not is_recon_signed(recon_id) :
                if recon_id != '' and Recon.objects.filter(recon_id=recon_id, is_deleted=False).exists():
                    # Storing file
                    save_file = store_file(recon_id, file_obj)
                    file_path = save_file[1]

                    is_valid = is_valid_file(file_path)
                    file_load = TrackFileLoadStatus(recon_id=recon_id, app_id=app1_id if app_type=='0' else app2_id,
                                                    file_location=save_file[1], file_name=save_file[0],
                                                    uploaded_by=request.user.email,is_je_file=False,file_type="bridge")
                    file_load.save()
                    if is_valid['status'] == 200:
                        # Get the imported file data
                        file_data = get_import_data(recon_id, app_type, file_path)
                        response_data = copy.deepcopy(file_data)
                        if merge:
                            for i in range(len(file_data['rows'])-1, -1, -1):
                                dim_id = file_data['rows'][i]['dim_id']
                                source_member = file_data['rows'][i]['source_member']
                                bridge_member = file_data['rows'][i]['bridge_member']
                                exists = ReconBridgeMapping.objects.filter(recon_id=recon_id, app_type=app_type, dim_id=dim_id, source_member=source_member, bridge_member=bridge_member).exists()
                                if exists:
                                    del file_data['rows'][i]

                        # Saving the bridge info
                        if file_data['status'] == 200:
                            # bridge_data = convert_bridge(file_data)
                            save_data = save_bridge_import(file_data,merge)

                            if save_data['status'] == 6002:
                                response_data = save_data
                            else:
                                # response_data = add_bridge_id(response_data)
                                # # base_data = get_bridge_data(recon_id, app_type, 'F')
                                # response_data = add_dim_name(recon_id, response_data)
                                response_data = bridge_data_from_query(recon_id,app_type)

                                if response_data["status"] == 200:
                                    check_app1_app2=list(ReconBridgeMapping.objects.filter(recon_id=recon_id).values_list('app_type', flat=True).distinct())
                                    reconbridge_dim_ids=set(ReconBridgeMapping.objects.filter(recon_id=recon_id).values_list('dim_id',flat=True).distinct())
                                    recondim_dim_ids =set(ReconDimensions.objects.filter(recon_id=recon_id).values_list('dimensions_id',flat=True))
                                    all_present = reconbridge_dim_ids.issubset(recondim_dim_ids)
                                    
                                    if check_app1_app2==['0','1'] or check_app1_app2==['1','0'] and all_present:
                                        response_data['call_sp'] = True
                                    else:
                                        response_data['call_sp'] = False


                    else:
                        response_data = is_valid
                else:
                    response_data = {
                        'status': 403,
                        'message': 'No recon found with the specified id!'
                    }
            else:
                response_data = {
                        'status': 403,
                        'message': 'This Recon is Signed Off'
                    }
        else:
            response_data = {
                'status': 6002,
                'message': 'Un-authorized action detected!'
            }

        if response_data.get("status")==200:
            user_logger.info("Imported the bridge",extra=log_context)
        
        else:
            logger.error(response_data,extra=log_context)
        
        log_context["time_taken"]=int(time.time()-start_time)
        logger.info(" Import_bridge function execution ends",extra=log_context)

        return Response(response_data, status=status.HTTP_200_OK)

    except Exception as e:
        log_context["variable_state"]=locals()
        logger.error(f" Exception occured in Import_bridge : {str(e)}",exc_info=1,extra=log_context)
        raise e
    



@api_view(['POST'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
@check_user_write_access
def default_kickout(request):
    try:
        allowed = validate_user_recon_permission(request.user.email, "write", request.data['recon_id'] )
        if not allowed:
            response_data = {
                'status': 403,
                'message': 'Un-authorized action detected!'
            }
            return Response(response_data, status=status.HTTP_403_FORBIDDEN)
        
        start_time = time.time()
        log_context = {
            "recon_id": request.data['recon_id'],
            "request_id": request.request_id,
            "user_email": request.user.email,
            "request_url": request.path,
            "event_stage": 'Bridgemembers'
        }
        logger.info("default_kickout function execution start",extra=log_context)

        # Getting the data from request
        recon_id = request.data['recon_id']
        je_flag = request.data['je_flag']
        recon_data = get_recon(recon_id)
        app1_id = recon_data['app1_id']
        app2_id = recon_data['app2_id']

        
        if not is_recon_signed(recon_id) :
                # Checking if recon exists or not deleted
                
                if (je_flag):
                            kickout_exists=is_exists("fileservice",f"view_bridge_je_{recon_id}_kickout")

                else:
                    kickout_exists=is_exists("fileservice",f"view_bridge_{recon_id}_kickout")

                if kickout_exists['rows'][0]['exists']:
                
                # Getting both apps data
                    if(je_flag):
                        view_query = 'SELECT * FROM fileservice.view_bridge_je_' + str(recon_id) + \
                                '_kickout'

                    else:
                        view_query = 'SELECT * FROM fileservice.view_bridge_' + str(recon_id) + \
                                '_kickout'
                    kickout_data = get_kick_out_view_data(view_query, app1_id, app2_id)
                    if kickout_data["status"]==200:
                        response_data=update_default_outs(recon_id, kickout_data["rows"])

                    else:
                        response_data = kickout_data
                else:
                    response_data = {

                        'status': 200,
                        'message': 'No recon found with the specified id!'

                    }
        else:
                response_data = {
                        'status': 403,
                        'message': 'This Recon is Signed Off'
                }
        

        if response_data.get("status")!=200:
            logger.error(response_data,extra=log_context)

        user_logger.info("Kickouts updated",extra=log_context)
        log_context["time_taken"]=int(time.time()-start_time)
        logger.info(" default_kickout function execution ends",extra=log_context)

        return Response(response_data, status=status.HTTP_200_OK)
    
    except Exception as e:
        log_context["variable_state"]=locals()
        logger.error(f" Exception occured in default_kickout : {str(e)}",exc_info=1,extra=log_context)
        raise e
    


@api_view(['GET'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def file_info(request, recon_id):
    try:
        start_time = time.time()
        log_context = {
            "recon_id": recon_id,
            "request_id": request.request_id,
            "user_email": request.user.email,
            "request_url": request.path,
        }

        logger.info("file_info function execution start",extra=log_context)
        app1_bridge_file,app2_bridge_file=bridge_file_info(recon_id)
        response_data={
            "status":200,
            "app1_bridge_file_detail":app1_bridge_file,
            "app2_bridge_file_detail":app2_bridge_file

        }
        
        log_context["time_taken"]=int(time.time()-start_time)
        logger.info("file_info function execution ends",extra=log_context)

        return Response(response_data, status=status.HTTP_200_OK)

    except Exception as e:
        log_context["variable_state"]=locals()
        logger.error(f" Exception occured in file_info : {str(e)}",exc_info=1,extra=log_context)
        raise e


