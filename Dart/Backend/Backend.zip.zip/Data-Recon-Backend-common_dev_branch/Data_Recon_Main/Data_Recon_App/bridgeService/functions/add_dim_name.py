from ...models import ReconDimensions
from ..serializers import DimensionNameSerializer


def add_dim_name(recon_id, bridge_data):
    app_01_instance = ReconDimensions.objects.filter(is_deleted=False, recon_id=recon_id, app_type='0')
    app_01_serialized = DimensionNameSerializer(app_01_instance, many=True)
    app_02_instance = ReconDimensions.objects.filter(is_deleted=False, recon_id=recon_id, app_type='1')
    app_02_serialized = DimensionNameSerializer(app_02_instance, many=True)
    if 'app_type' in bridge_data:
        if bridge_data['app_type'] == '0':
            bridge_data['rows'] = add_name_key_value(bridge_data['rows'], app_01_serialized.data)
        else:
            bridge_data['rows'] = add_name_key_value(bridge_data['rows'], app_02_serialized.data)
    else:
        bridge_data['app1_rows'] = add_name_key_value(bridge_data['app1_rows'], app_01_serialized.data)
        bridge_data['app2_rows'] = add_name_key_value(bridge_data['app2_rows'], app_02_serialized.data)
    return bridge_data


def add_name_key_value(base_list, dim_name_list):
    updated_list = []
    for bridge in base_list:
        matching_object = list(filter(lambda dim: dim.get('dimensions_id') == bridge['dim_id'], dim_name_list))
        if len(matching_object) > 0:
            bridge['dimension'] = matching_object[0]['dimension']
        else:
            bridge['dimension'] = 'NA'
        updated_list.append(bridge)

    return updated_list


def generic_dim_add(recon_id, source, prop_key, dim_id_key, dim_name_key):
    app_01_instance = ReconDimensions.objects.filter(is_deleted=False, recon_id=recon_id, app_type='0')
    app_01_serialized = DimensionNameSerializer(app_01_instance, many=True)
    app_01_dim_data = app_01_serialized.data

    app_02_instance = ReconDimensions.objects.filter(is_deleted=False, recon_id=recon_id, app_type='1')
    app_02_serialized = DimensionNameSerializer(app_02_instance, many=True)
    app_02_dim_data = app_02_serialized.data

    updated_obj = source[prop_key]
    for dim_id in dim_id_key:
        dim_data_obj = app_01_dim_data if dim_id['key_value'] == 'app_01' else app_02_dim_data
        updated_obj = generic_add_name_key_value(updated_obj, dim_data_obj, dim_id['key_id'],
                                                 dim_name_key[dim_id['key_id']])
    source[prop_key] = updated_obj
    return source


def generic_add_name_key_value(base_list, dim_name_list, target_key, source_key):
    updated_list = []
    for bridge in base_list:
        matching_object = list(filter(lambda dim: dim.get('dimensions_id') == bridge[target_key], dim_name_list))
        if len(matching_object) > 0:
            bridge[source_key] = matching_object[0]['dimension']
        else:
            bridge[source_key] = 'NA'

        updated_list.append(bridge)
    return updated_list
