import csv
from .get_import_data import get_dim_id, get_bridge_dim_id
from .update_comments import update_comments
from .get_comments import get_comments
from ...bridgeService.functions.get_disk_space import get_disk_space
from ...maintenanceService.functions.update_config import get_diskspace_thresh

'''
<!---------- Method to get the imported comment file data
             and return as structured data ----------!>
'''


def get_import_comments(recon_id, file_path, je):

    # Creating the data object
    data_object = {
        'status': 200,
        'recon_id': recon_id,
        'rows': []
    }

    # Reding the imported file
    with open(file_path, newline='', encoding="utf-8-sig") as Comments_File:
        reader = csv.DictReader(Comments_File)

        # Looping through the file data
        for index, row in enumerate(reader):
            number_of_col = len(row)

            # Checking if all columns are there
            if number_of_col < 4:
                response_data = {
                    'status': 6002,
                    'message': 'Missing required columns in file!'
                }
                return response_data
            else:
                app_key = (row["app_type"]).lower()
                if app_key != 'bridge':
                    app_type = '0' if app_key == 'app1' else '1'
                    dim_id = get_dim_id(recon_id, row["dimension"], app_type)
                    row_object = {
                        'app_type': (row["app_type"]).upper(),
                        'dim_id': dim_id if dim_id != 'None' else row[1],
                        'source_member': row["source_member"],
                        'comment': row["comment"],
                        'is_invalid': False if dim_id != 'None' else True
                    }
                    data_object['rows'].append(row_object)
                else:
                    dim_id = get_bridge_dim_id(recon_id, row["dimension"])
                    row_object = {
                        'app_type': (row["app_type"]).upper(),
                        'dim_id': dim_id if len(dim_id) > 0 else row[1],
                        'source_member': row["source_member"],
                        'comment': row["comment"],
                        'is_invalid': False if len(dim_id) > 0 else True
                    }
                    data_object['rows'].append(row_object)
                    
    # Get disk space usage
    if get_diskspace_thresh()!="None":
        disk_usage = get_disk_space()
        if get_diskspace_thresh() == disk_usage:
            data_object["disk_usage"] = disk_usage

    # Saving the comments in DB
    update_comments(recon_id, data_object['rows'], je)

    imported_comments = get_comments(recon_id,je)

    return data_object

