from ...models import TrackFileLoadStatus
from ...utils.app_info import get_app_ids


def bridge_file_info(recon_id):
    app1_id ,app2_id=get_app_ids(recon_id)
    app1_bridge_file=TrackFileLoadStatus.objects.filter(recon_id=recon_id,app_id=app1_id,file_type="bridge").order_by('-created_date')[:1]
    app2_bridge_file=TrackFileLoadStatus.objects.filter(recon_id=recon_id,app_id=app2_id,file_type="bridge").order_by('-created_date')[:1]

    app_1_bridge_file_data={}
    app_2_bridge_file_data={}
    if app1_bridge_file:


        app_1_bridge_file_data["file_id"]=app1_bridge_file[0].file_id
        app_1_bridge_file_data["file"]=app1_bridge_file[0].file_name[app1_bridge_file[0].file_name.find("_",app1_bridge_file[0].file_name.find("_")+1)+1:]
        app_1_bridge_file_data["time_stamp"]=app1_bridge_file[0].created_date.strftime('%Y-%m-%dT%H:%M:%SZ')
        app_1_bridge_file_data["uploaded_by"]=app1_bridge_file[0].uploaded_by

    if app2_bridge_file:
        app_2_bridge_file_data["file_id"]=app2_bridge_file[0].file_id
        app_2_bridge_file_data["file"]=app2_bridge_file[0].file_name[app2_bridge_file[0].file_name.find("_",app2_bridge_file[0].file_name.find("_")+1)+1:]
        app_2_bridge_file_data["time_stamp"]=app2_bridge_file[0].created_date.strftime('%Y-%m-%dT%H:%M:%SZ')
        app_2_bridge_file_data["uploaded_by"]=app2_bridge_file[0].uploaded_by
    
    return app_1_bridge_file_data,app_2_bridge_file_data
