from rest_framework import serializers
from .. models import ReconBridgeMapping, ReconDimensions, ReconApplications


class DimensionNameSerializer(serializers.ModelSerializer):
    class Meta:
        model = ReconDimensions
        fields = ['dimensions_id', 'dimension', 'turn_on_define_order']


class BridgeSerializer(serializers.ModelSerializer):
    class Meta:
        model = ReconBridgeMapping
        fields = ['bridge_id', 'recon_id', 'app_id', 'dim_id', 'flip_sign', 'app_type',
                  'source_member', 'bridge_member', 'dim_comment', 'bridge_comment', 'is_invalid']


class BridgeGetSerializer(serializers.ModelSerializer):
    class Meta:
        model = ReconBridgeMapping
        fields = ['bridge_id', 'dim_id', 'flip_sign', 'source_member', 'bridge_member', 'is_invalid', 'dim_comment']

    def to_representation(self, instance):
        representation = super(BridgeGetSerializer, self).to_representation(instance)
        if instance.flip_sign:
            representation['flip_sign'] = 'Yes'
        else:
            representation['flip_sign'] = 'No'
        return representation


class DimCommentSerializer(serializers.ModelSerializer):
    class Meta:
        model = ReconBridgeMapping
        fields = ['bridge_id', 'app_type', 'dim_id', 'source_member', 'dim_comment']

    def to_representation(self, instance):
        representation = super(DimCommentSerializer, self).to_representation(instance)
        representation['app_type'] = 'APP1' if instance.app_type == '0' else 'APP2'
        return {
            'bridge_id': representation['bridge_id'],
            'app_type': representation['app_type'],
            'dim_id': representation['dim_id'],
            'source_member': representation['source_member'],
            'comment': representation['dim_comment']
        }


class BridgeCommentSerializer(serializers.ModelSerializer):
    class Meta:
        model = ReconBridgeMapping
        fields = ['bridge_id', 'app_type', 'dim_id', 'bridge_member', 'bridge_comment']

    def to_representation(self, instance):
        representation = super(BridgeCommentSerializer, self).to_representation(instance)
        representation['app_type'] = 'BRIDGE'
        return {
            'bridge_id': representation['bridge_id'],
            'app_type': representation['app_type'],
            'dim_id': representation['dim_id'],
            'source_member': representation['bridge_member'],
            'comment': representation['bridge_comment']
        }


class BridgeDimIdSerializer(serializers.ModelSerializer):
    class Meta:
        model = ReconBridgeMapping
        fields = ['dim_id']


class DimIdSerializer(serializers.ModelSerializer):
    class Meta:
        model = ReconDimensions
        fields = ['dimensions_id']


class JeCommentSerializer(serializers.ModelSerializer):
    class Meta:
        model = ReconBridgeMapping
        fields = ['bridge_id', 'app_type', 'dim_id', 'source_member', 'je_comment']

    def to_representation(self, instance):
        representation = super(JeCommentSerializer, self).to_representation(instance)
        representation['app_type'] = 'APP1' if instance.app_type == '0' else 'APP2'
        return {
            'bridge_id': representation['bridge_id'],
            'app_type': representation['app_type'],
            'dim_id': representation['dim_id'],
            'source_member': representation['source_member'],
            'comment': representation['je_comment']
        }


class ReconApplicationSerializer(serializers.ModelSerializer):
    class Meta:
        model = ReconApplications
        fields = ['app_name', 'has_header']