from ...models import UpdateNotification,Recon
from django.db.models import Q
from ...utils.pgsql_conn import call_sp_params



def alter_app_table(recon_id):
    
    # to do after getting the stored procedure
    #query the update notification table with the following condition "recon_id=recon_id and message_type=updated a dimension or message_type=added a new dimension"
    # recon_app_ids=list(Recon.objects.filter(recon_id=recon_id).values_list("app1_id","app2_id")[0])
    # old_column=UpdateNotification.objects.filter(Q(recon_id=recon_id, message_type='updated a dimension') | Q(recon_id=recon_id, message_type='added a new dimension')).values_list("old_column",flat=True)
    # new_column=UpdateNotification.objects.filter(Q(recon_id=recon_id, message_type='updated a dimension') | Q(recon_id=recon_id, message_type='added a new dimension')).values_list("new_column",flat=True)
    
    # for app_id in recon_app_ids:
    #     app_id_index=recon_app_ids.index(app_id)
    #     if old_column[app_id_index] != new_column[app_id_index]:
    #         old_column = old_column.replace('"', "'")
    #         new_column = new_column.replace('"', "'")
    #         if old_column == '':
    #             call_sp_params(#add new sp,
    #                 [app_id, new_column], 2)
    #         else:
    #             call_sp_params(#add new sp,
    #                         [app_id, new_column, old_column], 3)
    pass