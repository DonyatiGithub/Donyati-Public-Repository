from ...models import GlobalReconDimensions,GlobalReconApplications,GlobalVariable
from Data_Recon_App.global_variable.serializers import DimensionupdateSerializer


def get_update_dimensions(global_var_id):
    dimensions_instance = GlobalReconDimensions.objects.filter(global_var_id=global_var_id)
    serialized_dimensions = DimensionupdateSerializer(dimensions_instance, many=True)

    # Merging the same order dimension together
    merged_var_dimensions = []
    number_of_dimensions = len(serialized_dimensions.data)
    for i in range(0, number_of_dimensions):
        for j in range(i + 1, number_of_dimensions):
            if serialized_dimensions.data[i]['order'] == serialized_dimensions.data[j]['order']:
                merged_dict = serialized_dimensions.data[i] | serialized_dimensions.data[j]
                merged_var_dimensions.append(merged_dict)

    # Ordering dimensions
    merged_var_dimensions.sort(key=lambda x: int(x['order']))
    final_merged_var_dimensions={'status': 200,'message': 'globaldimension updated successfully', "global_var_id": global_var_id, "dimensions": merged_var_dimensions}
    return final_merged_var_dimensions




'''
<!---------- Method to get recon and corresponding applications'
            data as a response ----------!>
'''

def get_app_details(global_var_id):
    variable_instance = GlobalVariable.objects.filter(global_var_id=global_var_id)[0]

    app1_instance = GlobalReconApplications.objects.filter(global_var_id=global_var_id,app_name='0')[0]
    app2_instance = GlobalReconApplications.objects.filter(global_var_id=global_var_id,app_name='1')[0]

    response = {
        "status":200,
        "message":"variable attached with recon successfully",
        'global_var_id': global_var_id,
        'global_variable_name': variable_instance.global_variable_name,
        'app1_id': app1_instance.global_recon_app_id,
        'app2_id': app2_instance.global_recon_app_id,
        'app1_delimiter': app1_instance.import_delimiter,
        'app2_delimiter': app2_instance.import_delimiter,
        'app1_has_header': app1_instance.has_header,
        'app2_has_header': app2_instance.has_header,
        'app1_import_type': app1_instance.import_type,
        'app2_import_type': app2_instance.import_type,
        'app1_currency_symbol': app1_instance.currency_symbol,
        'app1_currency_delimiter': app1_instance.currency_delimiter,
        'app2_currency_symbol': app2_instance.currency_symbol,
        'app2_currency_delimiter': app2_instance.currency_delimiter,
        'created_by': variable_instance.created_by,
        'created_date': variable_instance.created_at,
        'description': variable_instance.description
        
    }

    return response