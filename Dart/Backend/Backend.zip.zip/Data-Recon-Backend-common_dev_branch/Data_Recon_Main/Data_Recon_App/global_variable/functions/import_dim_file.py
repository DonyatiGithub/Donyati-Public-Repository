import os, csv, datetime
from django.core.files.storage import default_storage
from django.conf import settings
from django.core.files.base import ContentFile
from ...models import GlobalReconDimensions,GlobalReconApplications,UpdateNotification,Recon
from Data_Recon_App.global_variable.serializers import GlobalDimensionSerializer,GlobalvariableSerializer
from Data_Recon_App.global_variable.functions.variabledim import get_update_dimensions

'''
<!---------- Method to store the uploaded file to django media
             folder and return filename, filepath as a response ----------!>
'''


def store_dim_file(global_var_id, file_obj):
    filename = []
    file_path = []
    time_stamp = int(round(datetime.datetime.now().timestamp()))
    if type(file_obj) is list:
        if file_obj[0] == 'je':
            je = True
            file_obj.pop(0)
        else:
            je = False
        for file in range(len(file_obj)):
            time_stamp = int(round(datetime.datetime.now().timestamp()))
            if je:
                filename.append('je_'+str(time_stamp) + '_global_variable_' + str(global_var_id) + '_' + str(file_obj[file]))
            else:
                filename.append(str(time_stamp) + '_global_variable_' + str(global_var_id) + '_' + str(file_obj[file]))

            save_path = default_storage.save(f"global_variable_{global_var_id}" + '/' + str(filename[file]), ContentFile(file_obj[file].read()))
            save_file = os.path.join(settings.MEDIA_ROOT, save_path)
            file_path.append((str(save_file)).replace('\\', '/'))
        return [filename, file_path]
    
    else:
        filename = str(time_stamp) + '_global_variable_' + str(global_var_id) + '_' + file_obj.name
        save_path = default_storage.save(f"global_variable_{global_var_id}" + '/' + filename, ContentFile(file_obj.read()))
        save_file = os.path.join(settings.MEDIA_ROOT, save_path)
        file_path = (str(save_file)).replace('\\', '/')
        return [filename, file_path]
    



'''
<!---------- Method to get the imported dimension file data
             and return as structured data ----------!>
'''


def get_import_data(global_var_id, file_path):
    # Creating the data object
    data_object = {
        'status': 200,
        'global_var_id': global_var_id,
        'rows': []
    }

    # Reding the imported file
    with open(file_path, newline='', encoding="utf-8-sig") as Dim_File:
        next(Dim_File)
        reader = csv.reader(Dim_File)

        # Looping through the file data
        for index, row in enumerate(reader):
            number_of_col = len(row)

            # Checking if all columns are there
            if number_of_col < 4:
                response_data = {
                    'status': 6002,
                    'message': 'Missing required columns in file!'
                }
                return response_data
            else:
                row_object = {
                    "order": row[0],
                    "app1_dimension": row[1].upper(),
                    "app1_dim_in_file": row[2],
                    "app1_type_field": row[3],
                    "app1_top_member": row[4],
                    "app1_is_active": row[5],
                    "app1_app_type": "0",
                    "app2_dimension": row[6].upper(),
                    "app2_dim_in_file": row[7],
                    "app2_type_field": row[8],
                    "app2_top_member": row[9],
                    "app2_is_active": row[10],
                    "app2_app_type": "1",
                }
                data_object['rows'].append(row_object)

    return data_object



def variable_dim_update(global_var_dimensions, global_var_id, upload=None):
    number_of_dimensions = len(global_var_dimensions)
    dimensions_list = []
    global_recon_app1_id=GlobalReconApplications.objects.filter(global_var_id=global_var_id,app_name='0')[0]
    global_recon_app2_id=GlobalReconApplications.objects.filter(global_var_id=global_var_id,app_name='1')[0]
    attached_recon_ids=Recon.objects.filter(global_var_id=global_var_id).values_list("recon_id",flat=True)

    for i in range(0, number_of_dimensions):
        # Application one dimension
        dimensions_list = []
        if global_var_dimensions[i]['app1_dim_in_file'] == 'YES':
            app1_top_member=None
            if global_var_dimensions[i]['app1_top_member']:
                app1_top_member=global_var_dimensions[i]['app1_top_member']
            else:
                global_var_dimensions[i]['app1_top_member'] =app1_top_member
        else:
            global_var_dimensions[i]['app1_type_field'] = None

        dim = global_var_dimensions[i]['app1_dimension'].upper()

        if any(char.isspace() for char in dim):
            response_data = {
                'status': 6001,
                'message': 'Please correct Dimension names. Spaces are not acceptable in Dimension names',
                'data': dim,
            }

            return response_data
        else:
            
            dimensions_list.append(
                {
                    'turn_on_define_order': global_var_dimensions[i]['order'],
                    'dimension': global_var_dimensions[i]['app1_dimension'].upper(),
                    'dim_in_file': global_var_dimensions[i]['app1_dim_in_file'],
                    'type_field': global_var_dimensions[i]['app1_type_field'],
                    'top_member': global_var_dimensions[i]['app1_top_member'],
                    'app_type': global_var_dimensions[i]['app1_app_type'],
                    'is_active': global_var_dimensions[i]['app1_is_active'],
                    'global_recon_app_id': global_recon_app1_id.global_recon_app_id
                }
            )

        # Application two dimension
        if global_var_dimensions[i]['app2_dim_in_file'] == 'YES':

            app2_top_member =None
            if global_var_dimensions[i]['app2_top_member']:
                app2_top_member=global_var_dimensions[i]['app2_top_member']
            else:
                global_var_dimensions[i]['app2_top_member'] = app2_top_member
        else:
            global_var_dimensions[i]['app2_type_field'] = None

        dim = global_var_dimensions[i]['app2_dimension'].upper()
            

        if any(char.isspace() for char in dim):
            response_data = {
                'status': 6001,
                'message': 'Please correct Dimension names. Spaces are not acceptable in Dimension names',
                'data': dim,
            }
            return response_data
        else:
            dimensions_list.append(
                {
                    'turn_on_define_order': global_var_dimensions[i]['order'],
                    'dimension': global_var_dimensions[i]['app2_dimension'].upper(),
                    'dim_in_file': global_var_dimensions[i]['app2_dim_in_file'],
                    'type_field': global_var_dimensions[i]['app2_type_field'],
                    'top_member': global_var_dimensions[i]['app2_top_member'],
                    'app_type': global_var_dimensions[i]['app2_app_type'],
                    'is_active': global_var_dimensions[i]['app1_is_active'],
                    'global_recon_app_id': global_recon_app2_id.global_recon_app_id
                }
            )

        dimensions_length = len(dimensions_list)
        
        for j in range(0, dimensions_length):
            dimension = dimensions_list[j]
            dimension['global_var_id'] = global_var_id
        

            # Check if the dimension exists --then update else create
            if GlobalReconDimensions.objects.filter(
                    turn_on_define_order=dimensions_list[j]['turn_on_define_order'],
                    app_type=dimensions_list[j]['app_type'], global_var_id=global_var_id).exists():
                dim_instance = GlobalReconDimensions.objects.filter(
                    turn_on_define_order=dimensions_list[j]['turn_on_define_order'],
                    app_type=dimensions_list[j]['app_type'], global_var_id=global_var_id)[0]
                dimension["old_column"] = dim_instance.dimension
                serialized_dim = GlobalDimensionSerializer(dim_instance, data=dimension, partial=True)
            else:
                if GlobalReconDimensions.objects.filter(dimension=dimensions_list[j]['dimension'], global_var_id=global_var_id,
                                                  app_type=dimensions_list[j]['app_type']).exists():
                    response_data = {
                        'status': 6001,
                        'message': 'Dimension name already exists within another order!'
                    }
                    return response_data

                else:
                    serialized_dim = GlobalDimensionSerializer(data=dimension)

            if serialized_dim.is_valid():
                serialized_dim.save()
                if attached_recon_ids and not upload:
                    
                    save_notification(attached_recon_ids,dimension,global_var_id)

                                
            else:
                response_data = {
                    'status': 6001,
                    'error': serialized_dim.errors,
                    'message': 'Recon dimensions update failed'
                }
                return response_data
            
    if upload==True:

        if Recon.objects.filter(global_var_id=global_var_id).exists():
            recon_ids=Recon.objects.filter(global_var_id=global_var_id).values_list("recon_id",flat=True)
            for recon_id in recon_ids:
                notify=UpdateNotification(recon_id=recon_id,global_var_id=global_var_id,message_type="re-imported_dim_file")
                notify.save()
        response_data = {
            'status': 200,
            'message': 'variable imported successfully',
            'rows':get_import_dimensions(global_var_id)
        }
    else:
        response_data = get_update_dimensions(global_var_id)
        
    return response_data



def get_import_dimensions(global_var_id):
    dimensions_instance = GlobalReconDimensions.objects.filter(global_var_id=global_var_id)
    serialized_dimensions = GlobalvariableSerializer(dimensions_instance, many=True)

    # Merging the same order dimension together
    merged_var_dimensions = []
    number_of_dimensions = len(serialized_dimensions.data)
    for i in range(0, number_of_dimensions):
        for j in range(i + 1, number_of_dimensions):
            if serialized_dimensions.data[i]['order'] == serialized_dimensions.data[j]['order']:
                merged_dict = serialized_dimensions.data[i] | serialized_dimensions.data[j]
                merged_var_dimensions.append(merged_dict)

    # Ordering dimensions
    merged_var_dimensions.sort(key=lambda x: int(x['order']))
    
    return merged_var_dimensions



def save_notification(recon_ids,dimension,global_var_id):
    
    for recon_id in recon_ids:

        if dimension.get("old_column"):

            notify=UpdateNotification(recon_id=recon_id,global_var_id=global_var_id,new_column=dimension["dimension"],old_column=dimension["old_column"],app_type=dimension["app_type"],message_type="updated_dimension")
            notify.save()
        else:
            notify=UpdateNotification(recon_id=recon_id,global_var_id=global_var_id,new_column=dimension["dimension"],old_column=None,app_type=dimension["app_type"],message_type="added_new_dimension")
            notify.save()




