from django.urls import path
from rest_framework.urlpatterns import format_suffix_patterns
from . import views

urlpatterns = [
    path('list', views.global_variable_list, name='list_global_variable'),
    path('delete', views.delete_global_variable, name='delete_global_variable'),
    path('delete-dimension', views.variable_delete_dimension, name= 'delete_dimension'),
    path('detach-recon', views.variable_detach_recon, name= 'variable detach recon'),
    path('application-update', views.update_variable_details, name='update-variable-details'),
    path('create', views.create_variable, name='create-variable'),
    path('dim-import', views.import_variable_dimensions, name='import-variable-dimensions'),
    path('dim-update', views.global_dimensions_update, name='global-dimensions-update'),
    path('info/<int:global_var_id>', views.global_variable_info, name='global-variable-info'),
    path('attach-recon', views.variable_attach_recon, name='variable-attach-recon'),
    path('dim-order-update', views.variable_dim_order_update, name='variable-dim-order-update'),
    path('dimensions/export/<int:global_var_id>', views.dimensions_export, name='dimensions-export'),
    path('attached-recons/<int:global_var_id>', views.attached_recons, name='attached_recons'),
    path('get-notification',views.get_notification,name='get-notification'),
    path('acknowledge-updates',views.acknowledge_updates,name='acknowledge-updates')
]

urlpatterns = format_suffix_patterns(urlpatterns)