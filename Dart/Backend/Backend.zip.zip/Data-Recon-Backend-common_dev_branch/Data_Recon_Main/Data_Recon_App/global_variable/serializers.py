from rest_framework import serializers
from .. models import GlobalReconApplications,GlobalReconDimensions,GlobalVariable

class GlobalVariableSerializer(serializers.ModelSerializer):
    class Meta:
        model = GlobalVariable
        fields = ['global_var_id', 'global_variable_name', 'description', 'created_by', 'created_at']

class GlobalReconAppSerializer(serializers.ModelSerializer):
    class Meta:
        model = GlobalReconApplications
        fields = ['global_recon_app_id','global_var_id','app_name', 'import_type', 'import_delimiter', 'has_header',
                  'url', 'cube', 'username', 'password', 'filename', 'is_deleted', 'currency_symbol','currency_delimiter']

class GlobalDimensionSerializer(serializers.ModelSerializer):
    class Meta:
        model = GlobalReconDimensions
        fields = ['global_dimensions_id','global_var_id','global_recon_app_id', 'turn_on_define_order', 'dimension', 'dim_in_file',
                  'type_field', 'top_member', 'app_type','is_active']
        

class GlobalvariableSerializer(serializers.ModelSerializer):
    class Meta:
        model = GlobalReconDimensions
        fields = ['global_dimensions_id', 'turn_on_define_order', 'dimension', 'dim_in_file',
                  'type_field', 'top_member', 'app_type', 'is_active']

    def to_representation(self, instance):
      
        if instance.app_type == "0":
            return {
                'order': instance.turn_on_define_order,
                'app1_dimension': instance.dimension,
                'app1_dim_in_file': instance.dim_in_file,
                'app1_type_field': instance.type_field,
                'app1_top_member': instance.top_member,
                'app1_app_type': instance.app_type,
                'app1_is_active': instance.is_active
            }
        elif instance.app_type == "1":
            return {
                'order': instance.turn_on_define_order,
                'app2_dimension': instance.dimension,
                'app2_dim_in_file': instance.dim_in_file,
                'app2_type_field': instance.type_field,
                'app2_top_member': instance.top_member,
                'app2_app_type': instance.app_type,
                'app2_is_active': instance.is_active
            }


class DimensionupdateSerializer(serializers.ModelSerializer):
    class Meta:
        model = GlobalReconDimensions
        fields = ['global_dimensions_id', 'turn_on_define_order', 'dimension', 'dim_in_file',
                  'type_field', 'top_member', 'app_type', 'is_active']

    def to_representation(self, instance):
      
        if instance.app_type == "0":
            return {
                'global_dimensions_id':instance.global_dimensions_id,
                'order': instance.turn_on_define_order,
                'app1_dimension': instance.dimension,
                'app1_dim_in_file': instance.dim_in_file,
                'app1_type_field': instance.type_field,
                'app1_top_member': instance.top_member,
                'app1_app_type': instance.app_type,
                'app1_is_active': instance.is_active
            }
        elif instance.app_type == "1":
            return {
                'order': instance.turn_on_define_order,
                'app2_dimension': instance.dimension,
                'app2_dim_in_file': instance.dim_in_file,
                'app2_type_field': instance.type_field,
                'app2_top_member': instance.top_member,
                'app2_app_type': instance.app_type,
                'app2_is_active': instance.is_active
            }
