from rest_framework import status
from rest_framework.decorators import permission_classes, api_view, renderer_classes , parser_classes
from rest_framework.permissions import IsAuthenticated
from rest_framework.renderers import JSONRenderer
from rest_framework.response import Response
from ..models import GlobalVariable,  GlobalReconDimensions,Recon, GlobalReconApplications,UpdateNotification
from .serializers import GlobalVariableSerializer, GlobalReconAppSerializer, GlobalDimensionSerializer
from rest_framework.parsers import MultiPartParser, FormParser
from Data_Recon_App.utils.user_permission_decorator import check_user_write_access
from .functions.import_dim_file import store_dim_file,get_import_data,variable_dim_update, get_import_dimensions
from .functions.variabledim import get_app_details
from Data_Recon_App.reconService.functions.is_valid_file import is_valid_file
import datetime, copy, os
from django.conf import settings
from ..utils.run_export_script import dimension_export_script
from ..utils.export_query import dimension_query
from django.http import HttpResponse
from django.db.models import F
from .functions.alter_app_table import alter_app_table
from ..utils.recon_permission_check import check_globalvariable_owner

import logging
import time

user_logger = logging.getLogger("userlog")
# use this user_logger to log user log 
logger = logging.getLogger("techlog")
# use 'logger' to for general application log


@api_view(['GET'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
@check_user_write_access
def global_variable_list(request):
    try:
        log_context = {
            "request_id": request.request_id,
            "user_email": request.user.email,
            "request_url": request.path,
        }

        start_time = time.time()
        user_logger.info(" global_variable_list function execution start",extra=log_context)


        global_var_list = GlobalVariable.objects.all()

        serialized = GlobalVariableSerializer(global_var_list, many=True)
        response_data = {
            'status': 200,
            'global_variables': serialized.data
        }
        
        log_context["time_taken"]=int(time.time()-start_time)
        logger.info("global_variable_list function execution end",extra=log_context)
        return Response(response_data, status=status.HTTP_200_OK)
    except Exception as e:

        log_context["variable_state"]=locals()
        user_logger.error("Exception occured at global_variable_list function",exc_info=True,extra=log_context)
        raise e
    
@api_view(['DELETE'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
@check_user_write_access
def delete_global_variable(request):
    try:
        validate_owner = check_globalvariable_owner(request.user.email,request.data["global_var_id"][0])
        if not validate_owner:
            response_data = {
                'status': 403,
                'message': 'Un-authorized action detected!'
            }
            return Response(response_data, status=status.HTTP_403_FORBIDDEN)

        log_context = {
            "request_id": request.request_id,
            "user_email": request.user.email,
            "request_url": request.path,
        }
        start_time = time.time()
        logger.info("delete_global_variable function execution start", extra=log_context)

        payload = request.data
        global_var_ids = payload.get("global_var_id", [])

        for global_var_id in global_var_ids:
            if Recon.objects.filter(global_var_id=global_var_id).exists():
                global_variable_name = GlobalVariable.objects.get(global_var_id=global_var_id).global_variable_name 
                response_data = {
                    "status": 500,
                    "message": f"{global_variable_name} is connected with the recon."
                }
            else:
                GlobalVariable.objects.filter(global_var_id=global_var_id).delete()
                response_data = {
                    "status": 200,
                    "message": "successfully deleted"
                }
        if response_data.get("status") == 200:
            user_logger.info("deleted global dimension",extra=log_context)
        else:
            logger.error(response_data,extra=log_context)

        log_context["time_taken"] = int(time.time() - start_time)
        logger.info("delete_global_variable function execution end", extra=log_context)
        
        return Response(response_data, status=status.HTTP_200_OK)

    except Exception as e:
        log_context["variable_state"] = locals()
        logger.error("Exception occurred at delete_global_variable function", exc_info=1, extra=log_context)
        raise e

@api_view(['DELETE'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
@check_user_write_access
def variable_delete_dimension(request):
    try:
        validate_owner = check_globalvariable_owner(request.user.email,request.data["global_var_id"])
        if not validate_owner:
            response_data = {
                'status': 403,
                'message': 'Un-authorized action detected!'
            }
            return Response(response_data, status=status.HTTP_403_FORBIDDEN)
        
        global_var_id=request.data['global_var_id']
        app1_dimension_list=request.data['order_id']
        start_time = time.time()
        log_context = {
            "request_id": request.request_id,
            "user_email": request.user.email,
            "request_url": request.path,
        }
        logger.info("delete_dimension function execution start",extra=log_context)


        gvd_id_exist=GlobalReconDimensions.objects.filter(global_var_id=global_var_id, turn_on_define_order__in=app1_dimension_list).delete()

        if gvd_id_exist[0]!= 0:
            response_data = {
                "status":200,
                "message": "Successfully deleted"
            }
        
        else:
            response_data = {
                "status":204,
                "message": "Global variable Dimension not found"
            }
                
        if response_data.get("status") == 200:
            user_logger.info("deleted global dimension",extra=log_context)
        else:
            logger.error(response_data,extra=log_context)

        log_context["time_taken"]=int(time.time()-start_time)
        logger.info("delete dimension function execution ends", extra=log_context)

        return Response(response_data,status=status.HTTP_200_OK)
            
    except Exception as e:
        log_context["variable_state"] = locals()
        logger.error(f"Exception occured at delete dimension  {str(e)}",exc_info=1,extra=log_context)
        raise e
    
@api_view(['DELETE'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
@check_user_write_access
def variable_detach_recon(request):
    try:
        log_context = {
            "recon_id": request.data['recon_id'],
            "request_id": request.request_id,
            "user_email": request.user.email,
            "request_url": request.path,

        }
        
        start_time = time.time()
        logger.info("variable detach recon function execution starts", extra=log_context)

        recon_id =  request.data['recon_id']

        recon_instance = Recon.objects.filter(recon_id=recon_id)

        if recon_instance.exists():
            Recon.objects.filter(recon_id=recon_id).update(global_var_id=None)

            response_data = {
                'status': 200,
                'message': 'Global variable detached from recon'
            }
        else:
            response_data = {
                'status': 403,
                'message': 'Recon not found'
            }

        if response_data.get("status") == 200:
            logger.info("Detach recon from global variable",extra=log_context)
        else:
            logger.error(response_data,extra=log_context)

        log_context["time_taken"]=int(time.time()-start_time)
        logger.info("variable_detach recon function execution end",extra=log_context)
        
        return Response(response_data, status=status.HTTP_200_OK)
    
    except Exception as e:
        log_context["variable_state"]=locals()
        logger.error(f"Exception occured on detach_recon {str(e)} ",exc_info=1,extra=log_context)
        raise e
        
        

  
@api_view(['POST'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
@check_user_write_access
def create_variable(request):
    try:
        log_context = {
            "request_id": request.request_id,
            "user_email": request.user.email,
            "request_url": request.path,
        }
        start_time = time.time()
        logger.info("create_variable function execution start",extra=log_context)

        global_variable=request.data["global_variable"]
        description=request.data["description"]
        current_timestamp = datetime.datetime.now()
        created_date = current_timestamp.strftime('%Y-%m-%d' + ' ' + '%H:%M:%S')
        variable_dimensions=[{'order': '0', 'app1_app_type': 0, 'app1_is_active': True, 'app1_dimension': 'YEAR', 'app1_dim_in_file': 'NO', 'app1_type_field': None, 'app1_top_member': None, 'app2_dimension': 'YEAR', 'app2_dim_in_file': 'NO', 'app2_type_field': None, 'app2_top_member': None, 'app2_app_type': 1, 'app2_is_active': True}, 
                             {'order': '1', 'app1_app_type': 0, 'app1_is_active': True, 'app1_dimension': 'PERIOD', 'app1_dim_in_file': 'NO', 'app1_type_field': None, 'app1_top_member': None, 'app2_dimension': 'PERIOD', 'app2_dim_in_file': 'NO', 'app2_type_field': None , 'app2_top_member': None, 'app2_app_type': 1, 'app2_is_active': True}, 
                             {'order': '2', 'app1_app_type': 0, 'app1_is_active': True, 'app1_dimension': 'AMOUNT', 'app1_dim_in_file': 'NO', 'app1_type_field': None, 'app1_top_member': None, 'app2_dimension': 'AMOUNT', 'app2_dim_in_file': 'NO', 'app2_type_field': None, 'app2_top_member': None, 'app2_app_type': 1, 'app2_is_active': True}]
        variable_filter=GlobalVariable.objects.filter(global_variable_name=global_variable).first()

        if variable_filter is None:
            create_variable=GlobalVariable(global_variable_name=global_variable,description=description,created_by=request.user.email,created_at=created_date)
            create_variable.save()
        else:
            response_data={
                "status": 6001,
                "message": "Globalvariable name already exist please enter unique name"
            }
            logger.error(response_data,extra=log_context)
            return Response(response_data, status=status.HTTP_200_OK)
        
        global_var_id = GlobalVariable.objects.filter(global_variable_name=global_variable).values_list('global_var_id', flat=True).first()
       
        create_global_app1=GlobalReconApplications(global_var_id=global_var_id, app_name='0', import_type='0')
        create_global_app2=GlobalReconApplications(global_var_id=global_var_id, app_name='1', import_type='0')
        create_global_app1.save()
        create_global_app2.save()


        number_of_dimensions = len(variable_dimensions)
        dimensions_list = []
        for i in range(0, number_of_dimensions):
            # default Application one dimension
            dimensions_list.append(
                {
                    'turn_on_define_order': variable_dimensions[i]['order'],
                    'dimension': variable_dimensions[i]['app1_dimension'],
                    'dim_in_file': variable_dimensions[i]['app1_dim_in_file'],
                    'type_field': variable_dimensions[i]['app1_type_field'],
                    'top_member': variable_dimensions[i]['app1_top_member'],
                    'app_type': variable_dimensions[i]['app1_app_type'],
                    'is_active': variable_dimensions[i]['app1_is_active'],
                    'global_recon_app_id': create_global_app1.global_recon_app_id
                }
            )

            # default Application two dimension
            dimensions_list.append(
                {
                    'turn_on_define_order': variable_dimensions[i]['order'],
                    'dimension': variable_dimensions[i]['app2_dimension'],
                    'dim_in_file': variable_dimensions[i]['app2_dim_in_file'],
                    'type_field': variable_dimensions[i]['app2_type_field'],
                    'top_member': variable_dimensions[i]['app2_top_member'],
                    'app_type': variable_dimensions[i]['app2_app_type'],
                    'is_active': variable_dimensions[i]['app1_is_active'],
                    'global_recon_app_id': create_global_app2.global_recon_app_id
                }
            )

        dimensions_length = len(dimensions_list)
        for i in range(0, dimensions_length):
            dimension = dimensions_list[i]
            dimension['global_var_id'] = global_var_id
            serialized_dim = GlobalDimensionSerializer(data=dimension)
            if serialized_dim.is_valid():
                serialized_dim.save()
            else:
                logger.error(response_data,extra=log_context)
                return Response(serialized_dim.errors, status=status.HTTP_400_BAD_REQUEST)

        response_data={
            "status": 200,
            "message": "successfully created",
            "global_var_id": create_variable.global_var_id,
            "global_variable_name": create_variable.global_variable_name,
            "created_by": create_variable.created_by,
            "created_at": create_variable.created_at,
            "description":create_variable.description

        }

        user_logger.info("created the variable",extra=log_context)

        log_context["time_taken"]=int(time.time()-start_time)
        logger.info("create_variable function execution end",extra=log_context)
        return Response(response_data, status=status.HTTP_200_OK)
    
    except Exception as e:
        log_context["variable_state"]=locals()
        logger.error("Exception occured at create_variable function",exc_info=1,extra=log_context)
        raise e



@api_view(['PUT'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
@check_user_write_access
def update_variable_details(request):
    try:
        validate_owner = check_globalvariable_owner(request.user.email,request.data["data"]["global_var_id"])
        if not validate_owner:
            response_data = {
                'status': 403,
                'message': 'Un-authorized action detected!'
            }
            return Response(response_data, status=status.HTTP_403_FORBIDDEN)
        
        payload_data = request.data['data']
        log_context = {
            "request_id": request.request_id,
            "user_email": request.user.email,
            "request_url": request.path,
        }
        global_var_id=payload_data['global_var_id']
        start_time = time.time()
        logger.info("update_variable_details function execution start",extra=log_context)

        app1_data={'import_type':payload_data['app1_import_type'], 'import_delimiter':payload_data['app1_import_delimiter'], 'has_header':payload_data['app1_has_header'],'currency_symbol': payload_data['app1_currency_symbol'], 'currency_delimiter': payload_data['app1_currency_delimiter']}
        app2_data={'import_type':payload_data['app2_import_type'], 'import_delimiter':payload_data['app2_import_delimiter'], 'has_header':payload_data['app2_has_header'], 'currency_symbol': payload_data['app2_currency_symbol'], 'currency_delimiter': payload_data['app2_currency_delimiter']}

        app1_instance = GlobalReconApplications.objects.filter(global_var_id=global_var_id, app_name='0')[0]
        app1_serialized = GlobalReconAppSerializer(app1_instance,app1_data,partial=True)
        valid=True
        if app1_serialized.is_valid():
            app1_serialized.save()
        else:
            valid=False
        
        app2_instance = GlobalReconApplications.objects.filter(global_var_id=global_var_id, app_name='1')[0]
        app2_serialized = GlobalReconAppSerializer(app2_instance,app2_data,partial=True)
        if app2_serialized.is_valid():
            app2_serialized.save()
        else:
            valid=False

        if not valid:
            response_data = {
                'status': 6001,
                'message': 'Something went wrong while updating app details!'
            }
            logger.error(response_data,extra=log_context)
            return Response(response_data, status=status.HTTP_200_OK)

        saved_data = {
            "global_var_id": global_var_id,
            "app1_import_type": app1_instance.import_type,
            "app1_import_delimiter": app1_instance.import_delimiter,
            "app1_has_header": app1_instance.has_header,
            "app1_currency_symbol": app1_instance.currency_symbol,
            "app1_currency_delimiter": app1_instance.currency_delimiter,
            "app2_import_type": app2_instance.import_type,
            "app2_import_delimiter": app2_instance.import_delimiter,
            "app2_has_header": app2_instance.has_header,
            "app2_currency_symbol": app2_instance.currency_symbol,
            "app2_currency_delimiter": app2_instance.currency_delimiter,
        }
        
        response_data={
            "status": 200,
            "message": "successfully updated",
            "data":saved_data
        }

        user_logger.info("updated the variable details",extra=log_context)

        log_context["time_taken"]=int(time.time()-start_time)
        logger.info("update_variable_details function execution end",extra=log_context)
        return Response(response_data, status=status.HTTP_200_OK)
    
    except Exception as e:
        log_context["variable_state"]=locals()
        logger.error("Exception occured at update_variable_details function",exc_info=1,extra=log_context)
        raise e
    

@api_view(['POST'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
@parser_classes((MultiPartParser, FormParser))
@check_user_write_access
def import_variable_dimensions(request):
    try:
        validate_owner = check_globalvariable_owner(request.user.email,request.data["global_var_id"])
        if not validate_owner:
            response_data = {
                'status': 403,
                'message': 'Un-authorized action detected!'
            }
            return Response(response_data, status=status.HTTP_403_FORBIDDEN)
        
        log_context = {
            "request_id": request.request_id,
            "user_email": request.user.email,
            "request_url": request.path,
        }
        start_time = time.time()
        logger.info("import_variable_dimensions function execution start",extra=log_context)

        global_var_id = request.data['global_var_id']
        file_obj = request.FILES["dim_in_file"]

        #Bulk delete except year,period,amount dimensions
        GlobalReconDimensions.objects.filter(global_var_id=int(global_var_id)).exclude(dimension__in=['YEAR', 'PERIOD', 'AMOUNT']).delete()

        save_file = store_dim_file(global_var_id, file_obj)
        file_path = save_file[1]

        is_valid = is_valid_file(file_path)
        if is_valid['status'] == 200:
           dim_data = get_import_data(global_var_id, file_path)
           response_data = copy.deepcopy(dim_data)
           dim=dim_data['rows']   

           # check the year,period and amount dimensions   
           if (dim[0]['app1_dimension'] and dim[0]['app2_dimension'] != 'YEAR') or (dim[1]['app1_dimension'] and dim[1]['app2_dimension'] != 'PERIOD') or (dim[2]['app1_dimension'] and dim[2]['app2_dimension'] != 'AMOUNT'):
                response_data = {
                    'status': 422,
                    'message': 'Check the uploaded file,the first three rows must contain YEAR, PERIOD, and AMOUNT dimensions'
                }
                
                logger.error(response_data,extra=log_context)
                return Response(response_data, status=status.HTTP_200_OK)
           
           # Check order starts from 0
           if dim_data['rows'][0]['order']!='0':
                response_data = {
                    'status': 6001,
                    'message': 'Imported Dimension File, ColumnA should start from 0'
                }
                
                logger.error(response_data,extra=log_context)
                return Response(response_data, status=status.HTTP_200_OK)
           
           save_data = variable_dim_update(dim_data['rows'], global_var_id,upload=True)
           response_data = save_data

        else:
            response_data = is_valid
        
        if response_data.get("status")==200:
            user_logger.info("Imported the variable dimensions",extra=log_context)
        else:
            logger.error(response_data,extra=log_context)

        log_context["time_taken"]=int(time.time()-start_time)
        logger.info("import_variable_dimensions function execution end",extra=log_context)
        return Response(response_data, status=status.HTTP_200_OK)
    
    except Exception as e:
        log_context["variable_state"]=locals()
        logger.error("Exception occured at import_variable_dimensions function",exc_info=1,extra=log_context)
        raise e
                

@api_view(['POST'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
@check_user_write_access
def global_dimensions_update(request):
    try:
        validate_owner = check_globalvariable_owner(request.user.email,request.data['data']["global_var_id"])
        if not validate_owner:
            response_data = {
                'status': 403,
                'message': 'Un-authorized action detected!'
            }
            return Response(response_data, status=status.HTTP_403_FORBIDDEN)
        
        log_context = {
            "request_id": request.request_id,
            "user_email": request.user.email,
            "request_url": request.path,
        }
        start_time = time.time()
        logger.info("global_dimensions_update function execution start",extra=log_context)

        global_var_id = request.data['data']['global_var_id']
        variable_dimensions=request.data['data']['dimensions']

        global_dim_update = variable_dim_update(variable_dimensions, global_var_id, upload=False)
        response_data= global_dim_update
        
        if response_data.get("status")==200:
            user_logger.info("updated the global dimesions",extra=log_context)
        else:
            logger.error(response_data,extra=log_context)
        
        log_context["time_taken"]=int(time.time()-start_time)
        logger.info("global_dimensions_update function execution end",extra=log_context)
        return Response(response_data, status=status.HTTP_200_OK)
    
    except Exception as e:
        log_context["variable_state"]=locals()
        logger.error("Exception occured at global_dimensions_update function",exc_info=1,extra=log_context)
        raise e



@api_view(['GET'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
@check_user_write_access
def global_variable_info(request,global_var_id):
    try:
        log_context = {
            "request_id": request.request_id,
            "user_email": request.user.email,
            "request_url": request.path,
        }
        start_time = time.time()
        logger.info("global_variable_info function execution start",extra=log_context)   

        variables_list = get_app_details(global_var_id)
        variable_dimensions = get_import_dimensions(global_var_id)
        
        variables_list['dimensions'] = variable_dimensions
        del variables_list["status"],variables_list["message"]
        response_data={"status":200,"data":variables_list}

        user_logger.info("Get all the global variable information",extra=log_context)

        log_context["time_taken"]=int(time.time()-start_time)
        logger.info("global_variable_info function execution end",extra=log_context)
        return Response(response_data, status=status.HTTP_200_OK)
    
    except Exception as e:
        log_context["variable_state"]=locals()
        logger.error("Exception occured at global_variable_info function",exc_info=1,extra=log_context)
        raise e
    

@api_view(['POST'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
@check_user_write_access
def variable_attach_recon(request):
    try:
        log_context = {
            "recon_id":request.data["recon_id"],
            "request_id": request.request_id,
            "user_email": request.user.email,
            "request_url": request.path,
        }
        start_time = time.time()
        logger.info("variable_attach_recon function execution start",extra=log_context) 

        global_var_id=request.data['global_var_id']
        recon_id=request.data["recon_id"]

        Recon.objects.filter(recon_id=recon_id).update(global_var_id=global_var_id)
        Recon.objects.filter(recon_id=recon_id).update(status='Dim Updated')

        variables_list = get_app_details(global_var_id)
        del variables_list["global_var_id"],variables_list["global_variable_name"]
        variable_dimensions = get_import_dimensions(global_var_id)
        
        variables_list['dimensions'] = variable_dimensions
        response_data=variables_list

        user_logger.info("variable attached with recon successfully",extra=log_context)

        log_context["time_taken"]=int(time.time()-start_time)
        logger.info("variable_attach_recon function execution end",extra=log_context)
        return Response(response_data, status=status.HTTP_200_OK)
    
    except Exception as e:
        log_context["variable_state"]=locals()
        logger.error("Exception occured at variable_attach_recon function",exc_info=1,extra=log_context)
        raise e
        


@api_view(['PUT'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
@check_user_write_access
def variable_dim_order_update(request):
    try:
        validate_owner = check_globalvariable_owner(request.user.email,request.data["global_var_id"])
        if not validate_owner:
            response_data = {
                'status': 403,
                'message': 'Un-authorized action detected!'
            }
            return Response(response_data, status=status.HTTP_403_FORBIDDEN)
        
        log_context = {
            "request_id": request.request_id,
            "user_email": request.user.email,
            "request_url": request.path,
        }
        start_time = time.time()
        logger.info("variable_dim_order_update function execution start",extra=log_context)

        global_var_id = request.data['global_var_id']
        drag_order = request.data['dragOrder']
        drop_order = request.data['dropOrder']

        if GlobalReconDimensions.objects.filter(global_var_id=global_var_id, turn_on_define_order=drag_order).exists():

            # Obtaining the dragged dimension details
            updated_list = []
            instance = GlobalReconDimensions.objects.filter(global_var_id=global_var_id, turn_on_define_order=drag_order)
            updated_list.append(instance[0].global_dimensions_id)
            updated_list.append(instance[1].global_dimensions_id)

            # Updating the order for dropped dimension
            GlobalReconDimensions.objects.filter(global_var_id=global_var_id, turn_on_define_order=drag_order).update(turn_on_define_order=drop_order)

            # Checking if the order got increased or decreased
            if drag_order > drop_order:
                # Drag order is greater. Need to increment other fields
                for i in range(drop_order, drag_order):
                    loop_instance = GlobalReconDimensions.objects.filter(global_var_id=global_var_id,turn_on_define_order=i)
                    dim_len = len(loop_instance)
                    for j in range(0, dim_len):
                        app_id = loop_instance[j].global_dimensions_id
                        if app_id not in updated_list:
                            GlobalReconDimensions.objects.filter(global_var_id=global_var_id, global_dimensions_id=app_id).update(turn_on_define_order=i + 1)
                            updated_list.append(app_id)

            else:
                # Drag order is lesser. Need to decrement other fields
                for i in range(drop_order, drag_order, -1):
                    loop_instance = GlobalReconDimensions.objects.filter(global_var_id=global_var_id,turn_on_define_order=i)
                    dim_len = len(loop_instance)
                    for j in range(0, dim_len):
                        app_id = loop_instance[j].global_dimensions_id
                        if app_id not in updated_list:
                            GlobalReconDimensions.objects.filter(global_var_id=global_var_id, global_dimensions_id=app_id).update(turn_on_define_order=i - 1)
                            updated_list.append(app_id)

            final_result=get_import_dimensions(global_var_id)
            response_data={"status":200, "message":"Dimensions reordered successfully", "data":final_result}
        
        else:
            response_data = {
                'status': 403,
                'message': 'No recon found with the specified id!'
            }

        if response_data.get("status")==200:
            user_logger.info("dimensions reordered successfully",extra=log_context)
        else:
            logger.error(response_data,extra=log_context)

        log_context["time_taken"]=int(time.time()-start_time)
        logger.info("variable_dim_order_update function execution end",extra=log_context)
        return Response(response_data, status=status.HTTP_200_OK)
    
    except Exception as e:
        log_context["variable_state"]=locals()
        logger.error("Exception occured at variable_dim_order_update function",exc_info=1,extra=log_context)
        raise e
        


@api_view(['GET'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
@check_user_write_access
def dimensions_export(request, global_var_id):
    try:
        log_context = {
            "request_id": request.request_id,
            "user_email": request.user.email,
            "request_url": request.path,
        }
        start_time = time.time()
        logger.info("variable_dim_order_update function execution start",extra=log_context)

        current_timestamp = datetime.datetime.now()
        modified_date = current_timestamp.strftime('%Y-%m-%d' + '_' + '%H:%M:%S')
        file_name = 'Dimension_export.csv'

        #Constructing the query
        query = dimension_query(global_var_id)

        # Calling the Shell script to create a csv file
        dimension_export_script(global_var_id, file_name, query)

        file_path = os.path.join(settings.MEDIA_ROOT,f"Global_Variable_{global_var_id}" + "/export/" +file_name)
        file_path = (str(file_path).replace("\\", "/"))
        if os.path.exists(file_path):
            with open(file_path, 'rb') as fh:
                response = HttpResponse(fh.read(), content_type="application/vnd.ms-excel")
                response['Content-Disposition'] = 'inline; filename=' + os.path.basename(modified_date + file_path)
                response['Access-Control-Expose-Headers'] = 'Content-Disposition'

                user_logger.info("Exported the dimension",extra=log_context)
                log_context["time_taken"]=int(time.time()-start_time)
                logger.info("dimensions_export function execution ends",extra=log_context)
                
                return response
        else:
            response = {
                'status': 6002,
                'message': 'File Not Found'
            }

        if response.get("status")!=200:
            logger.error(response,extra=log_context)

        log_context["time_taken"]=int(time.time()-start_time)
        logger.info("variable_dim_order_update function execution end",extra=log_context)
        return Response(response, status=status.HTTP_200_OK)
    
    except Exception as e:
        log_context["variable_state"]=locals()
        logger.error("Exception occured at variable_dim_order_update function",exc_info=1,extra=log_context)
        raise e




@api_view(['GET'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
@check_user_write_access
def attached_recons(request, global_var_id):
    try:
        log_context = {
            "request_id": request.request_id,
            "user_email": request.user.email,
            "request_url": request.path,
        }
        start_time = time.time()
        logger.info("attached_recons function execution start",extra=log_context)

        recon_info = Recon.objects.filter(global_var_id=global_var_id).values(recon_name=F('name'), recon_created_by=F('created_by')).order_by('-created_date')
        response_data={"status":200,"attached-recon-list":recon_info}
        
        user_logger.info("retrieved all the attached recon list",extra=log_context)
        log_context["time_taken"]=int(time.time()-start_time)
        logger.info("attached_recons function execution end",extra=log_context)
        return Response(response_data, status=status.HTTP_200_OK)
    
    except Exception as e:
        log_context["variable_state"]=locals()
        logger.error("Exception occured at attached_recons function",exc_info=1,extra=log_context)
        raise e
        

@api_view(['POST'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
@check_user_write_access
def get_notification(request):
    try:
        log_context = {
            "request_id": request.request_id,
            "user_email": request.user.email,
            "request_url": request.path,
        }
        start_time = time.time()
        logger.info("get_notification function execution start",extra=log_context)

        global_var_id = request.data['global_var_id']
        recon_id = request.data['recon_id']

        response_data={"status":200,"dimension_renamed":False,"reimported":False,"new_dimension":False}

        response_data["dimension_renamed"] = UpdateNotification.objects.filter(recon_id=recon_id,global_var_id=global_var_id,message_type="updated_dimension").exists()
        response_data["new_dimension"] =  UpdateNotification.objects.filter(recon_id=recon_id,global_var_id=global_var_id,message_type="added_new_dimension").exists() 
        response_data["reimported"] =UpdateNotification.objects.filter(global_var_id=global_var_id,message_type="re-imported_dim_file").exists() 
       

        
        user_logger.info("retrieved all the attached recon list",extra=log_context)
        log_context["time_taken"]=int(time.time()-start_time)
        logger.info("get_notification function execution end",extra=log_context)
        return Response(response_data, status=status.HTTP_200_OK)
    
    except Exception as e:
        log_context["variable_state"]=locals()
        logger.error("Exception occured at get_notification function",exc_info=1,extra=log_context)
        raise e
    


@api_view(['POST'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
@check_user_write_access
def acknowledge_updates(request):
    try:
        log_context = {
            "request_id": request.request_id,
            "user_email": request.user.email,
            "request_url": request.path,
        }
        start_time = time.time()
        logger.info("acknowledge_updates function execution start",extra=log_context)

        recon_id = request.data['recon_id']

        alter_app_table(recon_id)

        UpdateNotification.objects.filter(recon_id=recon_id).delete()

        response_data={"status":200,"message":"acknowledged succesfully"}
    
       

        
        user_logger.info("retrieved all the attached recon list",extra=log_context)
        log_context["time_taken"]=int(time.time()-start_time)
        logger.info("acknowledge_updates function execution end",extra=log_context)
        return Response(response_data, status=status.HTTP_200_OK)
    
    except Exception as e:
        log_context["variable_state"]=locals()
        logger.error("Exception occured at acknowledge_updates function",exc_info=1,extra=log_context)
        raise e