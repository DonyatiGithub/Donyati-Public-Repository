from .get_sync_data import get_sync_data,get_all_sync_data


'''
<!---------- Method to get transformations sync data of both
             apps then structure and return response ----------!>
'''


def combine_sync_list(recon_id):
    app1_sync_data = get_sync_data(recon_id, '0')
    app2_sync_data = get_sync_data(recon_id, '1')
    app1_all_sync_data = get_all_sync_data(recon_id, '0')
    app2_all_sync_data = get_all_sync_data(recon_id, '1')

    if app1_sync_data['status'] == 6002:
        return app1_sync_data

    if app2_sync_data['status'] == 6002:
        return app2_sync_data

    response_data = {
        'status': 200,
        'recon_id': recon_id,
        'app1_rows': app1_sync_data['rows'],
        'app2_rows': app2_sync_data['rows'],
        'app1_all_sync': app1_all_sync_data['rows'],
        'app2_all_sync': app2_all_sync_data['rows'],
        'message': 'Obtained all the transformation sync mappings!'
    }

    return response_data
