from django.db import connections

def get_column_name(recon_id):
    cursor = connections['Recon'].cursor()

    try:
        query = (
            'SELECT column_name '
            'FROM information_schema.columns '
            'WHERE table_schema = %s '
            'AND table_name = %s;'
        )
        # Execute the query with parameterized inputs
        cursor.execute(query, ('fileservice', f'bridgesync_{recon_id}'))
        
        # Fetch all column names from the result
        columns = cursor.fetchall()
        
        # Extract column names from the fetched data
        column_names = [row[0] for row in columns]
        # print(column_names)
        return column_names
    except Exception as e:
        return []
    finally:
        cursor.close()   