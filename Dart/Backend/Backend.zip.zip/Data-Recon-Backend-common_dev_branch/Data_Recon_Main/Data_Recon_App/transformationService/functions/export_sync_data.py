import io
import csv
from .get_sync_data import get_sync_data
from ...models import ReconDimensions


'''
<!---------- Method to get export data of transformations sync
             then structure and return response as file ----------!>
'''


def export_sync_data(recon_id, app_type):
    sync_data = get_sync_data(recon_id, app_type)

    # Creating a file object without saving
    csv_file = io.StringIO()
    header = ['dimensions_id', 'source_sync', 'flip_sign', 'target_sync']
    csv_writer = csv.DictWriter(csv_file, fieldnames=header)

    for i in range(0, len(sync_data['rows'])):
        # Creating the row object
        row = dict()

        # Looping headers and adding in object
        for head in header:
            if head == 'dimensions_id':
                row[head] = get_dim_name(recon_id, sync_data['rows'][i][head])
            else:
                row[head] = sync_data['rows'][i][head]

        # Writing to file object
        csv_writer.writerow(row)

    return csv_file


def get_dim_name(recon_id, dim_id):
    instance = ReconDimensions.objects.filter(recon_id=recon_id, is_deleted=False, dimensions_id=dim_id)[0]
    dim_name = instance.dimension
    return dim_name
