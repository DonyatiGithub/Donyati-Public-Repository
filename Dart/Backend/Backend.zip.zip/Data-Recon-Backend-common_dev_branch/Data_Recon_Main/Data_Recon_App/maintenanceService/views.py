from rest_framework import status
from rest_framework.decorators import api_view, permission_classes, renderer_classes
from rest_framework.permissions import IsAuthenticated
from rest_framework.renderers import JSONRenderer
from rest_framework.response import Response

from ..utils.user_permissions import is_write_permitted
from .functions.update_config import update_conf, start_function, update_diskspace



# This function will run when django server is started
def startup_function():
    # print('Loading config file')
    start_function()


@api_view(['POST'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def update_config(request):
    if is_write_permitted(request.user.email):
        if request.data['autoRun'] not in [True,False]:
            response_data = {
                'status':6002,
                'message':'Invalid flag value'
            }
            return Response(response_data, status=status.HTTP_200_OK)
        
        response_data = update_conf(request.data['autoRun'])
    else:
        response_data = {
            'status': 6002,
            'message': 'Un-authorized action detected!'
        }
    return Response(response_data, status=status.HTTP_200_OK)  




@api_view(['POST'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def update_diskspace_thresh(request):
    if is_write_permitted(request.user.email):
        
        response_data = update_diskspace(request.data['diskspace'])
    else:
        response_data = {
            'status': 6002,
            'message': 'Un-authorized action detected!'
        }
    return Response(response_data, status=status.HTTP_200_OK)  