from django.urls import path
from rest_framework.urlpatterns import format_suffix_patterns
from . import views


urlpatterns = [
    path('permission', views.get_permission, name='get_permission'),
    path('permission-group',views.create_permission_group,name='create permission '),
    path('permission-group-list',views.fetch_permission_group,name='fetch permission '),
    path('attach-permission',views.add_permission,name='add permission to permission group'),
    path('attached-permissions/<int:permission_group_id>',views.get_permission_for_group,name='get permission for group'),
    path('attach-user',views.add_user_group,name='add user to permission group'),
    path('attached-user/<int:permission_group_id>',views.get_user_from_group,name='get permission for group'),
    path('attach-recon-perm-group',views.add_recon_permission_group,name="add permission group to recon"),
    path('attached-recon-perm-group/<int:permission_group_id>',views.get_recon_perm_group,name="get recon perm group"),
    path('detach-permission',views.detach_permission,name="detach permission"),
    path('delete-permission-group',views.delete_permission_grp,name="delete permission group"),
    path('detach-user',views.detach_user,name="detach user"),
    path('detach-recon-perm-group',views.detach_recon_permission_grp,name="detach recon permission group"),
    path('update-groupname',views.update_groupname,name="update permission groupname"),
    path('group-export',views.group_export,name="export group"),
    path('group-import',views.group_import,name="import group")
]

urlpatterns = format_suffix_patterns(urlpatterns)
