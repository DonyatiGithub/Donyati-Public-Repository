# serializers.py

from rest_framework import serializers
from Data_Recon_App.models import Permissions,PermissionGroup,PermissionGroupMap,PermissionGroupUser,ReconGroupMap

class PermissionsSerializer(serializers.ModelSerializer):
    class Meta:
        model = Permissions
        fields = ['permission_id', 'permission_name']

class PermissionsGroupSerializer(serializers.ModelSerializer):
    class Meta:
        model = PermissionGroup
        fields = ['permission_group_id', 'permission_group_name','created_by','created_at']


class PermissionsGroupUserSerializer(serializers.ModelSerializer):
    class Meta:
        model = PermissionGroupUser
        fields = ['permission_group_user_id', 'permission_group_id','user_email']

class ReconGroupMapSerializer(serializers.ModelSerializer):
    permission_group = PermissionsGroupSerializer()  # Serializer for nested PermissionGroup field

    class Meta:
        model = ReconGroupMap
        fields = '__all__'

    def to_representation(self, instance):
        # Perform any custom logic to customize the representation
        representation = super().to_representation(instance)
        # Add or modify fields in the representation dictionary
        for key,value in representation["permission_group"].items():
            representation[key]=value
        
        del representation["permission_group"]
        
        return representation

    
