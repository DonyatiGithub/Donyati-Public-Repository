from Data_Recon_App.models import PermissionGroup,PermissionGroupMap,Permissions
from django.db import connections
from Data_Recon_App.utils.pgsql_conn import call_query


class PermissionGroupManager():

    def __init__(self) -> None:
        pass

    def add_permission_to_group(self,permission_group_id:int,permissions:list):

        Exist_permission_id = PermissionGroupMap.objects.filter(permission_group_id=permission_group_id).values_list('permission_id', flat=True)
        List_Exist_permission_id = list(Exist_permission_id)

        for permission in permissions:
            payload_permid=permission["permission_id"]

            if payload_permid not in List_Exist_permission_id:
                per_gmap=PermissionGroupMap(permission_group_id=permission_group_id,
                                            permission_id=payload_permid)
                per_gmap.save()

        return self.get_permission_group_map(permission_group_id)
    
    
    def get_permission_group_map(self,permission_group_id):

        query = """
                    SELECT permission_group_map_id, p.permission_id, permission_name
                    FROM fileservice.permission_group_map pgm
                    INNER JOIN fileservice.permissions p ON pgm.permission_id = p.permission_id AND pgm.permission_group_id = %s;
                    """ % permission_group_id
        
        data=call_query(query)
        
        return data["rows"]



    def update_permission_group_name(self,permission_group:list):

        updated_group_data=[]

        for group in permission_group:
            permission_group_id = group["permission_group_id"]
            permission_group_name = group["permission_group_name"]

            row_affected=PermissionGroup.objects.filter(permission_group_id=permission_group_id).update(permission_group_name=permission_group_name)

            if row_affected > 0:
                group_data = {
                    'permission_group_id': permission_group_id,
                    'permission_group_name': permission_group_name,
                }

            updated_group_data.append(group_data)

        return(updated_group_data)
     