from Data_Recon_App.models import ReconUser,PermissionGroup,Recon
from Data_Recon_App.utils.user_permissions import is_admin


def permission_group_security(email,permission_group_id):
    
    
    is_owner=PermissionGroup.objects.filter(permission_group_id=permission_group_id,created_by=email).exists()
    admin=is_admin(email)
    allowed=admin or is_owner

    return allowed


def recon_owner_or_admin(email,recon_id):
    
    admin=is_admin(email)

    user_name=ReconUser.objects.filter(email=email).get().username
    
    owner=Recon.objects.filter(created_by=user_name,recon_id=recon_id).exists()

    allowed=admin or owner

    return allowed

