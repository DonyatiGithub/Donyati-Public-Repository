from Data_Recon_App.models import PermissionGroupMap,PermissionGroupUser
from django.db import connections
from Data_Recon_App.utils.pgsql_conn import call_query


class PermissionGroupUserManager():

    def __init__(self) -> None:
        pass

    def add_user_to_group(self,permission_group_id:int,users:list):

        per_grp_user_list = []

        for user in users:
            per_grp_user=PermissionGroupUser(permission_group_id=permission_group_id,user_email=user)
            per_grp_user_filter=PermissionGroupUser.objects.filter(permission_group_id=permission_group_id,user_email=user).first()
            
            if per_grp_user_filter is None:
                per_grp_user.save()
                per_grp_user_list.append(per_grp_user)
           
        return per_grp_user_list



        



    



        
