from Data_Recon_App.models import ReconGroupMap
from django.db import connections
from Data_Recon_App.utils.pgsql_conn import call_query
from .permission_security import recon_owner_or_admin


class ReconGroupPermissionManager():


    def __init__(self) -> None:
        pass

    def add_permission_grp_to_recon(self,email,permission_groups:list):

        permission_group_id=permission_groups[0]["permission_group_id"]
        for group in permission_groups:
            recon_id=group["recon_id"]
            if not recon_owner_or_admin(email,group["recon_id"]):
                raise Exception("unauthorized error")

            permission_grp_user_filter=ReconGroupMap.objects.filter(recon_id=recon_id,permission_group_id=group["permission_group_id"]).first()
        
            
            
            if permission_grp_user_filter is None:
                recon_grp_map=ReconGroupMap(recon_id=recon_id,permission_group_id=group["permission_group_id"])
                recon_grp_map.save()
            

        attached_group=self.get_attached_recon(permission_group_id)
        return attached_group


    def get_attached_recon(self,permission_group_id):

        query = """
                    select  rgm.recon_group_map_id ,rgm.recon_id ,r.name,pg.permission_group_id ,pg.permission_group_name  
                    from fileservice.recon_group_map rgm  inner join fileservice.permission_group pg 
                    on rgm.permission_group_id =pg.permission_group_id and pg.permission_group_id =%s inner join 
                    fileservice.recon r on rgm.recon_id =r.recon_id ;
                    """ % permission_group_id
        
        data=call_query(query)
        
        return data["rows"]




