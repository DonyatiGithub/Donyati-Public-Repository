from rest_framework import status
from rest_framework.decorators import permission_classes, api_view, renderer_classes, parser_classes
from rest_framework.permissions import IsAuthenticated
from rest_framework.renderers import JSONRenderer
from rest_framework.response import Response
from ..models import Permissions,PermissionGroup,PermissionGroupMap,PermissionGroupUser,ReconGroupMap
from .serializers import PermissionsSerializer,PermissionsGroupSerializer,PermissionsGroupUserSerializer,ReconGroupMapSerializer
from .recon_permission_manager import PermissionGroupManager,PermissionGroupUserManager,ReconGroupPermissionManager
from Data_Recon_App.utils.user_permission_decorator import check_user_write_access
from Data_Recon_App.utils.user_permissions import is_admin
from .recon_permission_manager.permission_security import permission_group_security,recon_owner_or_admin
from django.http import HttpResponse
from datetime import datetime
from rest_framework.parsers import MultiPartParser, FormParser
from .. utils.store_file import store_group_file
from django.conf import settings
from ..utils.run_export_script import group_export_script
import os, csv


import logging
import time


user_logger = logging.getLogger("userlog")
# use this user_logger to log user log 
logger = logging.getLogger("techlog")
# use 'logger' to for general application log


@api_view(['GET'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def get_permission(request):
    try:
        log_context = {
            "request_id": request.request_id,
            "user_email": request.user.email,
            "request_url": request.path,
        }
        start_time = time.time()
        logger.info("get_permission function execution start",extra=log_context)
        instance = Permissions.objects.all()
        serailized=PermissionsSerializer(instance,many=True)
        response_data = {
            'status': 200,
            'permissions': serailized.data
        }
        
        log_context["time_taken"]=int(time.time()-start_time)
        logger.info("get_permission function execution end",extra=log_context)
        return Response(response_data, status=status.HTTP_200_OK)
    except Exception as e:
        log_context["variable_state"]=locals()
        logger.error("Exception occured at get_permission function",exc_info=1,extra=log_context)
        raise e



@api_view(['POST'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
@check_user_write_access
def create_permission_group(request):
    try:
        log_context = {
            "request_id": request.request_id,
            "user_email": request.user.email,
            "request_url": request.path,
        }
        start_time = time.time()
        logger.info("create_permission_group function execution start",extra=log_context)
        payload=request.data
        
        group=PermissionGroup.objects.filter(permission_group_name=payload["permission_group_name"]).first()

        if group is None:
            group=PermissionGroup(permission_group_name=payload["permission_group_name"],created_by=request.user.email)
            group.save()

            permission_group_id=group.permission_group_id
            read_permission_id = Permissions.objects.get(permission_name="read").permission_id
            PermissionGroupMap.objects.create(permission_id=read_permission_id, permission_group_id=permission_group_id)
        
        else:
            response_data = {
                "status":203,
                "message": "The given permission group name is already created"
            }
            return Response(response_data, status=status.HTTP_200_OK)

        serialized_data=PermissionsGroupSerializer(group)
        
        response_data = {
            "status":200,
            "message": "Sucessfully created",
            "group_detail":serialized_data.data
        }
        
        user_logger.info("Created the permission group",extra=log_context)
        log_context["time_taken"]=int(time.time()-start_time)
        logger.info("create_permission_group function execution end",extra=log_context)
        return Response(response_data, status=status.HTTP_200_OK)
    
    except Exception as e:
        log_context["variable_state"]=locals()
        logger.error("Exception occured at create_permission_group function",exc_info=1,extra=log_context)
        raise e
    


@api_view(['GET'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def fetch_permission_group(request):
    try:
        log_context = {
            "request_id": request.request_id,
            "user_email": request.user.email,
            "request_url": request.path,
        }
        start_time = time.time()
        logger.info("fetch_permission_group function execution start",extra=log_context)
        
        if is_admin(request.user.email):
            group=PermissionGroup.objects.all()
        else:
            group=PermissionGroup.objects.filter(created_by=request.user.email).all()

           
        serialized_data=PermissionsGroupSerializer(group,many=True)
        
        
        response_data = {
            "status":200,
            "permission_groups":serialized_data.data
        }
        
        log_context["time_taken"]=int(time.time()-start_time)
        logger.info("fetch_permission_group function execution end",extra=log_context)
        return Response(response_data, status=status.HTTP_200_OK)
    
    except Exception as e:
        log_context["variable_state"]=locals()
        logger.error("Exception occured at fetch_permission_group function",exc_info=1,extra=log_context)
        raise e
    


@api_view(['POST'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
@check_user_write_access
def add_permission(request):
    try:
        log_context = {
            "request_id": request.request_id,
            "user_email": request.user.email,
            "request_url": request.path,
        }
        start_time = time.time()
        logger.info("add_permission function execution start",extra=log_context)
        
        payload=request.data

        permission_group_id=payload["permission_group_id"]
        permissions=payload["permission"]
        allowed=permission_group_security(request.user.email,permission_group_id)
        if not allowed:
            response_data = {
                'status': 403,
                'message': 'Un-authorized action detected!'
            }
            return Response(response_data, status=status.HTTP_403_FORBIDDEN)

        pg_manager=PermissionGroupManager()

        added_list=pg_manager.add_permission_to_group(permission_group_id,permissions)


        response_data = {
            "status":200,
            "message": "Sucessfully created",
            "permission_group_map":added_list
        }
        
        log_context["time_taken"]=int(time.time()-start_time)
        logger.info("add_permission function execution end",extra=log_context)
        return Response(response_data, status=status.HTTP_200_OK)
    
    except Exception as e:
        log_context["variable_state"]=locals()
        logger.error("Exception occured at add_permission function",exc_info=1,extra=log_context)
        raise e
    



@api_view(['GET'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
@check_user_write_access
def get_permission_for_group(request,permission_group_id):
    try:
        log_context = {
            "request_id": request.request_id,
            "user_email": request.user.email,
            "request_url": request.path,
        }
        start_time = time.time()
        logger.info("get_permission_for_group function execution start",extra=log_context)
        

        
        pg_manager=PermissionGroupManager()

        permissions=pg_manager.get_permission_group_map(permission_group_id)


        response_data = {
            "status":200,
            "permission_group_map":permissions
        }
        
        log_context["time_taken"]=int(time.time()-start_time)
        logger.info("get_permission_for_group function execution end",extra=log_context)
        return Response(response_data, status=status.HTTP_200_OK)
    
    except Exception as e:
        log_context["variable_state"]=locals()
        logger.error("Exception occured at get_permission_for_group function",exc_info=1,extra=log_context)
        raise e
    


    
@api_view(['POST'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
@check_user_write_access
def add_user_group(request):
    try:
        log_context = {
            "request_id": request.request_id,
            "user_email": request.user.email,
            "request_url": request.path,
        }
        start_time = time.time()
        logger.info("add_user_group function execution start",extra=log_context)
        
        payload=request.data

        permission_group_id=payload["permission_group_id"]
        users=payload["users"]

        allowed=permission_group_security(request.user.email,permission_group_id)
        if not allowed:
            response_data = {
                'status': 403,
                'message': 'Un-authorized action detected!'
            }
            return Response(response_data, status=status.HTTP_403_FORBIDDEN)

        pgu_manager=PermissionGroupUserManager()

        added_list=pgu_manager.add_user_to_group(permission_group_id,users)
        serialized_data=PermissionsGroupUserSerializer(instance=added_list,many=True)


        response_data = {
            "status":200,
            "message": "Sucessfully created",
            "permission_group_map":serialized_data.data
        }
        
        log_context["time_taken"]=int(time.time()-start_time)
        logger.info("add_user_group function execution end",extra=log_context)
        return Response(response_data, status=status.HTTP_200_OK)
    
    except Exception as e:
        log_context["variable_state"]=locals()
        logger.error("Exception occured at add_user_group function",exc_info=1,extra=log_context)
        raise e
    

@api_view(['GET'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def get_user_from_group(request,permission_group_id):
    try:
        log_context = {
            "request_id": request.request_id,
            "user_email": request.user.email,
            "request_url": request.path,
        }
        start_time = time.time()
        logger.info("get_user_from_group function execution start",extra=log_context)
        
        per_grp_user=PermissionGroupUser.objects.filter(permission_group_id=permission_group_id).all()
        serialized_data=PermissionsGroupUserSerializer(instance=per_grp_user,many=True)


        response_data = {
            "status":200,
            "permission_group_users":serialized_data.data
        }
        
        log_context["time_taken"]=int(time.time()-start_time)
        logger.info("get_user_from_group function execution end",extra=log_context)
        return Response(response_data, status=status.HTTP_200_OK)
    
    except Exception as e:
        log_context["variable_state"]=locals()
        logger.error("Exception occured at get_user_from_group function",exc_info=1,extra=log_context)
        raise e
    

    

@api_view(['POST'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
@check_user_write_access
def add_recon_permission_group(request):
    try:
        log_context = {
            "request_id": request.request_id,
            "user_email": request.user.email,
            "request_url": request.path,
        }
        start_time = time.time()
        logger.info("add_recon_permission_group function execution start",extra=log_context)

        payload=request.data

        recon_perm_manager=ReconGroupPermissionManager()
        recon_grp_map =  recon_perm_manager.add_permission_grp_to_recon(request.user.email,payload["recon_group_map"])

      
        
        response_data = {
            "status":200,
            "message":"sucessfully created",
            "permission_group_users":recon_grp_map
        }
        
        log_context["time_taken"]=int(time.time()-start_time)
        logger.info("add_recon_permission_group function execution end",extra=log_context)
        return Response(response_data, status=status.HTTP_200_OK)
    
    except Exception as e:
        log_context["variable_state"]=locals()
        logger.error("Exception occured at add_recon_permission_group function",exc_info=1,extra=log_context)
        raise e
    


@api_view(['GET'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def get_recon_perm_group(request,permission_group_id):
    try:
        log_context = {
            "request_id": request.request_id,
            "user_email": request.user.email,
            "request_url": request.path,
        }
        start_time = time.time()
        logger.info("get_recon_perm_group function execution start",extra=log_context)
        
        
        recon_grp_manager=ReconGroupPermissionManager()
        recon_group_map=recon_grp_manager.get_attached_recon(permission_group_id)



        response_data = {
            "status":200,
            "recon_group_map":recon_group_map
        }
        
        log_context["time_taken"]=int(time.time()-start_time)
        logger.info("get_recon_perm_group function execution end",extra=log_context)
        return Response(response_data, status=status.HTTP_200_OK)
    
    except Exception as e:
        log_context["variable_state"]=locals()

        logger.error("Exception occured at get_recon_perm_group function",exc_info=1,extra=log_context)

        raise e
    

@api_view(['DELETE'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
@check_user_write_access
def detach_permission(request):
    try:
        log_context = {
            "request_id": request.request_id,
            "user_email": request.user.email,
            "request_url": request.path,
        }
        start_time = time.time()
        logger.info(" detach_permission function execution start",extra=log_context)

        payload =request.data
        payload_value = payload["permission_group_map_id"]

        permission_group_id=payload["permission_group_id"]
        allowed=permission_group_security(request.user.email,permission_group_id)
        if not allowed:
            response_data = {
                'status': 403,
                'message': 'Un-authorized action detected!'
            }
            return Response(response_data, status=status.HTTP_403_FORBIDDEN)

        pgm_id_exist=PermissionGroupMap.objects.filter(permission_group_map_id__in=payload_value).delete()
        
        if pgm_id_exist[0]!= 0:
            response_data = {
                "status":200,
                "message": "Successfully deleted"
            }
        
        else:
            response_data = {
                "status":204,
                "message": "permission_group_map_id not found"
            }
        
        if response_data["status"] == 200:
            user_logger.info("Deleted the permission from a permission group",extra=log_context)

        else:
            logger.error(response_data["message"],extra=log_context)

        log_context["time_taken"]=int(time.time()-start_time)
        logger.info("detach_permission function execution end",extra=log_context)
        return Response(response_data, status=status.HTTP_200_OK)
    
    except Exception as e:
        log_context["variable_state"]=locals()
        logger.error("Exception occured at detach_permission function",exc_info=1,extra=log_context)
        raise e



@api_view(['DELETE'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
@check_user_write_access
def delete_permission_grp(request):
    try:
        log_context = {
            "request_id": request.request_id,
            "user_email": request.user.email,
            "request_url": request.path,
        }
        start_time = time.time()
        logger.info(" delete_permission_grp function execution start",extra=log_context)

        payload =request.data
        payload_value = payload["permission_group_id"]

        permission_group_id=payload["permission_group_id"][0]
        allowed=permission_group_security(request.user.email,permission_group_id)
        if not allowed:
            response_data = {
                'status': 403,
                'message': 'Un-authorized action detected!'
            }
            return Response(response_data, status=status.HTTP_403_FORBIDDEN)

        pg_id_exist=PermissionGroup.objects.filter(permission_group_id__in=payload_value).delete()
        
        if pg_id_exist[0]!= 0:
            response_data = {
                "status":200,
                "message": "Successfully deleted"
            }
        
        else:
            response_data = {
                "status":204,
                "message": "permission_group_id not found"
            }
        
        if response_data["status"] == 200:
            user_logger.info("Deleted the permission group",extra=log_context)

        else:
            logger.error(response_data["message"],extra=log_context)

        log_context["time_taken"]=int(time.time()-start_time)
        logger.info("delete_permission_grp function execution end",extra=log_context)
        return Response(response_data, status=status.HTTP_200_OK)
    
    except Exception as e:
        log_context["variable_state"]=locals()
        logger.error("Exception occured at delete_permission_grp function",exc_info=1,extra=log_context)
        raise e


@api_view(['DELETE'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
@check_user_write_access
def detach_user(request):
    try:
        log_context = {
            "request_id": request.request_id,
            "user_email": request.user.email,
            "request_url": request.path,
        }
        start_time = time.time()
        logger.info(" detach_user function execution start",extra=log_context)

        payload =request.data
        payload_value = payload["permission_group_users_id"]

        permission_group_id=payload["permission_group_id"]
        allowed=permission_group_security(request.user.email,permission_group_id)
        if not allowed:
            response_data = {
                'status': 403,
                'message': 'Un-authorized action detected!'
            }
            return Response(response_data, status=status.HTTP_403_FORBIDDEN)

        pgu_id_exist=PermissionGroupUser.objects.filter(permission_group_user_id__in=payload_value).delete()
        
        if pgu_id_exist[0]!= 0:
            response_data = {
                "status":200,
                "message": "Successfully deleted"
            }
        
        else:
            response_data = {
                "status":204,
                "message": "permission_group_users_id not found"
            }
        
        if response_data["status"] == 200:
            user_logger.info("Deleted the user from user group",extra=log_context)

        else:
            logger.error(response_data["message"],extra=log_context)

        log_context["time_taken"]=int(time.time()-start_time)
        logger.info("detach_user function execution end",extra=log_context)
        return Response(response_data, status=status.HTTP_200_OK)
    
    except Exception as e:
        log_context["variable_state"]=locals()
        logger.error("Exception occured at detach_user function",exc_info=1,extra=log_context)
        raise e
    


@api_view(['DELETE'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
@check_user_write_access
def detach_recon_permission_grp(request):
    try:
        log_context = {
            "request_id": request.request_id,
            "user_email": request.user.email,
            "request_url": request.path,
        }
        start_time = time.time()
        logger.info(" detach_recon_permission_grp function execution start",extra=log_context)

        payload =request.data
        payload_value = payload["recon_group_map_id"]

        rgm_id_exist=ReconGroupMap.objects.filter(recon_group_map_id__in=payload_value).delete()
        
        if rgm_id_exist[0]!= 0:
            response_data = {
                "status":200,
                "message": "Successfully deleted"
            }
        
        else:
            response_data = {
                "status":204,
                "message": "recon_group_map_id not found"
            }
        
        if response_data["status"] == 200:
            user_logger.info("Deleted the permission group from a recon",extra=log_context)

        else:
            logger.error(response_data["message"],extra=log_context)

        log_context["time_taken"]=int(time.time()-start_time)
        logger.info("detach_recon_permission_grp function execution end",extra=log_context)
        return Response(response_data, status=status.HTTP_200_OK)
    
    except Exception as e:
        log_context["variable_state"]=locals()
        logger.error("Exception occured at detach_recon_permission_grp function",exc_info=1,extra=log_context)
        raise e
    


@api_view(['PATCH'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
@check_user_write_access
def update_groupname(request):
    try:
        log_context = {
            "request_id": request.request_id,
            "user_email": request.user.email,
            "request_url": request.path,
        }
        start_time = time.time()
        logger.info(" update_groupname function execution start",extra=log_context)

        payload =request.data
        permission_group=(payload["permission_group"])

        updated_list=PermissionGroupManager().update_permission_group_name(permission_group)

        response_data={
                        "status": 200,
                        "message": "updated Sucessfully",
                        "permission_group": updated_list
                    } 
        
        user_logger.info("updated the permission groupname to permission group",extra=log_context)
        log_context["time_taken"]=int(time.time()-start_time)
        logger.info("update_groupname function execution end",extra=log_context)

        return Response(response_data, status=status.HTTP_200_OK)
    
    except Exception as e:
        log_context["variable_state"]=locals()
        logger.error("Exception occured at update_groupname function",exc_info=1,extra=log_context)
        raise e
    



@api_view(['GET'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def group_export(request):
    try:
        start_time = time.time()
        log_context = {
            "request_id": request.request_id,
            "user_email": request.user.email,
            "request_url": request.path,
        }
        logger.info("group_export function execution start",extra=log_context)
        
        current_time = datetime.now().time().strftime("%H:%M:%S")
        current_date = datetime.now().strftime("%Y-%m-%d")
        modified_date = str(current_date) + '_' + str(current_time)
        file_name = 'Group_Export.csv'

        query = '''select r."name" as recon_name, permission_group_name, permission_name, user_email 
                    from fileservice.user_recon_permission urp inner join fileservice.recon r on
                    urp.recon_id = r.recon_id '''
        group_export_script(file_name, query)

        file_path = os.path.join(settings.MEDIA_ROOT+"/groups/"+"/export/" + file_name)
        file_path = (str(file_path).replace("\\", "/"))

        if os.path.exists(file_path):
            with open(file_path, 'rb') as fh:
                response_data = HttpResponse(fh.read(), content_type="text/csv")
                response_data['Content-Disposition'] = 'inline; filename=' + modified_date + os.path.basename(file_path)
                response_data['Access-Control-Expose-Headers'] = 'Content-Disposition'

                user_logger.info("Exported the group ",extra=log_context)
                log_context["time_taken"]=int(time.time()-start_time)
                logger.info(" group_export function execution ends",extra=log_context)

                return response_data
        else:
            response_data = {
                'status': 6002,
                'message': 'File Not Found'
            }
    
        if response_data.get("status")!=200:
            logger.error(response_data,extra=log_context)

        log_context["time_taken"]=int(time.time()-start_time)
        logger.info(" group_export function execution ends",extra=log_context)

        return Response(response_data, status=status.HTTP_200_OK)

    except Exception as e:
        log_context["variable_state"]=locals()
        logger.error(f" Exception occured in group_export : {str(e)}",exc_info=1,extra=log_context)
        raise e




@api_view(['PUT'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
@parser_classes((MultiPartParser, FormParser))
@check_user_write_access
def group_import(request):
    try:
        
        start_time = time.time()
        log_context = {
            "request_id": request.request_id,
            "user_email": request.user.email,
            "request_url": request.path,
        }
        logger.info("group_import function execution start",extra=log_context)

        # Getting the data from request
        file_obj = request.FILES['groups_file']
        group_details=[]

        # Storing file
        save_file = store_group_file(file_obj)
        file_path = save_file[1]

        
        with open(file_path, newline='', encoding="utf-8-sig") as groups_File:
            reader = csv.DictReader(groups_File)

            # Looping through the file data
            for index, row in enumerate(reader):
                group_names=row['group_names']
                group=PermissionGroup.objects.filter(permission_group_name=group_names).first()
            
                if group is None:
                    group=PermissionGroup(permission_group_name=group_names,created_by=request.user.email)
                    group.save()
                    
                    permission_group_id=group.permission_group_id
                    read_permission_id = Permissions.objects.get(permission_name="read").permission_id
                    PermissionGroupMap.objects.create(permission_id=read_permission_id, permission_group_id=permission_group_id)

                    serialized_data=PermissionsGroupSerializer(group)
                    group_details.append(serialized_data.data)
                else:
                    pass

            if group_details==[]:
                response_data = {
                    "status":203,
                    "message": "The given permission group name is already created",
                }
            else:
                response_data = {
                    "status":200,
                    "message": "Sucessfully created",
                    "group_detail":group_details
                }
                
            if response_data.get("status")!=200:
                logger.error(response_data,extra=log_context)
        
            user_logger.info("imported the permission group",extra=log_context)
            log_context["time_taken"]=int(time.time()-start_time)
            logger.info("group_import function execution end",extra=log_context)

            return Response(response_data, status=status.HTTP_200_OK)

    except Exception as e:
        log_context["variable_state"]=locals()
        logger.error(f" Exception occured in group_import : {str(e)}",exc_info=1,extra=log_context)
        raise e