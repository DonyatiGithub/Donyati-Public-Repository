from ...models import Recon

def is_global_attached(recon_id):
    check_attach=Recon.objects.filter(recon_id=recon_id).values_list('global_var_id',flat=True)[0]

    if check_attach:
        return True
    else:
        return False