import secrets
from rest_framework import status
from rest_framework.decorators import api_view, permission_classes, renderer_classes
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework.renderers import JSONRenderer
from rest_framework.response import Response
from .serializers import UserList, InviteList, UserInfo, DCUserSerializer
from ..models import ReconUser, InviteDetails, DCUser, ReconBridgeMapping, Reconreconcileperiod, Recon
from ..utils.email_util import send_mail
from ..utils.constants import INVITE_CONTENT, REACT_APP_URL, RESET_CONTENT
from ..utils.token_util import save_token, validate_token
from ..utils.user_permissions import is_write_permitted, is_admin
import datetime
from ..utils.pgsql_conn import call_admin_query
import requests
from Crypto.Cipher import AES
import re
import subprocess
from Data_Recon_App.models import ReconSpaceUsage
import psycopg2
from Data_Recon_Main.settings import MEDIA_ROOT
from django.db import connections
import codecs
import os, time
import logging
import time
from django.http import HttpRequest
from django.db import connections
from django.db.models import F
from .functions.global_variable import is_global_attached

user_logger = logging.getLogger("userlog")
logger = logging.getLogger("techlog")

@api_view(['POST'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def user_invite(request):
    email = request.data.get('email').lower()
    access_type = request.data.get('access_type')
    role = request.data.get('role')

    if is_admin(request.user.email):
        if InviteDetails.objects.filter(email=email).exists():
            response_data = {
                'status': 6002,
                'message': 'Invite was already sent to the user!'
            }
        elif ReconUser.objects.filter(email=email).exists():
            response_data = {
                'status': 6002,
                'message': 'User already exists for this mail!'
            }
        else:
            token = secrets.token_hex(32)
            button_url = REACT_APP_URL + 'register?token=' + token + '&email=' + email

            mail_context = {'name': 'there', 'button_label': 'Join now!',
                            'url': button_url, 'content': INVITE_CONTENT}
            send_mail(email, 'You are invited | Data Recon', mail_context)
            save_token(email, token, 'Pending', 1, 'INVITE')
            now = (datetime.datetime.now()).strftime("%m/%d/%Y, %H:%M:%S")
            current_date = datetime.datetime.strptime(now, "%m/%d/%Y, %H:%M:%S")

            new_invite = InviteDetails(email=email, status='Pending',
                                       role=role, access_type=access_type, token=token, created_date=current_date)
            new_invite.save()
            response_data = {
                'status': 200,
                'message': 'Invite sent successfully!'
            }
    else:
        response_data = {
            'status': 6002,
            'message': ' Only admin have access for invite !'
        }
    return Response(response_data, status=status.HTTP_200_OK)


@api_view(['POST'])
@permission_classes((AllowAny,))
@renderer_classes((JSONRenderer,))
def user_add(request):
    email = request.data.get('email').lower()
    firstName = request.data.get('firstName')
    lastName = request.data.get('lastName')
    password = request.data.get('password')
    token = request.data.get('token')
    reg_ex ="^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{12,}$"
    accepted = re.fullmatch(reg_ex,password)            
    if email and firstName and lastName and password and token:
        if not accepted:
            response_data = {
                        'status': 6002,
                        'message': 'Password must contain at least 12 characters, including at least 2 uppercase letters, 2 lowercase letters, 1 digit, and 1 special character.'
                    }
        else:    
            if validate_token(email, token, 'INVITE'):
                if ReconUser.objects.filter(email=email).exists():
                    response_data = {
                        'status': 6002,
                        'message': 'This email id already exists!'
                    }
                elif InviteDetails.objects.filter(email=email).exists():
                    invite_instance = InviteDetails.objects.filter(email=email)[0]
                    role = invite_instance.role
                    access_type = invite_instance.access_type

                    ReconUser.objects.create_user(email=email, username=email, password=password)
                    ReconUser.objects.filter(email=email).update(first_name=firstName, last_name=lastName, role=role,
                                                                access_type=access_type, admin_tag=False)

                    delete_email = InviteDetails.objects.filter(email=email)
                    delete_email.delete()
                    response_data = {
                        'status': 200,
                        'message': 'Registration successful!'
                    }
                else:
                    response_data = {
                        'status': 6002,
                        'message': 'Invalid Email id!'
                    }
            else:
                response_data = {
                    'status': 6002,
                    'message': 'Invalid / Expired link'
                }
    else:
        response_data = {
            'status': 6002,
            'message': 'Please provide all required fields!'
        }
    return Response(response_data, status=status.HTTP_200_OK)


@api_view(['POST'])
@permission_classes((AllowAny,))
@renderer_classes((JSONRenderer,))
def forgot_password(request):
    email = request.data.get('email')

    is_user_active = ReconUser.objects.get(email=email).is_active

    if not is_user_active:
        response_data = {
            'status': 6002,
            'message': 'Your account has been deactivated!, please contact admin'
        }

    elif ReconUser.objects.filter(email=email).exists():
        token = secrets.token_hex(32)
        button_url = REACT_APP_URL + 'reset?token=' + token + '&email=' + email
        mail_context = {'name': 'there', 'button_label': 'Reset Password',
                        'url': button_url, 'content': RESET_CONTENT}
        send_mail(email, "Reset Password | Data Recon", mail_context)

        save_token(email, token, 'Pending', 180, 'FORGOT')
        response_data = {
            'status': 200,
            'message': 'Reset password link is sent to the mail!'
        }
    else:
        response_data = {
            'status': 6002,
            'message': 'No user found with specified email'
        }

    return Response(response_data, status=status.HTTP_200_OK)


@api_view(['POST'])
@permission_classes((AllowAny,))
@renderer_classes((JSONRenderer,))
def reset_password(request):
    email = request.data.get('email').lower()
    token = request.data.get('token')
    password = request.data.get("password")

    if validate_token(email, token, 'FORGOT'):
        if ReconUser.objects.filter(email=email).exists():
            new_password = ReconUser.objects.get(email=email)
            new_password.set_password(password)
            new_password.save()

            response_data = {
                'status': 200,
                'message': 'Password updated successfully!',
            }
        else:
            response_data = {
                'status': 6002,
                'message': 'Invalid Email id'
            }
    else:
        response_data = {
            'status': 6002,
            'message': 'Invalid / Expired link!'
        }

    return Response(response_data, status=status.HTTP_200_OK)


@api_view(['GET'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def user_list(request):
    instance = ReconUser.objects.all()
    serialized = UserList(instance, many=True)

    response_data = {
        'status': 200,
        'data': serialized.data
    }

    return Response(response_data, status=status.HTTP_200_OK)


@api_view(['GET'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def invite_list(request):
    instance = InviteDetails.objects.all()
    serialized = InviteList(instance, many=True)

    response_data = {
        'status': 200,
        'data': serialized.data
    }

    return Response(response_data, status=status.HTTP_200_OK)


@api_view(['POST'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def update_user(request):
    email = request.data.get('email')
    role = request.data.get('role')
    access_type = request.data.get('access_type')
    is_active = request.data.get('is_active')
    onestream = request.data.get('onestream')

    if is_admin(request.user.email):
        if(role=='Admin' and access_type['privilege']==1):
            response_data = {
                'status': 6002,
                'message': 'The role admin cannot have read access'
            }
        else :    
            if ReconUser.objects.filter(email=email).exists():
                ReconUser.objects.filter(email=email).update(role=role, access_type=access_type, is_active=is_active,
                                                            onestream=onestream, admin_tag=request.user.email)
                instance = ReconUser.objects.all()
                serialized = UserList(instance, many=True)
                response_data = {
                    'status': 200,
                    'data': serialized.data,
                    'message': 'User Updated successfully!'
                }
            else:
                response_data = {
                    'status': 6002,
                    'message': 'Invalid email id!'
                }
    else:
        response_data = {
            'status': 6002,
            'message': 'Only admin have access for Update user!'
        }
    return Response(response_data, status=status.HTTP_200_OK)


@api_view(['POST'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def user_info(request):
    email = request.data.get('email')

    if ReconUser.objects.filter(email=email).exists():
        instance = ReconUser.objects.filter(email=email)[0]
        serialized = UserInfo(instance)

        response_data = {
            'status': 200,
            'data': serialized.data
        }
    else:
        response_data = {
            'status': 6002,
            'message': 'No User found with the specified id!'
        }

    return Response(response_data, status=status.HTTP_200_OK)


@api_view(['DELETE'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def user_delete(request):
    email = request.data.get('email')

    if is_admin(request.user.email):
        if ReconUser.objects.filter(email=email).exists():
            response = call_admin_query("DELETE FROM \"admin\".auth_user WHERE email='" + email + "'")
            if response['status'] == 200:
                response_data = {
                    'status': 200,
                    'message': 'User Deleted successfully!'
                }
            else:
                response_data = response
        else:
            response_data = {
                'status': 6002,
                'message': 'No User found with the specified id!'
            }
    else:
        response_data = {
            'status': 6002,
            'message': ' Only admin have access for Delete!'
        }
    return Response(response_data, status=status.HTTP_200_OK)


@api_view(['POST'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def resend_invite(request):
    email = request.data.get('email')

    if is_admin(request.user.email):
        if InviteDetails.objects.filter(email=email).exists():
            instance = InviteDetails.objects.filter(email=email)[0]
            access_type = instance.access_type
            role = instance.role

            token = secrets.token_hex(32)
            button_url = REACT_APP_URL + 'register?token=' + token + '&email=' + email

            mail_context = {'name': 'there', 'button_label': 'Join now!',
                            'url': button_url, 'content': INVITE_CONTENT}
            send_mail(email, 'You are invited | Data Recon', mail_context)
            save_token(email, token, 'Pending', 1, 'INVITE')
            now = (datetime.datetime.now()).strftime("%m/%d/%Y, %H:%M:%S")
            current_date = datetime.datetime.strptime(now, "%m/%d/%Y, %H:%M:%S")

            new_invite = InviteDetails.objects.filter(email=email).update(role=role, access_type=access_type,
                                                                          status='Pending', token=token,
                                                                          created_date=current_date)
            response_data = {
                'status': 200,
                'message': 'Invite sent successfully!'
            }
    else:
        response_data = {
            'status': 6002,
            'message': ' Only admin have access for invite !'
        }
    return Response(response_data, status=status.HTTP_200_OK)


@api_view(['POST'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def onestream_config(request):
    tenant_id = request.data.get('tenant_id')
    client_id = request.data.get('client_id')
    client_secret = request.data.get('client_secret')
    onestream_url = request.data.get('url')
    osname = request.data.get('osname')
    email = request.user.email

    if is_admin(request.user.email):

        payload = 'grant_type=client_credentials&Scope=api://' + client_id + '/.default'
        headers = {
            'Accept': 'application/json',
            'Content-Type': 'application/x-www-form-urlencoded'
        }
        url = "https://login.microsoftonline.com/" + tenant_id + "/oauth2/v2.0/token"

        response = requests.post(url, headers=headers, data=payload, auth=(client_id, client_secret))
        if response.status_code == 200:

            client_secret = client_secret.encode()
            key = b"\xf82\xea\xaap@\n'Yw\x10B\xd8b\xac\xc6"
            cipher = AES.new(key, AES.MODE_EAX)
            nonce = cipher.nonce
            client_secret, tag = cipher.encrypt_and_digest(client_secret)

            if DCUser.objects.filter(email=email, osname=osname).exists():
                DCUser.objects.filter(email=email).update(dc_username=client_id, dc_password=client_secret,
                                                          dc_url=onestream_url, tenant_id=tenant_id, tag=tag,
                                                          nonce=nonce, osname=osname)
            else:
                dc_user = DCUser(import_type=3, dc_username=client_id, dc_password=client_secret,
                                 dc_url=onestream_url, tenant_id=tenant_id, email=email, tag=tag, nonce=nonce,
                                 osname=osname)
                dc_user.save()
                # dc_user = DCUser(app_name="1", import_type=3, dc_username=client_id, dc_password=client_secret,
                #                  dc_url=onestream_url, tenant_id=tenant_id, email=email, tag=tag, nonce=nonce)
                # dc_user.save()
            response = response.json()
            ReconUser.objects.filter(email=email).update(admin_tag=email)
    else:
        response = {
            'status': 6002,
            'message': 'Only admin has access to configure onestream'
        }
    return Response(response, status=status.HTTP_200_OK)


@api_view(['GET'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def onestream_list(request):
    email = request.user.email
    instance = DCUser.objects.filter(email=email, import_type=3)
    serialized = DCUserSerializer(instance, many=True)

    data = serialized.data

    for val in data:
        client_id = val['dc_username']
        cl_len = len(client_id)
        client_id = client_id[-6:]
        cl_str = '*' * cl_len
        client_id = cl_str + client_id
        tenant_id = val['tenant_id']
        tn_len = len(tenant_id)
        tenant_id = tenant_id[-6:]
        tn_str = '*' * tn_len
        tenant_id = tn_str + tenant_id
        val['dc_username'] = client_id
        val['tenant_id'] = tenant_id
        del val['dc_password']
        # print(client_id)

    response_data = {
        'status': 200,
        'data': serialized.data
    }

    return Response(response_data, status=status.HTTP_200_OK)


@api_view(['DELETE'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def onestream_delete(request):
    email = request.user.email
    osname = request.data.get('osname')
    if is_admin(email):
        instance = DCUser.objects.filter(email=email, osname=osname)
        if email == instance[0].email:
            instance.delete()
        response_data = {
            'status': 200,
            'message': "Delete " + osname + " successfully"
        }
    else:
        response_data = {
            'status': 6002,
            'message': "Only the admin has access to delete"
        }

    return Response(response_data, status=status.HTTP_200_OK)


        
@api_view(['GET'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def get_disk_space(request):
    sql_query='''SELECT
                "name" AS Recon_Name,
                last_modified_by AS Last_User,
                TO_CHAR(last_modified_date, 'YYYY-MM-DD"T"HH24:MI:SS"Z"') AS Last_Modified_Date,
                TO_CHAR(created_date, 'YYYY-MM-DD"T"HH24:MI:SS"Z"') as created_date,
                sign_off,
                is_deleted,
                COALESCE(pg_size_pretty(SUM(q.table_size) OVER (PARTITION BY "name")), '0 kB') AS Recon_Table_Size,
                COALESCE(pg_size_pretty(rsu.disk_usage::numeric), '0 kB') AS File_Size,
                pg_size_pretty(coalesce(SUM(q.table_size) OVER (PARTITION BY "name"),'0')::numeric + coalesce(rsu.disk_usage,'0')::numeric) AS Total_Space_Used
            FROM (
                WITH cte AS (
                    SELECT
                        CASE
                            WHEN t.table_name LIKE 'app%' THEN 'Source Data'
                            WHEN t.table_name LIKE 'je%' THEN 'Journal Source Data'
                            WHEN t.table_name LIKE 'bridgesync_%' THEN 'Transformation'
                            WHEN t.table_name LIKE 'bridge_%' THEN 'Bridge'
                            WHEN t.table_name LIKE 'report_je%' THEN 'Report-Journal Entry'
                            WHEN t.table_name LIKE 'report_%' THEN 'Report'
                            WHEN t.table_name LIKE 'final_report_%' THEN 'Report-Consolidated'
                        END AS table_type,
                        CASE
                            WHEN right(t.table_name, length(t.table_name) - position('_' in t.table_name)) LIKE 'report_%' 
                            THEN right(right(t.table_name, length(t.table_name) - position('_' in t.table_name)), length(right(t.table_name, length(t.table_name) - position('_' in t.table_name))) - position('_' in right(t.table_name, length(t.table_name) - position('_' in t.table_name)))) 
                            WHEN right(t.table_name, length(t.table_name) - position('_' in t.table_name)) LIKE '%\_%' 
                            THEN left(right(t.table_name, length(t.table_name) - position('_' in t.table_name)), length(right(t.table_name, length(t.table_name) - position('_' in t.table_name))) - (length(right(t.table_name, length(t.table_name) - position('_' in t.table_name))) - position('_' in right(t.table_name, length(t.table_name) - position('_' in t.table_name)))) - 1)
                            ELSE right(t.table_name, length(t.table_name) - position('_' in t.table_name))
                        END AS recon_id,
                        pg_total_relation_size(pgc.oid) AS total_size
                    FROM
                        information_schema.tables t
                    INNER JOIN pg_catalog.pg_class pgc 
                    ON t.table_name = pgc.relname
                    WHERE
                        table_schema = 'fileservice'
                        AND table_type <> 'VIEW'
                        AND t.table_name NOT LIKE 'recon%'
                        AND t.table_name NOT LIKE 'track%'
                )
                SELECT
                    r."name",
                    r.recon_id,
                    r.last_modified_by,
                    r.last_modified_date,
                    r.created_date,
                    r.sign_off,
                    r.is_deleted,
                    SUM(cte.total_size) AS table_size
                FROM
                    cte
                RIGHT JOIN fileservice.recon r ON cte.recon_id::text = r.recon_id::text
                GROUP BY
                    r.recon_id,
                    r."name",
                    r.last_modified_by,
                    r.last_modified_date,
                    r.created_date,
                    r.sign_off,
                    r.is_deleted
                ORDER BY
                    r.recon_id
            ) q
            LEFT JOIN fileservice.recon_space_usage rsu 
            ON q.recon_id = rsu.recon_id
            order by created_date desc;
            '''

    if os.name == 'nt':
        csv_path = fr'{MEDIA_ROOT}\recon_size.csv'
        command_1 = f'Get-ChildItem -Path "{MEDIA_ROOT}" | Where-Object {{ $_.PSIsContainer }} | ForEach-Object {{ $folderName = $_.Name; $totalSizeBytes = ($_ | Get-ChildItem -Recurse | Measure-Object -Property Length -Sum).Sum; Write-Output "$folderName,$totalSizeBytes" }} | Out-File -FilePath "{csv_path}" -Encoding UTF8'
        subprocess.run(['powershell.exe', '-Command', command_1], shell=True, capture_output=True, text=True)

        with codecs.open(csv_path, 'r', encoding='utf-8-sig') as file:
            csv_content = file.read()
        with codecs.open(csv_path, 'w', encoding='utf-8') as file:
            file.write(csv_content)

        command_2 = 'psql -h localhost -d db_dataRecon -U user_dataRecon_file -c "delete from fileservice.recon_space_usage" -p 25432'
        command_3 = f'psql -h localhost -d db_dataRecon -U user_dataRecon_file -c "\\copy fileservice.recon_space_usage from \'{csv_path}\' with delimiter \',\'" -p 25432'
        command_4 = r'''
                    $disk = Get-WmiObject Win32_LogicalDisk -Filter "DeviceID='C:'" | Select-Object Size, FreeSpace
                    $totalSpace = $disk.Size
                    $freeSpace = $disk.FreeSpace
                    $usedSpace = $totalSpace - $freeSpace
                    $percentageUsed = [math]::Round(($usedSpace / $totalSpace) * 100, 1)
                    Write-Output "$($percentageUsed)%"'''
                    
        cursor = connections['Recon'].cursor()
        try:
            for command in [command_2,command_3]:
                subprocess.run(command, shell=True, capture_output=True, text=True)
            result1 = subprocess.run(['powershell', '-Command', command_4], capture_output=True, text=True)
            disk_usage_output = result1.stdout.strip()
            cursor.execute(sql_query)
            data = cursor.fetchall()
            columns = [col[0] for col in cursor.description]
            response = [dict(zip(columns, row)) for row in data]
            for entry in response:
                entry['is_deleted'] = 'No(Marked for deletion)' if entry['is_deleted'] else 'Yes'
            result2={"status":200,"data":response,'disk_space_used': disk_usage_output}
            return Response(result2)
            
        except Exception as e:
            return Response({"error": str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

        finally:
            cursor.close()

    else:
        command_1=f"du -d 1 -b {MEDIA_ROOT} | awk '{{print $2\",\"$1}}' | sed 's#{MEDIA_ROOT}/##' | sed 's/^\\.,[0-9]*//' | head -n -1 > {MEDIA_ROOT}/recon_size.csv"
        command_2='psql -h localhost -d db_dataRecon -U user_dataRecon_file -c "delete from fileservice.recon_space_usage" -p 5432'
        command_3=f'psql -h localhost -d db_dataRecon -U user_dataRecon_file -c "\copy fileservice.recon_space_usage from \'{MEDIA_ROOT}/recon_size.csv\' with delimiter \',\'" -p 5432'
        command_4="df -h / | awk '{print $5}' | tail -n -1"
        
        cursor = connections['Recon'].cursor()
        try:
            for command in [command_1,command_2,command_3]:
                subprocess.run(command, shell=True, capture_output=True, text=True)
            result1 = subprocess.run(command_4, shell=True, stdout=subprocess.PIPE, text=True)
            disk_usage_output = result1.stdout.strip()
            cursor.execute(sql_query)
            data = cursor.fetchall()
            columns = [col[0] for col in cursor.description]
            response = [dict(zip(columns, row)) for row in data]
            for entry in response:
                entry['is_deleted'] = 'No(Marked for deletion)' if entry['is_deleted'] else 'Yes'
            result2={"status":200,"data":response,'disk_space_used': disk_usage_output}
            return Response(result2)
            
        except Exception as e:
            return Response({"error": str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

        finally:
            cursor.close()
        

        



@api_view(['GET'])
@renderer_classes((JSONRenderer,))
def ping(request:HttpRequest):

    try:
        log_context = {
            "user_email":request.user.email,
            "request_id":request.request_id,
            "request_url":request.path,
            "recon_id" : 5


        }
        dummy_dict={"status":6002,"message":"bala"}
        if dummy_dict.get("status")==200:
            pass
        else:
            logger.error(dummy_dict,extra=log_context)
        logger.warning("this is the request_id",extra=log_context)
        logger.warning("this is a %s logger",__name__)
        logger.debug("This is a debug message")
        logger.info("This is an info message")
        logger.warning("This is a warning message")
        logger.error("This is an error message")
        logger.critical("This is a critical message")
        a =0 
        b =10
        return Response({"ping":"pong"},status=200)
    except Exception as e:
        log_context["variable_state"]=locals()
        logger.error(f"error occured in ping {str(e)}",exc_info=1,extra=log_context)

        return Response({"error":str(e)},status=500)
    

@api_view(['GET'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def user_logs_list(request):

    start =int(request.GET.get("start",0))
    end =int(request.GET.get("end",10))
    recon_id = request.GET.get("recon_id")

    cursor = connections['Recon'].cursor()
    try:

        if recon_id==None:
            query=f"select fileservice.log_entries.user_email,fileservice.log_entries.message,to_char(fileservice.log_entries.recorded_at, 'YYYY-MM-DD HH24:MI:SS.US') as recored_at,fileservice.recon.name as recon_name from fileservice.log_entries inner join fileservice.recon on fileservice.log_entries.recon_id=fileservice.recon.recon_id  where fileservice.log_entries.log_name='userlog' order by  recorded_at DESC  limit {end} offset {start};"
        else:
            recon_id = int(recon_id)
            query=f"select fileservice.log_entries.user_email,fileservice.log_entries.message,fileservice.log_entries.event_stage,to_char(fileservice.log_entries.recorded_at, 'YYYY-MM-DD HH24:MI:SS.US') as recored_at,fileservice.recon.name as recon_name from fileservice.log_entries inner join fileservice.recon on fileservice.log_entries.recon_id=fileservice.recon.recon_id  where fileservice.log_entries.log_name='userlog' and fileservice.log_entries.recon_id={recon_id} order by  recorded_at DESC limit {end} offset {start};"

        cursor.execute(query)
        data = cursor.fetchall()
        columns = [col[0] for col in cursor.description]
        result = [dict(zip(columns, row)) for row in data]
        
        if recon_id== None:
            count_query ="select count(*) from fileservice.log_entries le inner join fileservice.recon r on le.recon_id =r.recon_id  where le.log_name ='userlog'; "
            cursor.execute(count_query)
            count=cursor.fetchall()

            resp={"status":200,"data":result,"count":count[0][0]}
        else:
            resp={"status":200,"data":result}
         
        return Response(resp)
        
    except Exception as e:

        err_resp = {"err_msg":str(e),"status":500}
        return Response(err_resp,status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    finally:
        cursor.close()     


        
        
@api_view(['GET'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def user_recon_list(request:HttpRequest):

    try:
        start_time = time.time()
        log_context = {
            "request_id": request.request_id,
            "user_email": request.user.email,
            "request_url": request.path,
        }
        logger.info(" user_recon_list function execution start",extra=log_context)

        user_name= request.user.username
        role=request.user.role

        if role == "Admin":
            data = Recon.objects.values('recon_id', recon_name=F('name')).order_by('-created_date')
            result={"status":200 ,"recons":data}
        
        else:
            data = Recon.objects.filter(created_by = user_name).values('recon_id', recon_name=F('name')).order_by('-created_date')
            result={"status":200 ,"recons":data}

        log_context["time_taken"]=int(time.time()-start_time)
        logger.info("user_recon_list function execution ends",extra=log_context)
        
        return Response(result)

    
    except Exception as e:
        log_context["variable_state"]=locals()
        logger.error(f" exception occured on user_recon_list {str(e)} ",exc_info=1,extra=log_context)
        raise e

        
        

@api_view(['GET'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def user_email_list(request):

    try:
        start_time = time.time()
        log_context = {
            "request_id": request.request_id,
            "user_email": request.user.email,
            "request_url": request.path,
        }
        logger.info(" user_email_list function execution start",extra=log_context)

        users_email = ReconUser.objects.order_by('email').values_list('email',flat=True)
        result={"status":200 ,"user_email":users_email}

        log_context["time_taken"]=int(time.time()-start_time)
        logger.info("user_email_list function execution ends",extra=log_context)
        
        return Response(result)
    
    except Exception as e:
        log_context["variable_state"]=locals()
        logger.error(f" exception occured on user_email_list {str(e)} ",exc_info=1,extra=log_context)
        raise e
 



@api_view(['GET'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def bridgemember_period_list(request,recon_id):
    try:
        log_context = {
            "recon_id": recon_id,
            "request_id": request.request_id,
            "user_email": request.user.email,
            "request_url": request.path,
        }

        start_time = time.time()
        logger.info(" bridgemember_period_list function execution start",extra=log_context)
        attached_flag=is_global_attached(recon_id=recon_id)

        cursor = connections['Recon'].cursor()
        if attached_flag:
            sql_query=f'''SELECT bridge_member
                    FROM (
                        SELECT distinct bridge_member, TO_DATE(bridge_member, 'Mon') AS month_order
                        FROM recon_bridge_mapping rbm
                        INNER JOIN fileservice.global_recon_dimensions grd ON grd.global_dimensions_id = rbm.dim_id
                        WHERE rbm.recon_id = {recon_id} AND grd.dimension = 'PERIOD' ORDER BY month_order
                    ) as period ;'''
        else:
            sql_query=f'''SELECT bridge_member
                    FROM (
                        SELECT distinct bridge_member, TO_DATE(bridge_member, 'Mon') AS month_order
                        FROM recon_bridge_mapping rbm
                        INNER JOIN fileservice.recon_dimensions rd ON rd.dimensions_id = rbm.dim_id
                        WHERE rbm.recon_id = {recon_id} AND rd.dimension = 'PERIOD' ORDER BY month_order
                    ) as period;'''
        
        cursor.execute(sql_query)
        data = cursor.fetchall()
        flat_list = [month[0] for month in data]

        response_data={'status':200, 'bridgemember_period_list':flat_list}

        log_context["time_taken"]=int(time.time()-start_time)
        logger.info("bridgemember_period_list function execution end",extra=log_context)
        return Response(response_data, status=status.HTTP_200_OK)
    except Exception as e:

        log_context["variable_state"]=locals()
        logger.error("Exception occured at bridgemember_period_list function",exc_info=True,extra=log_context)
        raise e



@api_view(['POST'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def save_period_list(request):
    try:
        log_context = {
            "recon_id": request.data['recon_id'],
            "request_id": request.request_id,
            "user_email": request.user.email,
            "request_url": request.path,
            "event_stage": "Bridgemembers"
        }

        start_time = time.time()
        logger.info("save_period_list function execution start",extra=log_context)
        
        recon_id = request.data['recon_id']
        reconcile_period = request.data['reconcile_period']

        app_1_source_period=ReconBridgeMapping.objects.filter(recon_id=recon_id,app_type='0',bridge_member=reconcile_period).values_list('source_member',flat=True).first()
        app_2_source_period=ReconBridgeMapping.objects.filter(recon_id=recon_id,app_type='1',bridge_member=reconcile_period).values_list('source_member',flat=True).first()
        recon_instance = Reconreconcileperiod.objects.filter(recon_id=recon_id)

        if recon_instance.exists():
            save_details=recon_instance.update(user_selected_period=reconcile_period,app_1_source_period=app_1_source_period,app_2_source_period=app_2_source_period)
        else:
            save_details=Reconreconcileperiod(recon_id=recon_id,user_selected_period=reconcile_period,app_1_source_period=app_1_source_period,app_2_source_period=app_2_source_period)
            save_details.save()

        response_data={'status':200, 'message':"selected period saved successfully"}
        user_logger.info("Selected the period for reconcile",extra=log_context)

        log_context["time_taken"]=int(time.time()-start_time)
        logger.info("save_period_list function execution end",extra=log_context)
        return Response(response_data, status=status.HTTP_200_OK)
    except Exception as e:

        log_context["variable_state"]=locals()
        user_logger.error("Exception occured at save_period_list function",exc_info=True,extra=log_context)
        raise e        
    
@api_view(['DELETE'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def delete_period_list(request):
    try:
        log_context = {
            "recon_id": request.data['recon_id'],
            "request_id": request.request_id,
            "user_email": request.user.email,
            "request_url": request.path,
        }
        start_time = time.time()
        logger.info("delete_period_list function execution start",extra=log_context)

        recon_id = request.data['recon_id']
        recon_instance =  Reconreconcileperiod.objects.filter(recon_id = recon_id)
        if recon_instance.exists():
            recon_instance.delete()
            response_data = {
                'status': 200,
                'message': "Period deleted successfully"
            }
        else:
            response_data = {
                'status': 404,
                'message': "Period not found" 
            }
        log_context["time_taken"]=int(time.time()-start_time)
        logger.info("delete_period_list function execution end",extra=log_context)
        return Response(response_data, status=status.HTTP_200_OK)
    
    except Exception as e:

        log_context["variable_state"]=locals()
        logger.error("Exception occured at delete_period_list function",exc_info=True,extra=log_context)
        raise e    