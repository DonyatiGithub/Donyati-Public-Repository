REQUEST_DB_MAP ={
 "recorded_at":"fileservice.log_entries.recorded_at",
 "logging_level":"fileservice.log_entries.logging_level",
 "request_url":"fileservice.log_entries.request_url",
}