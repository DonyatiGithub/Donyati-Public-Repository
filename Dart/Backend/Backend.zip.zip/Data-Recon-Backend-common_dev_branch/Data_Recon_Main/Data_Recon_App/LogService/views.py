from rest_framework.permissions import IsAuthenticated
from rest_framework.renderers import JSONRenderer
from rest_framework import status
from rest_framework.decorators import permission_classes, api_view, renderer_classes, parser_classes
from django.http import HttpRequest
from .log_utils import build_log_filters
from django.db import connections
from rest_framework.response import Response




@api_view(['POST'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def error_log_list(request:HttpRequest):
    try:
        cursor = connections['Recon'].cursor()
        start =int(request.data.get("start",0))
        end =int(request.data.get("end",10))
        selected_filters = request.data.get("selected_filters")
        
        base_query =  f"""select fileservice.log_entries.*,to_char(fileservice.log_entries.recorded_at, 'YYYY-MM-DD"T"HH24:MI:SS"Z"') as recored_at,fileservice.recon.name as recon_name from fileservice.log_entries inner join fileservice.recon on fileservice.log_entries.recon_id=fileservice.recon.recon_id  where fileservice.log_entries.log_name='techlog'"""
        filter_query = build_log_filters(selected_filters)
        sort_query =" order by  recorded_at DESC "
        paginated_query=f" limit {end} offset {start};"
        final_query = base_query + filter_query + sort_query + paginated_query
        
        
        cursor.execute(final_query)
        data = cursor.fetchall()
        columns = [col[0] for col in cursor.description]
        result = [dict(zip(columns, row)) for row in data]

        count_query ="select count(*) from fileservice.log_entries le inner join fileservice.recon r on le.recon_id =r.recon_id  where le.log_name ='techlog'; "
        cursor.execute(count_query)
        count=cursor.fetchall()

        resp={"status":200,"data":result,"count":count[0][0]}
        return Response(resp)
    
    
    except Exception as e:
        err_resp = {"err_msg":str(e),"status":500}
        return Response(err_resp,status=status.HTTP_500_INTERNAL_SERVER_ERROR)
    
    finally:
        cursor.close()


@api_view(['GET'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def request_logs(request:HttpRequest,request_id):
    try:
        cursor = connections['Recon'].cursor()
                
        base_query =  f"select fileservice.log_entries.*,to_char(fileservice.log_entries.recorded_at, 'YYYY-MM-DD HH24:MI:SS.US') as recored_at,fileservice.recon.name as recon_name from fileservice.log_entries inner join fileservice.recon on fileservice.log_entries.recon_id=fileservice.recon.recon_id  where fileservice.log_entries.request_id='{request_id}';  "
        
        
        cursor.execute(base_query)
        data = cursor.fetchall()
        columns = [col[0] for col in cursor.description]
        result = [dict(zip(columns, row)) for row in data]


        resp={"status":200,"data":result}
        return Response(resp)
    
    
    except Exception as e:
        err_resp = {"err_msg":str(e),"status":500}
        return Response(err_resp,status=status.HTTP_500_INTERNAL_SERVER_ERROR)
    
    finally:
        cursor.close()
    


@api_view(['POST'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def db_log_list(request:HttpRequest):
    try:
        cursor = connections['Recon'].cursor()
                
        base_query =  f"select fileservice.log_entries.*,to_char(fileservice.log_entries.recorded_at, 'YYYY-MM-DD HH24:MI:SS.US') as recored_at,fileservice.recon.name as recon_name from fileservice.log_entries inner join fileservice.recon on fileservice.log_entries.recon_id=fileservice.recon.recon_id ;  "
        
        
        cursor.execute(base_query)
        data = cursor.fetchall()
        columns = [col[0] for col in cursor.description]
        result = [dict(zip(columns, row)) for row in data]


        resp={"status":200,"data":result}
        return Response(resp)
    
    except Exception as e:
        err_resp = {"err_msg":str(e),"status":500}
        return Response(err_resp,status=status.HTTP_500_INTERNAL_SERVER_ERROR)
    
    finally:
        cursor.close()

@api_view(['GET'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def db_error_log(request):

    start =int(request.GET.get("start",0))
    end =int(request.GET.get("end",5000))

    try:
        query = f"""SELECT r.\"name\" AS recon_name, CASE WHEN ra.app_name = '0' THEN 'App1' ELSE 'App2' END AS app_name, tadt.table_name, tadt.log_comment, to_char(tadt.created_date, 'YYYY-MM-DD"T"HH24:MI:SS"Z"') as created_date FROM fileservice.track_app_data_table tadt LEFT JOIN fileservice.recon r ON (tadt.application_id = r.app1_id OR tadt.application_id = r.app2_id OR tadt.recon_id = r.recon_id) LEFT JOIN fileservice.recon_applications ra ON tadt.application_id = ra.recon_app_id ORDER BY tadt.created_date DESC limit {end} offset {start};"""
        cursor = connections['Recon'].cursor()
        cursor.execute(query)
        data = cursor.fetchall()
        columns = [col[0] for col in cursor.description]
        result = [dict(zip(columns, row)) for row in data]
        response={"status":200,"data":result}
        return Response(response)
    
    except Exception as e:
        err_resp = {"err_msg":str(e),"status":500}
        return Response(err_resp,status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    finally:
        cursor.close()

