from django.urls import path
from rest_framework.urlpatterns import format_suffix_patterns
from rest_framework_simplejwt.views import TokenRefreshView
from . import views

urlpatterns = [
    path('auth', views.user_login, name='userLogin'),
    path('logout', views.user_logout, name='userLogout'),
    path('list', views.user_list, name='userList'),
    path('refresh', TokenRefreshView.as_view(), name='refresh_token'),
    path('recon-permission/<int:recon_id>',views.user_recon_permission,name='user_recon_permission')
]

urlpatterns = format_suffix_patterns(urlpatterns)
