from django.contrib.auth import authenticate
from rest_framework import status
from rest_framework.decorators import api_view, permission_classes, renderer_classes
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework.renderers import JSONRenderer
from rest_framework.response import Response
from rest_framework_simplejwt.tokens import RefreshToken
from . serilaizers import UserListSerializer
from .. models import ReconUser
import datetime
from Data_Recon_App.models import  Permissions,UserReconPermission
from django.db import connections
from Data_Recon_App.permission_service.recon_permission_manager.permission_security import recon_owner_or_admin


@api_view(['POST'])
@permission_classes((AllowAny,))
@renderer_classes((JSONRenderer,))
def user_login(request):
    email = request.data.get('email').lower()
    password = request.data.get('password')

    error_msg_data = {
        'status': 403,
        'message': 'Invalid username or password!'
    }

    if ReconUser.objects.filter(email=email).exists():
        username = ReconUser.objects.get(email=email).username
        is_user_active = ReconUser.objects.get(email=email).is_active
        if not is_user_active:
            error_msg_data = {
                'status': 403,
                'message': 'Your account has been deactivated!, please contact admin'
            }
    else:
        username = None

    user = authenticate(username=username, password=password)

    if user is not None:
        if user.is_active:
            refresh = RefreshToken.for_user(user)
            serialized = UserListSerializer(user)
            now = (datetime.datetime.now()).strftime("%m/%d/%Y, %H:%M:%S")
            last_login = datetime.datetime.strptime(now, "%m/%d/%Y, %H:%M:%S")
            ReconUser.objects.filter(email=email).update(last_login=last_login)

            response_data = {
                'status': 200,
                'accessToken': str(refresh.access_token),
                'refreshToken':str(refresh), # adding refresh token
                'data': serialized.data
            }
        else:
            response_data = {
                'status': 403,
                'message': 'Invalid email id or password!'
            }
    else:
        response_data = error_msg_data

    return Response(response_data, status=status.HTTP_200_OK)


@api_view(['GET'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def user_logout(request):
    response_data = {
        'status': 200,
        'accessToken': 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ0b2tlbl90'
                       'eXBlIjoiYWNjZXNzIiwiZXhwIjoxNjYxODM5NTMyLCJpYXQiO'
                       'jE2NjE4MzU5MzIsImp0aSI6Ijc1OGI5NDcyOGMyYzRiNzc5ODQ5MWF'
                       'jNDg1OTE1YTY4IiwidXNlcl9pZCI6MX0.gXS_IwIUHtchl0HmS1wO7Z'
                       'nT1vvwUIv1MlSFy-AJ630'
    }

    return Response(response_data, status=status.HTTP_200_OK)


@api_view(['GET'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def user_list(request):
    instance = ReconUser.objects.all()
    serialized = UserListSerializer(instance, many=True)

    response_data = {
        'status': 200,
        'data': serialized.data
    }

    return Response(response_data, status=status.HTTP_200_OK)



@api_view(['GET'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def user_recon_permission(request,recon_id):

    permissions=Permissions.objects.all()
    user_permission_map={}
    
    true_flag =recon_owner_or_admin(request.user.email,recon_id)
    for perm in permissions:
        
        if true_flag:
            user_permission_map[perm.permission_name]=True
        else:
            user_permission_map[perm.permission_name]=False
    
    if true_flag:
        response_data={"status":200,
                   "permission":user_permission_map
                   }
    
        return Response(response_data,status=status.HTTP_200_OK)
    
    cursor = connections['Recon'].cursor()
    checked_recon_id = int(recon_id)
    query = f"""select permission_name,recon_id,user_email from fileservice.user_recon_permission 
                where user_email='{request.user.email}' and recon_id={checked_recon_id}; """
    cursor.execute(query)
    user_permission=cursor.fetchall()

    for perm in user_permission:
        user_permission_map[perm[0]]=True

    response_data={"status":200,
                   "permission":user_permission_map
                   }
    
    return Response(response_data,status=status.HTTP_200_OK)

    