
# import EssbaseDataRecon
# import pandas as pd


# """
# 1) *mdxquery
# 2) *essbase server
# 3) py4j servername (localhost in Quanta's case),
# 4) py4j port number cd... default)
# 5) *Essbase username
# 6) *Essbase password 
# 7) *Essbase Application Name
# 8) *Essbase Database Name
# 9) EssbaseProviderServicesURL
# 10) output file path
# """

# Py4jServerName = "127.0.0.1"
# Py4jPortNumber = 25333


# EssbaseServerName = "ec2-3-208-240-106.compute-1.amazonaws.com"

# #EssbaseProviderServicesURL="http://ec2-3-208-240-106.compute-1.amazonaws.com:19000/aps/JAPI"
# EssbaseProviderServicesURL="http://epm-donyati-927535734.us-east-1.elb.amazonaws.com/aps/JAPI"

# EssbaseUserName = "admin"
# EssbasePassword = "P@ssword"
# EssbaseApplicationName = "Vision"
# EssbaseDatabaseName = "Plan1"
# OutputFilePath = "./essout.csv"

# mdxquery = """SELECT {[Actual]} ON COLUMNS,
#             NON EMPTY {CROSSJOIN({[P_TP],[Total Entity]},
#             CROSSJOIN({[FY19]},
#             CROSSJOIN({[NI]},
#             {[Jan]})))} ON ROWS
#             FROM [Vision.Plan1]
# WHERE ([Working],[Ram test],[Megha],[Sujeet],[Curr_Shab],[Sk Reddy])"""

# EssbaseDataRecon.CustomTabDelimetedReportMDX(mdxquery, EssbaseServerName, EssbaseProviderServicesURL, Py4jServerName, Py4jPortNumber, EssbaseUserName, EssbasePassword, EssbaseApplicationName, EssbaseDatabaseName, OutputFilePath)


# input_file_path = 'essout.csv'
# with open(input_file_path, 'r') as input_file:
#     lines = input_file.readlines()
# header = lines[0].strip().replace('\t', ',')
# data_rows = [line.strip().replace('\t', ',') for line in lines[1:]]
# with open(input_file_path, 'w') as output_file:
#     output_file.write(header + '\n')
#     output_file.write('\n'.join(data_rows))



