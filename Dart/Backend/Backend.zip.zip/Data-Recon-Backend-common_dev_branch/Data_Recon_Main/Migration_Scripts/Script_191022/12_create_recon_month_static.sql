-- SEQUENCE: fileservice.recon_month_static_id_seq

DROP SEQUENCE if exists fileservice.recon_month_static_id_seq cascade;

CREATE SEQUENCE fileservice.recon_month_static_id_seq
    INCREMENT 1
    START 1
    MINVALUE 1
    MAXVALUE 9223372036854775807
    CACHE 1;

ALTER SEQUENCE fileservice.recon_month_static_id_seq
    OWNER TO postgres;

GRANT ALL ON SEQUENCE fileservice.recon_month_static_id_seq TO postgres;

GRANT ALL ON SEQUENCE fileservice.recon_month_static_id_seq TO "user_dataRecon_file";

-- Table: fileservice.recon_month_static

DROP table if exists fileservice.recon_month_static cascade;

CREATE TABLE fileservice.recon_month_static
(
    id bigint NOT NULL DEFAULT nextval('fileservice.recon_month_static_id_seq'::regclass),
    "Month" character varying COLLATE pg_catalog."default",
    "Mon" character(3) COLLATE pg_catalog."default",
    "P_mm" character(3) COLLATE pg_catalog."default",
    "Month_ID" integer,
    CONSTRAINT recon_month_static_pkey PRIMARY KEY (id)
        USING INDEX TABLESPACE tbsp_data_recon
)

TABLESPACE tbsp_data_recon;

ALTER TABLE fileservice.recon_month_static
    OWNER to postgres;

GRANT ALL ON TABLE fileservice.recon_month_static TO postgres;

GRANT DELETE, UPDATE, INSERT, SELECT ON TABLE fileservice.recon_month_static TO "user_dataRecon_file";