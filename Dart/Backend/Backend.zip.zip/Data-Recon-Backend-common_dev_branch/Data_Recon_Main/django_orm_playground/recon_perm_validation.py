from boiler_plate import initalize_settings_finder
initalize_settings_finder()
from django.db import connection
from pypika import Query,Table,Order,PostgreSQLQuery
from Data_Recon_App.utils.pgsql_conn import call_generic_query,call_query
from rest_framework.response import Response
from rest_framework import status
from Data_Recon_App.models import UserReconPermission

user_recon_permission=Table("user_recon_permission")
q=PostgreSQLQuery.from_(user_recon_permission).select(
                 "permission_name","user_email","recon_id",).where(
                     (user_recon_permission.user_email=="balaji@gmail.com")
                    &(user_recon_permission.permission_name=="read")
                    &(user_recon_permission.recon_id==1))

def validate_user_recon_permission(email,permission,recon_id):
    user_recon_permission=Table("user_recon_permission")
    q=PostgreSQLQuery.from_(user_recon_permission).select(
                 "permission_name","user_email","recon_id",).where(
                     (user_recon_permission.user_email==email)
                    &(user_recon_permission.permission_name==permission)
                    &(user_recon_permission.recon_id==recon_id))
    data=call_query(q.get_sql())
    if data["rows"][0:1] :
        print("access gratend")
    else:
        print("access denied")



def orm_validate_user_recon_permission(email,permission,recon_id):

    user_perm=UserReconPermission.objects.filter(user_email=email,permission_name=permission,recon_id=recon_id).exists()

    if user_perm :
        print("orm access gratend")
    else:
        print("orm access denied")

validate_user_recon_permission("vani@gmail.com","read",11)
orm_validate_user_recon_permission("vani@gmail.com","read",16)

allowed = validate_user_recon_permission(request.user.email, "", )
if not allowed:
    response_data = {
        'status': 403,
        'message': 'Un-authorized action detected!'
    }
    return Response(response_data, status=status.HTTP_403_FORBIDDEN)


