from boiler_plate import initalize_settings_finder
initalize_settings_finder()
from django.db import connection
from Data_Recon_App.models import UserReconPermission,Recon

user_permission_map={}

user_permission=UserReconPermission.objects.filter(recon_id=5,user_email="nancy@gmail.com")

for perm in user_permission:
    print(perm.__dict__)
    user_permission_map[perm.permission_name]=True

print(user_permission_map)