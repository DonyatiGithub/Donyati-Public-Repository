

--user name is dhanush , email is dhanush@gmail.com password:recon@123  has only read access
INSERT INTO "admin".auth_user ("password", last_login, is_superuser, username, first_name, last_name, email, is_staff, is_active, date_joined, uuid, "role", access_type, "DC_Url", "DC_Username", "DC_Password", tag, nonce, admin_tag, onestream)
VALUES('pbkdf2_sha256$390000$QlWjnoKQXyT8mHEL5NMoe1$h17YPmXvk5EO1JlArhFL+jL/1Ob9UowGE7C7zupCAnA=', '2023-06-05 17:29:34.000', true, 'dhanush@gmail.com', 'dhanush', 'c', 'dhanush@gmail.com', true, true, '2022-08-29 15:49:14.301', 'e2d4fdc7-a808-4c44-b18b-3590fd739e34'::uuid, 'User', '{"privilege": 1}'::jsonb, '', '', decode('','hex'), decode('','hex'), decode('','hex'), '', true);


--user name is nancy , email is nancy@gmail.com password:recon@123 has read/write access but not the admin
INSERT INTO "admin".auth_user ("password", last_login, is_superuser, username, first_name, last_name, email, is_staff, is_active, date_joined, uuid, "role", access_type, "DC_Url", "DC_Username", "DC_Password", tag, nonce, admin_tag, onestream)
VALUES('pbkdf2_sha256$390000$QlWjnoKQXyT8mHEL5NMoe1$h17YPmXvk5EO1JlArhFL+jL/1Ob9UowGE7C7zupCAnA=', '2023-06-05 17:29:34.000', true, 'nancy@gmail.com', 'nancy', 'q', 'nancy@gmail.com', true, true, '2022-08-29 15:49:14.301', 'e2d4fdc7-a808-4c44-b18b-3590fd739e65'::uuid, 'User', '{"privilege": 0}'::jsonb, '', '', decode('','hex'), decode('','hex'), decode('','hex'), '', true);