import os
import sys

#this block of code is mandatory for python to find the setting.py filw 
current_path=sys.path[0]
if os.name=='nt':
    settings_path="\\".join(current_path.split("\\")[0:-1])
else :
    settings_path="/".join(current_path.split("/")[0:-1])
sys.path.append(settings_path)

import django 
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'Data_Recon_Main.settings')
from django.conf import settings
django.setup()
from Data_Recon_App.models import Permissions,PermissionGroup,PermissionGroupMap,PermissionGroupUser,ReconGroupMap
pgu =PermissionGroupUser(permission_group_id=1,user_email="karan@gmail.com")

# read=Permissions(permission_name='read')
# read.save()
# write=Permissions(permission_name='write')
# write.save()

group1=PermissionGroup(permission_group_name="karna-update",created_by="balaji@gmail.com")
group1.save()

pgm= PermissionGroupMap(permission_id=2,permission_group_id=1)
pgm.save()


# PermissionGroup.objects.filter(permission_group_id=1).delete()

pgu1=PermissionGroupUser(user_email="vani@gmail.com",permission_group_id=2)
pgu1.save()

PermissionGroupUser.objects.all().values()