import os
import sys
import django 

def initalize_settings_finder():
    #this block of code is mandatory for python to find the setting.py file and run the 
    current_path=sys.path[0]
    if os.name=='nt':
        settings_path="\\".join(current_path.split("\\")[0:-1])
    else :
        settings_path="/".join(current_path.split("/")[0:-1])
    sys.path.append(settings_path)
    os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'Data_Recon_Main.settings')
    django.setup()

initalize_settings_finder()

from Data_Recon_App.models import Permissions


read=Permissions(permission_name="read")
write=Permissions(permission_name="write")
execute=Permissions(permission_name="execute")
delete=Permissions(permission_name="delete")
sign_off=Permissions(permission_name="sign-off")


read.save()
write.save()
execute.save()
delete.save()
sign_off.save()


