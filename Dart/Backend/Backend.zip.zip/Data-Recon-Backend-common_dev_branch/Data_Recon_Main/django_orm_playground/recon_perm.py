from boiler_plate import initalize_settings_finder
initalize_settings_finder()
from django.db import connection
from Data_Recon_App.models import UserReconPermission,Recon

owned_instance = Recon.objects.filter(is_deleted=False,
                                        created_by="Admin").order_by('-created_date')
         
read_access_recon_id=UserReconPermission.objects.filter(user_email="vani@gmail.com",permission_name="read").values_list("recon_id",flat=True)

print(read_access_recon_id)
         
read_instance=Recon.objects.filter(is_deleted=False,
                                        recon_id__in=read_access_recon_id).order_by('-created_date')

print(owned_instance)
print(read_access_recon_id)
print(read_instance)

union_instance=owned_instance.union(read_instance)

print(union_instance)