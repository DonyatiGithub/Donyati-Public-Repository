from boiler_plate import initalize_settings_finder

initalize_settings_finder()

from Data_Recon_App.models import ReconGroupMap


payload_value=[16,8] 
rgm_id_exist=ReconGroupMap.objects.filter(recon_group_map_id__in=payload_value).delete()
#rgm_id when only one item present in the table (2, {'reconService.ReconGroupMap': 2}) where has muliple id passed in clause
#rgm_id when no item present in the table (2, {'reconService.ReconGroupMap': 2})
#rgm_id when single id in the table (1, {'reconService.ReconGroupMap': 1})
print(rgm_id_exist)