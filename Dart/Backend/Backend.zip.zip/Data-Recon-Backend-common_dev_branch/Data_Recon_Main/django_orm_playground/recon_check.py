from boiler_plate import initalize_settings_finder

initalize_settings_finder()

from Data_Recon_App.models import ReconGroupMap,ReconUser


email="nancy@gmail.com"
user_name=ReconUser.objects.filter(email=email).get().username

print(user_name)