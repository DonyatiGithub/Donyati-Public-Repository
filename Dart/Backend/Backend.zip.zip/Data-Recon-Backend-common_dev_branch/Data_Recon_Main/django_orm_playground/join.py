import os
import sys
import django 

def initalize_settings_finder():
    #this block of code is mandatory for python to find the setting.py file and run the django setup
    current_path=sys.path[0]


    if os.name=='nt':
        settings_path="\\".join(current_path.split("\\")[0:-1])
    else :
        settings_path="/".join(current_path.split("/")[0:-1])
    sys.path.append(settings_path)
    os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'Data_Recon_Main.settings')
    django.setup()

initalize_settings_finder()

from rest_framework import serializers

from Data_Recon_App.models import ReconGroupMap,PermissionGroup


from Data_Recon_App.permission_service.serializers import PermissionsGroupSerializer

class ReconGroupMapSerializer(serializers.ModelSerializer):
    permission_group = PermissionsGroupSerializer()  # Serializer for nested PermissionGroup field

    class Meta:
        model = ReconGroupMap
        fields = '__all__'

    def to_representation(self, instance):
        # Perform any custom logic to customize the representation
        representation = super().to_representation(instance)
        # Add or modify fields in the representation dictionary
        for key,value in representation["permission_group"].items():
            representation[key]=value
        
        del representation["permission_group"]
        
        return representation




obj=ReconGroupMap.objects.select_related("permission_group").filter(recon_id=8)

ser=ReconGroupMapSerializer(obj[0])
print(ser.data)
print(obj.query)

