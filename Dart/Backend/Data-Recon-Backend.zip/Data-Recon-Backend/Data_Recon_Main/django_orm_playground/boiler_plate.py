import os
import sys
import django 

def initalize_settings_finder():
    #this block of code is mandatory for python to find the setting.py file and run the django setup
    current_path=sys.path[0]


    if os.name=='nt':
        settings_path="\\".join(current_path.split("\\")[0:-1])
    else :
        settings_path="/".join(current_path.split("/")[0:-1])
    sys.path.append(settings_path)
    os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'Data_Recon_Main.settings')
    django.setup()

initalize_settings_finder()