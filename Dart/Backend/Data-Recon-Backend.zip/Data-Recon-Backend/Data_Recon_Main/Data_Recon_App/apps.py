from django.apps import AppConfig


class DataReconAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Data_Recon_App'
    default = False


class ReconAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'reconService'
    default = False