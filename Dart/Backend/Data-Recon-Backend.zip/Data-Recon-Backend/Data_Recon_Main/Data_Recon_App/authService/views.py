from django.contrib.auth import authenticate
from rest_framework import status
from rest_framework.decorators import api_view, permission_classes, renderer_classes
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework.renderers import JSONRenderer
from rest_framework.response import Response
from rest_framework_simplejwt.tokens import RefreshToken
from . serilaizers import UserListSerializer
from .. models import ReconUser
import datetime


@api_view(['POST'])
@permission_classes((AllowAny,))
@renderer_classes((JSONRenderer,))
def user_login(request):
    email = request.data.get('email').lower()
    password = request.data.get('password')

    error_msg_data = {
        'status': 403,
        'message': 'Invalid username or password!'
    }

    if ReconUser.objects.filter(email=email).exists():
        username = ReconUser.objects.get(email=email).username
        is_user_active = ReconUser.objects.get(email=email).is_active
        if not is_user_active:
            error_msg_data = {
                'status': 403,
                'message': 'Your account has been deactivated!, please contact admin'
            }
    else:
        username = None

    user = authenticate(username=username, password=password)

    if user is not None:
        if user.is_active:
            refresh = RefreshToken.for_user(user)
            serialized = UserListSerializer(user)
            now = (datetime.datetime.now()).strftime("%m/%d/%Y, %H:%M:%S")
            last_login = datetime.datetime.strptime(now, "%m/%d/%Y, %H:%M:%S")
            ReconUser.objects.filter(email=email).update(last_login=last_login)

            response_data = {
                'status': 200,
                'accessToken': str(refresh.access_token),
                'refreshToken':str(refresh), # adding refresh token
                'data': serialized.data
            }
        else:
            response_data = {
                'status': 403,
                'message': 'Invalid email id or password!'
            }
    else:
        response_data = error_msg_data

    return Response(response_data, status=status.HTTP_200_OK)


@api_view(['GET'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def user_logout(request):
    response_data = {
        'status': 200,
        'accessToken': 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ0b2tlbl90'
                       'eXBlIjoiYWNjZXNzIiwiZXhwIjoxNjYxODM5NTMyLCJpYXQiO'
                       'jE2NjE4MzU5MzIsImp0aSI6Ijc1OGI5NDcyOGMyYzRiNzc5ODQ5MWF'
                       'jNDg1OTE1YTY4IiwidXNlcl9pZCI6MX0.gXS_IwIUHtchl0HmS1wO7Z'
                       'nT1vvwUIv1MlSFy-AJ630'
    }

    return Response(response_data, status=status.HTTP_200_OK)


@api_view(['GET'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def user_list(request):
    instance = ReconUser.objects.all()
    serialized = UserListSerializer(instance, many=True)

    response_data = {
        'status': 200,
        'data': serialized.data
    }

    return Response(response_data, status=status.HTTP_200_OK)



