import subprocess

def get_disk_space():
    command = "df -h / | awk '{print $5}' | tail -n -1"
    result = subprocess.run(command, shell=True, capture_output=True, text=True)
    disk_usage = result.stdout.strip()
    return disk_usage