from ...models import ReconBridgeMapping, ReconDimensions
from ...bridgeService.functions.get_disk_space import get_disk_space
from ...maintenanceService.functions.update_config import get_diskspace_thresh

'''
<!---------- Method to update kick outs
             and return response ----------!>
'''


def update_outs(recon_id, kick_out_rows):
    # print(len(kick_out_rows))

    for i in range(0, len(kick_out_rows)):
        app_type = '0' if kick_out_rows[i]['app1_app2'] == 'App1' else '1'
        
        # Based on App ID get the dimension name
        dim_name = kick_out_rows[i]['dimension_name'].split('-')[0] if app_type == '0' else kick_out_rows[i]['dimension_name'].split('-')[1]

        dim=ReconDimensions.objects.filter(recon_id=recon_id,dimension=dim_name,app_type=app_type,is_deleted=False
                                              ).values_list("dimensions_id","recon_app_id")
        dim_id=dim[0][0]
        app_id=dim[0][1]
       
        # print(str(recon_id)+'------'+dim_name)
        # print(ReconDimensions.objects.filter(recon_id=recon_id, dimension=dim_name, app_type=app_type, is_deleted=False)[0])

        # Removing Bridge Update to replace with Insert for all kickouts
        # if ReconBridgeMapping.objects \
        #         .filter(recon_id=recon_id, source_member=kick_out_rows[i]['bridge_member'],
        #                 app_type=app_type).exists():
        #     instance = ReconBridgeMapping.objects \
        #         .filter(recon_id=recon_id, source_member=kick_out_rows[i]['bridge_member'],
        #                 app_type=app_type)[0]
        #     instance.source_member = kick_out_rows[i]['source_member']
        #     instance.save()

        #     # response_data = {
        #     #     'status': 200,
        #     #     'message': 'Kick outs updated successfully!'
        #     # }
        # else:
        kickout_row = ReconBridgeMapping(recon_id=recon_id,source_member=kick_out_rows[i]['source_member'],
                                            bridge_member=kick_out_rows[i]['bridge_member'],
                                            app_type=app_type, flip_sign=False, app_id=app_id, dim_id=dim_id)
        kickout_row.save()
        
    response_data = {
        'status': 200,
        'message': 'Kickouts updated successfully'
    }
    # Get disk space usage
    if get_diskspace_thresh()!="None":
        disk_usage = get_disk_space()
        if get_diskspace_thresh() == disk_usage:
            response_data["disk_usage"] = disk_usage  
    # 'Invalid bridge member!'

    return response_data
