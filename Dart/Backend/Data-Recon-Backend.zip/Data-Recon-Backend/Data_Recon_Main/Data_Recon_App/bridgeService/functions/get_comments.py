from ..serializers import DimCommentSerializer, BridgeCommentSerializer, JeCommentSerializer
from ...models import ReconBridgeMapping


'''
<!---------- Method to get the comment data from DB
             and return as structured data ----------!>
'''


def get_comments(recon_id, je):
    comment_instance = ReconBridgeMapping.objects.filter(recon_id=recon_id, is_deleted=False)\
        .exclude(dim_comment__isnull=True)
    comment_serialized = DimCommentSerializer(comment_instance, many=True)

    bridge_comment_instance = ReconBridgeMapping.objects.filter(recon_id=recon_id, is_deleted=False) \
        .exclude(bridge_comment__isnull=True)
    bridge_comment_serialized = BridgeCommentSerializer(bridge_comment_instance, many=True)

    je_comment_instance = ReconBridgeMapping.objects.filter(recon_id=recon_id, is_deleted=False) \
        .exclude(dim_comment__isnull=True)
    je_comment_serialized = JeCommentSerializer(je_comment_instance, many=True)

    if not je:
        rows = comment_serialized.data
        rows.extend(bridge_comment_serialized.data)
    else:
        rows = je_comment_serialized.data

    response_data = {
        'status': 200,
        'recon_id': recon_id,
        'rows': rows,
        'message': 'Comments retrieved successfully!'
    }

    return response_data
