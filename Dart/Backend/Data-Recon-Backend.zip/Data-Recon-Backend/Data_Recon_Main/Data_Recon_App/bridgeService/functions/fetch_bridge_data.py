from ...runImportService.functions.is_exists import is_exists
from ...utils.get_recon import get_recon
from .get_view_data import get_view_data




def fetch_bridge_data(recon_id,je_flag,start_point,end_point):


    recon_data = get_recon(recon_id)
    recon_name = recon_data['name']
    app1_id = recon_data['app1_id']
    app2_id = recon_data['app2_id']

    if (je_flag):

        bridge_view=is_exists("fileservice",f"view_bridge_je_{recon_id}")
    else:
        bridge_view=is_exists("fileservice",f"view_bridge_{recon_id}")
    
    if bridge_view['rows'][0]['exists']:


        if(je_flag):
            view_query = 'SELECT * FROM fileService.view_bridge_je_' + str(recon_id) + \
                            ' where not(kickout)' + \
                            ' LIMIT ' + str(end_point) + \
                            ' OFFSET ' + str(start_point)
        else:
            view_query = 'SELECT * FROM fileService.view_bridge_' + str(recon_id) + \
                            ' where not(kickout)' + \
                            ' LIMIT ' + str(end_point) + \
                            ' OFFSET ' + str(start_point)
        response_data = get_view_data(view_query, app1_id, app2_id, recon_id)

    else:
        response_data={
                    'status': 200,
                    'headers': [],
                    'rows': [],
                    'message': 'Data retrieved successfully!'
                    }
    
    return response_data