from ...models import ReconBridgeMapping, ReconDimensions

'''
<!---------- Method to update kick outs
             and return response ----------!>
'''


def update_default_outs(recon_id, kick_out_rows):

    for i in range(0, len(kick_out_rows)):
        app_type = '0' if kick_out_rows[i]['app1_app2'] == 'App1' else '1'
        
        # Based on App ID get the dimension name
        dim_name = kick_out_rows[i]['dimension_name'].split('-')[0] if app_type == '0' else kick_out_rows[i]['dimension_name'].split('-')[1]

        dim=ReconDimensions.objects.filter(recon_id=recon_id,dimension=dim_name,app_type=app_type,is_deleted=False
                                              ).values_list("dimensions_id","recon_app_id")
        dim_id=dim[0][0]
        app_id=dim[0][1]
       
        
        kickout_row = ReconBridgeMapping(recon_id=recon_id,source_member=kick_out_rows[i]['source_member'],
                                            bridge_member=kick_out_rows[i]['source_member'],
                                            app_type=app_type, flip_sign=False, app_id=app_id, dim_id=dim_id)
        kickout_row.save()
        
    response_data = {
        'status': 200,
        'message': 'Kickouts updated successfully'
    }
    # 'Invalid bridge member!'

    return response_data
