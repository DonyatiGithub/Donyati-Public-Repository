from ...models import ReconBridgeMapping, ReconDimensions
from .get_comments import get_comments
from .get_import_data import get_bridge_dim_id

'''
<!---------- Method to update comment data in DB
             and return as structured data ----------!>
'''


def update_comments(recon_id, comment_object, je):
    for i in range(0, len(comment_object)):
        if not 'is_invalid' in comment_object[i] or not comment_object[i]['is_invalid']:
            if comment_object[i]['app_type'] != 'BRIDGE':
                dim_id = comment_object[i]['dim_id']
                source_member = comment_object[i]['source_member']
                comment = comment_object[i]['comment']
                app_type = '0' if comment_object[i]['app_type'] == 'APP1' else '1'

                if not je:
                # Save / Updating dim comment
                    if ReconBridgeMapping.objects.filter(recon_id=recon_id, app_type=app_type, dim_id=dim_id,
                                                         source_member=source_member, is_deleted=False).exists():
                        ReconBridgeMapping.\
                            objects.filter(recon_id=recon_id, app_type=app_type, dim_id=dim_id,
                                           source_member=source_member, is_deleted=False).update(dim_comment=comment)
                else:
                    if ReconBridgeMapping.objects.filter(recon_id=recon_id, app_type=app_type, dim_id=dim_id,
                                                         source_member=source_member, is_deleted=False).exists():
                        ReconBridgeMapping.\
                            objects.filter(recon_id=recon_id, app_type=app_type, dim_id=dim_id,
                                           source_member=source_member, is_deleted=False).update(je_comment=comment)
            else:
                dim_id = comment_object[i]['dim_id']
                if not isinstance(dim_id, list):
                    if ReconDimensions.objects.filter(recon_id=recon_id, dimensions_id=dim_id).exists():
                        get_instance = ReconDimensions.objects.filter(recon_id=recon_id, dimensions_id=dim_id)[0]
                        dim_name = get_instance.dimension
                        dim_id = get_bridge_dim_id(recon_id, dim_name)
                    else:
                        response_data = {
                            'status': 6002,
                            'message': 'Invalid dimensions id ' + str(dim_id)
                        }
                        return response_data

                bridge_member = comment_object[i]['source_member']
                comment = comment_object[i]['comment']

                for j in range(0, len(dim_id)):
                    # Save / Updating bridge comment
                    if ReconBridgeMapping.objects.filter(recon_id=recon_id, dim_id=dim_id[j],
                                                         bridge_member=bridge_member, is_deleted=False).exists():
                        ReconBridgeMapping. \
                            objects.filter(recon_id=recon_id, dim_id=dim_id[j],
                                           bridge_member=bridge_member, is_deleted=False)\
                            .update(bridge_comment=comment)

    comments_data = get_comments(recon_id, je)
    response_data = {
        'status': 200,
        'recon_id': recon_id,
        'rows': comments_data['rows'],
        'message': 'Comments updated successfully!'
    }
    return response_data
