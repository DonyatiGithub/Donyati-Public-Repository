from django.db import connections
import json
from ...models import TrackReconRefresh
from .generate_variance_query import generate_variance_query


'''
<!---------- Method to do get view data and exclude
            some columns and return data as a response ----------!>
'''


def get_sync_view(query, app1_id, app2_id, recon_id):
    # Establishing connection
    cursor = connections['Recon'].cursor()

    try:
        cursor.execute(query)

        # Replacing headers / removing
        headers = [x[0] for x in cursor.description]
        headers = list(map(lambda x: x.replace('app_id', 'App1-App2'), headers))
        headers = list(map(lambda x: x.replace('AMOUNT-AMOUNT', 'Amount'), headers))
        headers = list(map(lambda x: x.replace('user_comment', 'Comments'), headers))
        amount_index = headers.index('Amount')
        comments_index = headers.index('Comments')

        transormation_timestamp=TrackReconRefresh.objects.filter(recon_id=recon_id).values_list('transformation_timestamp',flat=True)[0]
        formatted_timestamp = transormation_timestamp.strftime('%Y-%m-%dT%H:%M:%SZ')

        # Getting results
        results = cursor.fetchall()

        # Converting to JSON
        json_data = []
        for result in results:
            result_list = list(result)
            if result_list[0] == app1_id:
                result_list[0] = 'App1'
            elif result_list[0] == app2_id:
                result_list[0] = 'App2'

            # Re-formatting data
            result_list[amount_index] = "{:.2f}".format(float(result_list[amount_index]))
            result_list[comments_index] = (result_list[comments_index]).split('^')

            # Converting back to tuple
            result = tuple(result_list)
            json_data.append(dict(zip(headers, result)))


        json_rows = json.dumps(json_data)
        json_rows = json.loads(json_rows)

        response_data = {
            'status': 200,
            'headers': headers,
            'rows': json_rows,
            'message': 'Data retrieved successfully!',
            'transformation_timestamp': formatted_timestamp
        }
    except TypeError as e:
        response_data = {
            'status': 6001,
            'message': 'Something went wrong in query',
            'error': str(e)
        }
    finally:
        cursor.close()
    return response_data
