from ... models import ReconTransformation, ReconBridgeMapping, ReconTransformationOverride
from ..serializers import TransformationSerializer, BridgeSourceSerializer
from ...utils.get_recon import get_recon
import itertools
import copy
from .export_sync_data import get_dim_name


'''
<!---------- Method to get transformations sync combinations
             then structure and return response ----------!>
'''


def sync_combinations(recon_id, app_type, dim_id= False):
    response_data = {
        'status': 200,
        'recon_id': recon_id,
        'app_id': None,
        'dimensions': [],
        'data': [],
        'message': 'Obtained all the transformation combinations!'
    }

    recon_data = get_recon(recon_id)
    app_id = recon_data['app1_id'] if app_type == '0' else recon_data['app2_id']
    response_data['app_id'] = app_id
    if dim_id:
        instance = ReconTransformation.objects.filter(recon_id=recon_id, app_id=app_id, dim_id= dim_id)\
            .exclude(tgt_concat_dimid__isnull=True)
    else:
        instance = ReconTransformation.objects.filter(recon_id=recon_id, app_id=app_id)\
            .exclude(tgt_concat_dimid__isnull=True)
    serialized = TransformationSerializer(instance, many=True)

    for transformation in serialized.data:
        dim_list = (transformation['tgt_concat_dimid']).split('-')
        dim1_source = get_bridge_source(recon_id, dim_list[0])
        dim2_source = get_bridge_source(recon_id, dim_list[1])

        combinations = generate_combinations(dim1_source, dim2_source)
        combinations = pop_existing_sync(recon_id, app_id, transformation['id'], combinations)
        trans_object = {
            'tfn_id': transformation['id'],
            'dimensions_id': transformation['dim_id'],
            'combinations': combinations
        }
        response_data['data'].append(trans_object)

        dim_object = {
            'dimensions_id': transformation['dim_id'],
            'dimension': get_dim_name(recon_id, transformation['dim_id']),
            'tfn_id': transformation['id'],
        }
        response_data['dimensions'].append(dim_object)

    return response_data


def get_bridge_source(recon_id, dim_id):
    list_bridge_source = []

    if ReconBridgeMapping.objects.filter(recon_id=recon_id, dim_id=dim_id, is_deleted=False).exists():
        bridge_instance = ReconBridgeMapping.objects.filter(recon_id=recon_id, dim_id=dim_id, is_deleted=False)
        bridge_source = BridgeSourceSerializer(bridge_instance, many=True)

        for source in bridge_source.data:
            source_object = dict(source)
            list_bridge_source.append(source_object['source_member'])
        list_bridge_source = list(set(list_bridge_source))

    return list_bridge_source


def generate_combinations(list_01, list_02):
    unique_combinations = list(itertools.product(list_01, list_02))
    comb_list = []
    for combination in unique_combinations:
        tuple_list = list(combination)
        comb_list.append('-'.join(tuple_list))

    return comb_list


def pop_existing_sync(recon_id, app_id, tfn_id, comb_list):
    valid_comb = copy.deepcopy(comb_list)
    for comb in comb_list:
        if ReconTransformationOverride.objects.filter(recon_id=recon_id, app_id=app_id,
                                                      tfn_id=tfn_id, source_sync=comb):
            valid_comb.remove(comb)

    return valid_comb
