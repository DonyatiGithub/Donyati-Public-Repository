from ... models import ReconTransformationOverride, ReconTransformation
from ..serializers import TransOverrideSerializer
from ...utils.get_recon import get_recon


'''
<!---------- Method to create/update transformations sync
             then structure and return response ----------!>
'''


def update_tfn_sync(recon_id, app_type, rows):
    recon_data = get_recon(recon_id)
    app_id = recon_data['app1_id'] if app_type == '0' else recon_data['app2_id']

    for row in rows:
        row['app_id'] = app_id
        row['recon_id'] = recon_id

        if 'tfn_id' in row:
            if ReconTransformationOverride.objects.filter(recon_id=recon_id, app_id=app_id,
                                                          tfn_id=row['tfn_id'],
                                                          source_sync=row['source_sync']).exists():
                instance = ReconTransformationOverride.objects.filter(recon_id=recon_id, app_id=app_id,
                                                                      tfn_id=row['tfn_id'],
                                                                      source_sync=row['source_sync'])[0]
                serialized = TransOverrideSerializer(instance, data=row, partial=True)
            else:
                serialized = TransOverrideSerializer(data=row)
        else:
            tfn_id = get_tfn_id(recon_id, row['dimensions_id'])
            row['tfn_id'] = tfn_id
            if ReconTransformationOverride.objects.filter(recon_id=recon_id, app_id=app_id,
                                                          tfn_id=tfn_id,
                                                          source_sync=row['source_sync']).exists():
                instance = ReconTransformationOverride.objects.filter(recon_id=recon_id, app_id=app_id,
                                                                      tfn_id=tfn_id,
                                                                      source_sync=row['source_sync'])[0]
                serialized = TransOverrideSerializer(instance, data=row, partial=True)
            else:
                serialized = TransOverrideSerializer(data=row)

        if serialized.is_valid():
            serialized.save()
            response_data = {
                'status': 200,
                'message': 'Updated sync successfully!'
            }
        else:
            response_data = {
                'status': 6002,
                'message': serialized.errors
            }
            return response_data

    return response_data


def get_tfn_id(recon_id, dim_id):
    tfn_id = None
    if ReconTransformation.objects.filter(recon_id=recon_id, dim_id=dim_id).exists():
        tfn_instance = ReconTransformation.objects.filter(recon_id=recon_id, dim_id=dim_id)[0]
        tfn_id = tfn_instance.id

    return tfn_id
