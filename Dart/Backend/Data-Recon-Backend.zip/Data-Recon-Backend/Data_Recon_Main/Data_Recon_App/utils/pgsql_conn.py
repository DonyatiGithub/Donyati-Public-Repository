from django.db import connections
import json
from django.db.utils import InternalError,DataError


'''
<!---------- Method to do direct postgres query operations
            and return data as a response ----------!>
'''


# Generic function call any stored procedure with parameters
def call_sp_params(procedure_name, args, no_of_args):
    # Establishing connection
    cursor = connections['Recon'].cursor()

    # Creating the query
    args_holder = generate_holder(no_of_args)
    sp_query = 'CALL ' + procedure_name + '(' + args_holder + ');'

    try:
        cursor.execute(sp_query, args)
        response_data = {
            'status': 200,
            'message': 'Procedure ran successfully!'
        }
    except TypeError as e:
        response_data = {
            'status': 6001,
            'message': 'Something went wrong in procedure',
            'error': str(e)
        }
    except InternalError as e:
        error_msg=str(e)
        response_data = {
            'status': 6001,
            'message': error_msg.split("\n")[0],
            'error_message':error_msg
        }
    except DataError as e:
        error_msg=str(e)
        response_data = {
            'status': 6001,
            'message': error_msg.split("\n")[0],
            'error_message':error_msg
        }
    finally:
        cursor.close()
    return response_data


# Generic function call any stored procedure without parameters
def call_sp(procedure_name):
    # Establishing connection
    cursor = connections['Recon'].cursor()

    # Creating the query
    sp_query = 'CALL ' + procedure_name + ';'
    try:
        cursor.execute(sp_query)
        response_data = {
            'status': 200,
            'message': 'Procedure ran successfully!'
        }
    except TypeError as e:
        response_data = {
            'status': 6001,
            'message': 'Something went wrong in procedure',
            'error': str(e)
        }
    finally:
        cursor.close()
    return response_data


# Generic function call any sql query
def call_query(query):
    # Establishing connection
    cursor = connections['Recon'].cursor()

    try:
        cursor.execute(query)
        headers = [x[0] for x in cursor.description]
        results = cursor.fetchall()
        json_data = []
        for result in results:
            json_data.append(dict(zip(headers, result)))
        json_rows = json.dumps(json_data)
        json_rows = json.loads(json_rows)
        response_data = {
            'status': 200,
            'headers': headers,
            'rows': json_rows,
            'message': 'Query ran successfully!'
        }
    except TypeError as e:
        response_data = {
            'status': 6001,
            'message': 'Something went wrong in query',
            'error': str(e)
        }
    finally:
        cursor.close()
    return response_data


# Generic function to create args holder
def generate_holder(no_of_args):
    response = '%s ' * no_of_args
    response = response.strip()
    response = response.replace(' ', ',')
    return response


def call_admin_query(query):
    # Establishing connection
    cursor = connections['admin'].cursor()

    try:
        cursor.execute(query)
        response_data = {
            'status': 200,
            'message': 'Query ran successfully!'
        }
    except TypeError as e:
        response_data = {
            'status': 6001,
            'message': 'Something went wrong in query',
            'error': str(e)
        }
    finally:
        cursor.close()
    return response_data


def call_generic_query(query):
    # Establishing connection
    cursor = connections['Recon'].cursor()

    try:
        cursor.execute(query)
        response_data = {
            'status': 200,
            'message': 'Query ran successfully!'
        }
    except TypeError as e:
        response_data = {
            'status': 6001,
            'message': 'Something went wrong in query',
            'error': str(e)
        }
    finally:
        cursor.close()
    return response_data
