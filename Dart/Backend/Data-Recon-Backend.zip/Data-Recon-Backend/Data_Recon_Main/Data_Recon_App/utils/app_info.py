from ..models import ReconApplications


def get_app_ids(recon_id):

    app_data=ReconApplications.objects.filter(recon_id=recon_id)

    app1_id=None
    app2_id=None
    for app in app_data:
        if app.app_name=="0":
            app1_id=app.recon_app_id
        else:
            app2_id=app.recon_app_id

    return app1_id, app2_id
