from ... models import Recon, ReconDimensions, ReconApplications
from ... utils.get_recon import get_recon
import os


'''
<!---------- Method to validate the pre-requisites are
              valid and return response ----------!>
'''


def is_import_valid(recon_id, app_type, file_location, je='',etlType=6):

    # Making sure empty top member/type field values null in dimensions
    ReconDimensions.objects.filter(top_member='').update(top_member=None)
    ReconDimensions.objects.filter(type_field='').update(type_field=None)

    # Get recon details from DB
    # modifying for ETL starts -----
    # if etlType !=6:
    #     print(etlType)
    #     recon_instance = Recon.objects.filter(recon_id=recon_id)[0]
    #     app1_id = recon_instance.app1_id
    #     app2_id = recon_instance.app2_id
    #     app1_instance = ReconApplications.objects.filter(recon_app_id=app1_id)[0]
    #     app2_instance = ReconApplications.objects.filter(recon_app_id=app2_id)[0]
    #     if app_type == '0':
    #         app1_instance.import_delimiter = ','
    #         app1_instance.save()
    #     elif app_type == '1':
    #         app2_instance.import_delimiter = ','
    #         app2_instance.save()
    # modifying for ETL ends -----        
            
    recon_instance = get_recon(recon_id)
    app_delimiter = recon_instance['app1_delimiter'] if app_type == '0' else recon_instance['app2_delimiter']
    app_has_header = recon_instance['app1_has_header'] if app_type == '0' else recon_instance['app2_has_header']
    app_key = 'App1' if app_type == '0' else 'App2'
    # Getting the first line
    f = open(file_location, 'r')
    
    if app_has_header:
        f.readline()
        # line_list= first_line.strip().split(app_delimiter)
        # lower_line_list= [i.lower() for i in line_list]
        # default_dim= ['year', 'period', 'amount']

        # if app_has_header:
        #     for i in default_dim:
        #         if i not in lower_line_list:
        #             response_data= {
        #                 'status': 404,
        #                 'message': 'uploaded file has no header'
        #             }
        #             return response_data
            
    first_line = f.readline()

    error_msg = 'not found' if not app_delimiter else 'mismatch'
    if not app_delimiter or app_delimiter not in first_line:
        response_data = {
            'status': 6002,
            'message': 'Delimiter ' + error_msg + ' in ' + app_key + ' configuration.'
        }
        return response_data
    else:
        if app_type == '0':
            ReconApplications.objects.filter(recon_id=recon_id, app_name='0')\
                .update(filename=file_location)
        elif app_type == '1':
            ReconApplications.objects.filter(recon_id=recon_id, app_name='1')\
                .update(filename=file_location)
        else:
            response_data = {
                'status': 6002,
                'message': 'Invalid app type found in request!'
            }
            return response_data

    # Check if the file is valid
    line_list = first_line.split(app_delimiter)
    # print('line_list: ',line_list)
    num_columns = len(line_list)
    app_dim_list = ReconDimensions.objects.filter(recon_id=recon_id, app_type=app_type, is_deleted=False)\
        .order_by('type_field').exclude(type_field__isnull=True).values_list('type_field', flat=True)
    # print('app_dim_list: ',app_dim_list)
    casted_app_dim_list = [int(i) for i in list(app_dim_list)]
    if casted_app_dim_list:
        if je == "je":
            max_type_field = max(casted_app_dim_list) + 1
        else:
            max_type_field = max(casted_app_dim_list)
        # print(max_type_field,"====",num_columns)
        if max_type_field != num_columns:
            response_data = {
                'status': 6002,
                'message': 'Invalid file. Please check the columns!'
            }
            return response_data
    else:
        response_data = {
            'status': 6002,
            'message': 'Please configure dimensions!'
        }
        return response_data

    # Check if the file exists
    if os.path.exists(file_location):
        response_data = {
            'status': 200,
            'message': 'Everything is valid!'
        }
    else:
        response_data = {
            'status': 6002,
            'message': 'File not found in location!'
        }

    return response_data
