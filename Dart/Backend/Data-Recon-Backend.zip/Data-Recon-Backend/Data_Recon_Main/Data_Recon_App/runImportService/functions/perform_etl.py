import pandas as pd
import chardet
import csv
import time
import shutil
from ...models import ReconApplications


def perform_etl(inputfile, outputfile, delimiter, containsheader, filetype: int, app_type, recon_id):
    # inputfile = 'HFM_Data_Extract_Text format.csv'
    # Delimiter=";"
    # containsheader=0
    # filetype = "HFM" # HFM,FCCS,PBCS,Special,Default

    # outputfile = 'newout.csv'
    # Glob/alflag = 0

    # print('got params:'+str([inputfile,outputfile,delimiter,containsheader,filetype]))
    response_data = {
        'status': 200,
        'message': 'File has been processed successfully!'
    }
    delimiter_tgl = True

    with open(inputfile, 'rb') as file:
        raw_data = file.read()
        result = chardet.detect(raw_data)
        file_encoding = result['encoding']

    with open(inputfile, 'r', encoding=file_encoding) as csvfile:
        firstline = csvfile.readline().strip()

    if filetype == 4:
        hfm(inputfile, outputfile, file_encoding, containsheader, delimiter)

    elif filetype == 3:
        onestream(inputfile, outputfile, containsheader, delimiter)

    elif filetype == 1 or filetype == 2:
        # print("FCCS")
        pbcs_fccs(inputfile, outputfile)

    elif filetype == 5:
        special(inputfile, outputfile, file_encoding, delimiter)

    elif filetype == 6:
        default(inputfile, outputfile)
        delimiter_tgl = False

    elif filetype == 7:
        essbase_calc(inputfile, delimiter, file_encoding, outputfile)

    else:
        delimiter_tgl = False
        response_data = {
            'status': 403,
            'message': 'Invalid File Type!'
        }

    if delimiter_tgl:
        ReconApplications.objects.filter(recon_id=recon_id, app_name=app_type).update(import_delimiter=",")

    return response_data


def hfm(inputfile, outputfile, file_encoding, containsheader, delimiter):
    dummyheader = []
    with open(inputfile, 'r', encoding=file_encoding) as file:
        csv_reader = csv.reader(file)
        rows = [row[0].split(delimiter) for row in csv_reader]
        rows = rows[1:]

    with open(outputfile, 'w', newline='', encoding="utf-8") as file:
        csv_writer = csv.writer(file)
        csv_writer.writerows(rows)
    if containsheader == 0:
        with open(outputfile, 'r') as file:
            csv_reader = csv.reader(file)
            try:
                first_row = next(csv_reader)  # Read the first row
                num_columns = len(first_row)  # Get the number of columns
                # print("Number of columns:", num_columns)
            except StopIteration:
                print("The CSV file is empty or doesn't contain any valid rows.")
            for i in range(num_columns):
                dummyheader.append(i)
            # print(dummyheader)
            file = pd.read_csv(outputfile)
            file.to_csv(outputfile, header=dummyheader, index=False)
            df = pd.read_csv(outputfile, low_memory=False)
            df = df.applymap(lambda x: x.strip() if isinstance(x, str) else x)
            df_cleaned = df.dropna(how='all')
            df_cleaned = df_cleaned.dropna(how='all', axis=0, subset=df_cleaned.columns)
            df_cleaned.reset_index(drop=True, inplace=True)
            df_cleaned.to_csv(outputfile, index=False, quoting=csv.QUOTE_NONNUMERIC, escapechar='\\')


def onestream(inputfile, outputfile, containsheader, delimiter):
    df = pd.read_csv(inputfile, delimiter=delimiter, skipinitialspace=True)
    if containsheader == 0:
        if 'HasData' in df.columns:
            index_of_HasData = df.columns.get_loc("HasData")
            df = df.iloc[:, :index_of_HasData]
            num_columns = len(df.columns)
            num_columns = int(num_columns)
            my_list = [i for i in range(num_columns)]
            df.columns = my_list

    if 'Cube' in df.columns:
        df = df.drop('Cube', axis=1)

    if 'HasData' in df.columns:
        index_of_HasData = df.columns.get_loc("HasData")
        df = df.iloc[:, :index_of_HasData]
    df = df.applymap(lambda x: x.strip() if isinstance(x, str) else x)
    df.to_csv(outputfile, index=False, quoting=csv.QUOTE_NONNUMERIC, escapechar='\\')


def essbase_calc(inputfile,delimiter,file_encoding,outputfile):
  with open(inputfile, 'r',newline='', encoding=file_encoding) as input_file:
      csv_reader = csv.reader(input_file, delimiter=delimiter)
      
      header = next(csv_reader)
      header.pop()
      first_line = next(csv_reader)
      first_line = [item for item in first_line if item != '']
      meltlimit=len(first_line)
      newheader=header+first_line
      newheader = [str(index) if item.strip() == '' else item for index, item in enumerate(newheader)]
      content = [newheader] + list(csv_reader)
  with open(inputfile, 'w', newline='', encoding=file_encoding) as output_file:
      csv_writer = csv.writer(output_file, delimiter=",")
      csv_writer.writerows(content)
  df = pd.read_csv(inputfile)    
  selected_df = df[first_line]
  new_df = pd.concat([df] * meltlimit)
  df_melted = selected_df.melt(var_name="UD01", value_name='Amounts')
  df_melted['Amounts'].fillna(0, inplace=True)
  df2=new_df.drop(selected_df, axis=1)
  df2.reset_index(drop=True, inplace=True)
  df_melted.reset_index(drop=True, inplace=True)
  combined_df = pd.concat([df2, df_melted], axis=1)
  try:
   combined_df=combined_df[combined_df["Amounts"].str.contains("#Mi")==False]
  except:
     time.sleep(0)
  combined_df.to_csv(outputfile, index=False)

def pbcs_fccs(inputfile, outputfile):
    with open(inputfile, 'r', encoding='utf-8-sig') as infile:
        reader = csv.DictReader(infile)
        fieldnames = reader.fieldnames
        fc = fieldnames[0]  # first column

    stopwords = ['Point-of-View', fc, 'Data Load Cube Name']
    for fieldname in list(fieldnames):
        if fieldname in stopwords:
            fieldnames.remove(fieldname)
    lofn = len(fieldnames)
    new_list = [x for x in fieldnames if x != '']
    dummyheaderlen = len(new_list)

    accdf = pd.read_csv(inputfile, usecols=new_list, low_memory=False)
    # creating df with fc and unsplitted pov and geting length of input file
    df = pd.read_csv(inputfile, usecols=[fc, 'Point-of-View'], low_memory=False)
    loif = len(df)
    # spliting pov
    df1 = df['Point-of-View'].str.split(",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)", regex=True, expand=True)
    lenofreqheader = (df1.shape[1])
    df2 = df.join(df1)
    df2 = df2.drop(['Point-of-View'], axis=1)
    df2new = df
    dflast = pd.DataFrame()
    alteraccount=str(len(df2.columns))
    for i in range(0,lofn):
        dflast = pd.concat([dflast, df2], ignore_index=True)
    #dflast = dflast.append(df2, ignore_index=True) replacing this line since append function is going to be obsolete
    df_melted = accdf.melt(var_name=alteraccount, value_name='Amount')

    dflast = dflast.join(df_melted)
    try:
        dflast = dflast[dflast["Amount"].str.contains("#missing") == False]
    except:
        time.sleep(0)
    dflast.to_csv(outputfile, index=False)
    dfhead = dflast.head()


def special(inputfile, outputfile, file_encoding, delimiter):
    with open(inputfile, 'r', encoding=file_encoding) as file:
        reader = csv.reader(file, delimiter=delimiter)
        data = list(reader)
    with open(outputfile, 'w', newline='', encoding=file_encoding) as file:
        writer = csv.writer(file)
        writer.writerows(data)

    df = pd.read_csv(outputfile, low_memory=False)

    df = df.applymap(lambda x: x.strip() if isinstance(x, str) else x)
    df = df.apply(lambda col: col.str.replace("'", ""))
    df.to_csv(outputfile, index=False, quoting=csv.QUOTE_NONNUMERIC, escapechar='\\')


def default(inputfile, outputfile):
    source_file = inputfile
    destination_file = outputfile
    if (source_file != destination_file):
        shutil.copy(source_file, destination_file)