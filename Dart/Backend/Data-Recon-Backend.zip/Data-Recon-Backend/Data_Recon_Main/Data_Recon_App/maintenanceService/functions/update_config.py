import threading
import time
import datetime
import subprocess
import os, shutil

from django.conf import settings
from django.db.models import Q
from configparser import ConfigParser
from ...models import Recon
from ...utils.pgsql_conn import call_sp_params

exit_event = threading.Event()

# This is the thread function that will drop the recon tables
def delete_recon():
    delete_interval=48
    delete_frequency=86400
    x=0
    while True:
        # Check condition to stop looped execution
        if exit_event.is_set():
            break
        
        tmstp = datetime.datetime.now() - datetime.timedelta(hours=delete_interval)
        # search for recons that are deleted and (null last_modified_date or last_modified_date gt 2 days)
        data = list(Recon.objects.filter(
            Q(is_deleted=True),
            Q(last_modified_date__lt=tmstp) | Q(last_modified_date__isnull=True)
        ))
        # print(data)
        for d in data:
            # Call stored procedure to delete the recon from database
            result = call_sp_params('fileService.sp_delete_recon', [d.recon_id], 1)
            stat = result['status']
            # print(f'Recon {d.recon_id} completed with status {stat}')

            # Delete recon from file system
            path = os.path.join(settings.MEDIA_ROOT,str(d.recon_id))
            if os.name=='nt':
                path = path.replace('/','\\')
                shutil.rmtree(path, ignore_errors=True)
            else:
                subprocess.call(['rm -rf '+ path], shell=True)
        x+=1

         # Sleep for delete_frequency seconds
        time.sleep(delete_frequency)

    # print('Exiting delete_recon')

# This function will run at startup
# If config file autodelete is true, it will run periodically.
def start_function():
    # config_file = 'Data_Recon_Main\Data_Recon_App\maintenanceService\config.ini'
    config_file = settings.MEDIA_ROOT + "/config.ini"
    config = ConfigParser()
    config.read_file(open(config_file)) 
    if not config['Maintenance']['autodelete'] in ['True','False']:
        print('Invalid config')
        return

    # Convert the string value in file to boolean
    data = eval(config['Maintenance']['autodelete'])    
    if data:
        exit_event.clear()
        thread = threading.Thread(name='DeleteThread', target=delete_recon)
        thread.start()
    else:
        # print('Auto run is set to false')
        exit_event.set()
    

# This function is to update the config file
def update_conf(data):
    # print('In update config')
    # print('Data: '+str(data))
    # config_file = 'Data_Recon_Main\Data_Recon_App\maintenanceService\config.ini'
    config_file = settings.MEDIA_ROOT + "/config.ini"
    config = ConfigParser()
    config.read_file(open(config_file))

    config['Maintenance']['autodelete']=str(data)
    
    with open(config_file,'w') as cf:
        config.write(cf)
    
    if data:
        exit_event.clear()
        thread = threading.Thread(name='DeleteThread', target=delete_recon)
        thread.start()
    else:
        # print('Auto run is set to false')
        exit_event.set()
        
    msg = "Auto delete changed to "+str(data)
    return {'message':msg}




def update_diskspace(data):
    config_file = settings.MEDIA_ROOT + "/config.ini"
    config = ConfigParser()
    config.read_file(open(config_file))

    config['Maintenance']['diskspace']=str(data)

    with open(config_file,'w') as cf:
        config.write(cf)

    msg = "Message will alert when storage reaches "+str(data)+"%"
    return {'message':msg}




def get_diskspace_thresh():

    config_file = settings.MEDIA_ROOT + "/config.ini"
    config = ConfigParser()

    with open(config_file,'r') as cf:
        config.read_file(cf)

    if config.has_option('Maintenance', 'diskspace'):
        diskspace_threshold = config.get('Maintenance', 'diskspace')
        return (diskspace_threshold+"%")
    else:
        return "None"