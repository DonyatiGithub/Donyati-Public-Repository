def update_dim(recon_id, dim_object):
    pass
