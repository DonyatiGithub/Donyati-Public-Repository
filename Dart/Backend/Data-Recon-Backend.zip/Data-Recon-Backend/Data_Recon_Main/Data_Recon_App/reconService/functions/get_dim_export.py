from .get_dimensions import get_dimensions
import io
import csv


def get_dim_export(recon_id):
    dim_object = get_dimensions(recon_id)
    csv_file = io.StringIO()
    header = ['order', 'app1_dimension', 'app1_dim_in_file', 'app1_type_field', 'app1_top_member', 'app1_is_active',
              'app2_dimension', 'app2_dim_in_file', 'app2_type_field', 'app2_top_member', 'app2_is_active']
    csv_writer = csv.DictWriter(csv_file, fieldnames=header)

    for i in range(0, len(dim_object)):

        # Creating the row object
        row = dict()
        row['order'] = dim_object[i]['order']
        row['app1_dimension'] = dim_object[i]['app1_dimension']
        row['app1_dim_in_file'] = dim_object[i]['app1_dim_in_file']
        row['app1_type_field'] = dim_object[i]['app1_type_field']
        row['app1_top_member'] = dim_object[i]['app1_top_member']
        row['app1_is_active'] = dim_object[i]['app1_is_active']
        row['app2_dimension'] = dim_object[i]['app2_dimension']
        row['app2_dim_in_file'] = dim_object[i]['app2_dim_in_file']
        row['app2_type_field'] = dim_object[i]['app2_type_field']
        row['app2_top_member'] = dim_object[i]['app2_top_member']
        row['app2_is_active'] = dim_object[i]['app2_is_active']

        # Writing to file object
        csv_writer.writerow(row)

    return csv_file
