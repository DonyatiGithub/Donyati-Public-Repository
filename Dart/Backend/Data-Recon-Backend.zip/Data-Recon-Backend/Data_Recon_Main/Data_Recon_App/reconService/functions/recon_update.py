import string

from django.db import connections
from ...utils.pgsql_conn import call_sp_params
from ...models import ReconDimensions
from ..serializers import DimensionSerializer
from .get_dimensions import get_dimensions
from ...bridgeService.functions.get_disk_space import get_disk_space
from ...maintenanceService.functions.update_config import get_diskspace_thresh


# # def recon_update_dim(recon_dimensions, instance, recon_id):
# #     number_of_dimensions = len(recon_dimensions)
# #     dimensions_list = []
# #     for i in range(0, number_of_dimensions):
# #         if recon_dimensions[i]['app1_dim_in_file'] == 'YES':
# #             recon_dimensions[i]['app1_top_member'] = None
# #
# #         else:
# #             recon_dimensions[i]['app1_type_field'] = None
# #
# #         dim = recon_dimensions[i]['app1_dimension'].upper()
# #         print("tuche")
# #
# #         for elem in dim:
# #             if any(char.isspace() for char in elem):
# #                 response_data = {
# #                     'status': 6001,
# #                     'data': dim,
# #                     'message': 'Spaces are not acceptable in dimension names'
# #                 }
# #                 print( 'line 28',response_data)
# #                 return response_data
# #
# #             else:
# #                 # Application one dimension
# #                 dimensions_list.append(
# #                     {
# #                         'turn_on_define_order': recon_dimensions[i]['order'],
# #                         'dimension': recon_dimensions[i]['app1_dimension'].upper(),
# #                         'dim_in_file': recon_dimensions[i]['app1_dim_in_file'],
# #                         'type_field': recon_dimensions[i]['app1_type_field'],
# #                         'top_member': recon_dimensions[i]['app1_top_member'],
# #                         'app_type': recon_dimensions[i]['app1_app_type'],
# #                         'is_active': recon_dimensions[i]['app1_is_active'],
# #                         'recon_app_id': instance.app1_id
# #                     }
# #                 )
# #         # Application two dimension
# #         if recon_dimensions[i]['app2_dim_in_file'] == 'YES':
# #             recon_dimensions[i]['app2_top_member'] = None
# #
# #
# #         else:
# #             recon_dimensions[i]['app2_type_field'] = None
# #
# #         dim = recon_dimensions[i]['app2_dimension'].upper()
# #
# #
# #         for elem in dim:
# #             if any(char.isspace() for char in elem):
# #                 response_data = {
# #                     'status': 6001,
# #                     'data': dim,
# #                     'message': 'Spaces are not acceptable in dimension names'
# #                 }
# #                 print('line 62', response_data)
# #                 return response_data
# #             else:
# #                 dimensions_list.append(
# #                     {
# #                         'turn_on_define_order': recon_dimensions[i]['order'],
# #                         'dimension': recon_dimensions[i]['app2_dimension'].upper(),
# #                         'dim_in_file': recon_dimensions[i]['app2_dim_in_file'],
# #                         'type_field': recon_dimensions[i]['app2_type_field'],
# #                         'top_member': recon_dimensions[i]['app2_top_member'],
# #                         'app_type': recon_dimensions[i]['app2_app_type'],
# #                         'is_active': recon_dimensions[i]['app1_is_active'],
# #                         'recon_app_id': instance.app2_id
# #                     }
# #                 )
# #
# #         dimensions_length = len(dimensions_list)
# #         for j in range(0, dimensions_length):
# #             dimension = dimensions_list[j]
# #             dimension['recon_id'] = recon_id
# #
# #             # cursor = connections['Recon'].cursor()
# #             # try:
# #             #     cur = cursor.execute()
# #             #     cur.callproc('fileservice.sp_alter_app_je_table', [instance.app1_id, old_column, new_column])
# #
# #             # Check if the dimension exists --then update else create
# #             if ReconDimensions.objects.filter(
# #                     turn_on_define_order=dimensions_list[j]['turn_on_define_order'],
# #                     app_type=dimensions_list[j]['app_type'], recon_id=recon_id).exists():
# #                 dim_instance = ReconDimensions.objects.filter(
# #                     turn_on_define_order=dimensions_list[j]['turn_on_define_order'],
# #                     app_type=dimensions_list[j]['app_type'], recon_id=recon_id)[0]
# #                 serialized_dim = DimensionSerializer(dim_instance, data=dimension, partial=True)
# #             else:
# #                 if ReconDimensions.objects.filter(dimension=dimensions_list[j]['dimension'], recon_id=recon_id,
# #                                                   app_type=dimensions_list[j]['app_type']).exists():
# #                     response_data = {
# #                         'status': 6001,
# #                         'message': 'Dimension name already exists within another order!'
# #                     }
# #                     print('line 103', response_data)
# #                     return response_data
# #                 else:
# #                     serialized_dim = DimensionSerializer(data=dimension)
# #
# #             if serialized_dim.is_valid():
# #                 serialized_dim.save()
# #                 response_data = {
# #                     'status': 200,
# #                     'message': 'Recon dimensions updated successfully!'
# #                 }
# #             else:
# #                 response_data = {
# #                     'status': 6001,
# #                     'error': serialized_dim.errors,
# #                     'message': 'Recon dimensions updated failed!'
# #                 }
# #
# #             # except TypeError as e:
# #             #     response_data = {
# #             #         'status': 6001,
# #             #         'message': 'Something went wrong in query',
# #             #         'error': str(e)
# #             #     }
# #             # finally:
# #             #     cursor.close()
# #             print('line 129', response_data)
# #         return response_data
#
#
# def recon_update_dim(recon_dimensions, instance, recon_id, up=False):
#     number_of_dimensions = len(recon_dimensions)
#     dimensions_list = []
#     for i in range(0, number_of_dimensions):
#         if recon_dimensions[i]['app1_dim_in_file'] == 'YES':
#             recon_dimensions[i]['app1_top_member'] = None
#         else:
#             recon_dimensions[i]['app1_type_field'] = None
#
#         dim = recon_dimensions[i]['app1_dimension'].upper()
#
#         if any(char.isspace() for char in dim):
#             response_data = {
#                 'status': 6001,
#                 'message': 'Please correct Dimension names. Spaces are not acceptable in Dimension names',
#                 'data': dim,
#             }
#
#             return response_data
#         else:
#             # Application one dimension
#             dimensions_list.append(
#                 {
#                     'turn_on_define_order': recon_dimensions[i]['order'],
#                     'dimension': recon_dimensions[i]['app1_dimension'].upper(),
#                     'dim_in_file': recon_dimensions[i]['app1_dim_in_file'],
#                     'type_field': recon_dimensions[i]['app1_type_field'],
#                     'top_member': recon_dimensions[i]['app1_top_member'],
#                     'app_type': recon_dimensions[i]['app1_app_type'],
#                     'is_active': recon_dimensions[i]['app1_is_active'],
#                     'recon_app_id': instance.app1_id,
#                     'is_deleted': False
#                 }
#             )
#         # dim = recon_dimensions[i]['app1_dimension'].upper()
#
#         # for elem in dim:
#         #     if any(char.isspace() for char in elem):
#         #         response_data = {
#         #             'status': 6001,
#         #             'data': dim,
#         #             'message': 'Spaces are not acceptable in dimension names'
#         #         }
#         #
#         #         return response_data
#         #     else:
#         #         # Application one dimension
#         #         dimensions_list.append(
#         #             {
#         #                 'turn_on_define_order': recon_dimensions[i]['order'],
#         #                 'dimension': recon_dimensions[i]['app1_dimension'].upper(),
#         #                 'dim_in_file': recon_dimensions[i]['app1_dim_in_file'],
#         #                 'type_field': recon_dimensions[i]['app1_type_field'],
#         #                 'top_member': recon_dimensions[i]['app1_top_member'],
#         #                 'app_type': recon_dimensions[i]['app1_app_type'],
#         #                 'is_active': recon_dimensions[i]['app1_is_active'],
#         #                 'recon_app_id': instance.app1_id,
#         #                 'is_deleted': False
#         #             }
#         #         )
#         # Application two dimension
#         if recon_dimensions[i]['app2_dim_in_file'] == 'YES':
#             recon_dimensions[i]['app2_top_member'] = None
#
#         else:
#             recon_dimensions[i]['app2_type_field'] = None
#
#         dim = recon_dimensions[i]['app2_dimension'].upper()
#
#         if any(char.isspace() for char in dim):
#             response_data = {
#                 'status': 6001,
#                 'message': 'Please correct Dimension names. Spaces are not acceptable in Dimension names',
#                 'data': dim,
#             }
#             return response_data
#         else:
#             dimensions_list.append(
#                 {
#                     'turn_on_define_order': recon_dimensions[i]['order'],
#                     'dimension': recon_dimensions[i]['app2_dimension'].upper(),
#                     'dim_in_file': recon_dimensions[i]['app2_dim_in_file'],
#                     'type_field': recon_dimensions[i]['app2_type_field'],
#                     'top_member': recon_dimensions[i]['app2_top_member'],
#                     'app_type': recon_dimensions[i]['app2_app_type'],
#                     'is_active': recon_dimensions[i]['app1_is_active'],
#                     'recon_app_id': instance.app2_id,
#                     'is_deleted': False
#                 }
#             )
#
#         dimensions_length = len(dimensions_list)
#         # print(dimensions_list)
#         for j in range(0, dimensions_length):
#             dimension = dimensions_list[j]
#             dimension['recon_id'] = recon_id
#             old_column = ""
#             new_column = dimensions_list[j]['dimension']
#
#             # Check if the dimension exists --then update else create
#             if ReconDimensions.objects.filter(
#                     turn_on_define_order=dimensions_list[j]['turn_on_define_order'],
#                     app_type=dimensions_list[j]['app_type'], recon_id=recon_id).exists():
#                 dim_instance = ReconDimensions.objects.filter(
#                     turn_on_define_order=dimensions_list[j]['turn_on_define_order'],
#                     app_type=dimensions_list[j]['app_type'], recon_id=recon_id)[0]
#                 old_column = dim_instance.dimension
#                 serialized_dim = DimensionSerializer(dim_instance, data=dimension, partial=True)
#             else:
#                 if ReconDimensions.objects.filter(dimension=dimensions_list[j]['dimension'], recon_id=recon_id,
#                                                   app_type=dimensions_list[j]['app_type']).exists():
#                     response_data = {
#                         'status': 6001,
#                         'message': 'Dimension name already exists within another order!'
#                     }
#                     return response_data
#                 else:
#                     serialized_dim = DimensionSerializer(data=dimension)
#
#             if serialized_dim.is_valid():
#                 serialized_dim.save()
#                 # print(old_column)
#                 # print(new_column)
#                 if up and old_column != new_column:
#                     old_column = old_column.replace('"', "'")
#                     new_column = new_column.replace('"', "'")
#                     if old_column == '':
#                         call_sp_params('fileservice.sp_alter_app_je_table',
#                                        [dimensions_list[j]['recon_app_id'], new_column], 2)
#                     else:
#                         call_sp_params('fileservice.sp_alter_app_je_table',
#                                        [dimensions_list[j]['recon_app_id'], new_column, old_column], 3)
#             else:
#                 response_data = {
#                     'status': 6001,
#                     'error': serialized_dim.errors,
#                     'message': 'Recon dimensions update failed!'
#                 }
#                 return response_data
#
#     response_data = {
#         'status': 200,
#         'message': 'Recon dimensions updated successfully!'
#     }
#
#     return response_data


def recon_update_dim(recon_dimensions, instance, recon_id, up=False):
    number_of_dimensions = len(recon_dimensions)
    dimensions_list = []
    serialized_dim_list=[]
    for i in range(0, number_of_dimensions):
        if recon_dimensions[i]['app1_dim_in_file'] == 'YES':
            app1_top_member=None
            if recon_dimensions[i]['app1_top_member']:
                app1_top_member=recon_dimensions[i]['app1_top_member']
            recon_dimensions[i]['app1_top_member'] =app1_top_member
        else:
            recon_dimensions[i]['app1_type_field'] = None

        dim = recon_dimensions[i]['app1_dimension'].upper()

        if any(char.isspace() for char in dim):
            response_data = {
                'status': 6001,
                'message': 'Please correct Dimension names. Spaces are not acceptable in Dimension names',
                'data': dim,
            }

            return response_data
        else:
            # Application one dimension
            dimensions_list.append(
                {
                    'turn_on_define_order': recon_dimensions[i]['order'],
                    'dimension': recon_dimensions[i]['app1_dimension'].upper(),
                    'dim_in_file': recon_dimensions[i]['app1_dim_in_file'],
                    'type_field': recon_dimensions[i]['app1_type_field'],
                    'top_member': recon_dimensions[i]['app1_top_member'],
                    'app_type': recon_dimensions[i]['app1_app_type'],
                    'is_active': recon_dimensions[i]['app1_is_active'],
                    'recon_app_id': instance.app1_id,
                    'is_deleted': False
                }
            )
        # dim = recon_dimensions[i]['app1_dimension'].upper()

        # for elem in dim:
        #     if any(char.isspace() for char in elem):
        #         response_data = {
        #             'status': 6001,
        #             'data': dim,
        #             'message': 'Spaces are not acceptable in dimension names'
        #         }
        #
        #         return response_data
        #     else:
        #         # Application one dimension
        #         dimensions_list.append(
        #             {
        #                 'turn_on_define_order': recon_dimensions[i]['order'],
        #                 'dimension': recon_dimensions[i]['app1_dimension'].upper(),
        #                 'dim_in_file': recon_dimensions[i]['app1_dim_in_file'],
        #                 'type_field': recon_dimensions[i]['app1_type_field'],
        #                 'top_member': recon_dimensions[i]['app1_top_member'],
        #                 'app_type': recon_dimensions[i]['app1_app_type'],
        #                 'is_active': recon_dimensions[i]['app1_is_active'],
        #                 'recon_app_id': instance.app1_id,
        #                 'is_deleted': False
        #             }
        #         )
        # Application two dimension
        if recon_dimensions[i]['app2_dim_in_file'] == 'YES':
            
            app2_top_member =None
            if recon_dimensions[i]['app2_top_member']:
                app2_top_member=recon_dimensions[i]['app2_top_member']

            recon_dimensions[i]['app2_top_member'] = app2_top_member

        else:
            recon_dimensions[i]['app2_type_field'] = None

        dim = recon_dimensions[i]['app2_dimension'].upper()

        if any(char.isspace() for char in dim):
            response_data = {
                'status': 6001,
                'message': 'Please correct Dimension names. Spaces are not acceptable in Dimension names',
                'data': dim,
            }
            return response_data
        else:
            dimensions_list.append(
                {
                    'turn_on_define_order': recon_dimensions[i]['order'],
                    'dimension': recon_dimensions[i]['app2_dimension'].upper(),
                    'dim_in_file': recon_dimensions[i]['app2_dim_in_file'],
                    'type_field': recon_dimensions[i]['app2_type_field'],
                    'top_member': recon_dimensions[i]['app2_top_member'],
                    'app_type': recon_dimensions[i]['app2_app_type'],
                    'is_active': recon_dimensions[i]['app1_is_active'],
                    'recon_app_id': instance.app2_id,
                    'is_deleted': False
                }
            )

        dimensions_length = len(dimensions_list)
        # print(dimensions_list)
        for j in range(0, dimensions_length):
            dimension = dimensions_list[j]
            dimension['recon_id'] = recon_id
            old_column = ""
            new_column = dimensions_list[j]['dimension']

            # Check if the dimension exists --then update else create
            if ReconDimensions.objects.filter(
                    turn_on_define_order=dimensions_list[j]['turn_on_define_order'],
                    app_type=dimensions_list[j]['app_type'], recon_id=recon_id).exists():
                dim_instance = ReconDimensions.objects.filter(
                    turn_on_define_order=dimensions_list[j]['turn_on_define_order'],
                    app_type=dimensions_list[j]['app_type'], recon_id=recon_id)[0]
                old_column = dim_instance.dimension
                serialized_dim = DimensionSerializer(dim_instance, data=dimension, partial=True)
            else:
                if ReconDimensions.objects.filter(dimension=dimensions_list[j]['dimension'], recon_id=recon_id,
                                                  app_type=dimensions_list[j]['app_type']).exists():
                    response_data = {
                        'status': 6001,
                        'message': 'Dimension name already exists within another order!'
                    }
                    return response_data
                else:
                    serialized_dim = DimensionSerializer(data=dimension)

            if serialized_dim.is_valid():
                serialized_dim.save()
                # print(old_column)
                # print(new_column)
                serialized_dim_list.append(serialized_dim.data)
                if up and old_column != new_column:
                    old_column = old_column.replace('"', "'")
                    new_column = new_column.replace('"', "'")
                    if old_column == '':
                        call_sp_params('fileservice.sp_alter_app_je_table',
                                       [dimensions_list[j]['recon_app_id'], new_column], 2)
                    else:
                        call_sp_params('fileservice.sp_alter_app_je_table',
                                       [dimensions_list[j]['recon_app_id'], new_column, old_column], 3)
            else:
                response_data = {
                    'status': 6001,
                    'error': serialized_dim.errors,
                    'message': 'Recon dimensions update failed!'
                }
                return response_data

    response_data = {
        'status': 200,
        'message': 'Recon dimensions updated successfully!',
        'rows':get_dimensions(recon_id)
    }

    # Get disk space usage
    if get_diskspace_thresh()!="None":
        disk_usage = get_disk_space()
        if get_diskspace_thresh() == disk_usage:
            response_data["disk_usage"] = disk_usage

    return response_data