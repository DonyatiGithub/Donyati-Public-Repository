from rest_framework import serializers
from ..models import ReconUser, InviteDetails, DCUser


class UserList(serializers.ModelSerializer):
    class Meta:
        model = ReconUser
        fields = ('username', 'first_name', 'last_name', 'email', 'role', 'access_type',
                  'is_active', 'onestream')


class InviteList(serializers.ModelSerializer):
    class Meta:
        model = InviteDetails
        fields = ('email', 'role', 'access_type', 'status', 'created_date')


class UserInfo(serializers.ModelSerializer):
    class Meta:
        model = ReconUser
        fields = (
        'username', 'first_name', 'last_name', 'email', 'role', 'access_type', 'is_active', 'uuid', 'onestream')


class DCUserSerializer(serializers.ModelSerializer):
    class Meta:
        model = DCUser
        fields = ('app_name', 'import_type', 'dc_username', 'dc_password', 'dc_url', 'tenant_id', 'email', 'id', 'osname')
