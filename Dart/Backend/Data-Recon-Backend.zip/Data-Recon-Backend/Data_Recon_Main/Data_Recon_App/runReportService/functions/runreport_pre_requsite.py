from ...runImportService.functions.is_exists import is_exists

def report_pre_requsite(recon_id):
    sync_exists =is_exists("fileservice",f"bridgesync_{recon_id}")
    
    return sync_exists['rows'][0]['exists']