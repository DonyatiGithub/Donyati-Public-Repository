from django.db import connections

'''
<!---------- Method to do calculate over variance ----------!>
'''


def getVariance(query):
    cursor = connections['Recon'].cursor()
    try:
        cursor.execute(query)
        results = cursor.fetchall()    
    except Exception as e:
        print(e)
    finally:
        cursor.close()

    record_count = results[0][0]
    variance_count = results[0][1]

    variance_pct = (variance_count/record_count)*100
    variance_pct = "{:.1f}".format(float(variance_pct)) + '%'

    return variance_pct
