import io
import csv
from .get_report_view import get_report_view
from ...runImportService.functions.is_exists import is_exists


'''
<!---------- Method to get the run report data from db
             and return as file data for download ----------!>
'''


def export_report_run(recon_id):

    # Check if view exists
    view_exists = is_exists('fileservice', 'report_' + str(recon_id))

    if view_exists['rows'][0]['exists']:
        # Getting both apps data
        view_query = 'SELECT * FROM fileService.report_' + str(recon_id)
        report_run_data = get_report_view(view_query)
    else:
        report_run_data = {
            'status': 200,
            'headers': [],
            'rows': [],
            'message': 'No data found!'
        }

    # Creating a file object without saving
    csv_file = io.StringIO()
    header = report_run_data['headers']
    csv_writer = csv.DictWriter(csv_file, fieldnames=header)
    csv_writer.writeheader()

    for i in range(0, len(report_run_data['rows'])):
        # Creating the row object
        row = dict()

        # Looping headers and adding in object
        for head in header:
            if head == 'Comments':
                comment_data = list(filter(None, report_run_data['rows'][i][head]))
                if comment_data:
                    report_run_data['rows'][i][head] = "-".join(comment_data)
                else:
                    report_run_data['rows'][i][head] = None

            row[head] = report_run_data['rows'][i][head]

        # Writing to file object
        csv_writer.writerow(row)

    return csv_file
