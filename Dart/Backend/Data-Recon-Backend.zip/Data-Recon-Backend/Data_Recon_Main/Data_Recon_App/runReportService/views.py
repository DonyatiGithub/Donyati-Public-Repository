import io
from datetime import datetime
from django.db import connections
from django.http import HttpResponse
from rest_framework import status
from rest_framework.decorators import permission_classes, api_view, renderer_classes, parser_classes
from rest_framework.parsers import MultiPartParser, FormParser
from rest_framework.permissions import IsAuthenticated
from rest_framework.renderers import JSONRenderer
from rest_framework.response import Response
from ..models import Recon
from .functions.execute_report import execute_report
import zipfile
from django.conf import settings
import os
from .functions.get_all_paths import get_all_paths
from .functions.get_backup_file_path import get_backup_file_path
from ..reconService.functions.export_store import export_store
from ..transformationService.functions.export_sync_data import export_sync_data
from ..utils.user_permissions import is_write_permitted
from ..runReportService.functions.run_export_report import run_export_report
from .functions.getReport import getReport as gR
from ..utils.store_file import store_file
from ..utils.is_signed import is_recon_signed
import base64
import requests
from ..utils.run_export_script import run_export_script
from ..utils.export_query import dim_query, bridge_query, comment_query, bridge_kick_out_query, \
    run_bridge_export_query, export_source_data_query, run_trans_export_query
from .. utils.pgsql_conn import call_sp_params
from .functions.validate_zip import validate_zip, validate_zip_content
from .functions.create_file_with_permission import create_file_with_permission
from ..reconService.serializers import ReconSerializer, ReconGetSerializer
from .functions.create_duplicate_recon_file import create_duplicate_recon_file

from .functions.drill_down import prepare_dynamic_columns , dynamic_filter_values,get_drill_down
import json
from .functions.runreport_pre_requsite import report_pre_requsite
from ..runImportService.functions.is_exists import view_kickout


import logging
import time
import pandas as pd
import uuid

user_logger = logging.getLogger("userlog")
# use this user_logger to log user log 
logger = logging.getLogger("techlog")
# use 'logger' to for general application log


@api_view(['POST'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def run_report(request):
    try :
        start_time = time.time()
        log_context = {
            "recon_id": request.data['recon_id'],
            "request_id": request.request_id,
            "user_email": request.user.email,
            "request_url": request.path,
            "event_stage": 'Runreport'
        }
        logger.info("Run_report function execution start",extra=log_context)

        # Getting the data from request
        recon_id = request.data['recon_id']
        max_rows = request.data['max_rows']
        page_number = request.data['page_number']
        variance = request.data['variance_threshold']
        pre_requsite = report_pre_requsite(recon_id)
        
        Recon.objects.filter(recon_id=recon_id, is_deleted=False).update(variance_threshold= variance)
        if(request.data['colList']):
            colList = request.data['colList']
        else:
            colList = '*'
        
        if(request.data['sp_flag']):
            sp_flag = request.data['sp_flag']
        else:
            sp_flag = False

        if not pre_requsite and sp_flag:
            logger.error("please run the transformation before running the report")
            response_data={
                          "status":403,
                          "message": "please run the transformation before running the report"
                           }
            return Response(response_data, status=status.HTTP_200_OK)

        if is_write_permitted(request.user.email):
            # if not is_recon_signed(recon_id) :
                # Checking if recon exists or not deleted
                if recon_id != '' and Recon.objects.filter(recon_id=recon_id, is_deleted=False).exists():
                    response_data = execute_report(recon_id, max_rows, page_number, colList, sp_flag, variance_threshold=variance)
                else:
                    response_data = {
                        'status': 403,
                        'message': 'No recon found with the specified id!'
                    }
            # else:
            #     response_data = {
            #             'status': 403,
            #             'message': 'This Recon is Signed Off'
            #         }        
        else:
            if recon_id != '' and Recon.objects.filter(recon_id=recon_id, is_deleted=False).exists():
                response_data = execute_report(recon_id, max_rows, page_number, colList, sp_flag=False, variance_threshold=variance)
            else:
                response_data = {
                    'status': 403,
                    'message': 'No recon found with the specified id!'
                }

        log_context["time_taken"]=int(time.time()-start_time)
        logger.info("Run_report function execution ends",extra=log_context)

        if response_data.get("status")!=200:
            logger.error(response_data,extra=log_context)
        else:
            user_logger.info("Report run sucessfully")

        return Response(response_data, status=status.HTTP_200_OK)

    except Exception as e:
        log_context["variable_state"]=locals()
        logger.error(f" Exception occured in run_report : {str(e)}",exc_info=1,extra=log_context)
        raise e


@api_view(['POST'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def run_report_export(request):
    try :
        start_time = time.time()
        log_context = {
            "recon_id": request.data['recon_id'],
            "request_id": request.request_id,
            "user_email": request.user.email,
            "request_url": request.path,
            "event_stage": 'Runreport'
        }
        logger.info("Run_report_export function execution start",extra=log_context)

        recon_id = request.data['recon_id']
        if is_write_permitted(request.user.email):
            # if not is_recon_signed(recon_id) :
                if recon_id != '' and Recon.objects.filter(recon_id=recon_id, is_deleted=False).exists():
                    # variance = Recon.objects.get(recon_id=recon_id, is_deleted=False).variance_threshold
                    variance=request.data["variance_threshold"]
                    report_name=request.data["report_name"]
                    # report_type = request.data['report_type']
                    report_type = ''

                    if(request.data['colList']):
                        colList = request.data['colList']
                    else:
                        colList = '*'
                    
                    # Call export function
                    response_data = run_export_report(colList,recon_id,variance,report_type,report_name)

                    user_logger.info("Exported the runreport",extra=log_context)
                    log_context["time_taken"]=int(time.time()-start_time)
                    logger.info(" Export runreport function execution ends",extra=log_context)

                else:
                    response_data = {
                        'status': 403,
                        'message': 'No recon found with the specified id!'
                    }
            # else:
            #     response_data = {
            #             'status': 403,
            #             'message': 'This Recon is Signed Off'
            #         }        
        else:
            response_data = {
                'status': 6002,
                'message': 'Un-authorized action detected!'
            }

        # if response_data.get("status")!=200:
        #     logger.error(response_data,extra=log_context)

        log_context["time_taken"]=int(time.time()-start_time)
        logger.info("Run_report_export function execution ends",extra=log_context)

        return Response(response_data, status=status.HTTP_200_OK)

    except Exception as e:
        log_context["variable_state"]=locals()
        logger.error(f" Exception occured in run_report_export : {str(e)}",exc_info=1,extra=log_context)
        raise e



@api_view(['GET'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def getReport(request, recon_id, file_name):
    try :
        start_time = time.time()
        log_context = {
            "recon_id": recon_id,
            "request_id": request.request_id,
            "user_email": request.user.email,
            "request_url": request.path,
            "event_stage": 'Runreport'
        }
        logger.info("GetReport function execution start",extra=log_context)

        if is_write_permitted(request.user.email):
            # if not is_recon_signed(recon_id) :
                current_time = datetime.now().time().strftime("%H:%M:%S")
                current_date = datetime.now().strftime("%Y-%m-%d")
                modified_date = str(current_date) + '_' + str(current_time)

                fpath = os.path.join(settings.MEDIA_ROOT,str(recon_id) + "/export" + f"/{file_name}")
                fpath=fpath.replace('\\','/')
                if os.path.exists(fpath):
                    with open(fpath, 'rb') as fh:
                        response = HttpResponse(fh.read(),content_type="application/vnd.ms-excel")
                        response['Content-Disposition'] = 'inline; filename=' + os.path.basename(modified_date + fpath)
                        response['Access-Control-Expose-Headers'] = 'Content-Disposition'

                        user_logger.info("Get the report",extra=log_context)
                        log_context["time_taken"]=int(time.time()-start_time)
                        logger.info("getReport function execution ends",extra=log_context)
                        return response
            # else:
            #     response = {
            #             'status': 403,
            #             'message': 'This Recon is Signed Off'
            #         }
        else:
            response = {
                'status': 6002,
                'message': 'Un-authorized action detected!'
            }

        if response.get("status")!=200:
            logger.error(response,extra=log_context)

        log_context["time_taken"]=int(time.time()-start_time)
        logger.info("GetReport function execution ends",extra=log_context)

        return Response(response, status=status.HTTP_200_OK)

    except Exception as e:
        log_context["variable_state"]=locals()
        logger.error(f" Exception occured in getReport : {str(e)}",exc_info=1,extra=log_context)
        raise e

@api_view(['GET'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def archived_files(request, recon_id):
    try :
        start_time = time.time()
        log_context = {
            "recon_id": recon_id,
            "request_id": request.request_id,
            "user_email": request.user.email,
            "request_url": request.path,
            "event_stage": 'Runreport'
        }
        logger.info("Archived_files function execution start",extra=log_context)

        variance = Recon.objects.get(recon_id=recon_id, is_deleted=False).variance_threshold
        variance='0' if variance== None else variance
        if is_write_permitted(request.user.email):
            # if not is_recon_signed(recon_id) :
                # archiving export files
                objs = {
                    "Dimension_export.csv": dim_query(recon_id),
                    "App1_Bridge_Export.csv": bridge_query(recon_id, 0),
                    "App2_Bridge_Export.csv": bridge_query(recon_id, 1),
                    "Bridge_Comments_Export.csv": comment_query(recon_id),
                    "Bridge_Kick_out_Export.csv": bridge_kick_out_query(recon_id, False),
                    "JE_Bridge_Kick_out_Export.csv": bridge_kick_out_query(recon_id, True),
                    "Run_bridge_Export.csv": run_bridge_export_query(recon_id, False),
                    "JE_Run_bridge_Export.csv": run_bridge_export_query(recon_id, True),
                    "Source_Data_Export.csv": export_source_data_query(recon_id, False),
                    "JE_Source_Data_Export.csv": export_source_data_query(recon_id, True),
                    "Run_transformation_Export.csv": run_trans_export_query(recon_id),
                }

                for file_name, query in objs.items():
                    run_export_script(recon_id, file_name, query)

                sync_objs = {
                    "Sync_Mapping_app1_": export_sync_data(recon_id, 0),
                    "Sync_Mapping_app2_": export_sync_data(recon_id, 1)
                }
                for obj, fun in sync_objs.items():
                    export_store(recon_id, fun.getvalue(), obj)

                report_type = 'variance'

                run_export_report("*", recon_id, variance, report_type, 'all_report')

                # zipping the archived files
                # zip_file = 'archive_files' + datetime.now().time().strftime("%H:%M:%S") + '.zip'
                # response = HttpResponse(content_type='application/zip')
                # actual_file = io.BytesIO

                zpath = os.path.join(settings.MEDIA_ROOT, str(recon_id) + "archive.zip")

                with zipfile.ZipFile(zpath, 'w') as my_zip:
                    archive_path = os.path.join(settings.MEDIA_ROOT, str(recon_id))
                    file_paths = get_all_paths(archive_path)
                    for file in file_paths:
                        my_zip.write(file, os.path.basename(file))

                zpath = os.path.join(settings.MEDIA_ROOT, str(recon_id) + "archive.zip")
                zip_file = open(zpath, 'rb')

                response = HttpResponse(zip_file.read(), content_type='application/zip')
                response['Content-Disposition'] = f'attachment; filename= {str(recon_id)}_Archive.zip'
                response['Access-Control-Expose-Headers'] = 'Content-Disposition'

                user_logger.info("archieved the files",extra=log_context)
                log_context["time_taken"]=int(time.time()-start_time)
                logger.info(" archieved_files function execution ends",extra=log_context)
                return response
            # else:
            #     response = {
            #             'status': 403,
            #             'message': 'This Recon is Signed Off'
            #     }
        else:
            response = {
                'status': 6002,
                'message': 'Un-authorized action detected!'
            }

        if response.get("status")!=200:
            logger.error(response,extra=log_context)

        log_context["time_taken"]=int(time.time()-start_time)
        logger.info("Archived_files function execution ends",extra=log_context)

        return Response(response, status=status.HTTP_200_OK)

    except Exception as e:
        log_context["variable_state"]=locals()
        logger.error(f" Exception occured in archived_files : {str(e)}",exc_info=1,extra=log_context)
        raise e


@api_view(['GET'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def dim_view(request):
    try:
        start_time = time.time()
        log_context = {
            "recon_id": request.data['recon_id'],
            "request_id": request.request_id,
            "user_email": request.user.email,
            "request_url": request.path,
            "event_stage": 'Runreport'
        }
        logger.info("Dim_view function execution start",extra=log_context)

        # recon_id = request.data['recon_id']
        # dim_id_lst = request.data['dimensions_id']
        #
        # if is_write_permitted(request.user.email):
        #     if recon_id != '' and ReconDimensions.objects.filter(recon_id=recon_id, is_deleted=False).exists():
        #         ReconDimensions.objects.filter(recon_id=recon_id).update(in_recon=False)
        #         for dim_id in dim_id_lst:
        #             if ReconDimensions.objects.filter(recon_id=recon_id, dimensions_id=dim_id).exists():
        #                 for i in range(len(ReconDimensions.objects.filter(recon_id=recon_id, dimensions_id=dim_id))):
        #                     instance = ReconDimensions.objects.filter(recon_id=recon_id, dimensions_id=dim_id)[i]
        #                     ReconDimensions.objects.filter(recon_id=recon_id,
        #                                                    turn_on_define_order=instance.turn_on_define_order)\
        #                         .update(in_recon=True)
        #             else:
        #                 response_data = {
        #                     'status': 403,
        #                     'message': 'Invalid Dimension id'
        #                 }
        #                 return Response(response_data)
        #             response_data = {
        #                 'status': 200,
        #                 'in_recon_dims': in_recon_dims(recon_id),
        #                 'message': 'Success'
        #             }
        #     else:
        #         response_data = {
        #             'status': 403,
        #             'message': 'No recon found with the specified id!'
        #         }
        # else:
        #     response_data = {
        #         'status': 6002,
        #         'message': 'Un-authorized action detected!'
        #     }
        # return Response(response_data, status=status.HTTP_200_OK)

        # import requests
        # import base64  # OneStream REST API endpoint
        url = "https://onestream.donyati.com/onestreamapi/api/Authentication/LogonAndReturnCookie?api-version=5.2.0"  # Base64-encoded username and password
        username = "epmvelocity@donyati.com"
        password = "Alw@ys+ve21"
        auth_string = base64.b64encode(f"{username}:{password}".encode()).decode()  # HTTP request with Basic Authentication
        headers = {
            "Authorization": f"Basic {auth_string}",
            "Content-Type": "application/json"
        }
        response = requests.post(url, headers=headers)  # Process the response
        # print(response.content)
        # response = {
        #     'status': 200,
        #     'message': 'Request made'
        # }
        log_context["time_taken"]=int(time.time()-start_time)
        logger.info("Dim_view function execution ends",extra=log_context)

        return Response(response.content, status=status.HTTP_200_OK)

    except Exception as e:
        log_context["variable_state"]=locals()
        logger.error(f" Exception occured in dim_view : {str(e)}",exc_info=1,extra=log_context)
        raise e

@api_view(['POST'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def sign_off_recon(request):
    try :
        start_time = time.time()
        log_context = {
            "recon_id": request.data['recon_id'],
            "request_id": request.request_id,
            "user_email": request.user.email,
            "request_url": request.path,
            "event_stage": 'Runreport'
        }
        logger.info("Sign_off_recon function execution start",extra=log_context)

        signed_off = request.data['sign_off']
        recon_id = request.data['recon_id']    
        if is_write_permitted(request.user.email):
            if recon_id != '' and Recon.objects.filter(recon_id=recon_id, is_deleted=False).exists():
                instance = Recon.objects.filter(recon_id=recon_id, is_deleted=False)[0]
                instance.sign_off = signed_off
                instance.save()            
                response_data = {
                    'status': 200,
                    'message': 'Recon Signed Off successfully!' if signed_off else 'Recon Un Signed successfully!',
                    'sign_off': signed_off
                }
            else:
                response_data = {
                    'status': 403,
                    'message': 'No recon found with the specified id!'
                }
        else:
            response_data = {
            'status': 6002,
            'message': 'Un-authorized action detected!'
            }

        if response_data.get("status")!=200:
            logger.error(response_data,extra=log_context)

        log_context["time_taken"]=int(time.time()-start_time)
        logger.info("sign_off_recon function execution ends",extra=log_context)

        return Response(response_data, status=status.HTTP_200_OK)

    except Exception as e:
        log_context["variable_state"]=locals()
        logger.error(f" Exception occured in sign_off_recon : {str(e)}",exc_info=1,extra=log_context)
        raise e

@api_view(['GET'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def backup_recon_files(request, recon_id):
    try :
        start_time = time.time()
        log_context = {
            "recon_id": recon_id,
            "request_id": request.request_id,
            "user_email": request.user.email,
            "request_url": request.path,
            "event_stage": 'Runreport'
        }
        logger.info("Backup_recon_files function execution start",extra=log_context)

        # instance = Recon.objects.get(recon_id=recon_id, is_deleted=False)
        variance = Recon.objects.get(recon_id=recon_id, is_deleted=False).variance_threshold
        if is_write_permitted(request.user.email):
            # getting the path of app1,app2,je source files
            file_location = get_backup_file_path(recon_id)

            report_type = 'variance'
            # adding the path of report files
            file_location+=run_export_report("*", recon_id, variance, report_type)['file_location']
            
            xml_file_loc =os.path.join(settings.MEDIA_ROOT,str(recon_id) + "\\export\\" )
            # if linux create xml file and set permissions        
            create_file_with_permission(os.path.join(xml_file_loc,'recon.xml'))        
            sp_export_recon = call_sp_params('fileservice.sp_export_recon', [recon_id,xml_file_loc], 2)
            
            if(sp_export_recon['status']==200):
                # print('filecreated')
                # adding the recon meta data xml to zip path
                file_location.append(os.path.join(xml_file_loc,'recon.xml'))

            # zipping the archived files        

            zpath = os.path.join(settings.MEDIA_ROOT, str(recon_id) + "backup.zip")

            with zipfile.ZipFile(zpath, 'w') as my_zip:
                file_paths = file_location
                for file in file_paths:
                    my_zip.write(file, os.path.basename(file))

            zpath = os.path.join(settings.MEDIA_ROOT, str(recon_id) + "backup.zip")
            zip_file = open(zpath, 'rb')

            response = HttpResponse(zip_file.read(), content_type='application/zip')
            response['Content-Disposition'] = f'attachment; filename= {str(recon_id)}_Backup.zip'
            response['Access-Control-Expose-Headers'] = 'Content-Disposition'

            user_logger.info("Backup recon files",extra=log_context)
            log_context["time_taken"]=int(time.time()-start_time)
            logger.info(" Backup_recon_files function execution ends",extra=log_context)
            return response
        else:
            response = {
                'status': 6002,
                'message': 'Un-authorized action detected!'
            }

        if response.get("status")!=200:
            logger.error(response,extra=log_context)

        log_context["time_taken"]=int(time.time()-start_time)
        logger.info("Backup_recon_files function execution ends",extra=log_context)

        return Response(response, status=status.HTTP_200_OK)

    except Exception as e:
        log_context["variable_state"]=locals()
        logger.error(f" Exception occured in backup_recon_files : {str(e)}",exc_info=1,extra=log_context)
        raise e

@api_view(['PUT'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
@parser_classes((MultiPartParser, FormParser))
def import_backup(request):
    try :
        start_time = time.time()
        log_context = {
            "recon_id": request.data['recon_id'],
            "request_id": request.request_id,
            "user_email": request.user.email,
            "request_url": request.path,
        }
        logger.info("Import_backup function execution start",extra=log_context)

        # Getting the data from request
        recon_id = request.data['recon_id']    
        file_obj = request.FILES['backup_file']
        username = request.user.username

        if is_write_permitted(request.user.email):
            if not is_recon_signed(recon_id) :
                if recon_id != '' and Recon.objects.filter(recon_id=recon_id, is_deleted=False).exists():
                    # Storing zip file
                    save_file = store_file(recon_id, file_obj)
                    file_path = save_file[1]

                    is_valid = validate_zip(file_path)
                    if is_valid['status'] == 200:
                        # Getting file data
                        storage_path = os.path.join(settings.MEDIA_ROOT,str(recon_id))
                        with zipfile.ZipFile(file_path,'r') as zf:                        
                            for name in zf.namelist():
                                    is_valid_content = validate_zip_content(name)
                                    if(is_valid_content['status']==200):
                                        zf.extract(name,storage_path)
                                        file_name = os.path.join(storage_path,name)                                    
                                        if(file_name.endswith('.xml')):
                                            # print('is xml')
                                            query_xml = """insert into fileservice.track_file_load_status(file_location,file_name,created_date)
                                                        select '"""+storage_path+'\\'+"""' as file_location,
                                                        'recon.xml' as file_name,
                                                        now()::timestamp as created_date
                                                        returning file_id;"""                                    
                                            cursor = connections['Recon'].cursor()
                                            cursor.execute(query_xml)
                                            cursor = cursor.fetchone()[0]
                                            # print(cursor)
                                            # calling stored procedure for create xml
                                            res= call_sp_params('fileservice.sp_import_recon', [cursor,username], 2)                
                                            # print(res)
                                        # else:
                                            # print('non xml')    
                                            
                                    # else:
                                        # print(is_valid_content['message'])     
                                    # file_data= zf.read(name)
                                    # print(file_data)
                            # call stored procedures in order        
                                    
                            response_data = {'status':200,'message': zf.namelist()}

                            user_logger.info("imported the backup ",extra=log_context)
                            log_context["time_taken"]=int(time.time()-start_time)
                            logger.info(" Import backup function execution ends",extra=log_context)

                    else:
                        response_data = is_valid
                else:
                    response_data = {
                        'status': 403,
                        'message': 'No recon found with the specified id!'
                    }
            else:
                response_data = {
                        'status': 403,
                        'message': 'This Recon is Signed Off'
                    }        
        else:
            response_data = {
                'status': 6002,
                'message': 'Un-authorized action detected!'
            }
        if response_data.get("status")!=200:
            logger.error(response_data,extra=log_context)

        log_context["time_taken"]=int(time.time()-start_time)
        logger.info("Import_backup function execution ends",extra=log_context)

        return Response(response_data, status=status.HTTP_200_OK)

    except Exception as e:
        log_context["variable_state"]=locals()
        logger.error(f" Exception occured in import_backup : {str(e)}",exc_info=1,extra=log_context)
        raise e

# create a copy of recon
@api_view(['POST'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def create_copy_of_recon(request):
    try:
        start_time = time.time()
        log_context = {
            "recon_id": request.data['recon_id'],
            "request_id": request.request_id,
            "user_email": request.user.email,
            "request_url": request.path,
            "event_stage": 'Runreport'
        }
        logger.info("Create_copy_of_recon function execution start",extra=log_context)

        # Getting the data from request
        old_recon_id = request.data['recon_id']
        new_recon_name = request.data['recon_name']
        created_by = request.user.username
        current_time = datetime.now().time().strftime("%H:%M:%S")
        current_date = datetime.now().strftime("%Y-%m-%d")
        created_date = str(current_date) + ' ' + str(current_time)
        old_recon = Recon.objects.get(recon_id=old_recon_id)

        if is_write_permitted(request.user.email):
            #check whether the original recon complete till run report
            if old_recon.status == "Reporting":
                
            # if not is_recon_signed(old_recon_id) :
                # checking if original recon exist
                if old_recon_id != '' and Recon.objects.filter(recon_id=old_recon_id, is_deleted=False).exists():
                    serialized = ReconSerializer(data=request.data)
                    
                
                    if serialized.is_valid():
                            old_recon_variance_threshold = Recon.objects.filter(recon_id=old_recon_id, is_deleted=False)[0].variance_threshold
                            new_recon = Recon(name=new_recon_name, created_by=created_by,
                                            created_date=created_date,variance_threshold=old_recon_variance_threshold)
                            new_recon.save()
                            new_recon_id = new_recon.recon_id
                            # executing stored procedure to replecate recon
                            res = call_sp_params('fileservice.sp_replicate_recon', [int(old_recon_id) , int(new_recon_id), created_by], 3)
                        
                            if res['status'] != 200:
                                response_data = {
                                    'status': res['status'],
                                    'message': res['message']
                                }
                                return Response(response_data, status=status.HTTP_200_OK)
                            
                            srcFilePath = os.path.join(settings.MEDIA_ROOT, str(old_recon_id))
                            dstFilePath = os.path.join(settings.MEDIA_ROOT, str(new_recon_id))
                            resp = create_duplicate_recon_file(srcFilePath,dstFilePath,str(old_recon_id),str(new_recon_id))
                            if resp['status'] == 200:
                                # Get the recon info
                                instance = Recon.objects.filter(recon_id=new_recon_id)[0]
                                serialized = ReconGetSerializer(instance)
                                response_data = {
                                    'status': resp['status'],
                                    'data': serialized.data,
                                    'message': resp['message']
                                }
                            else:
                                response_data = {
                                    'status': resp['status'],
                                    'message': resp['message']
                                }
                    else:

                        return Response(serialized.errors, status=status.HTTP_400_BAD_REQUEST)
                    
                else:
                    response_data = {
                        'status': 403,
                        'message': 'No recon found with the specified id!'
                    }
            else:
                response_data = {
                    'status': 500,
                    'message': 'you need to complete till run report'
                }
                logger.error("you need to complete till run report",extra=log_context)
                log_context["time_taken"]=int(time.time()-start_time)
                logger.info(" Create_copy_of_recon function execution ends",extra=log_context)

                return Response(response_data, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
                
            # else:
            #     response_data = {
            #             'status': 403,
            #             'message': 'This Recon is Signed Off'
            #         }        
        else:
            response_data = {
                'status': 6002,
                'message': 'Un-authorized action detected!'
            }

        if response_data.get("status")==200:
            user_logger.info("Created the copy of recon",extra=log_context)
        
        else:
            logger.error(response_data,extra=log_context)
        log_context["time_taken"]=int(time.time()-start_time)
        logger.info(" Create_copy_of_recon function execution ends",extra=log_context)

        return Response(response_data, status=status.HTTP_200_OK)

    except Exception as e:
        log_context["variable_state"]=locals()
        logger.error(f" Exception occured in create_copy_of_recon : {str(e)}",exc_info=1,extra=log_context)
        raise e

@api_view(['POST'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def drill_down(request):

    try:
        recon_id =str(json.loads(request.body)["recon_id"])
        start_time = time.time()
        log_context = {
            "recon_id": recon_id,
            "request_id": request.request_id,
            "user_email": request.user.email,
            "request_url": request.path,
            "event_stage": 'Runreport'
        }
        logger.info("drill_down function execution start",extra=log_context)

        #prepearing the input data from the payload
        request_data = json.loads(request.body)
        recon_id=recon_id
        dimension_members:dict = request_data["dimension_members"]
        year_period = request_data.get("year_period")
        members=list(map(str.upper,dimension_members.values()))
        members.append(year_period)
        cursor=None

        if not year_period:
            response_data ={"data":" year_period is mandatory","status":400}
            logger.error(response_data,extra=log_context)
            log_context["time_taken"]=int(time.time()-start_time)
            logger.info(" drill_down function execution ends",extra=log_context)

            return Response(response_data,status=400)

    
        result = get_drill_down(dimension_members,members,recon_id)

        response_data={"data":result,"status":200}
        user_logger.info("drilldowned for the specific year",extra=log_context)
        log_context["time_taken"]=int(time.time()-start_time)
        logger.info(" drill_down function execution ends",extra=log_context)
       
        return Response(response_data)
    
    except Exception as e:
        raise e
    
    


@api_view(['POST'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def drill_down_export(request):

    try:
        recon_id =str(json.loads(request.body)["recon_id"])
        start_time = time.time()
        log_context = {
            "recon_id": recon_id,
            "request_id": request.request_id,
            "user_email": request.user.email,
            "request_url": request.path,
            "event_stage": 'Runreport'
        }
        logger.info("drill_down_export function execution start",extra=log_context)

        #prepearing the input data from the payload
        request_data = json.loads(request.body)
        recon_id=recon_id
        dimension_members:dict = request_data["dimension_members"]
        year_period = request_data.get("year_period")
        members=list(map(str.upper,dimension_members.values()))
        members.append(year_period)
        cursor=None

        if not year_period:
            response_data ={"data":" year_period is mandatory","status":400}
            logger.error(response_data,extra=log_context)
            log_context["time_taken"]=int(time.time()-start_time)
            logger.info(" drill_down_export function execution ends",extra=log_context)

            return Response(response_data,status=400)
        
        result = get_drill_down(dimension_members,members,recon_id)
        dataframe = pd.DataFrame(data=result)
        file_name=f"{uuid.uuid4()}_drill_down.csv"
        file_path=os.path.join(settings.MEDIA_ROOT,recon_id,file_name)
        dataframe.to_csv(file_path,index=False)
        if os.path.exists(file_path):
            with open(file_path, 'rb') as fh:
                            response = HttpResponse(fh.read(), content_type="text/csv")
                            response['Content-Disposition'] = 'inline; filename= drill_down.csv'
                            response['Access-Control-Expose-Headers'] = 'Content-Disposition'

                            user_logger.info("exported the drilldown",extra=log_context)
                            log_context["time_taken"]=int(time.time()-start_time)
                            logger.info(" drill_down_export function execution ends",extra=log_context)
                            return response

        else:
            response_data={"data":"No Data for particular drill or File not created ","status":204}
            logger.error(response_data,extra=log_context)
            log_context["time_taken"]=int(time.time()-start_time)
            logger.info(" drill_down_export function execution ends",extra=log_context)
       
        return Response(response_data)
    
    except Exception as e:
        raise e
    




@api_view(['GET'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def check_report_exists(request,recon_id):
    try :
        start_time = time.time()
        log_context = {
            "recon_id": recon_id,
            "request_id": request.request_id,
            "user_email": request.user.email,
            "request_url": request.path,
        }
        logger.info("check_report_exists function execution start",extra=log_context)

        check_kickout = view_kickout('fileservice', 'view_bridge_' + str(recon_id) + '_kickout', recon_id)
        if check_kickout['status'] == 200:
            run_report = True
        else:
            run_report = False

        cursor = connections['Recon'].cursor()
        query = "SELECT table_name FROM information_schema.tables WHERE table_name like 'report%' or table_name like 'final%';"   
        cursor.execute(query)
        data = cursor.fetchall()
        report_table_name = f'report_{recon_id}' ,
        final_report_table_name = f'final_report_{recon_id}' ,
        je_report_table_name = f'report_je_{recon_id}' ,

        if report_table_name in data or final_report_table_name in data or je_report_table_name in data:
            call_sp = False
        else:
            call_sp = True

        response_data = {
            'status': 200,
            'call_sp': call_sp,
            'run_report': run_report
        }

        log_context["time_taken"]=int(time.time()-start_time)
        logger.info(" check_report_exists function execution ends",extra=log_context)

        return Response(response_data, status=status.HTTP_200_OK)

    except Exception as e:
        log_context["variable_state"]=locals()
        logger.error(f" Exception occured in check_report_exists : {str(e)}",exc_info=1,extra=log_context)
        raise e
    
  