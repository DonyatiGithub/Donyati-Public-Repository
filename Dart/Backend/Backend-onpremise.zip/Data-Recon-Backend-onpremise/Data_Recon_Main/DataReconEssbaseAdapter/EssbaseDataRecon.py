
# def writeToDestFileFloat(val, OutputFile):
#   OutputFile.write(str(val)+"\t")

# def writeToDestFile(msgString, end, OutputFile):
#   OutputFile.write(msgString.replace("\t","").replace("\n",""))
#   if "\t" in str(msgString) or "\t" in end:
#     OutputFile.write("\t")
#   if "\n" in msgString or "\n" in end:
#     OutputFile.write("\n")
#   return

# def getTupleArray(mem):

#   returnArray = []
#   for i in range(len(mem)-1):
#     returnArray.append(mem[i].getName())
#   returnArray.append(mem[len(mem)-1].getName())
#   returnTuple = tuple(returnArray)
#   return returnTuple

# """Print columns vertical so it works in SmartView
# However for data recon tool we will put the member
# names surrounded by square brackets with a comma 
# between them"""
# def printTupleVertical(mem, OutputFile):
#   needComma = False
#   for i in range(len(mem)-1):
#     if (needComma):
#       writeToDestFile(",","",OutputFile)
#     needComma = True
#     writeToDestFile("["+mem[i].getName()+"]","", OutputFile)

#   writeToDestFile("["+mem[len(mem)-1].getName()+"]","", OutputFile)

# def printTupleHorizontal(mem, OutputFile):
#   for i in range(len(mem)-1):
#     writeToDestFile(mem[i].getName() + "\t","",OutputFile)
#   writeToDestFile(mem[len(mem)-1].getName() + "\t","",OutputFile)

# def printMdDataSetInGridForm_Rows_Columns(mddata, columnAxis, rowAxis, pageNum, OutputFile):
#   cols = columnAxis.getTupleCount()
#   rows = rowAxis.getTupleCount()
#   if (cols <= 0 or rows <= 0):
#     writeToDestFile ("This Sample has limited support for printing this MDX result in Grid form " + "because this has "+str(cols)+" columns & "+str(rows)+" rows.", "", OutputFile)
#     writeToDestFile ("Note: If there no rows and 'n' number of columns, you can still print result in table format by modifying this sample code.", "", OutputFile)

#   mem = rowAxis.getAllTupleMembers(0)

#   rowIndexArray = []
#   colIndexArray = []

#   colDims = columnAxis.getAllDimensions()
#   rowDims = rowAxis.getAllDimensions()

#   colNames = []

#   for i in range(len(colDims)):
#     colNames.append(colDims[i].getName())

#   rowNames = []
#   for i in range(len(rowDims)):
#     rowNames.append(rowDims[i].getName())
    
  
#   for i in range(len(mem)):
#     writeToDestFile(rowNames[i],"\t", OutputFile)

#   for j in range(cols):
#     mem = columnAxis.getAllTupleMembers(j)
#     #Don't output column headers for recon
#     printTupleVertical(mem, OutputFile)
#     colIndexArray.append(getTupleArray(mem))
#   writeToDestFile("\n", "", OutputFile)

#   k = pageNum * cols * rows
#   for i in range(int(rows)):
#     mem = rowAxis.getAllTupleMembers(i)
#     printTupleHorizontal(mem, OutputFile)
#     rowIndexArray.append(getTupleArray(mem))

#     for j in range(int(cols)):
#       if (mddata.isMissingCell(k)):
#         writeToDestFileFloat(0.0, OutputFile)
#       elif (mddata.isNoAccessCell(k)):
#         writeToDestFile("#NoAccess\t","", OutputFile)
#       else:
#         val = mddata.getCellValue(k)
#         #writeToDestFile(float(val),end="\t")
#         writeToDestFileFloat(val, OutputFile)
#       k += 1

#     writeToDestFile("\n","", OutputFile)


# """ Prints the MDX result in a Grid form (separator used is tab char)
# * This example handles any result set having only
# * a ROW and COLUMN axis
# """
# def printMdDataSetInGridForm(mddata, OutputFile):

#   axes = mddata.getAllAxes()

#   slicerOrPovAxis = None
#   columnAxis = None
#   rowAxis = None
#   pageAxis = None

#   # If slicer axis is present then it will be 1st axis.
#   axisIndex = 0
#   if (axes[axisIndex].isSlicerAxis()):
#     slicerOrPovAxis = axes[axisIndex]
#     axisIndex += 1

#   columnAxis = axes[axisIndex]
#   axisIndex += 1

#   # Check if row axis are part of result...
#   if (axisIndex < len(axes)):
#     rowAxis = axes[axisIndex]
#     axisIndex += 1

#   # Check if page axis are part of result...
#   if (axisIndex < len(axes)):
#     pageAxis = axes[axisIndex]

#   #if (slicerOrPovAxis != None):
#   #  mem = slicerOrPovAxis.getAllTupleMembers(0)
#   #  sTuple = "("
#   #  for i in range(len(mem)-1):
#   #    sTuple += "[" + mem[i].getName() + "], "
#   #  sTuple += "[" + mem[len(mem)-1].getName() + "])"
#   #  #leave out Slicer (POV) Tuple for data recon tool
#   #  #writeToDestFile("Slicer(POV) Tuple: " + sTuple,end="",OutputFile)

#   """  if (pageAxis != None):
#     # Identify #of Pages, i.e., #of Tupes in PageAxis. For every Page,
#     # print the Grid belonging to that page.

#     for i in range(pageAxis.getTupleCount()):
#       # Print Page Header.
#       pageHeader = "------- PAGE " + str(i) + ", Tuple: ("
#       pageFooter = "------- PAGE " + str(i) + " ends -------"
#       mem = pageAxis.getAllTupleMembers(i)
#       for j in range(len(mem)-1):
#         pageHeader += "[" + mem[j].getName() + "], "

#       pageHeader += "[" + mem[len(mem)-1].getName() + "]) --------"

#       #writeToDestFile(pageHeader+"\n",end="")
#       printMdDataSetInGridForm_Rows_Columns(mddata, columnAxis, rowAxis, i)
#       #writeToDestFile(pageFooter+"\n",end="")
#   elif (rowAxis != None):
# """
#   if (rowAxis != None):
#     printMdDataSetInGridForm_Rows_Columns(mddata, columnAxis, rowAxis, 0, OutputFile)

# def CustomTabDelimetedReportMDX(mdxquery, EssbaseServerName, EssbaseProviderServicesURL, Py4jServerName, Py4jPortNumber, EssbaseUserName, EssbasePassword, EssbaseApplicationName, EssbaseDatabaseName, OutputFilePath):

#   from py4j.java_gateway import JavaGateway
#   from py4j.java_gateway import GatewayParameters


#   gateway = JavaGateway(gateway_parameters=GatewayParameters(address=Py4jServerName, port=Py4jPortNumber))

#   ess = gateway.createIEssbase()


#   dom = ess.signOn(EssbaseUserName, EssbasePassword, False, None, EssbaseProviderServicesURL)
#   cv = dom.openCubeView("Mdx Query Example", EssbaseServerName, EssbaseApplicationName, EssbaseDatabaseName)

#   bDataLess = False
#   bNeedCellAttributes = False
#   bHideData = True

#   op = cv.createIEssOpMdxQuery()




#   op.setQuery(bDataLess, bHideData, mdxquery, bNeedCellAttributes, op.getMemberIdentifierType().fromString("NAME"))

#   op.setXMLAMode(False)


#   op.setNeedFormattedCellValue(True)
#   op.setNeedSmartlistName(True)
#   op.setNeedFormatString(False)
#   op.setNeedFormattedMissingCells(True)

#   op.setNeedMeaninglessCells(False)

#   cv.performOperation(op)

#   mddata = cv.getMdDataSet()

#   OutputFile = open(OutputFilePath, "w")
  
#   printMdDataSetInGridForm(mddata, OutputFile)
  
#   OutputFile.close()

#   ess.signOff()

