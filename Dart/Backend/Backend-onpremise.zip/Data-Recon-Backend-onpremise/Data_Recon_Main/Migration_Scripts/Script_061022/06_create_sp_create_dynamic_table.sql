CREATE OR REPLACE PROCEDURE fileService.sp_create_dynamic_table(
	in recon_app_id integer
)
LANGUAGE 'plpgsql'
AS $BODY$
DECLARE
var_app_id integer := recon_app_id;
var_script varchar := ''; 
var_dim_name text := '';
v_dim_name_rec record;
var_table_rec record;
s_schema_name text := 'fileservice';
begin
	
-- If the recon application id exists, then fetch it's corresponding dimensions
if
		exists(select count(*) from fileservice.recon_dimensions rd where rd.recon_app_id = var_app_id)
	then
--		raise notice '1';
	
		select concat(string_agg(dim,', '),', file_name character varying COLLATE pg_catalog."default", file_id integer')
		into var_dim_name
		from (
			select concat(dim,' character varying COLLATE pg_catalog."default"') as dim
			from (
				select rd.dimension as dim
				from fileservice.recon_dimensions rd
				where rd.recon_app_id = var_app_id
				order by rd.dimensions_id
			) q1
		) q2;
--		raise notice '%', var_dim_name;
		
	-- Preparation of the create table script
		select concat('app_',r.recon_id,'_',var_app_id) as table_name, r.recon_id as rec_id 
		into var_table_rec
		from fileservice.recon r 
		where r.app1_id = var_app_id
		or r.app2_id = var_app_id;
		
		var_script = 'Drop table if exists '||s_schema_name||'.'||var_table_rec.table_name||' cascade;';
		var_script = var_script ||' Create table if not exists '||s_schema_name||'.'||var_table_rec.table_name||' ( app_id integer null default '||var_app_id||', '||var_dim_name||' ) TABLESPACE tbsp_data_recon;';
		
	-- Adding permissions to the table
		var_script = var_script ||' GRANT ALL ON TABLE '||s_schema_name||'.'||var_table_rec.table_name||' TO postgres;';
		var_script = var_script ||' GRANT DELETE, UPDATE, INSERT, SELECT ON TABLE '||s_schema_name||'.'||var_table_rec.table_name||' TO "user_dataRecon_file";';
	
--		raise notice '%',var_script;
	
	-- Run create table script
	execute var_script;

	-- Log Script
	call fileService.sp_log_entry(
								var_app_id::integer,
								'''Table created'''::text,
								var_table_rec.rec_id::integer,
								var_table_rec.table_name::text
								);
	
	end if;	

END
$BODY$;
