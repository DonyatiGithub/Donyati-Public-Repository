ALTER TABLE fileservice.recon ALTER COLUMN variance_threshold TYPE decimal USING variance_threshold::decimal;
ALTER TABLE fileservice.recon ALTER COLUMN variance_threshold SET DEFAULT 0;
