"""Data_Recon_Main URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.conf.urls import include
from django.conf import settings
from django.conf.urls.static import static
from django.urls import path

urlpatterns = [
    path('admin/', admin.site.urls),
    path('user/', include('Data_Recon_App.authService.urls'), name='api_v1_auth'),
    path('recon/', include('Data_Recon_App.reconService.urls'), name='api_v1_recon'),
    path('bridge/', include('Data_Recon_App.bridgeService.urls'), name='api_v1_bridge'),
    path('source/', include('Data_Recon_App.runImportService.urls'), name='api_v1_source'),
    path('transformation/', include('Data_Recon_App.transformationService.urls'), name='api_v1_transformation'),
    path('report/', include('Data_Recon_App.runReportService.urls'), name='api_v1_run_report'),
    path('general/', include('Data_Recon_App.userService.urls'), name='api_v1_user_service'),
    path('maintenance/', include('Data_Recon_App.maintenanceService.urls'), name='api_v1_maintenance'),
    path('',include('Data_Recon_App.LogService.urls'),name='api_v1_maintenance')
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
