 #!/bin/bash

 cd "$(dirname "$0")"

 export CLASSPATH=./DataReconEssbaseAdapter.jar:./ess_es_server.jar:./ess_japi.jar:./py4j0.10.9.7.jar

 java donyati.recon.adapter.EssbaseAdapter 127.0.0.1 >EssbaseAdapter.log 2>&1 &

