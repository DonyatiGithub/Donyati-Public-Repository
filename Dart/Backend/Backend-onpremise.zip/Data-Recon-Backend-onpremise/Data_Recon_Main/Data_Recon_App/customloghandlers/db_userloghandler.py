import logging
import json

def safe_dumps(obj):
    captured_vars = {}
    for var_name, var_value in obj.items():
        try:
            # Try to serialize the variable as is
            captured_vars[var_name] =(json.dumps(var_value),str(type(var_value)))
        except TypeError:
            # Handle non-serializable objects (e.g., dates, custom objects)
            captured_vars[var_name] = (str(var_value),str(type(var_value)))
    return captured_vars

class UserlogHandler(logging.Handler):
    def emit(self, record):
        from ..models import LogEntry
        try:
            # You can customize the handling of log records here
            log_message = self.format(record)            
            # Add your custom logic to store or process the log message
            # Example: Store logs in a database, send them to a service, etc.
            log_context = record.__dict__
            processed_var ={}
            if log_context.get("variable_state"):
                if log_context["variable_state"].get("log_context"):
                    del log_context["variable_state"]["log_context"]
                processed_var = safe_dumps(log_context["variable_state"])
                if log_context.get("exc_text"):
                    processed_var["exception_location"]=log_context["exc_text"]
            
            if processed_var=={}:
                processed_var =None

            time_taken =None
            if log_context.get("time_taken"):
                time_taken =str(log_context["time_taken"])

            
            
            
            values= {
                "recon_id":log_context.get("recon_id"),
                "request_id":log_context.get("request_id"),
                "log_name":log_context["name"],
                "logging_level":log_context["levelname"],
                "message":log_context["msg"],
                "user_email":log_context.get("user_email"),
                "time_taken":time_taken,
                "variable_state": processed_var,
                "request_url":log_context.get("request_url"),
                "event_stage":log_context.get("event_stage")
            }
            log_record = LogEntry(**values)
            log_record.save()
            

            
        except Exception as e:
            raise e
            self.handleError(record)