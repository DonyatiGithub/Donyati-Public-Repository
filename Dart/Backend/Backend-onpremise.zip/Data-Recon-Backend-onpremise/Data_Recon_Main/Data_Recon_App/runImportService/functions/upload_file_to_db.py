from ...models import Recon, TrackFileLoadStatus, ReconUser, ReconApplications
from ...utils.get_recon import get_recon
from ...utils.pgsql_conn import call_sp_params
from .is_import_valid import is_import_valid
from .get_view_data import get_view_data
from .is_exists import is_exists
from ...utils.user_permissions import is_write_permitted
from django.conf import settings


def upload_to_db(request, file_names):
    recon_id = request.data['recon_id']
    app_type = request.data['appType']
    app_type = str(app_type)

    max_rows = int(request.data['max_rows'])
    page_number = int(request.data['page_number'])
    start_point = (page_number - 1) * max_rows
    end_point = page_number * max_rows

    recon_data = get_recon(recon_id)
    recon_name = recon_data['name']
    app1_id = recon_data['app1_id']
    app2_id = recon_data['app2_id']
    app_id = recon_data['app1_id'] if app_type == '0' else recon_data['app2_id']
    inverse_app_id = recon_data['app2_id'] if app_type == '0' else recon_data['app1_id']

    if is_write_permitted(request.user.email):

        for i in range(len(file_names)):
            file = file_names[i]
            filepath = str(settings.MEDIA_ROOT + "/" + str(recon_id) + "/" + file)
            file_location = filepath.replace(file, '')

            # Validating all the pre-requisites
            is_valid = is_import_valid(recon_id, app_type, filepath)

            if is_valid['status'] == 200:
                # Calling the dynamic table create SP
                create_dtable = call_sp_params('fileService.sp_create_dynamic_table', [app_id, False], 2)
                table_exists = is_exists('fileservice', 'app_' + str(recon_id) + '_' + str(inverse_app_id))

                # Check if table exists for other app
                if not table_exists['rows'][0]['exists']:
                    call_sp_params('fileService.sp_create_dynamic_table', [inverse_app_id, False], 2)

                if create_dtable['status'] == 200:
                    # Saving the file details in DB
                    file_load = TrackFileLoadStatus(recon_id=recon_id, app_id=app_id,
                                                    file_location=file_location, file_name=file,
                                                    uploaded_by=request.user.email,is_je_file=False,file_type="app")
                    file_load.save()

                    # Calling the load data SP
                    load_data = call_sp_params('fileService.sp_load_dynamic_table', [app_id, False], 2)

                    if load_data['status'] == 200:
                        create_view = call_sp_params('fileService.sp_create_recon_app_view', [recon_id, False], 2)
                        if create_view['status'] == 200:
                            view_query = 'SELECT * FROM fileService.view_' + str(recon_id) + \
                                         ' WHERE app_id=' + str(app_id) + ' LIMIT ' + str(end_point) + \
                                         ' OFFSET ' + str(start_point)
                            response_data = get_view_data(view_query, app1_id, app2_id)
                        else:
                            response_data = create_view
                    else:
                        response_data = load_data
                else:
                    response_data = create_dtable
            else:
                response_data = is_valid
    else:
        response_data = {
            'status': 6002,
            'message': 'Un-authorized action detected!'
        }
    return response_data
