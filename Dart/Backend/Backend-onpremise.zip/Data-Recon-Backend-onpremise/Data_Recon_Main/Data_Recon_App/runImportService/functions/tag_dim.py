from ...models import ReconDimensions
import pandas as pd
from ..serializers import DimensionNameSerializer
from collections import OrderedDict


def tag_dim(recon_id, filepath, headers, app_type):
    app_instance = ReconDimensions.objects.filter(is_deleted=False, recon_id=recon_id, app_type=app_type,
                                                  dim_in_file='YES', is_active=True)
    app_serialized = DimensionNameSerializer(app_instance, many=True)

    for dim in app_serialized.data:
        dim['type_field'] = int(dim['type_field'])  # Converting type_field to integer

    srt = sorted(app_serialized.data, key=lambda x: x['type_field'])  # sorting ordered dictionary based on the type_field value

    ordered_dimensions = [x['dimension'] for x in srt]  # adding only the dimensions in a variable

    df = pd.read_csv(filepath)
    df.columns = headers  # Replace the headers

    if 'Not Applicable' in headers:
        df = df.drop('NOT APPLICABLE', axis=1)  # Dropping the columns with the string Not Applicable

    df = df.loc[:, ordered_dimensions]

    # Changing year from FY to 20
    # if 'YEAR' in df.columns:
    #     yr = 'YEAR'
    # else:
    #     yr = 'YEARS'
    #
    # df[yr] = df[yr].str[2:].apply(lambda x: '20' + x).str.replace('FY', 'new')

    df.to_csv(filepath, index=False)