from django.http import HttpResponse
from rest_framework import status
from rest_framework.decorators import permission_classes, api_view, renderer_classes, parser_classes
from rest_framework.parsers import MultiPartParser, FormParser

from ..bridgeService.functions.add_dim_name import generic_dim_add
from ..utils.store_file import store_file
from rest_framework.permissions import IsAuthenticated
from rest_framework.renderers import JSONRenderer
from rest_framework.response import Response
from ..models import Recon, ReconTransformationOverride, ReconTransformation, ReconDimensions
from .functions.update_recon_trans import update_recon_trans
from .functions.get_transformations import get_transformations
from .functions.combine_sync_comb import combine_sync_comb
from .functions.update_tfn_sync import update_tfn_sync
from .functions.combine_sync_list import combine_sync_list
from .functions.export_sync_data import export_sync_data
from ..bridgeService.functions.is_valid_file import is_valid_file
from .functions.get_import_sync import get_import_sync
from .functions.execute_trans import execute_trans
from .functions.export_trans_run import export_trans_run
import datetime
from ..utils.user_permissions import is_write_permitted
from ..utils.is_signed import is_recon_signed
from ..utils.run_export_script import run_export_script
from django.conf import settings
import pandas as pd
import os
from django.db import connections
from ..utils.export_query import run_trans_export_query
from .functions.sync_combinations import sync_combinations
import logging
import time
from ..bridgeService.functions.get_disk_space import get_disk_space
from ..runImportService.functions.is_exists import view_kickout
from ..maintenanceService.functions.update_config import get_diskspace_thresh

user_logger = logging.getLogger("userlog")
# use this user_logger to log user log 
logger = logging.getLogger("techlog")
# use 'logger' to for general application log


@api_view(['GET'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def get_transformation(request, recon_id):
    # Checking if recon exists or not deleted
    try :
        start_time = time.time()
        log_context = {
            "recon_id": recon_id,
            "request_id": request.request_id,
            "user_email": request.user.email,
            "request_url": request.path,
            "event_stage": 'Transformation'
        }
        logger.info("Get_transformation function execution start",extra=log_context)

        if recon_id != '' and Recon.objects.filter(recon_id=recon_id, is_deleted=False).exists():
            source_data = get_transformations(recon_id)
            response_data = generic_dim_add(
                recon_id, source_data, 'rows', [{'key_id': 'app1_dimension_id', 'key_value': 'app_01'},
                                                {'key_id': 'app2_dimension_id', 'key_value': 'app_02'}],
                {'app1_dimension_id': 'app1_dim_name', 'app2_dimension_id': 'app2_dim_name'})
        else:
            response_data = {
                'status': 403,
                'message': 'No recon found with the specified id!'
            }

        log_context["time_taken"]=int(time.time()-start_time)
        logger.info("Get_transformation function execution ends",extra=log_context)

        return Response(response_data, status=status.HTTP_200_OK)
        
    except Exception as e:
        log_context["variable_state"]=locals()
        logger.error(f" Exception occured in get_transformation : {str(e)}",exc_info=1,extra=log_context)
        raise e



@api_view(['PUT'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def update_transformation(request):
    try:
        start_time = time.time()
        log_context = {
            "recon_id": request.data['recon_id'],
            "request_id": request.request_id,
            "user_email": request.user.email,
            "request_url": request.path,
            "event_stage": 'Transformation'
        }
        logger.info("Update_transformation function execution start",extra=log_context)

        # Getting the data from request
        recon_id = request.data['recon_id']
        trans_rows = request.data['rows']

        if is_write_permitted(request.user.email):
            if not is_recon_signed(recon_id) :
                # Checking if recon exists or not deleted
                if recon_id != '' and Recon.objects.filter(recon_id=recon_id, is_deleted=False).exists():
                    response_data = update_recon_trans(recon_id, trans_rows)
                else:
                    response_data = {
                        'status': 403,
                        'message': 'No recon found with the specified id!'
                    }
            else:
                response_data = {
                        'status': 403,
                        'message': 'This Recon is Signed Off'
                }        
        else:
            response_data = {
                'status': 6002,
                'message': 'Un-authorized action detected!'
            }

        if response_data.get("status")==200:
            user_logger.info("Updated the tranformation",extra=log_context)
        
        else:
            logger.error(response_data,extra=log_context)
        log_context["time_taken"]=int(time.time()-start_time)
        logger.info(" Update_transformation function execution ends",extra=log_context)

        return Response(response_data, status=status.HTTP_200_OK)
        
    except Exception as e:
        log_context["variable_state"]=locals()
        logger.error(f" Exception occured in update_transformation : {str(e)}",exc_info=1,extra=log_context)
        raise e



@api_view(['GET'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def get_sync_combinations(request, recon_id):
    # Checking if recon exists or not deleted
    try :
        start_time = time.time()
        log_context = {
            "recon_id": recon_id,
            "request_id": request.request_id,
            "user_email": request.user.email,
            "request_url": request.path,
            "event_stage": 'Transformation'
        }
        logger.info("Get_sync_combinations function execution start",extra=log_context)

        if recon_id != '' and Recon.objects.filter(recon_id=recon_id, is_deleted=False).exists():
            response_data = combine_sync_comb(recon_id)
        else:
            response_data = {
                'status': 403,
                'message': 'No recon found with the specified id!'
            }
        
        if response_data.get("status")!=200:
            logger.error(response_data,extra=log_context)

        log_context["time_taken"]=int(time.time()-start_time)
        logger.info(" Get_sync_combinations function execution ends",extra=log_context)

        return Response(response_data, status=status.HTTP_200_OK)

    except Exception as e:
        log_context["variable_state"]=locals()
        logger.error(f" Exception occured in get_sync_combinations : {str(e)}",exc_info=1,extra=log_context)
        raise e


@api_view(['PUT'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def update_sync_mappings(request):
    try :
        start_time = time.time()
        log_context = {
            "recon_id": request.data['recon_id'],
            "request_id": request.request_id,
            "user_email": request.user.email,
            "request_url": request.path,
            "event_stage": 'Transformation'
        }
        logger.info("Update_sync_mappings function execution start",extra=log_context)

        # Getting the data from request
        recon_id = request.data['recon_id']
        app_type = request.data['app_type']
        sync_rows = request.data['rows']

        if is_write_permitted(request.user.email):
            if not is_recon_signed(recon_id) :
                # Checking if recon exists or not deleted
                if recon_id != '' and Recon.objects.filter(recon_id=recon_id, is_deleted=False).exists():
                    response_data = update_tfn_sync(recon_id, app_type, sync_rows)
                else:
                    response_data = {
                        'status': 403,
                        'message': 'No recon found with the specified id!'
                    }
            else:
                response_data = {
                        'status': 403,
                        'message': 'This Recon is Signed Off'
                }        
        else:
            response_data = {
                'status': 6002,
                'message': 'Un-authorized action detected!'
            }

        if response_data.get("status")==200:
            user_logger.info("Updated the sync mappings",extra=log_context)

        else:
            logger.error(response_data,extra=log_context)
        log_context["time_taken"]=int(time.time()-start_time)
        logger.info(" Update_sync_mappings function execution ends",extra=log_context)

        return Response(response_data, status=status.HTTP_200_OK)

    except Exception as e:
        log_context["variable_state"]=locals()
        logger.error(f" Exception occured in update_sync_mappings : {str(e)}",exc_info=1,extra=log_context)
        raise e


@api_view(['GET'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def get_tfn_sync(request, recon_id):
    try :
        start_time = time.time()
        log_context = {
            "recon_id": recon_id,
            "request_id": request.request_id,
            "user_email": request.user.email,
            "request_url": request.path,
            "event_stage": 'Transformation'
        }
        logger.info("Get_tfn_sync function execution start",extra=log_context)

        # Checking if recon exists or not deleted
        if recon_id != '' and Recon.objects.filter(recon_id=recon_id, is_deleted=False).exists():
            response_data = combine_sync_list(recon_id)
        else:
            response_data = {
                'status': 403,
                'message': 'No recon found with the specified id!'
            }

        if response_data.get("status")!=200:
            logger.error(response_data,extra=log_context)

        log_context["time_taken"]=int(time.time()-start_time)
        logger.info(" Get_tfn_sync function execution ends",extra=log_context)

        return Response(response_data, status=status.HTTP_200_OK)

    except Exception as e:
        log_context["variable_state"]=locals()
        logger.error(f" Exception occured in get_tfn_sync : {str(e)}",exc_info=1,extra=log_context)
        raise e


@api_view(['POST'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def sync_export(request):
    try :
        start_time = time.time()
        log_context = {
            "recon_id": request.data['recon_id'],
            "request_id": request.request_id,
            "user_email": request.user.email,
            "request_url": request.path,
            "event_stage": 'Transformation'
        }
        logger.info("Sync_export function execution start",extra=log_context)

        # Getting the data from request
        recon_id = request.data['recon_id']
        app_type = request.data['app_type']
        app_key = 'App1_' if app_type == '0' else 'App2_'

        if is_write_permitted(request.user.email):
            # if not is_recon_signed(recon_id) :
                if recon_id != '' and Recon.objects.filter(recon_id=recon_id, is_deleted=False).exists():
                    current_time = datetime.datetime.now().time().strftime("%H:%M:%S")
                    current_date = datetime.datetime.now().strftime("%Y-%m-%d")
                    modified_date = str(current_date) + '_' + str(current_time)
                    file_name = app_key + 'Sync_Mappings_Export' + modified_date + '.csv'
                    export_file = export_sync_data(recon_id, app_type)

                    # Setting the download response
                    response_data = HttpResponse(export_file.getvalue(), content_type='text/csv')
                    response_data['Content-Disposition'] = 'attachment; filename=' + file_name
                    response_data['Access-Control-Expose-Headers'] = 'Content-Disposition'

                    user_logger.info("Exported the sync",extra=log_context)
                    log_context["time_taken"]=int(time.time()-start_time)
                    logger.info(" Export sync function execution ends",extra=log_context)

                    return response_data
                else:
                    response_data = {
                        'status': 403,
                        'message': 'No recon found with the specified id!'
                    }
            # else:
            #     response_data = {
            #             'status': 403,
            #             'message': 'This Recon is Signed Off'
            #         }        
        else:
            response_data = {
                'status': 6002,
                'message': 'Un-authorized action detected!'
            }

        if response_data.get("status")!=200:
            logger.error(response_data,extra=log_context)

        log_context["time_taken"]=int(time.time()-start_time)
        logger.info(" Sync_export function execution ends",extra=log_context)

        return Response(response_data, status=status.HTTP_200_OK)

    except Exception as e:
        log_context["variable_state"]=locals()
        logger.error(f" Exception occured in sync_export : {str(e)}",exc_info=1,extra=log_context)
        raise e


@api_view(['PUT'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
@parser_classes((MultiPartParser, FormParser))
def import_sync(request):
    try :
        start_time = time.time()
        log_context = {
            "recon_id": request.data['recon_id'],
            "request_id": request.request_id,
            "user_email": request.user.email,
            "request_url": request.path,
            "event_stage": 'Transformation'
        }
        logger.info("Import_sync function execution start",extra=log_context)
        global counter

        # Getting the data from request
        recon_id = request.data['recon_id']
        app_type = request.data['app_type']
        file_obj = request.FILES['sync_file']

        if is_write_permitted(request.user.email):
            if not is_recon_signed(recon_id) :
                if recon_id != '' and Recon.objects.filter(recon_id=recon_id, is_deleted=False).exists():
                    # Storing file
                    save_file = store_file(recon_id, file_obj)
                    file_path = save_file[1]

                    is_valid = is_valid_file(file_path)
                    if is_valid['status'] == 200:

                        #Get the existing app_id details
                        tnf_id_count=list(ReconTransformationOverride.objects.filter(recon_id=recon_id).values_list('tfn_id',flat=True).distinct())
                        dim_ids = list(ReconTransformation.objects.filter(recon_id=recon_id, id__in=tnf_id_count).values_list('dim_id', flat=True))
                        existing_app_ids = list(ReconDimensions.objects.filter(dimensions_id__in=dim_ids).values_list('app_type', flat=True))
                        ex_count_0 = existing_app_ids.count('0')
                        ex_count_1 = existing_app_ids.count('1')

                        # Getting file data
                        response_data = get_import_sync(recon_id, app_type, file_path)

                        if response_data["status"] == 200:

                            #Get the updated app_id details
                            tnf_id_count=list(ReconTransformationOverride.objects.filter(recon_id=recon_id).values_list('tfn_id',flat=True).distinct())
                            dim_ids = list(ReconTransformation.objects.filter(recon_id=recon_id, id__in=tnf_id_count).values_list('dim_id', flat=True))
                            updated_app_ids = list(ReconDimensions.objects.filter(recon_id=recon_id, dimensions_id__in=dim_ids).values_list('app_type', flat=True))
                            updated_count_0 = updated_app_ids.count('0')
                            updated_count_1 = updated_app_ids.count('1')

                            #checks app1id and app2id are updated or not
                            if ex_count_0!=updated_count_0 or ex_count_1!=updated_count_1: 
                                if 'counter' not in globals():
                                    counter = 0  
                                counter += 1  

                            if counter == 2 and updated_count_0!=0 and updated_count_1!=0:
                                counter=0
                                response_data['call_sp'] = True
                            else:
                                response_data['call_sp'] = False

                    else:
                        response_data = is_valid
                else:
                    response_data = {
                        'status': 403,
                        'message': 'No recon found with the specified id!'
                    }
            else:
                response_data = {
                        'status': 403,
                        'message': 'This Recon is Signed Off'
                    }        
        else:
            response_data = {
                'status': 6002,
                'message': 'Un-authorized action detected!'
            }

        if response_data.get("status")==200:

            if get_diskspace_thresh()!="None":
                disk_usage = get_disk_space()
                if get_diskspace_thresh() == disk_usage:
                    response_data["disk_usage"] = disk_usage

            user_logger.info("Imported the sync",extra=log_context)

        else:
            logger.error(response_data,extra=log_context)
        log_context["time_taken"]=int(time.time()-start_time)
        logger.info(" Import_sync function execution ends",extra=log_context)

        return Response(response_data, status=status.HTTP_200_OK)

    except Exception as e:
        log_context["variable_state"]=locals()
        logger.error(f" Exception occured in import_sync : {str(e)}",exc_info=1,extra=log_context)
        raise e



@api_view(['POST'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def run_transformation(request):
    try :
        start_time = time.time()
        log_context = {
            "recon_id": request.data['recon_id'],
            "request_id": request.request_id,
            "user_email": request.user.email,
            "request_url": request.path,
            "event_stage": 'Transformation'
        }
        logger.info("Run_transformation function execution start",extra=log_context)

        # Getting the data from request
        recon_id = request.data['recon_id']
        max_rows = request.data['max_rows']
        page_number = request.data['page_number']

        if (request.data['sp_flag']):
            sp_flag = request.data['sp_flag']
        else:
            sp_flag = False

        # Checking if recon exists or not deleted
        if recon_id != '' and Recon.objects.filter(recon_id=recon_id, is_deleted=False).exists():
            response_data = execute_trans(recon_id, max_rows, page_number, sp_flag)
        else:
            response_data = {
                'status': 403,
                'message': 'No recon found with the specified id!'
            }

        log_context["time_taken"]=int(time.time()-start_time)
        logger.info(" Run_transformation function execution ends",extra=log_context)
        if response_data.get("status")!=200:
            logger.error(response_data,extra=log_context)
        else:
            user_logger.info("Tranformation run sucessfully")

        return Response(response_data, status=status.HTTP_200_OK)
    except Exception as e:
        log_context["variable_state"]=locals()
        logger.error(f" Exception occured in run_transformation : {str(e)}",exc_info=1,extra=log_context)
        raise e


@api_view(['DELETE'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def delete_sync(request):
    try :
        start_time = time.time()
        log_context = {
            "recon_id":  request.data['recon_id'],
            "request_id": request.request_id,
            "user_email": request.user.email,
            "request_url": request.path,
            "event_stage": 'Transformation'
        }
        logger.info("Delete_sync function execution start",extra=log_context)

        recon_id = request.data['recon_id']
        sync_id_list = request.data['sync_id']

        if is_write_permitted(request.user.email):
            if not is_recon_signed(recon_id) :
                if recon_id != '' and Recon.objects.filter(recon_id=recon_id, is_deleted=False).exists():
                    for sync_id in sync_id_list:
                        if ReconTransformationOverride.objects.filter(recon_id=recon_id, id=sync_id).exists():
                            instance = ReconTransformationOverride.objects.filter(recon_id=recon_id, id=sync_id)[0]
                            instance.delete()
                        else:
                            response_data = {
                                'status': 403,
                                'message': 'No sync found with id ' + sync_id
                            }
                            return Response(response_data, status=status.HTTP_200_OK)
                    response_data = {
                        'status': 200,
                        'message': 'Transformation sync deleted successfully!'
                    }
                else:
                    response_data = {
                        'status': 403,
                        'message': 'No recon found with the specified id!'
                    }
            else:
                response_data = {
                        'status': 403,
                        'message': 'This Recon is Signed Off'
                }
        else:
            response_data = {
                'status': 6002,
                'message': 'Un-authorized action detected!'
            }

        if response_data.get("status")==200:
            user_logger.info("Deleted the sync",extra=log_context)
        else:
            logger.error(response_data,extra=log_context)
        log_context["time_taken"]=int(time.time()-start_time)
        logger.info(" Delete_sync function execution ends",extra=log_context)

        return Response(response_data, status=status.HTTP_200_OK)

    except Exception as e:
        log_context["variable_state"]=locals()
        logger.error(f" Exception occured in delete_sync : {str(e)}",exc_info=1,extra=log_context)
        raise e


@api_view(['GET'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def run_trans_export(request, recon_id):
    try :
        start_time = time.time()
        log_context = {
            "recon_id": recon_id,
            "request_id": request.request_id,
            "user_email": request.user.email,
            "request_url": request.path,
            "event_stage": 'Transformation'
        }
        logger.info("Run_trans_export function execution start",extra=log_context)

        if is_write_permitted(request.user.email):
            # if not is_recon_signed(recon_id) :
                if recon_id != '' and Recon.objects.filter(recon_id=recon_id, is_deleted=False).exists():
                    current_time = datetime.datetime.now().time().strftime("%H:%M:%S")
                    current_date = datetime.datetime.now().strftime("%Y-%m-%d")
                    modified_date = str(current_date) + '_' + str(current_time)
                    file_name = 'Run_transformation_Export.csv'

                    # Calling functions for export query
                    query = run_trans_export_query(recon_id)

                    run_export_script(recon_id, file_name, query)

                    file_path = os.path.join(settings.MEDIA_ROOT, str(recon_id) + "/export/" + file_name)
                    file_path = (str(file_path).replace("\\", "/"))

                    if os.path.exists(file_path):
                        with open(file_path, 'rb') as fh:
                            response_data = HttpResponse(fh.read(), content_type="text/csv")
                            response_data['Content-Disposition'] = 'inline; filename=' + modified_date + os.path.basename(file_path)
                            response_data['Access-Control-Expose-Headers'] = 'Content-Disposition'

                            user_logger.info("Exported the runtrans",extra=log_context)
                            log_context["time_taken"]=int(time.time()-start_time)
                            logger.info(" Export runtrans function execution ends",extra=log_context)

                            return response_data

                    else:
                        response_data = {
                            'status': 6002,
                            'message': 'File Not Found'
                        }

                    # Setting the download response
                    # response_data = HttpResponse(export_file.getvalue(), content_type='text/csv')
                    # response_data['Content-Disposition'] = 'attachment; filename=' + file_name
                    # response_data['Access-Control-Expose-Headers'] = 'Content-Disposition'
                    # return response_data
                else:
                    response_data = {
                        'status': 403,
                        'message': 'No recon found with the specified id!'
                    }
            # else:
            #     response_data = {
            #             'status': 403,
            #             'message': 'This Recon is Signed Off'
            #     }
        else:
            response_data = {
                'status': 6002,
                'message': 'Un-authorized action detected!'
            }
            
        if response_data.get("status")!=200:
            logger.error(response_data,extra=log_context)

        log_context["time_taken"]=int(time.time()-start_time)
        logger.info(" Run_trans_export function execution ends",extra=log_context)

        return Response(response_data, status=status.HTTP_200_OK)

    except Exception as e:
        log_context["variable_state"]=locals()
        logger.error(f" Exception occured in run_trans_export : {str(e)}",exc_info=1,extra=log_context)
        raise e


@api_view(['POST'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def source_sync_members(request):
    try :
        start_time = time.time()
        log_context = {
            "recon_id": request.data['recon_id'],
            "request_id": request.request_id,
            "user_email": request.user.email,
            "request_url": request.path,
            "event_stage": 'Transformation'
        }
        logger.info("Source_sync_members function execution start",extra=log_context)
    
        recon_id = request.data['recon_id']
        app_type = request.data['appType']
        dim_id = request.data['dimension_id']
        combinations = []

        all_combs = sync_combinations(recon_id, app_type)

        for item in all_combs.values():
            if type(item) is list:
                for dimensions in item:
                    combinations.append(dimensions) if dimensions['dimensions_id'] == dim_id else None

        response_data = {
            'status': 200,
            'data': combinations,
        }

        log_context["time_taken"]=int(time.time()-start_time)
        logger.info(" Source_sync_members function execution ends",extra=log_context)

        return Response(response_data, status=status.HTTP_200_OK)

    except Exception as e:
        log_context["variable_state"]=locals()
        logger.error(f" Exception occured in source_sync_members : {str(e)}",exc_info=1,extra=log_context)
        raise e
    




@api_view(['GET'])
@permission_classes((IsAuthenticated,))
@renderer_classes((JSONRenderer,))
def check_runtrans_exists(request,recon_id):
    try :
        start_time = time.time()
        log_context = {
            "recon_id": recon_id,
            "request_id": request.request_id,
            "user_email": request.user.email,
            "request_url": request.path,
        }
        logger.info("check_runtrans_exists function execution start",extra=log_context)

        check_kickout = view_kickout('fileservice', 'view_bridge_' + str(recon_id) + '_kickout', recon_id)
        if check_kickout['status'] == 200:
            run_trans = True
        else:
            run_trans = False

        cursor = connections['Recon'].cursor()
        query = "SELECT table_name FROM information_schema.tables WHERE table_name LIKE 'b%';"   
        cursor.execute(query)
        data = cursor.fetchall()
        bridge_table_name=f'bridgesync_{recon_id}' ,

        if bridge_table_name in data:
            call_sp = False
        else:
            call_sp = True

        response_data = {
            'status': 200,
            'call_sp': call_sp,
            'run_trans': run_trans
        }


        log_context["time_taken"]=int(time.time()-start_time)
        logger.info(" check_runtrans_exists function execution ends",extra=log_context)

        return Response(response_data, status=status.HTTP_200_OK)

    except Exception as e:
        log_context["variable_state"]=locals()
        logger.error(f" Exception occured in check_runtrans_exists : {str(e)}",exc_info=1,extra=log_context)
        raise e
