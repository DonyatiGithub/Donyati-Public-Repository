from ...runReportService.functions.getVariance import getVariance
from django.db import connections

def generate_variance_query(app1_id, app2_id, recon_id):
    coalesce_col_query = f"""
    SELECT string_agg(
        'coalesce(b1."' || column_name || '", b2."' || column_name || '") as "' || column_name || '"', ',')
    FROM (
        SELECT column_name
        FROM information_schema.columns c
        WHERE table_name = 'bridgesync_{recon_id}'
        AND (column_name LIKE 'bridge%')
    ) q;"""

    coalesce_amount_query = f"""
    SELECT string_agg(
        'coalesce(b1."' || column_name || '", 0::numeric) as b1_amt, coalesce(b2."' || column_name || '", 0::numeric) as b2_amt', ', ')
    FROM (
        SELECT column_name
        FROM information_schema.columns c
        WHERE table_name = 'bridgesync_{recon_id}'
        AND column_name LIKE 'AMOUNT%'
    ) q;"""

    coalesce_amount_sum_query = f"""
    SELECT string_agg(
        'coalesce(b1."' || column_name || '", 0::numeric) + coalesce(b2."' || column_name || '", 0::numeric) as grand_abs_total', ', ')
    FROM (
        SELECT column_name
        FROM information_schema.columns c
        WHERE table_name = 'bridgesync_{recon_id}'
        AND column_name LIKE 'AMOUNT%'
    ) q;"""

    join_query = f"""
    SELECT string_agg('b1."' || column_name || '" = b2."' || column_name || '"', ' AND ')
    FROM (
        SELECT column_name
        FROM information_schema.columns c
        WHERE table_name = 'bridgesync_{recon_id}'
        AND column_name LIKE 'bridge%'
    ) q;"""

    inner_query = f"""
    SELECT string_agg(
        CASE 
            WHEN column_name = 'AMOUNT-AMOUNT' THEN 'coalesce("' || column_name || '", 0::numeric) as "' || column_name || '"'
            ELSE '"' || column_name || '"'
        END, ', ')
    FROM (
        SELECT column_name
        FROM information_schema.columns c
        WHERE table_name = 'bridgesync_{recon_id}'
        AND (column_name = 'AMOUNT-AMOUNT' OR column_name LIKE 'bridgesync-%')
    ) q;"""

    # Execute the queries and fetch the results
    with connections['Recon'].cursor() as cursor:
        cursor.execute(coalesce_col_query)
        coalesce_col_result = cursor.fetchone()[0]

        cursor.execute(coalesce_amount_query)
        coalesce_amount_result = cursor.fetchone()[0]  

        cursor.execute(coalesce_amount_sum_query)
        coalesce_amount_sum_result = cursor.fetchone()[0]  

        cursor.execute(join_query)
        join_result = cursor.fetchone()[0]  

        cursor.execute(inner_query)
        inner_result = cursor.fetchone()[0]  

    outer_query = f"SELECT {inner_result} FROM fileservice.bridgesync_{recon_id} WHERE app_id = {app1_id}"
    full_outer_join_query = f"SELECT {inner_result} FROM fileservice.bridgesync_{recon_id} WHERE app_id = {app2_id}"

    gr_abs_tot_query = f"""
    SELECT {coalesce_col_result}, {coalesce_amount_result}, {coalesce_amount_sum_result}
    FROM ({outer_query}) b1
    FULL OUTER JOIN ({full_outer_join_query}) b2 
    ON {join_result}"""

    final_query = f"""select COUNT(*) AS rec_count, 
    SUM(CASE WHEN grand_abs_total != 0 THEN 1 ELSE 0 END) AS variance_count
    from ({gr_abs_tot_query}) as joined_data;"""

    variance_percentage = getVariance(final_query)
    return variance_percentage