from django.db import connections
import json


'''
<!---------- Method to do check if table exists or not
            and return true or false ----------!>
'''


def is_exists(schema_name, table_name):
    # Establishing connection
    cursor = connections['Recon'].cursor()

    try:
        query = 'SELECT EXISTS (SELECT FROM information_schema.tables ' \
                'WHERE table_schema = \'' + schema_name + '\' AND table_name = \'' + \
                table_name + '\');'
        cursor.execute(query)

        # Replacing headers / removing
        headers = [x[0] for x in cursor.description]

        # Getting results
        results = cursor.fetchall()

        # Converting to JSON
        json_data = []
        for result in results:
            json_data.append(dict(zip(headers, result)))

        json_rows = json.dumps(json_data)
        json_rows = json.loads(json_rows)

        response_data = {
            'status': 200,
            'headers': headers,
            'rows': json_rows,
            'message': 'Data retrieved successfully!'
        }
    except TypeError as e:
        response_data = {
            'status': 6001,
            'message': 'Something went wrong in query',
            'error': str(e)
        }
    finally:
        cursor.close()
    return response_data
