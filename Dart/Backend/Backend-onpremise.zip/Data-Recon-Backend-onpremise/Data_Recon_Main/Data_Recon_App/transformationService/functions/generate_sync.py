from ...utils.get_recon import get_recon
from .sync_combinations import sync_combinations
from .update_tfn_sync import update_tfn_sync


'''
<!---------- Method to generate sync object and save it
             in db if apply all members is true ----------!>
'''


def generate_sync(recon_id, tfn_id, row_obj):
    # Getting recon data
    recon_data = get_recon(recon_id)
    app1_id = recon_data['app1_id']
    app_type = '0' if row_obj['app_id'] == app1_id else '1'

    # Getting possible combinations
    combinations = sync_combinations(recon_id, app_type)
    tfn_combinations = [comb for comb in combinations['data'] if comb.get('tfn_id') == tfn_id]

    for comb in tfn_combinations[0]['combinations']:
        sync_obj = [{
            'tfn_id': tfn_id,
            'source_sync': comb
        }]

        # Saving or updating sync obj
        update_tfn_sync(recon_id, app_type, sync_obj)
