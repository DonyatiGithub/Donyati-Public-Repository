from ... models import ReconTransformation, ReconDimensions
from ..serializers import DimIdCombinations


'''
<!---------- Method to get recon transformations
             then structure and return response ----------!>
'''


def get_transformations(recon_id):

    response_data = {
        'status': 200,
        'recon_id': recon_id,
        'rows': [],
        'message': 'Transformations data retrieved successfully!'
    }

    # Getting dimension combinations
    combinations = get_id_comb(recon_id)

    for i in combinations:
        dim_id_list = i.split('-')
        trans_data_01 = get_transformation_data(recon_id, dim_id_list[0])
        trans_data_02 = get_transformation_data(recon_id, dim_id_list[1])

        app1_apply_all_members = get_apply_all_members_reverse(trans_data_01['apply_all_members'])
        app2_apply_all_members = get_apply_all_members_reverse(trans_data_02['apply_all_members'])
        if trans_data_01['dimension_id'] and trans_data_02['dimension_id']:
            row_object = {
                "app1_dimension_id": trans_data_01['dimension_id'],
                "app1_concatenation": trans_data_01['concatenation'],
                "app1_apply_all_members": app1_apply_all_members,
                "app2_dimension_id": trans_data_02['dimension_id'],
                "app2_concatenation": trans_data_02['concatenation'],
                "app2_apply_all_members": app2_apply_all_members
            }
            response_data['rows'].append(row_object)

    return response_data


def get_id_comb(recon_id):
    dimensions_instance = ReconDimensions.objects.filter(recon_id=recon_id)
    dim_combinations = DimIdCombinations(dimensions_instance, many=True)
    combinations = dict()
    for i in dim_combinations.data:
        for j in i:
            if j in combinations and j != 'app_type':
                if i['app_type'] == '0':
                    combinations[j] = str(i[j]) + '-' + str(combinations[j])
                else:
                    combinations[j] += '-' + str(i[j])
            elif j == 'app_type':
                pass
            else:
                combinations[j] = str(i[j])
    sorted_combinations = dict(sorted(combinations.items(), key=lambda x: int(x[0])))
    merged_combinations = dict()
    merged_combinations.update(sorted_combinations)
    combinations = list(merged_combinations.values())
    return combinations


def get_transformation_data(recon_id, dim_id):
    row_object = {
        'dimension_id': None,
        'concatenation': [],
        'apply_all_members': None
    }

    if ReconTransformation.objects.filter(recon_id=recon_id, dim_id=dim_id).exists():
        instance = ReconTransformation.objects.filter(recon_id=recon_id, dim_id=dim_id)[0]
        row_object['dimension_id'] = instance.dim_id
        row_object['apply_all_members'] = instance.apply_all_members
        if instance.tgt_concat_dimid:
            concatenation = instance.tgt_concat_dimid
            row_object['concatenation'] = concatenation.split('-')

    return row_object


def get_apply_all_members_reverse(type_id):
    apply_all_members = 0
    if type_id:
        apply_all_members = 1
    elif type_id == False:
        apply_all_members = 2

    return apply_all_members
