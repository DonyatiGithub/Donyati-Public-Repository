import csv
from ... models import ReconDimensions, ReconApplications , ReconBridgeMapping
from ..serializers import ReconApplicationSerializer
from django.db.models import F
from django.db import connections
from ...bridgeService.functions.get_disk_space import get_disk_space
from ...maintenanceService.functions.update_config import get_diskspace_thresh



'''
<!---------- Method to get the imported bridge file data
             and return as structured data ----------!>
'''


def get_import_data(recon_id, app_type, file_path):
    header_instance = ReconApplications.objects.filter(recon_id=recon_id, app_name=app_type)

    header_stat = ReconApplicationSerializer(header_instance, many=True)

    dimension_map=Bridge_utils(recon_id,app_type)
    # Creating the data object
    data_object = {
        'status': 200,
        'recon_id': recon_id,
        'app_type': app_type,
        'rows': []
    }

    # Reding the imported file
    with open(file_path, newline='', encoding="utf-8-sig") as Bridge_File:
        if header_stat.data[0]['has_header']:
            next(Bridge_File)
        reader = csv.reader(Bridge_File)

        # Looping through the file data
        for index, row in enumerate(reader):
            number_of_col = len(row)

            # Checking if all columns are there
            if number_of_col < 4:
                response_data = {
                    'status': 6002,
                    'message': 'Missing required columns in file!'
                }
                return response_data
            else:
                # dim_id = get_dim_id(recon_id, row[0], app_type)
                # 'dim_id': dim_id if dim_id != 'None' else row[0],
                dim_id=dimension_map.get_dim_id(dim_name=row[0],app_type=app_type)
                row_object = {
                    'dim_id':dim_id,
                    'source_member': row[1],
                    'flip_sign':  False if row[2]=="NO" else True,
                    'bridge_member': row[3],
                    'is_invalid': True if dim_id is None else False,
                    'dim_comment': row[4]
                }
                data_object['rows'].append(row_object)

    return data_object


def get_dim_id(recon_id, dim_name, app_type):
    dimension_id = 'None'
    if ReconDimensions.objects.filter(recon_id=recon_id, dimension=dim_name.upper(), app_type=app_type).exists():
        dim_instance = ReconDimensions.objects.filter(recon_id=recon_id, dimension=dim_name.upper(), app_type=app_type)[0]
        dimension_id = dim_instance.dimensions_id

    return dimension_id


def get_bridge_dim_id(recon_id, dim_name):
    dimension_id = []
    if ReconDimensions.objects.filter(recon_id=recon_id, dimension=dim_name, app_type='0').exists():
        dim_instance = ReconDimensions.objects.filter(recon_id=recon_id, dimension=dim_name, app_type='0')[0]
        dimension_id.append(dim_instance.dimensions_id)
    if ReconDimensions.objects.filter(recon_id=recon_id, dimension=dim_name, app_type='1').exists():
        dim_instance = ReconDimensions.objects.filter(recon_id=recon_id, dimension=dim_name, app_type='1')[0]
        dimension_id.append(dim_instance.dimensions_id)

    return dimension_id

'''
<!---------- Method to get the formated bridge file data
             from request and add missing attributes ----------!>
'''

def get_formated_bridge_data(recon_id,app_type,data_object):
    # print( data_object['rows'][0])
    if 'dim_id' not in data_object['rows'][0]:
        dim_id = get_dim_id(recon_id, data_object['rows'][0]['dimension'], app_type)    
        dim_id = dim_id if dim_id != 'None' else None
        data_object['rows'][0]['dim_id']=dim_id
        data_object['rows'][0]['is_invalid'] =False if dim_id != None else True
        # print('adding key')
        #removing bridge_id tag if its "" [because its a new row &
        #  save_data function treats data as update if bridge_id exists]
        # if(data_object['rows'][0]['bridge_id']==""):
        #     del(data_object['rows'][0]['bridge_id'])
    # else: 
        # print('key exists') 
    return data_object



class Bridge_utils:

    def __init__(self,recon_id,app_type) -> None:
        self.dim_map={}
        dim_instance = ReconDimensions.objects.filter(recon_id=recon_id, app_type=app_type)
        
        for dim in dim_instance:
            self.dim_map[(dim.dimension,dim.app_type)]=dim.dimensions_id



    def get_dim_id(self,dim_name:str,app_type):

        try:
            return self.dim_map[(dim_name.upper(),app_type)]
        
        except KeyError as e:
            return None
        


def bridge_data_from_query(recon_id,app_type):
    try:

        response_structure={
            "status":200,
            "headers":[],
            "rows":[],
            "app_type":app_type,
        
        }
        cursor = connections['Recon'].cursor()
        # bridge_data = ReconBridgeMapping.objects.join(ReconDimensions, dimensions_id=F('dim_id')).values('dimension')
        sql_query = f"""
                    SELECT
                        rbm.bridge_id,
                        rd.dimension,
                        case when rd.dimensions_id is null then 'NA' else rd.dimension end as dimension,
                        rbm.source_member,
                        rbm.bridge_member,
                        case when rbm.flip_sign = true then 'Yes' else 'No' end as flip_sign ,
                        rbm.dim_comment,
                        rbm.is_invalid
                    FROM
                        recon_bridge_mapping rbm
                    INNER JOIN
                        recon_dimensions rd ON rbm.dim_id = rd.dimensions_id
                    WHERE
                        rbm.recon_id = {recon_id}
                        AND rbm.app_type = '{app_type}';
                    """
        cursor.execute(sql_query)
        data = cursor.fetchall()
        columns = [col[0] for col in cursor.description]
        result = [dict(zip(columns, row)) for row in data]
        response_structure['headers']=columns
        response_structure['rows']=result

        # Get disk space usage
        if get_diskspace_thresh()!="None":
            disk_usage = get_disk_space()
            if get_diskspace_thresh() == disk_usage:
                response_structure["disk_usage"] = disk_usage       
        
        return response_structure

    
    
    except Exception as e:
        raise e
    finally:
        if cursor:
            cursor.close()
