from django.db import connections
import json
from ...models import TrackReconRefresh


'''
<!---------- Method to do get view data and exclude
            some columns and return data as a response ----------!>
'''


def get_view_data(query, app1_id, app2_id, recon_id):
    # Establishing connection
    cursor = connections['Recon'].cursor()
    bridge_timestamp=TrackReconRefresh.objects.filter(recon_id=recon_id).values_list('bridge_timestamp',flat=True)[0]
    je_bridge_timestamp=TrackReconRefresh.objects.filter(recon_id=recon_id).values_list('je_bridge_timestamp',flat=True)[0]
    formatted_bridge_timestamp=bridge_timestamp.strftime('%Y-%m-%dT%H:%M:%SZ')

    if je_bridge_timestamp:
        je_bridge_timestamp=je_bridge_timestamp.strftime('%Y-%m-%dT%H:%M:%SZ')
    else:
        je_bridge_timestamp=je_bridge_timestamp

    try:
        cursor.execute(query)

        # Replacing headers / removing
        headers = [x[0] for x in cursor.description]

        if 'kickout' in headers:
            headers.remove('kickout')

        if 'file_id' in headers:
            file_id_index = headers.index('file_id')
            headers.remove('file_id')

        if 'file_name' in headers:
            file_name_index = headers.index('file_name')
            headers.remove('file_name')

        headers = list(map(lambda x: x.replace('app_id', 'App1-App2'), headers))
        headers = list(map(lambda x: x.replace('AMOUNT-AMOUNT', 'Initial Amount'), headers))
        headers = list(map(lambda x: x.replace('user_comment', 'Comments'), headers))
        headers = list(map(lambda x: x.replace('je_comment', 'Journal Entry Comments'), headers))
        headers = list(map(lambda x: x.replace('sign_reversal_amount', 'Amounts with Sign Flips & App2 Reversals'), headers))
        amount_index = headers.index('Initial Amount')

        # Modified below code. For Journal Entries, the comments_index will be populated with 'Journal Entry Comments'
        # when headers.index('Comments') throws ValueError -- Anirudh
        try:
            comments_index = headers.index('Comments')
        except ValueError:
            comments_index = headers.index('Journal Entry Comments')
        
        reversal_index = headers.index('Amounts with Sign Flips & App2 Reversals')

        # Getting results
        results = cursor.fetchall()

        # Converting to JSON
        json_data = []
        for result in results:
            result_list = list(result)
            if result_list[1] == app1_id:
                result_list[1] = 'App1'
            elif result_list[1] == app2_id:
                result_list[1] = 'App2'
            result_list.pop(0)
            result_list.pop(file_id_index)
            result_list.pop(file_name_index)

            # Re-formatting data
            result_list[amount_index] = "{:.2f}".format(float(result_list[amount_index]))
            result_list[reversal_index] = str(result_list[reversal_index])
            result_list[reversal_index] = "{:.2f}".format(float(result_list[reversal_index]))
            result_list[comments_index] = (result_list[comments_index]).split('^')

            # Converting back to tuple
            result = tuple(result_list)
            json_data.append(dict(zip(headers, result)))

        json_rows = json.dumps(json_data)
        json_rows = json.loads(json_rows)


        response_data = {
            'status': 200,
            'headers': headers,
            'rows': json_rows,
            'message': 'Data retrieved successfully!',
            'bridge_timestamp': formatted_bridge_timestamp,
            'je_bridge_timestamp': je_bridge_timestamp
        }
    except TypeError as e:
        response_data = {
            'status': 6001,
            'message': 'Something went wrong in query',
            'error': str(e)
        }
    finally:
        cursor.close()
    return response_data


def get_kick_out_view_data(query, app1_id, app2_id):
    # Establishing connection
    cursor = connections['Recon'].cursor()

    try:
        cursor.execute(query)

        # Replacing headers / removing
        headers = [x[0] for x in cursor.description]
        headers = list(map(lambda x: x.replace('app_id', 'app1_app2'), headers))
        headers.append('out_id')

        # Getting results
        results = cursor.fetchall()

        # Converting to JSON
        json_data = []
        for index, result in enumerate(results):
            result_list = list(result)
            if result_list[0]:
                if result_list[1] == app1_id:
                    result_list[1] = 'App1'
                elif result_list[1] == app2_id:
                    result_list[1] = 'App2'

                result_list.append(index)
                result = tuple(result_list)
                json_data.append(dict(zip(headers, result)))

        # Loop through response rows(json_data)
        # Find out members that are kickouts
        # Add kickout source and dimension to resp_data[] and return API call
        resp_data=set()
        for row in json_data:
            for dimension, member in row.items():
                if member=='kickout':
                    source_dimension = dimension.replace('bridge-','')
                    resp_data.add(tuple([str(row['app1_app2']),
                    source_dimension,
                    row.get(source_dimension),
                    ''
                    ]))
                    # print(row['kickout']+'----'+str(row['app1_app2'])+'----'+source_dimension+'----'+row.get(source_dimension))
        
        # Define headers for resp-data
        headers = ['kickout_id','app1_app2','dimension_name','source_member','bridge_member']

        seq=1
        # Convert resp_data into dictionary with pre-defined headers
        json_data = []
        for r in resp_data:
            # Prefix sequence to tuple, zip with headers and convert to dictionary for json
            json_data.append(dict(zip(headers,list((seq,)+r))))
            seq+=1

        json_rows = json.dumps(json_data)
        json_rows = json.loads(json_rows)

        response_data = {
            'status': 200,
            'rows': json_rows,
            'message': 'Data retrieved successfully!'
        }
    except TypeError as e:
        response_data = {
            'status': 6001,
            'message': 'Something went wrong in query',
            'error': str(e)
        }
    finally:
        cursor.close()
    return response_data
