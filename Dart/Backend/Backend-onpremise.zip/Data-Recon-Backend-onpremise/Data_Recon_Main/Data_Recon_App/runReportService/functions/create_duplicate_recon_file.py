import os
import shutil

# copy all the files from old recon id and paste with new recon id
def create_duplicate_recon_file(source_folder, destination_folder, old_recon_id, new_recon_id):
    try:
        # print("source_folder :",source_folder,"\ndestination_folder :",destination_folder,"\nold_recon_id",old_recon_id,"\nnew_recon_id",new_recon_id)
        # Create the destination folder if it doesn't exist
        # if not os.path.exists(destination_folder):
        #     print("inside not exist")
        #     os.makedirs(destination_folder)

        
        # Copy the source folder to the destination folder
        shutil.copytree(source_folder, destination_folder)
        # print("check existance",os.path.exists(destination_folder))
        # Rename the contents of the destination folder
        for root, dirs, files in os.walk(destination_folder):
            for directory in dirs:
             if directory != None and "Recon"+old_recon_id in dirs:
                old_dir_path = os.path.join(root, directory)
                new_dir_name = directory.replace("Recon"+old_recon_id, "Recon"+new_recon_id)
                new_dir_path = os.path.join(root, new_dir_name)
                os.rename(old_dir_path, new_dir_path)

            for file in files:
             if file != None and "Recon"+old_recon_id in file:
                old_file_path = os.path.join(root, file)
                new_file_name = file.replace("Recon"+old_recon_id, "Recon"+new_recon_id)
                new_file_path = os.path.join(root, new_file_name)
                os.rename(old_file_path, new_file_path)
                # print("new_file_path :",new_file_path,"file :",file)

        # print("Folder copied and renamed successfully.")
        response = {
           'status':200,
           'message':"Successfully created a copy of this recon!"
        }
    except Exception as e:
        response = {
           'status':500,
           'message':e
        }
        # print(f"An error occurred: {e}")
    return response