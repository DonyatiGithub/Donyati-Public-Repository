import os
from django.conf import settings
from ...utils.run_export_script import run_export_script

# from django.http import HttpResponse
# from ...utils.run_export_script import run_export_script

def create_export_file(recon_id, file, query,variance=None, variance_percentage=None):
    # print('------------------------------------------------------')
    # Run psql export command
    run_export_script(recon_id, file, query,variance, variance_percentage)

    if os.name=='nt':
        file_path = os.path.join(settings.MEDIA_ROOT,str(recon_id)+'\\export\\'+file)
        # print('file_path=',file_path)
        # print(type(file_path))
        # print(os.path.exists('C:\\Recon_Files\\media\\1\\exports\\'))
    else:
        # Prepare and return generated file
        file_path = os.path.join(settings.MEDIA_ROOT, str(recon_id) + "/export/" + file)
        file_path = (str(file_path).replace("\\", "/"))

    if os.path.exists(file_path):
        return file_path
    else:
        response_data = {
            'status': 6002,
            'message': 'File '+ file +' Not Found'
        }

    return response_data