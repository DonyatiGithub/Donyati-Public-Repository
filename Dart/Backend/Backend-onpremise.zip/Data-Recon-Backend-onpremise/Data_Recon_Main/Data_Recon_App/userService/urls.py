from django.urls import path
from rest_framework.urlpatterns import format_suffix_patterns
from . import views

urlpatterns = [
    path('forgot', views.forgot_password, name='forgotPassword'),
    path('reset', views.reset_password, name='resetPassword'),
    path('user/invite', views.user_invite, name='userInvite'),
    path('user/add', views.user_add, name='userAdd'),
    path('user/list', views.user_list, name='user_list'),
    path('invite/list', views.invite_list, name='invite_list'),
    path('user/update', views.update_user, name='update_user'),
    path('user/delete', views.user_delete, name='delete_user'),
    path('user/info', views.user_info, name='user_info'),
    path('user/resend', views.resend_invite, name='resend_invite'),
    path('user/onestream_config', views.onestream_config, name='onestream_config'),
    path('user/onestream_list', views.onestream_list, name='onestream_list'),
    path('user/onestream_del', views.onestream_delete, name='onestream_delete'),
    path('user/diskspace', views.get_disk_space, name='user_diskspace'),
    path('user/ping',views.ping,name="name"),
    path("user/view-user-log",views.user_logs_list,name="userlogs_list"),
    path("user/period_list/<int:recon_id>",views.bridgemember_period_list,name="period_list"),
    path("user/save_period",views.save_period_list,name="save_period_list"),
    path("user-recon",views.user_recon_list,name="userrecon_list"),
    path("recon-user-email",views.user_email_list,name="useremail_list"),
    path('delete-recon-period',views.delete_period_list,name="delete_period_list")
]

urlpatterns = format_suffix_patterns(urlpatterns)
