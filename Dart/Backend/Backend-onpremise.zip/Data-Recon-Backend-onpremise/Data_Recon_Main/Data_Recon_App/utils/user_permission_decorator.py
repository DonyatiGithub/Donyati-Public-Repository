from functools import wraps
from .user_permissions import is_write_permitted
from rest_framework.response import Response
from rest_framework import status




def check_user_write_access(func):


    def wrapper(request,*args,**kwargs):
        if is_write_permitted(request.user.email):
            return func(request,*args,**kwargs)
        else:
            response_data = {
                'status': 6002,
                'message': "Un-authorized action detected!, User may not have a write access please contact admin user "
            }
            return Response(response_data, status=status.HTTP_403_FORBIDDEN)

    return wrapper