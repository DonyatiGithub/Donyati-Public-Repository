from ..models import ReconUser


def is_write_permitted(email):
    user_instance = ReconUser.objects.filter(email=email)[0]
    access_type = user_instance.access_type
    access = True if access_type['privilege'] == 0 else False

    return access


def is_admin(email):
    user_instance = ReconUser.objects.filter(email=email)[0]
    role = user_instance.role
    access = True if role == "Admin" else False

    return access
