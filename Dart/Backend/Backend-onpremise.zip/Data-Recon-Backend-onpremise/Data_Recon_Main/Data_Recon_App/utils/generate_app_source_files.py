import os
from django.conf import settings
from django.db import connections
from .run_export_script import run_export_script

'''
<!---------- Method to generate source data files in /media/export folder
             with a prefix of [app_type] and returns a list of string with
             absolute path ----------!>
'''
def generate_app_source_files(recon_id,app_type,query,je_flag,file_name):
    split_file_name = []
    #offset starts from 0 with 100000 increments
    offset = 0
    limit = 100000
    tableName =''
    cursor = connections['Recon'].cursor()            
    cursor.execute(query) # query for single app_type
    cursor = cursor.fetchone()
    cursor = ','.join(map(str, cursor)).split(",")
    cursor_end = cursor[-1] # getting the last element, eg: \""file_name"\" from  fileservice.app_7_12
    cursor=cursor[:len(cursor)-1] # removing the last element
    tableName=cursor_end.split('from')[1].replace(';','') # getting the table name and removing ';', eg: fileservice.app_7_12
    lastColumn=cursor_end.split('from')[0].replace(' ','') # getting only the column name, eg: \""file_name"\"
    cursor.append(lastColumn) # adding the last column name to cursor
    if je_flag:
        tableName = tableName.replace('app_','je_') #replacing app prefix with je            
    headers = ""
    for x in range(len(cursor)):
        headers += "\\\"" + cursor[x] + "\\\""
        if x < len(cursor) - 1:
            headers += ","
    # print("headers "+str(headers))
    query = "select " + headers +' from '+ tableName 
    count = "select COUNT(*) from "+tableName 
    new_cursor = connections['Recon'].cursor()
    new_cursor.execute(count)
    new_cursor = new_cursor.fetchone()

    run_times = int(new_cursor[0]) / limit
    fraction = int(new_cursor[0]) % limit
    if(fraction>0):
        # if fraction is positive then add it as a run
        run_times += 1
    for i in range(int(run_times)):
        split_file_name.append(str(app_type)+'_'+str(i)+file_name)
        fquery = query + " OFFSET " + str(offset) + " LIMIT "+str(limit)
        run_export_script(recon_id,split_file_name[i], fquery)
        offset = offset + limit
    path=os.path.join(settings.MEDIA_ROOT, str(recon_id) + "/export/")
    # modifying the list to have absolute path of generated files
    result =[path+x for x in split_file_name]
    return result