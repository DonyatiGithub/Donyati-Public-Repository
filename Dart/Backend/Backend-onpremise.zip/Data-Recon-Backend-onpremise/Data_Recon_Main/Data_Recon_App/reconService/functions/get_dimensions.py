from ...models import ReconDimensions
from ..serializers import DimensionGetSerializer


def get_dimensions(recon_id):
    dimensions_instance = ReconDimensions.objects.filter(recon_id=recon_id, is_deleted=False)
    serialized_dimensions = DimensionGetSerializer(dimensions_instance, many=True)
    # Merging the same order dimension together
    merged_dimensions = []
    number_of_dimensions = len(serialized_dimensions.data)
    for i in range(0, number_of_dimensions):
        for j in range(i + 1, number_of_dimensions):
            if serialized_dimensions.data[i]['order'] == serialized_dimensions.data[j]['order']:
                merged_dict = serialized_dimensions.data[i] | serialized_dimensions.data[j]
                merged_dimensions.append(merged_dict)

    # Ordering dimensions
    merged_dimensions.sort(key=lambda x: int(x['order']))

    return merged_dimensions
