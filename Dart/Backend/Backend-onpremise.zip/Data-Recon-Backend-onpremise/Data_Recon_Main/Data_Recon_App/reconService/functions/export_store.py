import datetime
from django.conf import settings
import os


def export_store(recon_id, export_file, tab):

    folder_path = os.path.join(settings.MEDIA_ROOT, str(recon_id))
    export_path = folder_path + "/export"
    if not os.path.exists(export_path):
        os.makedirs(export_path)

    time_stamp = int(round(datetime.datetime.now().timestamp()))
    filename = str(time_stamp) + "Recon" + str(recon_id) + tab + 'export' + ".csv"
    with open(settings.MEDIA_ROOT + "/" + str(recon_id) + "/export/" + filename, "w") as dim_file:
        dim_file.write(str(export_file))
