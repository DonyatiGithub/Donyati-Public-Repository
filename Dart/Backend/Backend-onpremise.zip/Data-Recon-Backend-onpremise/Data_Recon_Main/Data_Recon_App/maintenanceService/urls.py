from django.urls import path
from rest_framework.urlpatterns import format_suffix_patterns
from . import views

urlpatterns = [
    path('update_config', views.update_config, name='update_config'),
    path('update_diskspace', views.update_diskspace_thresh, name='update_diskspace')
]

urlpatterns = format_suffix_patterns(urlpatterns)

views.startup_function()
