from typing import List
from .log_configs  import REQUEST_DB_MAP

def build_tuple_str(values_:List):
    value =[]
    for i in values_:
         value.append(repr(i))
    return "(" + ",".join(value) + ")"  

def build_log_filters(selected_filters:List):
    filter_query =" "
    for filter_ in selected_filters:
        final_query =" "
        if filter_["type"] in ["request_url","logging_level"]:
            tuple_str =  build_tuple_str(filter_['values'])
            query = f" {REQUEST_DB_MAP[filter_['type']]} {filter_['operator']} "
            final_query  = "and " + query + tuple_str
        
        elif filter_["type"] in ["recorded_at"]:
            query =  f" {REQUEST_DB_MAP[filter_['type']]} between {repr(filter_['values'][0])} and {repr(filter_['values'][0])}"
            final_query =" and " + query            
            
        filter_query+=final_query
    return filter_query