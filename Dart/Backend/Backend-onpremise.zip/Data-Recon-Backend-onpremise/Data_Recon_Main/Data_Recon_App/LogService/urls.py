from django.urls import path
from rest_framework.urlpatterns import format_suffix_patterns
from . import views


urlpatterns = [
    path('logs/list', views.error_log_list, name='recon_app_list'),
    path('logs/<str:request_id>', views.request_logs, name='recon_app_list'),
    path('db-logs/list',views.db_log_list,name='db_log_list'),
    path('db-error/logs',views.db_error_log,name='db_error_logging')
  
]

urlpatterns = format_suffix_patterns(urlpatterns)
