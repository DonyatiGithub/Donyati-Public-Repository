-- Drop table
DROP TABLE if exists "admin".auth_user cascade;

CREATE TABLE "admin".auth_user (
	id serial4 NOT NULL,
	"password" varchar NOT NULL,
	last_login timestamptz NULL,
	is_superuser bool NOT NULL,
	username varchar NOT NULL,
	first_name varchar NOT NULL,
	last_name varchar NOT NULL,
	email varchar NOT NULL,
	is_staff bool NOT NULL,
	is_active bool NOT NULL,
	date_joined timestamptz NOT NULL,
	uuid uuid NULL,
	"role" varchar NULL,
	access_type jsonb NULL,
	"DC_Url" varchar NULL,
	"DC_Username" varchar NULL,
	"DC_Password" bytea NULL,
	tag bytea NULL,
	nonce bytea NULL,
	admin_tag varchar NULL,
	onestream bool NULL,
	CONSTRAINT auth_user_pkey PRIMARY KEY (id),
	CONSTRAINT auth_user_username_key UNIQUE (username)
)
tablespace tbsp_meta;
CREATE INDEX auth_user_username_6821ab7c_like ON admin.auth_user USING btree (username varchar_pattern_ops);

alter table "admin".auth_user owner to "user_dataRecon_admin";