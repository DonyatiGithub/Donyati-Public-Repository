-- SEQUENCE: "admin".recon_recon_id_seq
DROP SEQUENCE IF EXISTS "admin".os_dc_members_seq cascade;

CREATE SEQUENCE "admin".os_dc_members_seq
    INCREMENT 1
    START 1
    MINVALUE 1
    MAXVALUE 9223372036854775807
    CACHE 1;

ALTER SEQUENCE "admin".os_dc_members_seq OWNER TO "user_dataRecon_admin";

GRANT ALL ON SEQUENCE "admin".os_dc_members_seq TO postgres;
GRANT ALL ON SEQUENCE "admin".os_dc_members_seq TO "user_dataRecon_admin";

-- Table: "admin".os_dc_members
DROP TABLE IF EXISTS "admin".os_dc_members CASCADE;

CREATE TABLE "admin".os_dc_members (
	member_id bigint NOT NULL DEFAULT nextval('"admin".os_dc_members_seq'::regclass),
	recon_id bigint not null default 0,
	email varchar,
	appType varchar,
	osname varchar,
	application_name varchar,
	cube_name varchar,
	dimension jsonb,
--	dimension_id bigint not null,
--	dimension_value varchar,
	CONSTRAINT pk_dc_member_id PRIMARY KEY (member_id)
)
TABLESPACE tbsp_meta;

ALTER TABLE IF EXISTS "admin".os_dc_members OWNER to "user_dataRecon_admin";

GRANT ALL ON TABLE "admin".os_dc_members TO postgres;
GRANT DELETE, UPDATE, INSERT, SELECT ON TABLE "admin".os_dc_members TO "user_dataRecon_admin";
