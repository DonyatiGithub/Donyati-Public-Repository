CREATE OR REPLACE PROCEDURE admin.updateuser(useremail character varying, userrole character varying, usergroup character varying, accesstype character varying)
 LANGUAGE plpgsql
AS $procedure$  
BEGIN 
	
   UPDATE admin."UserDetails" SET role = UserRole, 
   "group" = UserGroup, access_type = to_jsonb(AccessType::jsonb[])
   WHERE email = UserEmail;
	
END  
$procedure$
;

-- Permissions

ALTER PROCEDURE "admin".updateuser(varchar, varchar, varchar, varchar) OWNER TO "user_dataRecon_admin";
GRANT ALL ON PROCEDURE "admin".updateuser(varchar, varchar, varchar, varchar) TO postgres;
