CREATE OR REPLACE PROCEDURE fileservice.sp_create_recon_app_view(recon_id integer, journal_entry boolean DEFAULT false)
 LANGUAGE plpgsql
AS $procedure$
declare 
var_recon_id integer := recon_id;
var_je boolean := journal_entry;
s_schema_name text := 'fileservice';
var_recon_name text := '';
var_view text;

var_app1_id integer := 0;
var_app1_script text := '';
var_app1_table text := '';

var_app2_id integer := 0;
var_app2_script text := '';
var_app2_table text := '';

var_view_script text := 'Create or replace view '||s_schema_name||'.';
var_view_dim text[];
v_dim_name text := '';

begin 
	/*
	 * Check if recon is not signed-off
	 */
	
	if
		not exists(SELECT 1 FROM fileservice.recon r WHERE r.recon_id = var_recon_id AND NOT r.sign_off)
		then 
			-- Log Script
			call fileService.sp_log_entry(
									NULL::integer,
									'''ERROR: Recon is signed-off'''::text,
									var_recon_id,
									NULL::text
									);
			return;		
	end if;
	
	/*
	 * if active get the individual application id that belong to the recon id
	 * 
	 */
	if
		exists (select 1 from fileservice.recon r where r.recon_id=var_recon_id and r.is_deleted=false)
		then
			if (var_je)
			then
				select r.app1_id, r.app2_id, r.recon_id::text , concat('je_',r.recon_id,'_',app1_id) as app1_table, concat('je_',r.recon_id,'_',app2_id) as app2_table
				into var_app1_id, var_app2_id, var_recon_name, var_app1_table, var_app2_table
				from fileservice.recon r 
				where r.recon_id = var_recon_id
				and r.is_deleted = false;
				
				var_view = 'view_je_';
			else
				select r.app1_id, r.app2_id, r.recon_id::text , concat('app_',r.recon_id,'_',app1_id) as app1_table, concat('app_',r.recon_id,'_',app2_id) as app2_table
				into var_app1_id, var_app2_id, var_recon_name, var_app1_table, var_app2_table
				from fileservice.recon r 
				where r.recon_id = var_recon_id
				and r.is_deleted = false;
				
				var_view = 'view_';
			end if;
		else
			call fileService.sp_log_entry(
				null::integer, 
				'''ERROR: Recon id '|| var_recon_id ||' does not exist''', 
				var_recon_id, 
				null::text
			);
			return;
	end if;
	var_view = var_view||var_recon_name;
	
--	raise notice 'app ids are % and %', var_app1_id, var_app2_id;
	/*
	 * get the dimension combinations between the two applications
	 */
	select 
	CASE
		WHEN var_je
		THEN concat('select record_id, app_id, ',string_agg(app1,','),', je_comment, file_name as "file_name", file_id as "file_id"')
		ELSE concat('select record_id, app_id, ',string_agg(app1,','),', file_name as "file_name", file_id as "file_id"') 
		END as app1, 
	CASE
		WHEN var_je
		THEN concat('select record_id, app_id, ',string_agg(app2,','),', je_comment, file_name as "file name", file_id as "file_id"')
		ELSE concat('select record_id, app_id, ',string_agg(app2,','),', file_name as "file name", file_id as "file_id"')
		END as app2
	into var_app1_script, var_app2_script
	from (
		select 
			concat(app1,' as "',dim_name,'"') as app1,
			concat(app2,' as "',dim_name,'"') as app2
		from (
			select
				'"'||rd1.dimension||'"' as app1, '"'||rd2.dimension||'"' as app2, concat(rd1.dimension,'-' ,rd2.dimension) as dim_name 
			from
				fileservice.recon_dimensions rd1
				full outer join	fileservice.recon_dimensions rd2
				on rd1.turn_on_define_order  = rd2.turn_on_define_order
				and rd2.is_active  
				and not rd2.is_deleted
				and rd2.recon_app_id = var_app2_id
			where
				rd1.recon_app_id = var_app1_id
				and rd1.is_active  
				and not rd1.is_deleted
			order by rd1.dimensions_id 
		) q1
	)q2;
		
	var_app1_script = var_app1_script ||' from '||s_schema_name||'.'||var_app1_table;
	var_app2_script = var_app2_script ||' from '||s_schema_name||'.'||var_app2_table;

	var_view_script = var_view_script || var_view || ' as (';
	var_view_script = var_view_script || var_app1_script ||' union all '||var_app2_script||');';

--	raise notice '%',var_view_script;
    begin
	    execute var_view_script;
	exception
		when others then
		call fileservice.sp_log_entry(
			null::integer, 
			'''Error: '|| SQLERRM ||' ''', 
			var_recon_id::integer, 
			null::text 
		);
	end;

--	 Log Script
	call fileService.sp_log_entry(
								null::integer,
								'''View '|| var_view || ' created'''::text,
								var_recon_id::integer,
								var_view::text
								);


	update fileservice.recon r 
	set status = 'Imported'
	where r.recon_id = var_recon_id;
	
	
end;
$procedure$
;

-- Permissions

ALTER PROCEDURE fileservice.sp_create_recon_app_view(int4, bool) OWNER TO "user_dataRecon_file";
GRANT ALL ON PROCEDURE fileservice.sp_create_recon_app_view(int4, bool) TO public;
GRANT ALL ON PROCEDURE fileservice.sp_create_recon_app_view(int4, bool) TO postgres;
GRANT ALL ON PROCEDURE fileservice.sp_create_recon_app_view(int4, bool) TO "user_dataRecon_file";
