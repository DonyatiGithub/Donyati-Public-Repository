DROP TABLE IF EXISTS fileservice.log_entries cascade;

CREATE TABLE fileservice.log_entries (
    log_id SERIAL PRIMARY KEY,
    recon_id integer,
    request_id VARCHAR(320),
    log_name varchar(100),
    request_url varchar(100),
    logging_level VARCHAR(10),
    user_email varchar(50),
    message TEXT,
    recorded_at TIMESTAMP,
    time_taken varchar(30) ,
    variable_state json,
    event_stage varchar(30)

    )
TABLESPACE tbsp_data;

ALTER TABLE IF EXISTS fileservice.log_entries OWNER to "user_dataRecon_file";

GRANT ALL ON TABLE fileservice.log_entries TO postgres;
GRANT DELETE, UPDATE, INSERT, SELECT ON TABLE fileservice.log_entries TO "user_dataRecon_file";