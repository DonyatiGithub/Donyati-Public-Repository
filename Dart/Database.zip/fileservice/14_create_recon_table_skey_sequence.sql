DROP SEQUENCE if exists fileservice.recon_table_skey cascade;

CREATE SEQUENCE fileservice.recon_table_skey
	INCREMENT BY 1
	MINVALUE 1
	MAXVALUE 9223372036854775807
	START 1
	CACHE 1
	CYCLE;

-- Permissions
ALTER SEQUENCE fileservice.recon_table_skey OWNER TO "user_dataRecon_file";
GRANT ALL ON SEQUENCE fileservice.recon_table_skey TO "user_dataRecon_file";