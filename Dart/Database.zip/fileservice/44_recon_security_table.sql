
CREATE TABLE IF NOT EXISTS fileservice.permissions (
    permission_id SERIAL PRIMARY KEY,
    permission_name VARCHAR(320)
  )
TABLESPACE tbsp_meta;


ALTER TABLE IF EXISTS fileservice.permissions OWNER to "user_dataRecon_file";

GRANT ALL ON TABLE fileservice.permissions TO postgres;
GRANT DELETE, UPDATE, INSERT, SELECT ON TABLE fileservice.permissions TO "user_dataRecon_file";



CREATE TABLE IF NOT EXISTS fileservice.permission_group (
    permission_group_id SERIAL PRIMARY KEY,
    permission_group_name VARCHAR(320),
    created_by VARCHAR(320),
    created_at TIMESTAMP
  )
TABLESPACE tbsp_meta;


ALTER TABLE IF EXISTS fileservice.permission_group OWNER to "user_dataRecon_file";

GRANT ALL ON TABLE fileservice.permission_group TO postgres;
GRANT DELETE, UPDATE, INSERT, SELECT ON TABLE fileservice.permission_group TO "user_dataRecon_file";




CREATE TABLE IF NOT EXISTS fileservice.permission_group_map (
    permission_group_map_id SERIAL PRIMARY KEY,
    permission_id INT,
    permission_group_id INT,
    CONSTRAINT fk_permission_group_map_permission_group
      FOREIGN KEY(permission_group_id)
          REFERENCES fileservice.permission_group(permission_group_id)
          ON DELETE CASCADE
  )
TABLESPACE tbsp_meta;



ALTER TABLE IF EXISTS fileservice.permission_group_map OWNER to "user_dataRecon_file";

GRANT ALL ON TABLE fileservice.permission_group_map TO postgres;
GRANT DELETE, UPDATE, INSERT, SELECT ON TABLE fileservice.permission_group_map TO "user_dataRecon_file";


CREATE TABLE IF NOT EXISTS fileservice.permission_group_users (
    permission_group_user_id SERIAL PRIMARY KEY,
    user_email VARCHAR(320),
    permission_group_id INT,
    CONSTRAINT fk_permission_group_user_permission_group
      FOREIGN KEY(permission_group_id) 
      REFERENCES fileservice.permission_group(permission_group_id)
      ON DELETE  CASCADE
  )
TABLESPACE tbsp_meta;


ALTER TABLE IF EXISTS fileservice.permission_group_users OWNER to "user_dataRecon_file";

GRANT ALL ON TABLE fileservice.permission_group_users TO postgres;
GRANT DELETE, UPDATE, INSERT, SELECT ON TABLE fileservice.permission_group_users TO "user_dataRecon_file";


CREATE TABLE IF NOT EXISTS fileservice.recon_group_map (
    recon_group_map_id SERIAL PRIMARY KEY,
    recon_id bigint NOT NULL,
    permission_group_id INT,
    CONSTRAINT fk_recon_group_map_permission_group
      FOREIGN KEY(permission_group_id) 
      REFERENCES fileservice.permission_group(permission_group_id)
      ON DELETE  CASCADE
    
    
  )
TABLESPACE tbsp_meta;


ALTER TABLE IF EXISTS fileservice.recon_group_map OWNER to "user_dataRecon_file";

GRANT ALL ON TABLE fileservice.recon_group_map TO postgres;
GRANT DELETE, UPDATE, INSERT, SELECT ON TABLE fileservice.recon_group_map TO "user_dataRecon_file";

create  or replace view fileservice.user_recon_permission as  select recon_id , pg.permission_group_name  ,permission_name  ,user_email from fileservice.recon_group_map as rgm inner join fileservice.permission_group  pg on rgm.permission_group_id =pg.permission_group_id 
inner join fileservice.permission_group_map   as pgm  on pg.permission_group_id=pgm.permission_group_id  
inner join fileservice.permissions  on pgm.permission_id=permissions.permission_id 
inner join fileservice.permission_group_users  pgu on pgu.permission_group_id =pg.permission_group_id ;