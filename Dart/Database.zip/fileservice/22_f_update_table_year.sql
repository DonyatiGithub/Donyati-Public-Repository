drop function if exists fileservice.f_update_table_year(varchar);

create function fileservice.f_update_table_year(table_name varchar)
returns integer
language plpgsql
as $function$
declare
	var_table_name varchar := table_name;
	var_script varchar := '';
	var_int boolean := false;
	var_record RECORD;
	var_record2 RECORD;
	var_count integer := 0;
	var_cnt integer := 0;
begin
	var_script = 'select exists (select 1 from information_schema.tables where table_schema = ''fileservice'' and table_name='''||var_table_name||''')';
	execute var_script into var_int;

	if not var_int
	then
		-- Create log entry
		call fileService.sp_log_entry(
			null::integer, 
			'''ERROR: Table '|| var_table_name ||' does not exist''', 
			var_recon_id, 
			null::text
		);
	else
		/*
		 * If the table exists perform below operations
		 */
		for var_record in execute
		'select reverse(substring(reverse(yr), 3)) as yr_format from (
		select distinct "YEAR" as yr
		from fileservice.'||var_table_name||') q'
		loop
			select source_format, target_format 
			into var_record2
			from fileservice.recon_year_static rys 
			where rys.source_format = var_record.yr_format;
			
--			raise notice '%----%', var_record, var_record2;
		
			if not var_record2.target_format is null
			then
				execute 'update fileservice.'||var_table_name||' set "YEAR"=replace("YEAR", '''||var_record2.source_format||''','''||var_record2.target_format||''')';
				get diagnostics var_cnt = ROW_COUNT;
			else 
				var_cnt = 0;
			end if;
		
			var_count = var_count + var_cnt;
		end loop;		
	return var_count;
	end if;
end
$function$
;
