CREATE OR REPLACE PROCEDURE fileservice.sp_delete_recon(recon_id integer)
 LANGUAGE plpgsql
AS $procedure$
declare
s_schema_name text := 'fileservice';
var_recon_id integer := recon_id;

var_app1_id integer := 0;
var_app2_id integer := 0;

var_name text := '';

var_rec record;
var_script text := '';

begin
	
	/*
	 * If in-active get the individual application id that belong to the recon id
	 * 
	 */
	if
		exists (select 1 from fileservice.recon r where r.recon_id=var_recon_id and r.is_deleted)
		then
			select r.app1_id, r.app2_id, r."name"
			into var_app1_id, var_app2_id, var_name
			from fileservice.recon r 
			where r.recon_id = var_recon_id
			and r.is_deleted;
		else
			call fileService.sp_log_entry(
				null::integer, 
				'''ERROR: Recon id '|| var_recon_id ||' is not deleted''', 
				var_recon_id, 
				null::text
			);
			return;
	end if;

	/*
	 * Check if recon is not signed-off
	 */	
	if
		not exists(SELECT 1 FROM fileservice.recon r WHERE r.recon_id = var_recon_id AND NOT r.sign_off)
		then 
			-- Log Script
			call fileService.sp_log_entry(
									NULL::integer,
									'''ERROR: Recon is signed-off'''::text,
									var_recon_id,
									NULL::text
									);
			return;		
	end if;

	/*
	 * Get Report table names - initial, je and final
	 * Get Transformation/ bridgesync table - bridgesync_
	 * Get Bridge tables and view names incl. kickouts - bridge_ ; bridge_je_ ; view_bridge_ ; view_bridge_je_ ; view_bridge_kickout_ ; view_bridge_je_kickout_ ;
	 * Get App tables and view names - app_ ; app_je_ ; view_ ; view_je_ ;
	 * 
	 */
	for var_rec in
		select 
		'drop'|| case when t.table_name like 'view_%' then ' view ' else ' table ' end || 'if exists ' || s_schema_name || '.' || t.table_name || ' cascade;' as "table_name"
		from information_schema."tables" t 
		where t.table_schema = s_schema_name -----------------------------------------------------------------------
		and (
		--Report tables 
		t.table_name = 'report_'||var_recon_id
		or t.table_name = 'report_je_'||var_recon_id
		or t.table_name = 'final_report_'||var_recon_id
		--Transformation tables
		or t.table_name = 'bridgesync_'||var_recon_id
		--Bridge tables
		or t.table_name = 'bridge_'||var_recon_id
		or t.table_name = 'bridge_je_'||var_recon_id
		or t.table_name = 'view_bridge_'||var_recon_id
		or t.table_name = 'view_bridge_je_'||var_recon_id
		or t.table_name = 'view_bridge_'||var_recon_id||'_kickout'
		or t.table_name = 'view_bridge_je_'||var_recon_id||'_kickout'
		--App tables
		or t.table_name = 'app_'||var_recon_id||'_'||var_app1_id
		or t.table_name = 'app_'||var_recon_id||'_'||var_app2_id
		or t.table_name = 'je_'||var_recon_id||'_'||var_app1_id
		or t.table_name = 'je_'||var_recon_id||'_'||var_app2_id
		or t.table_name = 'view_'||var_recon_id
		or t.table_name = 'view_je_'||var_recon_id
		)
	loop 
		raise notice 'Executing %',var_rec.table_name;
		begin
		    execute var_rec.table_name;
		exception
			when others 
			then
			call fileservice.sp_log_entry(
				null::integer,
				'''Error: '|| SQLERRM ||' ''', 
				var_recon_id::integer,
				var_name::text
			);
		end;
	end loop;

	delete from fileservice.recon_transformation_override rto where rto.recon_id  = var_recon_id;
	delete from fileservice.recon_transformation rt where rt.recon_id  = var_recon_id;
	delete from fileservice.recon_bridge_mapping rbm where rbm.recon_id = var_recon_id;
	delete from fileservice.recon_dimensions rd where rd.recon_id = var_recon_id; 
	delete from fileservice.recon_applications ra where ra.recon_id = var_recon_id;
	delete from fileservice.recon r where r.recon_id = var_recon_id;
	

	/*
	 * Log Script
	 */
	call fileService.sp_log_entry(
								null::integer,
								'''Deleted '|| var_name || ' recon'''::text,
								var_recon_id::integer,
								var_name::text
								);
								
							
end;
$procedure$
;

ALTER PROCEDURE fileservice.sp_delete_recon(int4) OWNER TO "user_dataRecon_file";
GRANT ALL ON PROCEDURE fileservice.sp_delete_recon(int4) TO public;
GRANT ALL ON PROCEDURE fileservice.sp_delete_recon(int4) TO postgres;
GRANT ALL ON PROCEDURE fileservice.sp_delete_recon(int4) TO "user_dataRecon_file";