
DROP DATABASE if exists "db_dataRecon";
CREATE DATABASE "db_dataRecon"
    WITH 
    OWNER = postgres
    ENCODING = 'UTF8'
    TABLESPACE = tbsp_meta
    CONNECTION LIMIT = -1;

/* ALTER DATABASE "db_dataRecon" set tablespace "tbsp_data_recon"; */
