-- SCHEMA: public

DROP SCHEMA IF EXISTS public;

-- SCHEMA: admin

DROP SCHEMA IF EXISTS admin ;

CREATE SCHEMA admin
    AUTHORIZATION postgres;

GRANT ALL ON SCHEMA admin TO postgres;

-- SCHEMA: fileservice

DROP SCHEMA IF EXISTS  fileservice ;

CREATE SCHEMA fileservice
    AUTHORIZATION postgres;

GRANT ALL ON SCHEMA fileservice TO postgres;
