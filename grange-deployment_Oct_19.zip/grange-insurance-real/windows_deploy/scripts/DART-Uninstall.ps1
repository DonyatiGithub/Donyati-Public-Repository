﻿# ===========================================================================
#  DART-Uninstall.ps1  -  complete teardown, then verify
#
#  Removes EVERYTHING this deployment creates, in dependency order, and then
#  CHECKS each item instead of assuming it worked. Written after a 2026-09-10
#  teardown left four things behind that a -Clean run does not touch:
#
#    1. Scheduled tasks (DART-Uvicorn / DART-FastAPI / DART-Airflow) - these
#       survive -Clean, and a stale one relaunches a service from a path that
#       no longer exists.
#    2. The RestartCount policy on those tasks, which resurrects a killed
#       process - so port 8000 never freed and looked unkillable.
#    3. The hosts-file entry for UI_HOST.
#    4. User PATH entries pointing into a deleted TOOLS_ROOT.
#
#  KEEPS, deliberately:
#    - dart_deploy_config.json (it lives in this scripts folder, and the fresh
#      install is regenerated FROM it - losing it means retyping UI_HOST, the
#      PAT and DB passwords)
#    - Windows firewall rules (reused, and recreating them needs admin)
#
#  Usage:
#     .\DART-Uninstall.ps1              # teardown + verify
#     .\DART-Uninstall.ps1 -KeepWSL     # leave the WSL distro registered
#     .\DART-Uninstall.ps1 -WhatIf      # show what it would remove
#     .\DART-Uninstall.ps1 -RemoveVSCode # also uninstall VS Code (kept by default)
#     .\DART-Uninstall.ps1 -AllWSLDistros # unregister EVERY WSL distro, not just the configured one
# ===========================================================================
param(
    [string]$ConfigFile = "",
    [switch]$KeepWSL,
    [switch]$AllWSLDistros,
    [switch]$RemoveVSCode,
    [switch]$WhatIf
)

# ---------------------------------------------------------------------------
# Administrator check - same as DART-Start.ps1.
#
# Removing the DART scheduled tasks, killing the elevated service processes,
# editing the hosts file and deleting INSTALL_ROOT / TOOLS_ROOT all need admin.
# Without it the teardown half-works and the verify step reports leftovers.
# A person running this by hand is asked up front: Yes relaunches elevated
# (UAC prompt), No cancels.
#
# Not prompted: -WhatIf (changes nothing) and a non-interactive session
# (nobody is there to click) - warning only.
# ---------------------------------------------------------------------------
$_isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole(
    [Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $_isAdmin -and ($WhatIf -or -not [Environment]::UserInteractive)) {
    Write-Host "[WARN] Not running as Administrator - a real uninstall would not be able to remove everything." -ForegroundColor Yellow
}
elseif (-not $_isAdmin) {
    Add-Type -AssemblyName System.Windows.Forms
    $_adminMsg = "DART-Uninstall needs Administrator rights.`n`n" +
                 "It removes the DART scheduled tasks, stops the services,`n" +
                 "removes the hosts-file entry and deletes the install folders.`n`n" +
                 "Yes  - restart DART-Uninstall as Administrator (Windows will ask for permission)`n" +
                 "No   - cancel`n`n" +
                 "If you do not have an administrator account, click No and ask your IT team."
    $_adminAns = [System.Windows.Forms.MessageBox]::Show($_adminMsg, "DART-Uninstall - Administrator rights required",
        [System.Windows.Forms.MessageBoxButtons]::YesNo, [System.Windows.Forms.MessageBoxIcon]::Warning)
    if ($_adminAns -ne [System.Windows.Forms.DialogResult]::Yes) {
        Write-Host "DART-Uninstall cancelled - Administrator rights were not granted." -ForegroundColor Yellow
        exit 0
    }
    if (-not $PSCommandPath) {
        Write-Host "[FAIL] Save the script to a file first, then run it again." -ForegroundColor Red
        exit 1
    }

    # Pass this run's parameters on. An elevated process starts in System32,
    # so a relative -ConfigFile is made absolute first.
    $_relaunchArgs = @('-NoExit', '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', "`"$PSCommandPath`"")
    foreach ($_p in $PSBoundParameters.GetEnumerator()) {
        if ($_p.Value -is [switch]) {
            if ($_p.Value.IsPresent) { $_relaunchArgs += "-$($_p.Key)" }
        } else {
            $_v = "$($_p.Value)"
            if ($_p.Key -eq 'ConfigFile' -and $_v) { $_v = (Resolve-Path -LiteralPath $_v -ErrorAction SilentlyContinue).Path; if (-not $_v) { $_v = "$($_p.Value)" } }
            $_relaunchArgs += "-$($_p.Key)", "`"$_v`""
        }
    }
    # Always 64-bit Windows PowerShell (from ISE x86, System32 is redirected
    # and wsl.exe would not be found).
    $_psExe = Join-Path $env:WINDIR 'Sysnative\WindowsPowerShell\v1.0\powershell.exe'
    if (-not (Test-Path $_psExe)) { $_psExe = Join-Path $env:WINDIR 'System32\WindowsPowerShell\v1.0\powershell.exe' }
    try {
        Start-Process -FilePath $_psExe -ArgumentList $_relaunchArgs -Verb RunAs -ErrorAction Stop | Out-Null
        Write-Host "DART-Uninstall restarted in a new Administrator window. This window can be closed." -ForegroundColor Green
        exit 0
    } catch {
        [System.Windows.Forms.MessageBox]::Show("Could not start DART-Uninstall as Administrator:`n$($_.Exception.Message)`n`nDART-Uninstall has been cancelled.",
            "DART-Uninstall", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Error) | Out-Null
        Write-Host "DART-Uninstall cancelled - could not start as Administrator: $($_.Exception.Message)" -ForegroundColor Yellow
        exit 1
    }
}

$_scriptDir = if ($PSScriptRoot) { $PSScriptRoot } else { (Get-Location).Path }
$cfgPath = if ($ConfigFile -and (Test-Path $ConfigFile)) { $ConfigFile } else { Join-Path $_scriptDir "dart_deploy_config.json" }
$cfg = $null
if (Test-Path $cfgPath) { try { $cfg = Get-Content $cfgPath -Raw -Encoding UTF8 | ConvertFrom-Json } catch { } }
function Get-Cfg($k, $d) { if ($cfg -and $cfg.PSObject.Properties.Name -contains $k -and $cfg.$k) { return $cfg.$k }; return $d }

function Step($m) { Write-Host "`n>>> $m" -ForegroundColor Cyan }
function OK  ($m) { Write-Host "  [OK]   $m" -ForegroundColor Green }
function WARN($m) { Write-Host "  [WARN] $m" -ForegroundColor Yellow }
function FAIL($m) { Write-Host "  [FAIL] $m" -ForegroundColor Red }
function INFO($m) { Write-Host "  [INFO] $m" -ForegroundColor Gray }

$INSTALL_ROOT = Get-Cfg "INSTALL_ROOT" "C:\DART_DEPLOY"
$TOOLS_ROOT   = Get-Cfg "TOOLS_ROOT"   "C:\DART_Tools"
$UI_HOST      = Get-Cfg "UI_HOST"      "local-dart.donyati.com"
$WSL_DISTRO   = Get-Cfg "WSL_DISTRO"   "Ubuntu-24.04"
$API_PORT     = [int](Get-Cfg "API_PORT" "8000")
$ALL_PORTS    = @(443, 80, $API_PORT, [int](Get-Cfg "FASTAPI_PORT" "5000"), [int](Get-Cfg "AIRFLOW_PORT" "8080"), [int](Get-Cfg "DB_PORT" "5432"))

Write-Host ""
Write-Host "==========================================" -ForegroundColor DarkCyan
Write-Host "   DART - COMPLETE UNINSTALL"              -ForegroundColor Cyan
Write-Host "==========================================" -ForegroundColor DarkCyan
INFO "INSTALL_ROOT : $INSTALL_ROOT"
INFO "TOOLS_ROOT   : $TOOLS_ROOT"
INFO "WSL distro   : $WSL_DISTRO$(if ($KeepWSL) { '  (kept: -KeepWSL)' })"
INFO "Config kept  : $cfgPath"
Write-Host ""
WARN "This deletes all installed software and directories ($INSTALL_ROOT and $TOOLS_ROOT)."
WARN "Back up anything you need from $INSTALL_ROOT\Recon_Files first."

if ($WhatIf) { INFO "-WhatIf: nothing will be changed."; }
else {
    $ans = Read-Host "Type UNINSTALL to proceed"
    if ($ans -cne 'UNINSTALL') { FAIL "Aborted - nothing changed."; exit 1 }
}

# --- 1. Scheduled tasks: stop, disable, UNREGISTER -------------------------
# Unregister (not just disable): a leftover task points at launcher scripts
# under a deleted INSTALL_ROOT, and its restart policy is what made a killed
# Uvicorn come straight back.
Step "Removing scheduled tasks"
foreach ($t in 'DART-Uvicorn', 'DART-FastAPI', 'DART-Airflow', 'DART-AutoStart', 'DART-Resume-Setup') {
    if (Get-ScheduledTask -TaskName $t -ErrorAction SilentlyContinue) {
        if ($WhatIf) { INFO "would unregister task $t"; continue }
        Stop-ScheduledTask       -TaskName $t -ErrorAction SilentlyContinue
        Disable-ScheduledTask    -TaskName $t -ErrorAction SilentlyContinue | Out-Null
        Unregister-ScheduledTask -TaskName $t -Confirm:$false -ErrorAction SilentlyContinue
        if (Get-ScheduledTask -TaskName $t -ErrorAction SilentlyContinue) { FAIL "task $t still registered" }
        else { OK "task $t removed" }
    } else { INFO "task $t not present" }
}

# --- 2. Airflow inside WSL ------------------------------------------------
Step "Stopping Airflow in WSL"
if (-not $WhatIf) {
    # --exec + '[a]irflow': see DART-Stop.ps1 (plain 'airflow' also matches this shell itself)
    & wsl -d $WSL_DISTRO -u root --exec bash -c "pkill -9 -f '[a]irflow' 2>/dev/null; true" 2>&1 | Out-Null
    OK "airflow processes signalled"
} else { INFO "would pkill airflow inside $WSL_DISTRO" }

# --- 3. Windows processes -------------------------------------------------
# By PORT and by PATH. Get-NetTCPConnection's OwningProcess can be STALE (it
# reported a long-dead PID while a different process actually served the port
# on 2026-09-10), so the path sweep is what reliably finds the real holder.
Step "Stopping Windows processes"
if (-not $WhatIf) {
    foreach ($p in $ALL_PORTS) {
        $c = Get-NetTCPConnection -LocalPort $p -State Listen -ErrorAction SilentlyContinue
        foreach ($pid2 in ($c.OwningProcess | Select-Object -Unique)) {
            if (Get-Process -Id $pid2 -ErrorAction SilentlyContinue) { & taskkill /PID $pid2 /T /F 2>&1 | Out-Null }
        }
    }
    Get-Process python*, pythonw*, uvicorn*, nginx*, postgres*, pg_ctl* -ErrorAction SilentlyContinue |
        Where-Object { $p = $null; try { $p = $_.Path } catch { }; $p -and ($p -like "$INSTALL_ROOT*" -or $p -like "$TOOLS_ROOT*") } |
        ForEach-Object { INFO "killing $($_.ProcessName) PID $($_.Id)"; & taskkill /PID $_.Id /T /F 2>&1 | Out-Null }
    Start-Sleep -Seconds 3
    OK "process sweep done"
} else { INFO "would kill processes on ports $($ALL_PORTS -join ',') and under the install/tools roots" }

# --- 4. Database ----------------------------------------------------------
# The database cluster lives inside $TOOLS_ROOT\postgres\data and is wiped
# completely when $TOOLS_ROOT is deleted in Step 7. Skipping psql / pg_ctl calls
# completely prevents interactive password prompts or lock timeouts from hanging.
Step "Database cleanup"
INFO "Database cluster will be wiped directly when `$TOOLS_ROOT is removed in Step 7."

# --- 5. WSL distro --------------------------------------------------------
# `wsl --unregister` deletes the distro's ENTIRE ext4 filesystem: the Airflow
# venvs, every pip and apt package, AIRFLOW_HOME, the repo checkout, /root -
# all of it. There is no partial uninstall and no recycle bin.
#
# It does NOT disable the WSL Windows feature (VirtualMachinePlatform /
# Microsoft-Windows-Subsystem-Linux) or remove the WSL2 kernel. That is
# deliberate: those are what make a reinstall work WITHOUT another reboot.
#
# It also only removes the ONE distro named in the config. This host has had
# three registered at once (Ubuntu-26.04, Ubuntu-24.04, Ubuntu) - leftovers
# from failed runs - and the stray default was what silently broke the
# Airflow install. So any survivor is reported loudly below, and
# -AllWSLDistros removes every one of them.
Step "Removing the WSL distro"
function Get-WslDistros {
    $raw = (& wsl --list --quiet 2>&1) -join "`n"
    ($raw -replace "`0", '') -split "`r?`n" | ForEach-Object { $_.Trim() } | Where-Object { $_ }
}
if ($KeepWSL) { INFO "-KeepWSL: leaving all WSL distros registered" }
elseif ($WhatIf) {
    $d = Get-WslDistros
    if ($AllWSLDistros) { INFO "would unregister ALL distros: $($d -join ', ')" }
    else {
        INFO "would unregister $WSL_DISTRO"
        $others = $d | Where-Object { $_ -ne $WSL_DISTRO }
        if ($others) { WARN "would LEAVE these registered: $($others -join ', ') - pass -AllWSLDistros to remove them too" }
    }
}
else {
    & wsl --shutdown 2>&1 | Out-Null
    Start-Sleep -Seconds 3
    $targets = if ($AllWSLDistros) { Get-WslDistros } else { @($WSL_DISTRO) }
    foreach ($d in $targets) {
        & wsl --unregister $d 2>&1 | ForEach-Object { INFO "  $_" }
        if ((Get-WslDistros) -contains $d) { WARN "$d still registered" } else { OK "$d unregistered (whole Linux filesystem deleted)" }
    }
}

# --- 6. Things installed OUTSIDE the two roots ----------------------------
# Deleting INSTALL_ROOT and TOOLS_ROOT does not cover everything the deploy
# script creates. These three live elsewhere:
Step "Removing artifacts outside the install roots"

# 6a. %APPDATA%\postgresql\pgpass.conf - written by Prerequisites (step 1) so
#     the native Windows psql.exe can authenticate. Contains real passwords,
#     so leaving it behind is a credential leak as well as stale state.
$appPg    = Join-Path $env:APPDATA "postgresql"
$pgPass   = Join-Path $appPg "pgpass.conf"
if (Test-Path $pgPass) {
    if ($WhatIf) { INFO "would delete $pgPass (and the folder, if it ends up empty)" }
    else {
        Remove-Item $pgPass -Force -ErrorAction SilentlyContinue
        if (Test-Path $pgPass) { WARN "could not remove $pgPass" } else { OK "removed $pgPass" }
        # only remove the folder itself if nothing else lives there - it is a
        # shared libpq location that pgAdmin and other clients also use.
        if ((Test-Path $appPg) -and -not (Get-ChildItem $appPg -Force -ErrorAction SilentlyContinue)) {
            Remove-Item $appPg -Force -ErrorAction SilentlyContinue
        }
    }
} else { INFO "$pgPass not present" }

# 6b. VS Code - installed by step 16 to LOCALAPPDATA or Program Files. NOT
#     removed by default: it is a general-purpose editor that someone may be
#     using for other work, and it is not required by the deployment at all.
$vsCodeUser = "$env:LOCALAPPDATA\Programs\Microsoft VS Code"
$vsCodeSys  = "C:\Program Files\Microsoft VS Code"
$vsCodeAt   = @($vsCodeUser, $vsCodeSys) | Where-Object { Test-Path $_ }
if ($vsCodeAt) {
    if ($RemoveVSCode) {
        foreach ($v in $vsCodeAt) {
            if ($WhatIf) { INFO "would run the VS Code uninstaller at $v"; continue }
            $un = Join-Path $v "unins000.exe"
            if (Test-Path $un) { Start-Process $un -ArgumentList "/VERYSILENT","/NORESTART" -Wait; OK "VS Code uninstalled from $v" }
            else { WARN "no uninstaller at $v - remove it from Settings > Apps if you want it gone" }
        }
    } else {
        INFO "VS Code present at: $($vsCodeAt -join ', ')"
        INFO "  KEPT (it is an editor, not part of the running app). Pass -RemoveVSCode to uninstall it."
    }
} else { INFO "VS Code not installed" }

# 6c. VS C++ Build Tools - step 7 installs to TOOLS_ROOT\VSBuild, but it is an
#     MSI-based product that ALSO registers with Windows Installer and writes
#     to ProgramData. Deleting the folder with TOOLS_ROOT leaves a broken
#     registration that can make a later reinstall fail, so do it properly.
$vsInstaller = "${env:ProgramFiles(x86)}\Microsoft Visual Studio\Installer\vs_installer.exe"
$vsBuildPath = Join-Path $TOOLS_ROOT "VSBuild"
if (Test-Path $vsBuildPath) {
    if ($WhatIf) { INFO "would uninstall VS Build Tools from $vsBuildPath via vs_installer.exe" }
    elseif (Test-Path $vsInstaller) {
        INFO "uninstalling VS Build Tools (this takes a few minutes)..."
        Start-Process $vsInstaller -ArgumentList "uninstall","--installPath","`"$vsBuildPath`"","--quiet","--norestart" -Wait
        if (Test-Path $vsBuildPath) { WARN "VS Build Tools folder still present - check Settings > Apps" }
        else { OK "VS Build Tools uninstalled" }
    } else {
        WARN "vs_installer.exe not found - the VSBuild folder will be deleted with TOOLS_ROOT,"
        WARN "  but Windows Installer may still think the product is installed. If a later"
        WARN "  reinstall of step 7 fails, remove 'Visual Studio Build Tools' from Settings > Apps."
    }
} else { INFO "VS Build Tools not installed under $TOOLS_ROOT" }

# --- 7. Directories -------------------------------------------------------
Step "Deleting install directories"
foreach ($d in @($INSTALL_ROOT, $TOOLS_ROOT)) {
    if (-not (Test-Path $d)) { INFO "$d already absent"; continue }
    if ($WhatIf) { INFO "would delete $d"; continue }
    Remove-Item $d -Recurse -Force -ErrorAction SilentlyContinue
    if (Test-Path $d) {
        # Retry once - a lock usually clears after the process sweep settles.
        Start-Sleep -Seconds 3
        Remove-Item $d -Recurse -Force -ErrorAction SilentlyContinue
    }
    if (Test-Path $d) { FAIL "$d could NOT be removed - a file is still open (check Explorer / VS Code / a shell sitting in it)" }
    else { OK "$d deleted" }
}

# --- 8. Hosts file --------------------------------------------------------
Step "Cleaning the hosts file"
$hosts = "$env:SystemRoot\System32\drivers\etc\hosts"
if ($WhatIf) { INFO "would remove lines matching '$UI_HOST' from $hosts" }
else {
    try {
        $lines = Get-Content $hosts -ErrorAction Stop
        $keep  = $lines | Where-Object { $_ -notmatch [regex]::Escape($UI_HOST) }
        if ($keep.Count -ne $lines.Count) {
            [System.IO.File]::WriteAllLines($hosts, [string[]]$keep, (New-Object System.Text.ASCIIEncoding))
            OK "removed the '$UI_HOST' entry"
        } else { INFO "no '$UI_HOST' entry present" }
    } catch { WARN "could not edit $hosts (needs admin): $($_.Exception.Message)" }
}

# --- 9. User PATH ---------------------------------------------------------
Step "Cleaning user PATH"
if ($WhatIf) { INFO "would strip entries under $TOOLS_ROOT from the user PATH" }
else {
    $p = [Environment]::GetEnvironmentVariable('Path', 'User')
    if ($p) {
        $clean = (($p -split ';') | Where-Object { $_ -and $_ -notlike "$TOOLS_ROOT*" }) -join ';'
        if ($clean -ne $p) { [Environment]::SetEnvironmentVariable('Path', $clean, 'User'); OK "removed $TOOLS_ROOT entries from user PATH" }
        else { INFO "user PATH has no $TOOLS_ROOT entries" }
    }
}

# ==========================================================================
#  VERIFY - the part that was missing before
# ==========================================================================
Write-Host ""
Write-Host "==========================================" -ForegroundColor DarkCyan
Write-Host "   VERIFICATION"                            -ForegroundColor Cyan
Write-Host "==========================================" -ForegroundColor DarkCyan
if ($WhatIf) { INFO "-WhatIf: nothing was changed, so verification is skipped."; exit 0 }

$bad = 0
function Chk($cond, $msg) { if ($cond) { OK $msg } else { FAIL $msg; $script:bad++ } }

Chk (-not (Test-Path $INSTALL_ROOT)) "$INSTALL_ROOT removed"
Chk (-not (Test-Path $TOOLS_ROOT))   "$TOOLS_ROOT removed"
foreach ($p in ($ALL_PORTS | Select-Object -Unique)) {
    Chk (-not (Get-NetTCPConnection -LocalPort $p -State Listen -ErrorAction SilentlyContinue)) "port $p free"
}
foreach ($t in 'DART-Uvicorn', 'DART-FastAPI', 'DART-Airflow', 'DART-AutoStart', 'DART-Resume-Setup') {
    Chk (-not (Get-ScheduledTask -TaskName $t -ErrorAction SilentlyContinue)) "scheduled task $t removed"
}
if (-not $KeepWSL) {
    $left = Get-WslDistros
    Chk ($left -notcontains $WSL_DISTRO) "WSL distro $WSL_DISTRO unregistered"
    if ($AllWSLDistros) { Chk (-not $left) "all WSL distros unregistered" }
    elseif ($left) {
        WARN "still registered: $($left -join ', ')"
        WARN "  These are NOT from this uninstall. A stray default distro is what broke"
        WARN "  the Airflow install before. Re-run with -AllWSLDistros to remove them."
    }
}
Chk (-not (Select-String -Path $hosts -Pattern ([regex]::Escape($UI_HOST)) -Quiet -ErrorAction SilentlyContinue)) "hosts entry for $UI_HOST removed"
Chk (([Environment]::GetEnvironmentVariable('Path','User') -notlike "*$TOOLS_ROOT*")) "user PATH clean"
Chk (-not (Test-Path (Join-Path $env:APPDATA "postgresql\pgpass.conf"))) "%APPDATA%\postgresql\pgpass.conf removed"
if ($RemoveVSCode) {
    Chk (-not ((Test-Path "$env:LOCALAPPDATA\Programs\Microsoft VS Code") -or (Test-Path "C:\Program Files\Microsoft VS Code"))) "VS Code removed"
}
Chk (Test-Path $cfgPath) "config preserved ($cfgPath)"

Write-Host ""
if ($bad -eq 0) {
    Write-Host "==========================================" -ForegroundColor DarkCyan
    Write-Host "  CLEAN - ready for a fresh installation" -ForegroundColor Green
    Write-Host "==========================================" -ForegroundColor DarkCyan
    INFO "Check UI_HOST / VM_PUBLIC_IP / CORS in dart_deploy_config.json, then:"
    INFO "    .\VM-Windows-Bash-Script_V2.ps1 -Silent"
} else {
    Write-Host "==========================================" -ForegroundColor DarkCyan
    Write-Host "  $bad ITEM(S) NOT REMOVED - see [FAIL] above" -ForegroundColor Red
    Write-Host "==========================================" -ForegroundColor DarkCyan
    WARN "Do NOT reinstall until these are clear, or the new install inherits them."
    WARN "A reboot releases locked files and orphaned sockets; then re-run this script."
    exit 1
}
