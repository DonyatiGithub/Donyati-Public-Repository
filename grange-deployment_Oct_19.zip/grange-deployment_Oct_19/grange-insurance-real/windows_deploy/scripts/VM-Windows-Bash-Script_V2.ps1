﻿param(
    [Parameter(Mandatory=$false)]
    [string]$GIT_PAT = "",

    [Parameter(Mandatory=$false)]
    [string]$ConfigFile = "",

    [Parameter(Mandatory=$false)]
    [switch]$Silent,

    [Parameter(Mandatory=$false)]
    [string]$StepList = "",

    # Suppress the end-of-run service restart.
    #
    # This script is RE-ENTRANT: DART-Start.ps1 starts Airflow by calling
    # back into it with -StepList "AirflowSetup". Without this switch the
    # end-of-run restart calls DART-Start, which calls this script, which
    # restarts again - an infinite loop, observed live 2026-09-16. Every
    # delegated call from DART-Start.ps1 passes it.
    [Parameter(Mandatory=$false)]
    [switch]$NoServiceRestart,

    [Parameter(Mandatory=$false)]
    [switch]$Clean
)

# ---------------------------------------------------------------------------
# Administrator check - runs before anything else, including the GUI.
#
# Without admin rights the install "completes" but leaves a box that does
# not work: no firewall rules, no hosts entry, no scheduled tasks (services
# die at logoff), and WSL/Airflow cannot be enabled. Found on a client VM
# 2026-10-16, where every one of those showed up only as a WARNING deep in
# the log. So an interactive run asks up front: Yes relaunches this script
# elevated (Windows shows its UAC prompt), No cancels.
#
# -Silent runs are not prompted: DART-Start.ps1 and DART-Resume-Setup.ps1
# call this script with -Silent and there is nobody to click. They only get
# a warning, as before.
# ---------------------------------------------------------------------------
$_isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole(
    [Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $_isAdmin -and $Silent) {
    Write-Host "[WARNING] Not running as Administrator - firewall rules, hosts file, scheduled tasks and WSL setup will fail." -ForegroundColor Yellow
}
elseif (-not $_isAdmin) {
    Add-Type -AssemblyName System.Windows.Forms
    $_adminMsg = "DART setup needs Administrator rights.`n`n" +
                 "It is used to:`n" +
                 "  - create Windows Firewall rules (443, 8000, 5432, 8080)`n" +
                 "  - add the site name to the hosts file`n" +
                 "  - register the DART scheduled tasks (services keep running after logoff/restart)`n" +
                 "  - enable WSL and install Ubuntu for Airflow`n`n" +
                 "Yes  - restart this setup as Administrator (Windows will ask for permission)`n" +
                 "No   - cancel the setup`n`n" +
                 "If you do not have an administrator account, click No and ask your IT team."
    $_adminAns = [System.Windows.Forms.MessageBox]::Show($_adminMsg, "DART Setup - Administrator rights required",
        [System.Windows.Forms.MessageBoxButtons]::YesNo, [System.Windows.Forms.MessageBoxIcon]::Warning)
    if ($_adminAns -ne [System.Windows.Forms.DialogResult]::Yes) {
        Write-Host "Deployment cancelled - Administrator rights were not granted." -ForegroundColor Yellow
        exit 0
    }
    if (-not $PSCommandPath) {
        Write-Host "[ERROR] Save the script to a file first, then run it again." -ForegroundColor Red
        exit 1
    }

    # Pass every parameter given to this run on to the elevated one. An
    # elevated process starts in System32, so a relative -ConfigFile is made
    # absolute first.
    $_relaunchArgs = @('-NoExit', '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', "`"$PSCommandPath`"")
    foreach ($_p in $PSBoundParameters.GetEnumerator()) {
        if ($_p.Value -is [switch]) {
            if ($_p.Value.IsPresent) { $_relaunchArgs += "-$($_p.Key)" }
        } else {
            $_v = "$($_p.Value)"
            if ($_p.Key -eq 'ConfigFile' -and $_v) { $_v = (Resolve-Path -LiteralPath $_v -ErrorAction SilentlyContinue).Path; if (-not $_v) { $_v = "$($_p.Value)" } }
            $_relaunchArgs += "-$($_p.Key)", "`"$_v`""
        }
    }
    # Always the 64-bit Windows PowerShell: from a 32-bit host (PowerShell ISE
    # x86) System32 is redirected and wsl.exe would not be found.
    $_psExe = Join-Path $env:WINDIR 'Sysnative\WindowsPowerShell\v1.0\powershell.exe'
    if (-not (Test-Path $_psExe)) { $_psExe = Join-Path $env:WINDIR 'System32\WindowsPowerShell\v1.0\powershell.exe' }
    try {
        Start-Process -FilePath $_psExe -ArgumentList $_relaunchArgs -Verb RunAs -ErrorAction Stop | Out-Null
        Write-Host "Setup restarted in a new Administrator window. This window can be closed." -ForegroundColor Green
        exit 0
    } catch {
        [System.Windows.Forms.MessageBox]::Show("Could not start the setup as Administrator:`n$($_.Exception.Message)`n`nThe setup has been cancelled.",
            "DART Setup", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Error) | Out-Null
        Write-Host "Deployment cancelled - could not start as Administrator: $($_.Exception.Message)" -ForegroundColor Yellow
        exit 1
    }
}

# --- Logging helpers (defined before GUI so always available) ---
# $script:LOG_FILE is null until after the GUI closes and LOG_DIR is known.
# Every helper checks for null before writing so it is safe to call at any time.
$script:HadError     = $false
$script:CURRENT_STEP = "Init"
$script:LOG_FILE     = $null

function Write-Log($level, $msg) {
    if ($script:LOG_FILE) {
        $ts   = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
        $line = "[$ts] [$level] [$script:CURRENT_STEP] $msg"
        Add-Content -Path $script:LOG_FILE -Value $line -Encoding UTF8
    }
}

function Log-Info($msg)  {
    Write-Host "[INFO] $msg" -ForegroundColor Cyan
    Write-Log "INFO   " $msg
}
function Log-Ok($msg)    {
    Write-Host "[SUCCESS] $msg" -ForegroundColor Green
    Write-Log "SUCCESS" $msg
}
function Log-Err($msg)   {
    Write-Host "[ERROR] $msg" -ForegroundColor Red
    $script:HadError = $true
    Write-Log "ERROR  " $msg
}
function Log-Skip($msg)  {
    Write-Host "[SKIPPED] $msg already installed." -ForegroundColor Yellow
    Write-Log "SKIPPED" "$msg already installed."
}
function Log-Warn($msg)  {
    Write-Host "[WARNING] $msg" -ForegroundColor Yellow
    Write-Log "WARNING" $msg
}
# For expected "stop and come back" checkpoints (e.g. a Windows restart is
# genuinely required, not a bug) - deliberately does NOT set $script:HadError
# and prints a visually distinct banner, so this doesn't read as a failure
# and doesn't produce "COMPLETED WITH ERRORS" for a run that's actually
# paused waiting on the operator, not broken.
$script:NeedsAction = $false
# Set ONLY by the WSL restart checkpoint. $script:NeedsAction covers every
# kind of pause; this distinguishes 'a reboot will finish the job' from
# 'a human has to go and do something', which is the difference between a
# run that can resume itself and one that cannot.
$script:NeedsRestart = $false
function Log-Pause($title, [string[]]$lines) {
    $script:NeedsAction = $true
    $bar = "=" * 70
    Write-Host ""
    Write-Host $bar -ForegroundColor Magenta
    Write-Host "  ACTION NEEDED: $title" -ForegroundColor Magenta
    Write-Host $bar -ForegroundColor Magenta
    foreach ($l in $lines) { Write-Host "  $l" -ForegroundColor White }
    Write-Host $bar -ForegroundColor Magenta
    Write-Host ""
    Write-Log "PAUSED " "$title -- $($lines -join ' | ')"
}
function Log-Step($step) {
    $script:CURRENT_STEP = $step
    $ts   = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $line = "[$ts] [STEP   ] ========== $step =========="
    Write-Host ""
    Write-Host "========== $step ==========" -ForegroundColor DarkCyan
    if ($script:LOG_FILE) {
        Add-Content -Path $script:LOG_FILE -Value "" -Encoding UTF8
        Add-Content -Path $script:LOG_FILE -Value $line -Encoding UTF8
    }
}

# ---------------------------------------------------------------------------
# PostgreSQL start/readiness - shared by Step 5 and AirflowSetup.
#
# PostgreSQL must NEVER share the operator's console window. `& pg_ctl start`
# run from a PowerShell window attaches postgres.exe to that console, so a
# Ctrl+C in it - or closing it - delivers CTRL_C/CLOSE to every backend.
# Found live 2026-10-14: a backend died mid-COMMIT with 0xC000013A
# (STATUS_CONTROL_C_EXIT), a second Ctrl+C killed the postmaster, and an
# orphaned child kept port 5432 LISTENING with no server behind it - every
# connection then hung while every port check reported "running".
#
# Start-Process gives pg_ctl, and so postgres.exe, its own hidden console.
# No -Wait: in Windows PowerShell that waits for the whole process tree,
# i.e. for postgres.exe itself, forever.
# ---------------------------------------------------------------------------
function Invoke-PgCtlDetached([string]$PgCtl, [string[]]$PgArgs, [int]$TimeoutSec = 90) {
    $quoted = $PgArgs | ForEach-Object { if ($_ -match '\s') { "`"$_`"" } else { $_ } }
    $p = Start-Process -FilePath $PgCtl -ArgumentList $quoted -WindowStyle Hidden -PassThru
    $null = $p.Handle   # hold the handle so ExitCode is still readable after exit
    if (-not $p.WaitForExit($TimeoutSec * 1000)) { return $null }
    return $p.ExitCode
}

# "Port 5432 is LISTENING" is not "Postgres is up" (see above). pg_isready
# does a real protocol handshake with a timeout: 0 = accepting,
# 1 = rejecting (starting up / recovering), 2 = no response.
function Get-PgReadyCode([string]$PgBin, [string]$Port, [int]$TimeoutSec = 5) {
    $isReady = Join-Path $PgBin "pg_isready.exe"
    if (-not (Test-Path $isReady)) {
        if (Get-NetTCPConnection -LocalPort ([int]$Port) -State Listen -ErrorAction SilentlyContinue) { return 0 } else { return 2 }
    }
    & $isReady -h 127.0.0.1 -p $Port -t $TimeoutSec *> $null
    return $LASTEXITCODE
}

# Makes sure PostgreSQL is running AND answering. Returns $true when it is.
#  - already answering             -> nothing to do
#  - starting/recovering           -> wait for it
#  - port held, no server answering -> orphaned postgres.exe from a dead
#    postmaster: kill only our own postgres.exe, clear postmaster.pid, start
#  - not running                   -> start it, detached
function Start-PgSafe([string]$PgBin, [string]$PgData, [string]$LogFile, [string]$Port = "5432", [int]$WaitSec = 90) {
    $pgCtl = Join-Path $PgBin "pg_ctl.exe"
    $code = Get-PgReadyCode $PgBin $Port
    if ($code -eq 0) { Log-Skip "PostgreSQL is already running and accepting connections"; return $true }

    # A recovering server answers "rejecting" (1) - give it time, it is not broken.
    $sw = [System.Diagnostics.Stopwatch]::StartNew()
    while ($code -eq 1 -and $sw.Elapsed.TotalSeconds -lt $WaitSec) {
        Log-Info "PostgreSQL is starting up / recovering - waiting..."
        Start-Sleep -Seconds 3
        $code = Get-PgReadyCode $PgBin $Port
    }
    if ($code -eq 0) { Log-Ok "PostgreSQL finished recovering and is accepting connections."; return $true }

    if (!(Test-Path $pgCtl)) { Log-Err "pg_ctl.exe not found at $pgCtl - cannot start PostgreSQL."; return $false }
    if (!(Test-Path (Join-Path $PgData "PG_VERSION"))) { Log-Err "Data cluster missing at $PgData."; return $false }

    & $pgCtl status -D $PgData *> $null
    $serverAlive = ($LASTEXITCODE -eq 0)
    $portHeld    = [bool](Get-NetTCPConnection -LocalPort ([int]$Port) -State Listen -ErrorAction SilentlyContinue)
    if ($serverAlive) {
        # The postmaster is alive but not answering - do not kill a live server.
        Log-Err "PostgreSQL is running (pg_ctl status) but not answering on port $Port. Check $LogFile."
        return $false
    }
    if ($portHeld -or (Get-Process postgres -ErrorAction SilentlyContinue)) {
        $ours = @(Get-Process postgres -ErrorAction SilentlyContinue | Where-Object { $_.Path -and $_.Path -like "$PgBin*" })
        Log-Warn "Port $Port is held by $($ours.Count) orphaned postgres.exe process(es) with no running server (postmaster died) - stopping them."
        $ours | Stop-Process -Force -ErrorAction SilentlyContinue
        Start-Sleep -Seconds 2
    }
    $pidFile = Join-Path $PgData "postmaster.pid"
    if ((Test-Path $pidFile) -and -not (Get-Process postgres -ErrorAction SilentlyContinue)) {
        Remove-Item $pidFile -Force -ErrorAction SilentlyContinue
    }

    Log-Info "Starting PostgreSQL from $PgData (detached from this console)..."
    $rc = Invoke-PgCtlDetached $pgCtl @('start', '-D', $PgData, '-l', $LogFile, '-w', '-t', "$WaitSec") ($WaitSec + 30)
    if ($null -eq $rc) { Log-Warn "pg_ctl start did not return within $($WaitSec + 30)s - checking the server directly." }

    $sw = [System.Diagnostics.Stopwatch]::StartNew()
    do {
        $code = Get-PgReadyCode $PgBin $Port
        if ($code -eq 0) { break }
        Start-Sleep -Seconds 2
    } while ($sw.Elapsed.TotalSeconds -lt 30)
    if ($code -eq 0) { Log-Ok "PostgreSQL is running and accepting connections on port $Port."; return $true }
    Log-Err "PostgreSQL did not become ready on port $Port - check $LogFile."
    return $false
}

function Test-Command($cmd) {
    return [bool](Get-Command $cmd -ErrorAction SilentlyContinue)
}

# Set (or add) a single KEY=value line in a .env file, preserving every other
# line. Written with WriteAllLines + a BOM-less UTF8 encoder on purpose:
# Out-File -Encoding utf8 on Windows PowerShell 5.x emits a BOM, and a BOM on
# the first line makes Django's env loader read the first key name as
# "﻿DJANGO_SETTINGS_MODULE" - which then silently isn't set.
function Set-EnvKey($envFile, $key, $value) {
    if (!(Test-Path $envFile)) { return $false }
    $lines = @(Get-Content $envFile)
    $found = $false
    # -cmatch (case-SENSITIVE), not -match. PowerShell's -match ignores case,
    # so setting "airflow_admin_password" would match an existing
    # "AIRFLOW_ADMIN_PASSWORD=" line and silently RENAME it - deleting the
    # uppercase key while appearing to add a lowercase one. Caught in testing
    # 2026-09-09. A key is its exact name; treat it that way.
    $out = foreach ($line in $lines) {
        if ($line -cmatch "^\s*$([regex]::Escape($key))\s*=") { $found = $true; "$key=$value" }
        else { $line }
    }
    if (-not $found) { $out = @($out) + "$key=$value" }
    [System.IO.File]::WriteAllLines($envFile, [string[]]$out, (New-Object System.Text.UTF8Encoding($false)))
    return $true
}

# Append a host to ALLOWED_HOSTS in a .env file if it isn't already listed.
# Django rejects any request whose Host header isn't in ALLOWED_HOSTS with a
# bare HTML 400 (DisallowedHost) before any view runs - so a caller using an
# address nobody thought to allow-list looks like a broken endpoint, not a
# configuration problem.
function Add-AllowedHost($envFile, $hostToAdd) {
    if (!(Test-Path $envFile) -or [string]::IsNullOrWhiteSpace($hostToAdd)) { return $false }
    $current = (Get-Content $envFile | Where-Object { $_ -match "^\s*ALLOWED_HOSTS\s*=" } | Select-Object -First 1)
    $existing = @()
    if ($current) { $existing = ($current -replace "^\s*ALLOWED_HOSTS\s*=", "") -split ',' | ForEach-Object { $_.Trim() } | Where-Object { $_ } }
    if ($existing -contains $hostToAdd) { return $false }
    $merged = (@($existing) + $hostToAdd) -join ','
    [void](Set-EnvKey $envFile "ALLOWED_HOSTS" $merged)
    return $true
}

# Push the settings this script is authoritative for into the BACKEND .env.
#
# Django's env loader walks UP from settings.py and takes the first file
# that defines a key, never overriding one already set. settings.py lives
# under backend\Data_Recon_Backend\, so a .env sitting there is NEARER
# than INSTALL_ROOT\.env and silently wins every time.
#
# Nothing in this script ever creates that file - it arrives with the
# backend repo checkout - so Step-1 could regenerate INSTALL_ROOT\.env
# perfectly and the running site would still read the repo's stale values.
# That has now bitten twice: the Airflow admin password, and
# dart-grange.donyati.com missing from ALLOWED_HOSTS while CORS looked
# correctly configured (bare HTML 400, DisallowedHost, before any view).
#
# Only the keys this script owns are written, each via Set-EnvKey, so
# everything else in that file - FastAPI secrets, the Airflow password,
# any repo-specific keys - is preserved. This is deliberately NOT a copy
# of the whole file.
function Sync-BackendEnv($backendEnvFile, $allowedHosts, $corsOrigins) {
    if ([string]::IsNullOrWhiteSpace($backendEnvFile) -or !(Test-Path $backendEnvFile)) { return $false }
    if ([string]::IsNullOrWhiteSpace($allowedHosts)) { return $false }
    # settings.py reads the env var "CORS", not "CORS_ALLOWED_ORIGINS", and
    # requires an exact match against the browser's Origin header - which
    # never carries a trailing slash. Both names are written: CORS is the
    # one Django actually uses, the other is kept for anything else that
    # references it.
    $corsNoSlash = ((($corsOrigins -split ',') | ForEach-Object { $_.Trim().TrimEnd('/') }) | Where-Object { $_ }) -join ','
    [void](Set-EnvKey $backendEnvFile "ALLOWED_HOSTS" $allowedHosts)
    if ($corsNoSlash) {
        [void](Set-EnvKey $backendEnvFile "CORS"                 $corsNoSlash)
        [void](Set-EnvKey $backendEnvFile "CORS_ALLOWED_ORIGINS" $corsOrigins)
    }
    return $true
}

function Add-To-Path($newPath) {
    $currentPath = [Environment]::GetEnvironmentVariable("Path", "User")
    if ($currentPath -notlike "*$newPath*") {
        [Environment]::SetEnvironmentVariable("Path", "$currentPath;$newPath", "User")
        $env:Path = "$env:Path;$newPath"
    }
}

# ===========================================================================
# PERSISTENT CONFIG  -  Load saved values from JSON (if exists)
# ===========================================================================
$_scriptDir = if ($PSScriptRoot) { $PSScriptRoot } else { (Get-Location).Path }
$script:CONFIG_FILE = if ($ConfigFile -and (Test-Path $ConfigFile)) { $ConfigFile } else { Join-Path $_scriptDir "dart_deploy_config.json" }

$savedCfg = $null
if (Test-Path $script:CONFIG_FILE) {
    try {
        $savedCfg = Get-Content $script:CONFIG_FILE -Raw -Encoding UTF8 | ConvertFrom-Json
    } catch {
        Write-Host "[WARNING] Could not load saved config: $_" -ForegroundColor Yellow
    }
}

# Helper: read a value from saved config, fall back to $default
function Get-Cfg($key, $default) {
    if ($null -ne $savedCfg) {
        $val = $savedCfg.$key
        if ($null -ne $val -and "$val" -ne "") { return "$val" }
    }
    return $default
}

# Recon_Files moved out of the backend checkout and up to $INSTALL_ROOT level
# (see $RECON_FILES_DIR further down for the reasoning). A dart_deploy_config
# .json written before that change still holds the backend-nested path, so
# every read point has to be able to spot and correct it.
#
# Used HERE, at the GUI textbox default, specifically so the Config tab shows
# the corrected path: without it the box would display the stale value and
# "Save Config" would write it straight back to disk, silently undoing the
# correction the deploy had already applied at runtime.
function Resolve-MediaPath($value, $installRoot) {
    if ($value -match '[\\/]backend[\\/]Data_Recon_Backend[\\/]Recon_Files[\\/]?$') {
        return (Join-Path $installRoot "Recon_Files")
    }
    return $value
}

# ===========================================================================
# Step catalog - defined once, used by BOTH the GUI checkboxes and Silent
# mode's -StepList filter, so the two paths can never drift apart.
# An entry with OptIn = $true is unchecked by default in the GUI and
# skipped by a bare -Silent run with no -StepList - it only runs when
# explicitly selected. FastAPISetup and SeedData both used this at one
# point but are now part of the default run like every other step.
# NodeJS now uses it (2026-08-25): FrontendBuild (step 12) installs Node.js
# itself, lazily, via the shared Ensure-NodeJS function - only if it turns
# out a real npm build is actually needed (no pre-built "build"/"dist" in
# the repo). Leaving this standalone step in the default run would install
# Node unconditionally at step 3, long before step 12 even gets to check
# whether that's necessary - defeating the whole point. Still available to
# run explicitly (`-StepList "NodeJS"`, or checked by hand in the GUI) for
# anyone who wants Node pre-installed ahead of time regardless.
# ===========================================================================
$components = @(
    [PSCustomObject]@{ Name = "Prerequisites";   Label = "1.  Copy Prereq Files & Set Environment Vars" },
    [PSCustomObject]@{ Name = "Git";             Label = "2.  Git Check & Install" },
    [PSCustomObject]@{ Name = "NodeJS";          Label = "3.  Node.js / NPM Check & Install"; OptIn = $true },
    [PSCustomObject]@{ Name = "Python";          Label = "4.  Python Force Reinstall (auto-installs if missing)" },
    [PSCustomObject]@{ Name = "PostgreSQL";      Label = "5.  PostgreSQL Client Tools (+ local server, only if DB_HOST is local)" },
    [PSCustomObject]@{ Name = "NginxInstall";    Label = "6.  Nginx Check & Install" },
    [PSCustomObject]@{ Name = "VSBuildTools";    Label = "7.  VS C++ Build Tools" },
    [PSCustomObject]@{ Name = "CloneRepos";      Label = "8.  Clone Repositories (Backend / Frontend / DB / Airflow)" },
    [PSCustomObject]@{ Name = "DatabaseSetup";   Label = "9.  Database Setup (az_exec.ps1 - all numbered overlay folders)" },
    [PSCustomObject]@{ Name = "NginxConfig";     Label = "10. Nginx Configuration & Restart" },
    [PSCustomObject]@{ Name = "BackendSetup";    Label = "11. Backend Setup (Python venv + pip)" },
    [PSCustomObject]@{ Name = "FrontendBuild";   Label = "12. Frontend Build (npm install + build)" },
    [PSCustomObject]@{ Name = "StartBackend";    Label = "13. Start Backend (Uvicorn)" },
    [PSCustomObject]@{ Name = "FastAPISetup";    Label = "14. FastAPI (AI Auto Draft) Setup & Start" },
    [PSCustomObject]@{ Name = "AirflowSetup";    Label = "15. Apache Airflow Setup (WSL2)" },
    [PSCustomObject]@{ Name = "VSCodeInstall";   Label = "16. VS Code Install (+ Extensions)" },
    [PSCustomObject]@{ Name = "BrowserTest";     Label = "17. Launch Browser & Test App URL" },
    [PSCustomObject]@{ Name = "SeedData";        Label = "18. Seed Demo Data (creates a real demo recon)" }
)

# ===========================================================================
# COMPONENT SELECTOR GUI  -  Run tab + Config tab
# Skipped entirely in -Silent mode (true one-click, no manual intervention -
# reads every value straight from dart_deploy_config.json instead). See the
# matching "else" branch after this block for the Silent-mode equivalent of
# everything the GUI would otherwise have collected.
# ===========================================================================
if (-not $Silent) {
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

# --- Config field helpers ---

function New-CfgField {
    param(
        [System.Windows.Forms.Control]$parent,
        [string]$label,
        [string]$default,
        [int]$yOffset,
        [bool]$isPassword = $false
    )
    $lbl           = New-Object System.Windows.Forms.Label
    $lbl.Text      = $label
    $lbl.Location  = New-Object System.Drawing.Point(8, $yOffset)
    $lbl.Size      = New-Object System.Drawing.Size(440, 16)
    $lbl.Font      = New-Object System.Drawing.Font("Segoe UI", 8)
    $lbl.ForeColor = [System.Drawing.Color]::FromArgb(60, 60, 60)
    $parent.Controls.Add($lbl)

    $tb            = New-Object System.Windows.Forms.TextBox
    $tb.Text       = $default
    $tb.Location   = New-Object System.Drawing.Point(8, ($yOffset + 18))
    $tb.Size       = New-Object System.Drawing.Size(440, 22)
    $tb.Font       = New-Object System.Drawing.Font("Segoe UI", 9)
    if ($isPassword) { $tb.PasswordChar = [char]'*' }
    $parent.Controls.Add($tb)
    return $tb
}

# Same layout as New-CfgField, but an editable drop-down: pick one of
# $options or type any other value. Returns the ComboBox, whose .Text works
# exactly like a TextBox's for the Save Config handler.
function New-CfgCombo {
    param(
        [System.Windows.Forms.Control]$parent,
        [string]$label,
        [string]$default,
        [int]$yOffset,
        [string[]]$options
    )
    $lbl           = New-Object System.Windows.Forms.Label
    $lbl.Text      = $label
    $lbl.Location  = New-Object System.Drawing.Point(8, $yOffset)
    $lbl.Size      = New-Object System.Drawing.Size(440, 16)
    $lbl.Font      = New-Object System.Drawing.Font("Segoe UI", 8)
    $lbl.ForeColor = [System.Drawing.Color]::FromArgb(60, 60, 60)
    $parent.Controls.Add($lbl)

    $cb               = New-Object System.Windows.Forms.ComboBox
    $cb.DropDownStyle = [System.Windows.Forms.ComboBoxStyle]::DropDown
    [void]$cb.Items.AddRange([object[]]$options)
    $cb.Text          = $default
    $cb.Location      = New-Object System.Drawing.Point(8, ($yOffset + 18))
    $cb.Size          = New-Object System.Drawing.Size(440, 22)
    $cb.Font          = New-Object System.Drawing.Font("Segoe UI", 9)
    $parent.Controls.Add($cb)
    return $cb
}

function New-CfgField2 {
    param(
        [System.Windows.Forms.Control]$parent,
        [string]$label1, [string]$default1,
        [string]$label2, [string]$default2,
        [int]$yOffset,
        [bool]$pass2 = $false
    )
    $lbl1           = New-Object System.Windows.Forms.Label
    $lbl1.Text      = $label1
    $lbl1.Location  = New-Object System.Drawing.Point(8, $yOffset)
    $lbl1.Size      = New-Object System.Drawing.Size(210, 16)
    $lbl1.Font      = New-Object System.Drawing.Font("Segoe UI", 8)
    $lbl1.ForeColor = [System.Drawing.Color]::FromArgb(60, 60, 60)
    $parent.Controls.Add($lbl1)
    $tb1            = New-Object System.Windows.Forms.TextBox
    $tb1.Text       = $default1
    $tb1.Location   = New-Object System.Drawing.Point(8, ($yOffset + 18))
    $tb1.Size       = New-Object System.Drawing.Size(210, 22)
    $tb1.Font       = New-Object System.Drawing.Font("Segoe UI", 9)
    $parent.Controls.Add($tb1)

    $lbl2           = New-Object System.Windows.Forms.Label
    $lbl2.Text      = $label2
    $lbl2.Location  = New-Object System.Drawing.Point(230, $yOffset)
    $lbl2.Size      = New-Object System.Drawing.Size(218, 16)
    $lbl2.Font      = New-Object System.Drawing.Font("Segoe UI", 8)
    $lbl2.ForeColor = [System.Drawing.Color]::FromArgb(60, 60, 60)
    $parent.Controls.Add($lbl2)
    $tb2            = New-Object System.Windows.Forms.TextBox
    $tb2.Text       = $default2
    $tb2.Location   = New-Object System.Drawing.Point(230, ($yOffset + 18))
    $tb2.Size       = New-Object System.Drawing.Size(218, 22)
    $tb2.Font       = New-Object System.Drawing.Font("Segoe UI", 9)
    if ($pass2) { $tb2.PasswordChar = [char]'*' }
    $parent.Controls.Add($tb2)
    return $tb1, $tb2
}

function New-CfgGroup {
    param([System.Windows.Forms.Control]$parent, [string]$text, [int]$y, [int]$h)
    $grp          = New-Object System.Windows.Forms.GroupBox
    $grp.Text     = $text
    $grp.Location = New-Object System.Drawing.Point(8, $y)
    $grp.Size     = New-Object System.Drawing.Size(462, $h)
    $grp.Font     = New-Object System.Drawing.Font("Segoe UI", 9, [System.Drawing.FontStyle]::Bold)
    $parent.Controls.Add($grp)
    return $grp
}

# ---- Main form ----
$form                 = New-Object System.Windows.Forms.Form
$form.Text            = "DART Deployment Manager"
$form.Size            = New-Object System.Drawing.Size(520, 820)
$form.StartPosition   = "CenterScreen"
# Sizable (height only - see MinimumSize/MaximumSize below) instead of
# FixedDialog: at a fixed 820px the Run/Cancel buttons fell off the bottom of
# any screen with less working height (768px RDP sessions, 125%+ scaling).
$form.FormBorderStyle = "Sizable"
$form.MaximizeBox     = $false
$form.BackColor       = [System.Drawing.Color]::White
$form.Font            = New-Object System.Drawing.Font("Segoe UI", 9)

# Header panel
$headerPanel           = New-Object System.Windows.Forms.Panel
$headerPanel.Size      = New-Object System.Drawing.Size(520, 55)
$headerPanel.Location  = New-Object System.Drawing.Point(0, 0)
$headerPanel.BackColor = [System.Drawing.Color]::FromArgb(30, 30, 80)
$form.Controls.Add($headerPanel)
$headerLabel           = New-Object System.Windows.Forms.Label
$headerLabel.Text      = "  DART  -  Deployment Manager"
$headerLabel.ForeColor = [System.Drawing.Color]::White
$headerLabel.Font      = New-Object System.Drawing.Font("Segoe UI", 11, [System.Drawing.FontStyle]::Bold)
$headerLabel.Location  = New-Object System.Drawing.Point(10, 15)
$headerLabel.Size      = New-Object System.Drawing.Size(490, 28)
$headerPanel.Controls.Add($headerLabel)

# TabControl
$tabControl          = New-Object System.Windows.Forms.TabControl
$tabControl.Location = New-Object System.Drawing.Point(10, 62)
$tabControl.Size     = New-Object System.Drawing.Size(490, 660)
$tabControl.Font     = New-Object System.Drawing.Font("Segoe UI", 9, [System.Drawing.FontStyle]::Bold)
$form.Controls.Add($tabControl)

# ============================================================
# RUN TAB
# ============================================================
$tabRun           = New-Object System.Windows.Forms.TabPage
$tabRun.Text      = "  Run  "
$tabRun.BackColor = [System.Drawing.Color]::White
$tabRun.AutoScroll = $true     # step list scrolls when the window is shorter than it
$tabControl.TabPages.Add($tabRun)

$subLabel           = New-Object System.Windows.Forms.Label
$subLabel.Text      = "Check/uncheck components, then click Run Selected."
$subLabel.Location  = New-Object System.Drawing.Point(8, 8)
$subLabel.Size      = New-Object System.Drawing.Size(460, 20)
$subLabel.ForeColor = [System.Drawing.Color]::FromArgb(80, 80, 80)
$subLabel.Font      = New-Object System.Drawing.Font("Segoe UI", 9)
$tabRun.Controls.Add($subLabel)

$sepRun           = New-Object System.Windows.Forms.Panel
$sepRun.Location  = New-Object System.Drawing.Point(8, 32)
$sepRun.Size      = New-Object System.Drawing.Size(460, 1)
$sepRun.BackColor = [System.Drawing.Color]::FromArgb(200, 200, 200)
$tabRun.Controls.Add($sepRun)

# ($components is defined once, above the "if (-not $Silent)" wrapper, so
# both the GUI checkboxes here and Silent mode's -StepList filter share
# the exact same catalog - see the top of the file.)

$checkboxes = @{}
$cbY = 38
foreach ($comp in $components) {
    $cb          = New-Object System.Windows.Forms.CheckBox
    $cb.Text     = $comp.Label
    $cb.Location = New-Object System.Drawing.Point(12, $cbY)
    $cb.Size     = New-Object System.Drawing.Size(455, 22)
    # OptIn steps (currently just NodeJS) start unchecked - they're
    # available to run, just not part of the default selection.
    $cb.Checked  = -not ($comp.PSObject.Properties.Name -contains 'OptIn' -and $comp.OptIn)
    $cb.Font     = New-Object System.Drawing.Font("Segoe UI", 9)
    $tabRun.Controls.Add($cb)
    $checkboxes[$comp.Name] = $cb
    $cbY += 28
}
# $cbY = 38 + 14*28 = 430

$sepRun2           = New-Object System.Windows.Forms.Panel
$sepRun2.Location  = New-Object System.Drawing.Point(8, ($cbY + 4))
$sepRun2.Size      = New-Object System.Drawing.Size(460, 1)
$sepRun2.BackColor = [System.Drawing.Color]::FromArgb(200, 200, 200)
$tabRun.Controls.Add($sepRun2)

$btnAll          = New-Object System.Windows.Forms.Button
$btnAll.Text     = "Select All"
$btnAll.Location = New-Object System.Drawing.Point(12, ($cbY + 12))
$btnAll.Size     = New-Object System.Drawing.Size(95, 28)
$btnAll.Font     = New-Object System.Drawing.Font("Segoe UI", 9)
$btnAll.Add_Click({ foreach ($cb in $checkboxes.Values) { $cb.Checked = $true } })
$tabRun.Controls.Add($btnAll)

$btnNone          = New-Object System.Windows.Forms.Button
$btnNone.Text     = "Deselect All"
$btnNone.Location = New-Object System.Drawing.Point(116, ($cbY + 12))
$btnNone.Size     = New-Object System.Drawing.Size(95, 28)
$btnNone.Font     = New-Object System.Drawing.Font("Segoe UI", 9)
$btnNone.Add_Click({ foreach ($cb in $checkboxes.Values) { $cb.Checked = $false } })
$tabRun.Controls.Add($btnNone)

# ============================================================
# CONFIG TAB
# ============================================================
$tabConfig           = New-Object System.Windows.Forms.TabPage
$tabConfig.Text      = "  Config  "
$tabConfig.BackColor = [System.Drawing.Color]::White
$tabControl.TabPages.Add($tabConfig)

# --- Scrollable panel (holds all groups) ---
$cfgScroll            = New-Object System.Windows.Forms.Panel
$cfgScroll.Location   = New-Object System.Drawing.Point(0, 0)
$cfgScroll.Size       = New-Object System.Drawing.Size(480, 592)
$cfgScroll.AutoScroll = $true
$tabConfig.Controls.Add($cfgScroll)

# --- Fixed Save button strip (always visible at bottom of Config tab) ---
$cfgBtnStrip           = New-Object System.Windows.Forms.Panel
$cfgBtnStrip.Location  = New-Object System.Drawing.Point(0, 592)
$cfgBtnStrip.Size      = New-Object System.Drawing.Size(480, 44)
$cfgBtnStrip.BackColor = [System.Drawing.Color]::FromArgb(240, 240, 248)
$tabConfig.Controls.Add($cfgBtnStrip)

$btnSaveConfig           = New-Object System.Windows.Forms.Button
$btnSaveConfig.Text      = "Save Config"
$btnSaveConfig.Location  = New-Object System.Drawing.Point(8, 8)
$btnSaveConfig.Size      = New-Object System.Drawing.Size(120, 28)
$btnSaveConfig.BackColor = [System.Drawing.Color]::FromArgb(30, 30, 80)
$btnSaveConfig.ForeColor = [System.Drawing.Color]::White
$btnSaveConfig.FlatStyle = "Flat"
$btnSaveConfig.Font      = New-Object System.Drawing.Font("Segoe UI", 9, [System.Drawing.FontStyle]::Bold)
$cfgBtnStrip.Controls.Add($btnSaveConfig)

$lblSaveHint           = New-Object System.Windows.Forms.Label
$lblSaveHint.Text      = "Saves all values to dart_deploy_config.json next to this script."
$lblSaveHint.Location  = New-Object System.Drawing.Point(138, 12)
$lblSaveHint.Size      = New-Object System.Drawing.Size(330, 18)
$lblSaveHint.Font      = New-Object System.Drawing.Font("Segoe UI", 8)
$lblSaveHint.ForeColor = [System.Drawing.Color]::FromArgb(80, 80, 80)
$cfgBtnStrip.Controls.Add($lblSaveHint)

# ---- GROUP: Paths ----
$grpPaths = New-CfgGroup $cfgScroll "Paths" 8 72
$tb_InstallRoot, $tb_ToolsRoot = New-CfgField2 $grpPaths `
    "Install Root" (Get-Cfg "INSTALL_ROOT" "C:\DARTV1") `
    "Tools Root"   (Get-Cfg "TOOLS_ROOT"   "C:\DART_Tools") `
    16

# ---- GROUP: Application ----
$grpApp = New-CfgGroup $cfgScroll "Application" 88 205
$tb_ApiHost, $tb_ApiPort = New-CfgField2 $grpApp `
    "API Host" (Get-Cfg "API_HOST" "127.0.0.1") `
    "API Port" (Get-Cfg "API_PORT" "8000") `
    16
$tb_UiHost, $tb_UiPort = New-CfgField2 $grpApp `
    "UI Domain (SSL hostname)" (Get-Cfg "UI_HOST" "local-dart.donyati.com") `
    "UI Port"                  (Get-Cfg "UI_PORT" "443") `
    58
$tb_VmIp = New-CfgField $grpApp "VM Public IP (informational)" (Get-Cfg "VM_PUBLIC_IP" "127.0.0.1") 100
$tb_WebCert, $tb_WebKey = New-CfgField2 $grpApp `
    "HTTPS cert (WEB_CERT_FILE)" (Get-Cfg "WEB_CERT_FILE" "demo-dart.pem") `
    "HTTPS key (WEB_KEY_FILE)"   (Get-Cfg "WEB_KEY_FILE"  "demo-dart.key") `
    142
$tipCert = New-Object System.Windows.Forms.ToolTip
$tipCert.SetToolTip($tb_WebCert, "Nginx's HTTPS certificate (PEM, full chain). A file name is looked up in Install Root; a full path is used as it is. With the default demo-dart.pem and no file, a self-signed certificate is generated.")
$tipCert.SetToolTip($tb_WebKey, "Private key for the HTTPS certificate (PEM, not password-protected). A file name is looked up in Install Root.")

# ---- GROUP: Git ----
$grpGit = New-CfgGroup $cfgScroll "Git" 301 163
$tb_Pat = New-CfgField $grpGit "Personal Access Token (PAT)" (Get-Cfg "GIT_PAT" $GIT_PAT) 16 $true
$tb_BranchBackend, $tb_BranchFrontend = New-CfgField2 $grpGit `
    "Backend Branch"  (Get-Cfg "BRANCH_BACKEND"  "UAT") `
    "Frontend Branch" (Get-Cfg "BRANCH_FRONTEND" "UAT") `
    58
$tb_BranchDb = New-CfgField $grpGit "Database Branch" (Get-Cfg "BRANCH_DB" "mvp_main") 100

# ---- GROUP: Database ----
# One value drives every service's DB connection (backend .env, az_exec.ps1,
# Airflow, and FastAPI's field if that step is ever re-enabled): leave it as
# "localhost" to use a database on this same VM, or replace it with your
# RDS endpoint hostname (e.g. mydb.xxxxxxxxxx.<region>.rds.amazonaws.com)
# to use a managed Postgres instance instead. Nothing else needs editing -
# every step below reads DB_HOST/DB_PORT from here.
$grpDb = New-CfgGroup $cfgScroll "Database" 472 72
$tb_DbHost, $tb_DbPort = New-CfgField2 $grpDb `
    "DB Host - localhost, or your RDS endpoint" (Get-Cfg "DB_HOST" "localhost") `
    "Port (HOST_PORT)"                          (Get-Cfg "DB_PORT" "5432") `
    16
$tipDb = New-Object System.Windows.Forms.ToolTip
$tipDb.SetToolTip($tb_DbHost, "Leave as 'localhost' to use a database on this VM. To use AWS RDS instead, paste your RDS endpoint hostname here, e.g. mydb.xxxxxxxxxx.eu-north-1.rds.amazonaws.com - do not include 'https://' or a port number, that goes in the Port field.")

# ---- GROUP: Email ----
$grpEmail = New-CfgGroup $cfgScroll "Email" 552 206
$tb_EmailHost, $tb_EmailPort = New-CfgField2 $grpEmail `
    "SMTP Host (EMAIL_HOST)"   (Get-Cfg "EMAIL_HOST" "smtp-legacy.office365.com") `
    "Port (EMAIL_PORT)"        (Get-Cfg "EMAIL_PORT" "587") `
    16
$tb_EmailUser, $tb_EmailPass = New-CfgField2 $grpEmail `
    "Email User (EMAIL_HOST_USER)"         (Get-Cfg "EMAIL_HOST_USER"     "datarecon@donyati.com") `
    "Email Password (EMAIL_HOST_PASSWORD)" (Get-Cfg "EMAIL_HOST_PASSWORD" "Maraco@234") `
    58 $true
$tb_EmailBackend = New-CfgField $grpEmail "Backend (EMAIL_BACKEND)" `
    (Get-Cfg "EMAIL_BACKEND" "django.core.mail.backends.smtp.EmailBackend") 100
$tb_EmailTls = New-CfgField $grpEmail "Use TLS - True or False (EMAIL_USE_TLS)" `
    (Get-Cfg "EMAIL_USE_TLS" "True") 148

# ---- GROUP: Storage & Media ----
$grpStorage = New-CfgGroup $cfgScroll "Storage & Media" 766 72
$_cfgInstallRoot = Get-Cfg "INSTALL_ROOT" "C:\DARTV1"
$tb_MediaPath, $tb_StorageType = New-CfgField2 $grpStorage `
    "Media Path (MEDIA_PATH)"   (Resolve-MediaPath (Get-Cfg "MEDIA_PATH" (Join-Path $_cfgInstallRoot "Recon_Files")) $_cfgInstallRoot) `
    "Storage Type (STORAGE_TYPE)" (Get-Cfg "STORAGE_TYPE" "local") `
    16

# ---- GROUP: Other Settings (.env) ----
$grpOther = New-CfgGroup $cfgScroll "Other Settings (.env)" 846 250
$tb_CorsOrigins = New-CfgField $grpOther "CORS Allowed Origins (CORS_ALLOWED_ORIGINS)" `
    (Get-Cfg "CORS_ALLOWED_ORIGINS" "https://local-dart.donyati.com/") 16
$tb_ReactAppUrl = New-CfgField $grpOther "React App URL (REACT_APP_URL)" `
    (Get-Cfg "REACT_APP_URL" "https://local-dart.donyati.com/api/") 58
$tb_RetrievalLimit, $tb_SslMode = New-CfgField2 $grpOther `
    "Retrieval Limit (RETRIEVAL_LIMIT)" (Get-Cfg "RETRIEVAL_LIMIT" "500") `
    "SSL Mode (SSLMODE)"                (Get-Cfg "SSLMODE"          "disable") `
    100
$tb_SslPath = New-CfgField $grpOther "DB CA file (SSLPATH) - not the HTTPS cert; unused if SSLMODE=disable" `
    (Get-Cfg "SSLPATH" "root_ca.pem") 142
# A bare file name is looked up in Install Root (default .pgpass); a full
# path is used as it is. Step 1 writes it, Step 9 / az_exec.ps1 read it.
$tb_PgPassFile = New-CfgField $grpOther "PG Pass File (PGPASSFILE) - file name in Install Root, or full path" `
    (Get-Cfg "PGPASSFILE" ".pgpass") 192

# ---- GROUP: FastAPI ----
$grpFastApi = New-CfgGroup $cfgScroll "FastAPI (AI Auto Draft)" 1104 163
$tb_FastApiHost, $tb_FastApiPort = New-CfgField2 $grpFastApi `
    "API Host (FASTAPI_HOST)" (Get-Cfg "FASTAPI_HOST" "127.0.0.1") `
    "API Port (FASTAPI_PORT)" (Get-Cfg "FASTAPI_PORT" "5000") `
    16
$tb_FastApiApp = New-CfgField $grpFastApi "Uvicorn App Entry (FASTAPI_APP)" `
    (Get-Cfg "FASTAPI_APP" "app.main:app") 58
$tb_FastApiJwtSecret = New-CfgField $grpFastApi "Internal JWT Secret (FASTAPI_INTERNAL_JWT_SECRET)" `
    (Get-Cfg "FASTAPI_INTERNAL_JWT_SECRET" "") 100 $true

# ---- GROUP: Airflow ----
$grpAirflow = New-CfgGroup $cfgScroll "Apache Airflow (WSL2)" 1275 210
# AIRFLOW_HOME and MEDIA_PATH must be the SAME folder: Django writes the
# generated DAGs under MEDIA_PATH and Airflow reads them from AIRFLOW_HOME
# (see $MEDIA_DIR_WIN). So the two boxes are linked - editing either one
# updates the other, and the value is saved as MEDIA_PATH.
$tb_AirflowHome = New-CfgField $grpAirflow "Airflow Home (same folder as Media Path - editing one updates the other)" `
    $tb_MediaPath.Text 16
$tb_AirflowHome.Add_TextChanged({ if ($tb_MediaPath.Text -ne $tb_AirflowHome.Text) { $tb_MediaPath.Text = $tb_AirflowHome.Text } })
$tb_MediaPath.Add_TextChanged({ if ($tb_AirflowHome.Text -ne $tb_MediaPath.Text) { $tb_AirflowHome.Text = $tb_MediaPath.Text } })
$tb_AirflowPort, $tb_BranchAirflow = New-CfgField2 $grpAirflow `
    "API Port (AIRFLOW_PORT)"         (Get-Cfg "AIRFLOW_PORT"   "8080") `
    "Airflow Branch (BRANCH_AIRFLOW)" (Get-Cfg "BRANCH_AIRFLOW" "UAT") `
    58
$tb_AirflowPgUser, $tb_AirflowPgPass = New-CfgField2 $grpAirflow `
    "DB User (AIRFLOW_PG_USER)"         (Get-Cfg "AIRFLOW_PG_USER"     "usr_dr_air_rw") `
    "DB Password (AIRFLOW_PG_PASSWORD)" (Get-Cfg "AIRFLOW_PG_PASSWORD" "admin") `
    100 $true
$tb_AirflowAdminUser, $tb_AirflowAdminPass = New-CfgField2 $grpAirflow `
    "Admin User (AIRFLOW_ADMIN_USER)"         (Get-Cfg "AIRFLOW_ADMIN_USER"     "admin") `
    "Admin Password (AIRFLOW_ADMIN_PASSWORD)" (Get-Cfg "AIRFLOW_ADMIN_PASSWORD" "") `
    142 $true

# ---- GROUP: Advanced ----
# Every remaining dart_deploy_config.json key that had no field here.
#
# They were not just invisible - "Save Config" rebuilt the JSON from the
# GUI fields alone and wrote it back, so opening the installer and saving
# DELETED every key without a field, along with the _NOTE documentation.
# Built from a table rather than 28 hand-placed controls so adding a config
# key here is one line, not four, and cannot drift from the save handler
# (which iterates the same $script:advTb).
$script:advTb = [ordered]@{}
$advSpecs = @(
    @{ Key = "API_BIND_HOST"; Label = "Uvicorn bind address (API_BIND_HOST)"; Default = "0.0.0.0"; Pw = $false }
    @{ Key = "DJANGO_AIRFLOW_SECRET_KEY"; Label = "Shared Django/Airflow secret (DJANGO_AIRFLOW_SECRET_KEY)"; Default = "thissecretkeywillbesharedbetweenDjangoandAirflow"; Pw = $true }
    @{ Key = "DB_MASTER_PASSWORD"; Label = "Postgres SUPERUSER password (DB_MASTER_PASSWORD)"; Default = "admin"; Pw = $true }
    @{ Key = "DB_ROLE_PASSWORD"; Label = "App role password (DB_ROLE_PASSWORD)"; Default = "admin"; Pw = $true }
    @{ Key = "DB_FOLDERS"; Label = "DB overlay folders (blank = all)"; Default = ""; Pw = $false }
    @{ Key = "DELETE_DB_REPO_AFTER_SETUP"; Label = "Delete Database repo after Step 9 (true/false)"; Default = "true"; Pw = $false }
    @{ Key = "WSL_DISTRO"; Label = "WSL distro (WSL_DISTRO)"; Default = "Ubuntu-24.04"; Pw = $false }
    @{ Key = "CLEAN_WSL_DISTRO"; Label = "-Clean also unregisters the distro (true/false)"; Default = "false"; Pw = $false }
    @{ Key = "AUTO_RESUME_AFTER_RESTART"; Label = "Auto-resume Airflow after restart (true/false)"; Default = "true"; Pw = $false }
    @{ Key = "AUTO_START_AT_LOGON"; Label = "Start all DART services after every restart (true/false)"; Default = "true"; Pw = $false }
    @{ Key = "AIRFLOW_DEFAULT_TIMEZONE"; Label = "Airflow timezone - pick or type (IST = Asia/Kolkata, EST = America/New_York)"; Default = "Asia/Kolkata"; Pw = $false
       Options = @("Asia/Kolkata", "America/New_York", "America/Chicago", "America/Denver", "America/Los_Angeles", "Europe/London", "UTC") }
    @{ Key = "AIRFLOW_CORS_ALLOW_HEADERS"; Label = "Airflow CORS allow-headers"; Default = "origin, content-type, accept"; Pw = $false }
    @{ Key = "AIRFLOW_CORS_ALLOW_METHODS"; Label = "Airflow CORS allow-methods"; Default = "POST, GET, OPTIONS, DELETE"; Pw = $false }
    @{ Key = "AIRFLOW_JWT_EXPIRATION_TIME"; Label = "Airflow JWT expiry (seconds)"; Default = "28800"; Pw = $false }
    @{ Key = "AIRFLOW_DAG_PROCESSOR_REFRESH_INTERVAL"; Label = "DAG processor refresh interval (s)"; Default = "30"; Pw = $false }
    @{ Key = "AIRFLOW_DAG_PROCESSOR_MIN_FILE_PROCESS_INTERVAL"; Label = "DAG min file process interval (s)"; Default = "30"; Pw = $false }
    @{ Key = "SMTP_SSL"; Label = "SMTP SSL (true/false)"; Default = "False"; Pw = $false }
    @{ Key = "AZURE_AC_NAME"; Label = "Azure storage account (AZURE_AC_NAME)"; Default = ""; Pw = $false }
    @{ Key = "AZURE_BLOB_KEY"; Label = "Azure blob key (AZURE_BLOB_KEY)"; Default = ""; Pw = $true }
    @{ Key = "COMMIT_BACKEND"; Label = "Pin Backend to commit (blank = branch HEAD)"; Default = ""; Pw = $false }
    @{ Key = "COMMIT_FRONTEND"; Label = "Pin Frontend to commit (blank = branch HEAD)"; Default = ""; Pw = $false }
    @{ Key = "COMMIT_DB"; Label = "Pin Database to commit (blank = branch HEAD)"; Default = ""; Pw = $false }
    @{ Key = "COMMIT_AIRFLOW"; Label = "Pin Airflow to commit (blank = branch HEAD)"; Default = ""; Pw = $false }
)
$grpAdvanced = New-CfgGroup $cfgScroll "Advanced (rarely changed - safe to leave as-is)" 1493 1208
for ($ai = 0; $ai -lt $advSpecs.Count; $ai++) {
    $spec = $advSpecs[$ai]
    if ($spec.Options) {
        $script:advTb[$spec.Key] = New-CfgCombo $grpAdvanced $spec.Label (Get-Cfg $spec.Key $spec.Default) (16 + $ai * 42) $spec.Options
    } else {
        $script:advTb[$spec.Key] = New-CfgField $grpAdvanced $spec.Label (Get-Cfg $spec.Key $spec.Default) (16 + $ai * 42) $spec.Pw
    }
}

# ---- Make the Config tab actually scroll -----------------------------------
# AutoScroll alone was not enough here.
#
# Two separate problems:
#
# 1. AutoScrollMinSize was never set. AutoScroll infers the scrollable area
#    from child bounds, which is unreliable for GroupBoxes placed at absolute
#    coordinates - so the panel could decide it had nothing to scroll even
#    with content far below the fold. Setting it explicitly from the lowest
#    control removes the guesswork, and computing it (rather than hardcoding
#    a number) means adding a group later cannot silently re-break it.
$maxBottom = 0
foreach ($c in $cfgScroll.Controls) { if ($c.Bottom -gt $maxBottom) { $maxBottom = $c.Bottom } }
$cfgScroll.AutoScrollMinSize = New-Object System.Drawing.Size(0, ($maxBottom + 24))

# 2. WinForms sends MouseWheel to the FOCUSED control, not the one under the
#    cursor. The moment you click any textbox inside a group, the wheel goes
#    to that textbox and the panel stops responding - which reads exactly
#    like 'the window does not scroll'. Forwarding the event from every
#    descendant to the panel fixes it without stealing focus, which is what
#    a Focus()-on-MouseEnter approach would do (and would interrupt typing).
$script:cfgWheelHandler = {
    param($eventSender, $e)
    $pos = $cfgScroll.AutoScrollPosition
    # AutoScrollPosition READS negative and is SET positive - a real WinForms
    # asymmetry, not a typo. Abs() converts the read value back.
    $newY = [Math]::Abs($pos.Y) - $e.Delta
    if ($newY -lt 0) { $newY = 0 }
    $cfgScroll.AutoScrollPosition = New-Object System.Drawing.Point(0, $newY)
}
function Add-CfgWheelScroll($ctrl) {
    try { $ctrl.Add_MouseWheel($script:cfgWheelHandler) } catch { }
    foreach ($child in $ctrl.Controls) { Add-CfgWheelScroll $child }
}
Add-CfgWheelScroll $cfgScroll

# ---- Save Config button handler ----
$btnSaveConfig.Add_Click({
    $cfgData = [ordered]@{
        INSTALL_ROOT                = $tb_InstallRoot.Text
        TOOLS_ROOT                  = $tb_ToolsRoot.Text
        API_HOST                    = $tb_ApiHost.Text
        API_PORT                    = $tb_ApiPort.Text
        UI_HOST                     = $tb_UiHost.Text
        UI_PORT                     = $tb_UiPort.Text
        VM_PUBLIC_IP                = $tb_VmIp.Text
        WEB_CERT_FILE               = $tb_WebCert.Text
        WEB_KEY_FILE                = $tb_WebKey.Text
        GIT_PAT                     = $tb_Pat.Text
        BRANCH_BACKEND              = $tb_BranchBackend.Text
        BRANCH_FRONTEND             = $tb_BranchFrontend.Text
        BRANCH_DB                   = $tb_BranchDb.Text
        DB_HOST                     = $tb_DbHost.Text
        DB_PORT                     = $tb_DbPort.Text
        EMAIL_HOST                  = $tb_EmailHost.Text
        EMAIL_PORT                  = $tb_EmailPort.Text
        EMAIL_HOST_USER             = $tb_EmailUser.Text
        EMAIL_HOST_PASSWORD         = $tb_EmailPass.Text
        EMAIL_BACKEND               = $tb_EmailBackend.Text
        EMAIL_USE_TLS               = $tb_EmailTls.Text
        MEDIA_PATH                  = $tb_MediaPath.Text
        STORAGE_TYPE                = $tb_StorageType.Text
        CORS_ALLOWED_ORIGINS        = $tb_CorsOrigins.Text
        REACT_APP_URL               = $tb_ReactAppUrl.Text
        RETRIEVAL_LIMIT             = $tb_RetrievalLimit.Text
        SSLMODE                     = $tb_SslMode.Text
        SSLPATH                     = $tb_SslPath.Text
        PGPASSFILE                  = $tb_PgPassFile.Text
        FASTAPI_HOST                = $tb_FastApiHost.Text
        FASTAPI_PORT                = $tb_FastApiPort.Text
        FASTAPI_APP                 = $tb_FastApiApp.Text
        FASTAPI_INTERNAL_JWT_SECRET = $tb_FastApiJwtSecret.Text
        AIRFLOW_PORT                = $tb_AirflowPort.Text
        BRANCH_AIRFLOW              = $tb_BranchAirflow.Text
        AIRFLOW_PG_USER             = $tb_AirflowPgUser.Text
        AIRFLOW_PG_PASSWORD         = $tb_AirflowPgPass.Text
        AIRFLOW_ADMIN_USER          = $tb_AirflowAdminUser.Text
        AIRFLOW_ADMIN_PASSWORD      = $tb_AirflowAdminPass.Text
    }
    # Fold in the Advanced fields.
    foreach ($k in $script:advTb.Keys) { $cfgData[$k] = $script:advTb[$k].Text }

    try {
        # MERGE into the existing file - never rebuild it from scratch.
        #
        # This used to write $cfgData straight out, which silently deleted
        # every key the GUI does not model: 28 real settings plus all the
        # _NOTE documentation. Opening the installer and pressing Save was
        # enough to lose them, with no warning and no way to tell what had
        # gone. Unknown keys are preserved untouched.
        $merged = [ordered]@{}
        if (Test-Path $script:CONFIG_FILE) {
            try {
                $prev = Get-Content $script:CONFIG_FILE -Raw -Encoding UTF8 | ConvertFrom-Json
                foreach ($p in $prev.PSObject.Properties) { $merged[$p.Name] = $p.Value }
            } catch {
                # Unreadable/corrupt existing file: fall back to writing just
                # what the GUI holds rather than refusing to save at all.
            }
        }
        foreach ($k in $cfgData.Keys) { $merged[$k] = $cfgData[$k] }
        $merged | ConvertTo-Json -Depth 3 | Set-Content $script:CONFIG_FILE -Encoding UTF8
        [System.Windows.Forms.MessageBox]::Show(
            "Configuration saved to:`n$($script:CONFIG_FILE)",
            "DART - Config Saved",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Information
        ) | Out-Null
    } catch {
        [System.Windows.Forms.MessageBox]::Show(
            "Error saving config:`n$_",
            "DART - Save Error",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Error
        ) | Out-Null
    }
})

# ---- Run Selected / Cancel buttons (outside TabControl, always visible) ----
$btnRun              = New-Object System.Windows.Forms.Button
$btnRun.Text         = "Run Selected"
$btnRun.Location     = New-Object System.Drawing.Point(10, 730)
$btnRun.Size         = New-Object System.Drawing.Size(199, 36)
$btnRun.BackColor    = [System.Drawing.Color]::FromArgb(30, 30, 80)
$btnRun.ForeColor    = [System.Drawing.Color]::White
$btnRun.FlatStyle    = "Flat"
$btnRun.Font         = New-Object System.Drawing.Font("Segoe UI", 10, [System.Drawing.FontStyle]::Bold)
$btnRun.DialogResult = [System.Windows.Forms.DialogResult]::OK
$form.AcceptButton   = $btnRun
$form.Controls.Add($btnRun)

$btnCancel              = New-Object System.Windows.Forms.Button
$btnCancel.Text         = "Cancel"
$btnCancel.Location     = New-Object System.Drawing.Point(220, 730)
$btnCancel.Size         = New-Object System.Drawing.Size(100, 36)
$btnCancel.FlatStyle    = "Flat"
$btnCancel.DialogResult = [System.Windows.Forms.DialogResult]::Cancel
$form.CancelButton      = $btnCancel
$form.Controls.Add($btnCancel)

# ---- Fit the window to the screen it opens on ----
# Everything above is placed for an 820px window. On a screen with less
# working height (768px RDP sessions, 125%+ scaling) Run/Cancel ended up
# below the bottom edge. The window is now capped at the working area
# (screen minus taskbar) and re-laid out from its ACTUAL client height on
# every resize: buttons pinned to the bottom, tabs take what is left, the
# Config panel and the Run step list scroll. Explicit layout rather than
# Anchor - anchors keep distances measured before the form was scaled, and
# in testing left the buttons off-screen just the same.
$tabRun.AutoScrollMinSize = New-Object System.Drawing.Size(0, ($cbY + 48))
$form.MinimumSize = New-Object System.Drawing.Size(520, 460)
$form.MaximumSize = New-Object System.Drawing.Size(520, 820)
function Update-DartFormLayout {
    $btnTop = $form.ClientSize.Height - $btnRun.Height - 10
    $btnRun.Top    = $btnTop
    $btnCancel.Top = $btnTop
    $tabControl.Height = [Math]::Max(200, $btnTop - 8 - $tabControl.Top)
    # From the TabControl, not $tabConfig.ClientSize: a TabPage that is not the
    # selected one keeps reporting its old size until it is shown.
    $pageH = $tabControl.DisplayRectangle.Height
    $cfgScroll.Height  = [Math]::Max(100, $pageH - $cfgBtnStrip.Height)
    $cfgBtnStrip.Top   = $cfgScroll.Height
}
$form.Add_Load({
    $wa = [System.Windows.Forms.Screen]::FromPoint([System.Windows.Forms.Cursor]::Position).WorkingArea
    if ($form.Height -gt $wa.Height) { $form.Height = [Math]::Max($form.MinimumSize.Height, $wa.Height) }
    $form.Location = New-Object System.Drawing.Point(
        ($wa.X + [Math]::Max(0, [int](($wa.Width  - $form.Width)  / 2))),
        ($wa.Y + [Math]::Max(0, [int](($wa.Height - $form.Height) / 2))))
    Update-DartFormLayout
})
$form.Add_Resize({ Update-DartFormLayout })

$guiResult = $form.ShowDialog()
if ($guiResult -ne [System.Windows.Forms.DialogResult]::OK) {
    Write-Host "Deployment cancelled by user." -ForegroundColor Yellow
    exit 0
}

# ===========================================================================
# Read ALL configuration values from Config tab fields
# ===========================================================================
# --- Infrastructure ---
$INSTALL_ROOT    = $tb_InstallRoot.Text.TrimEnd('\')
$TOOLS_ROOT      = $tb_ToolsRoot.Text.TrimEnd('\')
$API_HOST        = $tb_ApiHost.Text.Trim()
$API_PORT        = $tb_ApiPort.Text.Trim()
$UI_HOST         = $tb_UiHost.Text.Trim()
$UI_PORT         = $tb_UiPort.Text.Trim()
$VM_PUBLIC_IP    = $tb_VmIp.Text.Trim()
# --- Git ---
$GIT_PAT         = $tb_Pat.Text.Trim()
$BRANCH_BACKEND  = $tb_BranchBackend.Text.Trim()
$BRANCH_FRONTEND = $tb_BranchFrontend.Text.Trim()
$BRANCH_DB       = $tb_BranchDb.Text.Trim()
# AI_Changes (recon_ai schema for FastAPI) lives on a dedicated DB branch.
$BRANCH_DB_AI    = "Auto_Draft_AI"
# --- Database ---
$DB_HOST         = $tb_DbHost.Text.Trim()
$DB_PORT         = $tb_DbPort.Text.Trim()
# Comma-separated subset of az_exec.ps1 overlay folders to run (e.g.
# "1_Golden_copy_V1,4_Bug_fixes"). No GUI field for this yet - it's a
# power-user/advanced knob, set it directly in dart_deploy_config.json.
# Empty (the normal case) = every folder, same as always.
$DB_FOLDERS      = Get-Cfg "DB_FOLDERS" ""
# --- Email ---
$EMAIL_HOST          = $tb_EmailHost.Text.Trim()
$EMAIL_PORT          = $tb_EmailPort.Text.Trim()
$EMAIL_HOST_USER     = $tb_EmailUser.Text.Trim()
$EMAIL_HOST_PASSWORD = $tb_EmailPass.Text
$EMAIL_BACKEND       = $tb_EmailBackend.Text.Trim()
$EMAIL_USE_TLS       = $tb_EmailTls.Text.Trim()
# --- Storage ---
$MEDIA_PATH    = $tb_MediaPath.Text.Trim()
$STORAGE_TYPE  = $tb_StorageType.Text.Trim()
# --- Other (.env) ---
$CORS_ALLOWED_ORIGINS = $tb_CorsOrigins.Text.Trim()
$REACT_APP_URL        = $tb_ReactAppUrl.Text.Trim()
$RETRIEVAL_LIMIT      = $tb_RetrievalLimit.Text.Trim()
$SSLMODE              = $tb_SslMode.Text.Trim()
$SSLPATH              = $tb_SslPath.Text.Trim()
$PGPASSFILE           = $tb_PgPassFile.Text.Trim()
$WEB_CERT_FILE        = $tb_WebCert.Text.Trim()
$WEB_KEY_FILE         = $tb_WebKey.Text.Trim()
# --- FastAPI (fields kept in the Config tab for when this step is re-enabled
#     later - see Step 14 - but never read into an active deploy today) ---
$FASTAPI_HOST                = $tb_FastApiHost.Text.Trim()
$FASTAPI_PORT                = $tb_FastApiPort.Text.Trim()
$FASTAPI_APP                 = $tb_FastApiApp.Text.Trim()
$FASTAPI_INTERNAL_JWT_SECRET = $tb_FastApiJwtSecret.Text.Trim()
# --- Airflow ---
$AIRFLOW_PORT          = $tb_AirflowPort.Text.Trim()
$BRANCH_AIRFLOW        = $tb_BranchAirflow.Text.Trim()
$AIRFLOW_PG_USER       = $tb_AirflowPgUser.Text.Trim()
$AIRFLOW_PG_PASSWORD   = $tb_AirflowPgPass.Text
$AIRFLOW_ADMIN_USER    = $tb_AirflowAdminUser.Text.Trim()
$AIRFLOW_ADMIN_PASSWORD= $tb_AirflowAdminPass.Text

# Build run-map from checkbox state
$run = @{}
foreach ($comp in $components) {
    $run[$comp.Name] = $checkboxes[$comp.Name].Checked
}

} else {
# ===========================================================================
# SILENT MODE  -  no GUI, no manual intervention. Every value below comes
# straight from dart_deploy_config.json (via Get-Cfg), the exact same
# defaults the GUI textboxes would have shown - the two paths cannot drift
# apart because both call the same Get-Cfg function with the same keys.
# Run once interactively first (Config tab -> Save Config) so the JSON has
# real values, then every subsequent run can be -Silent.
# ===========================================================================
Write-Host "Running in -Silent mode (no GUI) - reading dart_deploy_config.json" -ForegroundColor Cyan

# --- Infrastructure ---
$INSTALL_ROOT    = (Get-Cfg "INSTALL_ROOT" "C:\DARTV1").TrimEnd('\')
$TOOLS_ROOT      = (Get-Cfg "TOOLS_ROOT"   "C:\DART_Tools").TrimEnd('\')
$API_HOST        = Get-Cfg "API_HOST" "127.0.0.1"
$API_PORT        = Get-Cfg "API_PORT" "8000"
$UI_HOST         = Get-Cfg "UI_HOST" "local-dart.donyati.com"
$UI_PORT         = Get-Cfg "UI_PORT" "443"
$VM_PUBLIC_IP    = Get-Cfg "VM_PUBLIC_IP" "127.0.0.1"
# --- Git ---
$GIT_PAT         = Get-Cfg "GIT_PAT" $GIT_PAT
$BRANCH_BACKEND  = Get-Cfg "BRANCH_BACKEND"  "UAT"
$BRANCH_FRONTEND = Get-Cfg "BRANCH_FRONTEND" "UAT"
$BRANCH_DB       = Get-Cfg "BRANCH_DB" "mvp_main"
$BRANCH_DB_AI    = "Auto_Draft_AI"
# --- Database ---
$DB_HOST         = Get-Cfg "DB_HOST" "localhost"
$DB_PORT         = Get-Cfg "DB_PORT" "5432"
# Comma-separated subset of az_exec.ps1 overlay folders to run (e.g.
# "1_Golden_copy_V1,4_Bug_fixes"). Empty (the normal case) = every folder.
$DB_FOLDERS      = Get-Cfg "DB_FOLDERS" ""
# --- Email ---
$EMAIL_HOST          = Get-Cfg "EMAIL_HOST" "smtp-legacy.office365.com"
$EMAIL_PORT          = Get-Cfg "EMAIL_PORT" "587"
$EMAIL_HOST_USER     = Get-Cfg "EMAIL_HOST_USER" "datarecon@donyati.com"
$EMAIL_HOST_PASSWORD = Get-Cfg "EMAIL_HOST_PASSWORD" ""
$EMAIL_BACKEND       = Get-Cfg "EMAIL_BACKEND" "django.core.mail.backends.smtp.EmailBackend"
$EMAIL_USE_TLS       = Get-Cfg "EMAIL_USE_TLS" "True"
# --- Storage ---
# Default was "/app/Recon_Files/" - a Docker-container-style path left over
# from before this app ran natively on Windows. settings.py IS Windows-aware
# (DEFAULT_MEDIA_PATH switches on os.name == "nt"), but that only applies
# when the env var is unset - once MEDIA_PATH is explicitly set to a
# leading-slash path, Windows resolves it as "root of the current drive",
# turning it into the literal, nonexistent C:\app\Recon_Files\... . Found
# live 2026-08-22: Django's dag_gen.py (used by the create-workflow API)
# tried to write a DAG file there and got FileNotFoundError.
#
# The default was then "$BACKEND_DIR\Recon_Files" until this change moved
# the media root up to $INSTALL_ROOT level - see $RECON_FILES_DIR in the
# "Derive all paths" block below for why. Airflow's AIRFLOW_HOME follows
# whatever this resolves to, so the two can't diverge.
$MEDIA_PATH    = Get-Cfg "MEDIA_PATH" "$INSTALL_ROOT\Recon_Files"
$STORAGE_TYPE  = Get-Cfg "STORAGE_TYPE" "local"
# --- Other (.env) ---
$CORS_ALLOWED_ORIGINS = Get-Cfg "CORS_ALLOWED_ORIGINS" "https://local-dart.donyati.com/"
$REACT_APP_URL        = Get-Cfg "REACT_APP_URL" "https://local-dart.donyati.com/api/"
$RETRIEVAL_LIMIT      = Get-Cfg "RETRIEVAL_LIMIT" "500"
$SSLMODE              = Get-Cfg "SSLMODE" "disable"
$SSLPATH              = Get-Cfg "SSLPATH" "root_ca.pem"          # resolved against INSTALL_ROOT below
$PGPASSFILE           = Get-Cfg "PGPASSFILE" ".pgpass"           # resolved against INSTALL_ROOT below
$WEB_CERT_FILE        = Get-Cfg "WEB_CERT_FILE" "demo-dart.pem"
$WEB_KEY_FILE         = Get-Cfg "WEB_KEY_FILE"  "demo-dart.key"
# --- FastAPI (kept for when Step 14 is re-enabled - unused today) ---
$FASTAPI_HOST                = Get-Cfg "FASTAPI_HOST" "127.0.0.1"
$FASTAPI_PORT                = Get-Cfg "FASTAPI_PORT" "5000"
$FASTAPI_APP                 = Get-Cfg "FASTAPI_APP" "app.main:app"
$FASTAPI_INTERNAL_JWT_SECRET = Get-Cfg "FASTAPI_INTERNAL_JWT_SECRET" ""
# --- Airflow ---
$AIRFLOW_PORT          = Get-Cfg "AIRFLOW_PORT" "8080"
$BRANCH_AIRFLOW        = Get-Cfg "BRANCH_AIRFLOW" "UAT"
$AIRFLOW_PG_USER       = Get-Cfg "AIRFLOW_PG_USER" "usr_dr_air_rw"
$AIRFLOW_PG_PASSWORD   = Get-Cfg "AIRFLOW_PG_PASSWORD" "admin"
$AIRFLOW_ADMIN_USER    = Get-Cfg "AIRFLOW_ADMIN_USER" "admin"
$AIRFLOW_ADMIN_PASSWORD= Get-Cfg "AIRFLOW_ADMIN_PASSWORD" ""

# Build run-map from -StepList (comma-separated Name list), or every
# cataloged step if -StepList was omitted - the real one-click default.
# OptIn steps (currently just NodeJS) are excluded from that "every
# step" default - they only run when explicitly named in -StepList, same
# as the GUI's unchecked-by-default behavior for them.
$run = @{}
if ([string]::IsNullOrWhiteSpace($StepList)) {
    foreach ($comp in $components) {
        $isOptIn = ($comp.PSObject.Properties.Name -contains 'OptIn' -and $comp.OptIn)
        $run[$comp.Name] = -not $isOptIn
    }
    Write-Host "  -StepList not given: running all steps except opt-in ones (NodeJS)." -ForegroundColor Cyan
} else {
    $requested = $StepList -split ',' | ForEach-Object { $_.Trim() } | Where-Object { $_ -ne "" }
    foreach ($comp in $components) { $run[$comp.Name] = $false }
    foreach ($name in $requested) {
        if ($components.Name -contains $name) { $run[$name] = $true }
        else { Write-Host "  [WARNING] Unknown component '$name' in -StepList - ignored." -ForegroundColor Yellow }
    }
    Write-Host "  Running steps: $($requested -join ', ')" -ForegroundColor Cyan
}
}

# ===========================================================================
# Derive all paths from config variables
# ===========================================================================
$BACKEND_ROOT   = "$INSTALL_ROOT\backend"
$FRONTEND_ROOT  = "$INSTALL_ROOT\frontend"
$BACKEND_DIR    = "$BACKEND_ROOT\Data_Recon_Backend"
$FRONTEND_DIR   = "$FRONTEND_ROOT\Data_Recon_Frontend"
$DB_ROOT        = "$INSTALL_ROOT\Database"
$DB_DIR         = "$DB_ROOT\Data_Recon_Database"
$DB_AI_DIR      = "$INSTALL_ROOT\Database_AI\Data_Recon_Database"   # Auto_Draft_AI checkout (recon_ai)
$DB_SCRIPT_DIR  = "$DB_DIR\setup_scripts"
$PYTHON_DEST    = "$TOOLS_ROOT\Python"

# ---------------------------------------------------------------------------
# Certificate / credential file paths
# ---------------------------------------------------------------------------
# These used to be fixed in code (Nginx: $INSTALL_ROOT\demo-dart.pem/.key) or
# defaulted to the old install folder C:\DARTV1, whatever INSTALL_ROOT was.
# A client certificate with any other name was not found, and the installer
# quietly self-signed one instead.
#
# A bare file name is looked up in INSTALL_ROOT; a full path is used as it is.
function Resolve-InstallFile([string]$value, [string]$default) {
    $v = "$value".Trim().Trim('"')
    if (-not $v) { $v = $default }
    if ([System.IO.Path]::IsPathRooted($v)) { return $v }
    return (Join-Path $INSTALL_ROOT $v)
}

# Web (Nginx/HTTPS) certificate - see Step 10. The demo-dart.* defaults keep
# existing installs unchanged; the self-signed fallback applies to them only.
$WEB_CERT_DEFAULT_NAME = "demo-dart.pem"
$WEB_KEY_DEFAULT_NAME  = "demo-dart.key"
$WEB_CERT_PATH = Resolve-InstallFile $WEB_CERT_FILE $WEB_CERT_DEFAULT_NAME
$WEB_KEY_PATH  = Resolve-InstallFile $WEB_KEY_FILE  $WEB_KEY_DEFAULT_NAME
$WEB_CERT_IS_DEFAULT = ($WEB_CERT_PATH -eq (Join-Path $INSTALL_ROOT $WEB_CERT_DEFAULT_NAME)) -and
                       ($WEB_KEY_PATH  -eq (Join-Path $INSTALL_ROOT $WEB_KEY_DEFAULT_NAME))
# Written next to a certificate this installer generated, so -Clean can tell
# it apart from a client's real one and never delete the latter.
$WEB_CERT_SELFSIGNED_MARKER = "$WEB_CERT_PATH.dart-selfsigned"

# SSLPATH is the CA bundle for the DATABASE server's certificate (libpq
# sslrootcert), not the web certificate. It used to default to
# C:\DARTV1\demo-dart.pem - the web certificate, in the old install folder.
# Any value pointing at the web certificate is replaced here.
$DB_CA_DEFAULT_NAME = "root_ca.pem"
$SSLPATH = Resolve-InstallFile $SSLPATH $DB_CA_DEFAULT_NAME
if ($SSLPATH -eq $WEB_CERT_PATH -or (Split-Path $SSLPATH -Leaf) -eq $WEB_CERT_DEFAULT_NAME) {
    $fixedSslPath = Join-Path $INSTALL_ROOT $DB_CA_DEFAULT_NAME
    if ($SSLMODE -ne "disable") {
        Write-Host "  [WARNING] SSLPATH '$SSLPATH' is the web certificate, not the database CA - using $fixedSslPath instead." -ForegroundColor Yellow
    }
    $SSLPATH = $fixedSslPath
}
if ($SSLPATH -match '\s' -and $SSLMODE -ne "disable") {
    # The backend builds libpq connection strings with the path unquoted
    # (utils/fetch_query.py, update_query.py), so a space breaks them.
    Write-Host "  [WARNING] SSLPATH '$SSLPATH' contains a space - the backend's DB connection string will break. Use a path without spaces." -ForegroundColor Yellow
}

# PGPASSFILE: a bare name is looked up in INSTALL_ROOT, a full path is used
# as it is. Step 1 writes this file, Step 9 hands it to az_exec.ps1, and
# .env points at it, so all three always use the same file.
# A full path left over from another install root (e.g. C:\DART_DEPLOY\.pgpass
# after INSTALL_ROOT moved to D:) whose folder does not exist falls back to
# INSTALL_ROOT\.pgpass instead of failing in Step 1.
$_cfgPgPass = Resolve-InstallFile $PGPASSFILE ".pgpass"
$_pgPassDir = Split-Path $_cfgPgPass -Parent
if ($_cfgPgPass.StartsWith($INSTALL_ROOT + '\', [StringComparison]::OrdinalIgnoreCase) -or (Test-Path -LiteralPath $_pgPassDir)) {
    $PGPASSFILE = $_cfgPgPass
} else {
    $PGPASSFILE = Join-Path $INSTALL_ROOT ".pgpass"
    Write-Host "  [WARNING] PGPASSFILE '$_cfgPgPass' - folder '$_pgPassDir' does not exist; using $PGPASSFILE." -ForegroundColor Yellow
}

# Was the HTTPS certificate generated by this installer (safe to delete), or
# provided by the client (never delete)? New self-signed certificates get a
# marker file. Older installs have none, so a certificate at the default name
# that is self-signed for UI_HOST counts as generated too.
function Test-WebCertGenerated {
    if (Test-Path $WEB_CERT_SELFSIGNED_MARKER) { return $true }
    if (-not $WEB_CERT_IS_DEFAULT -or -not (Test-Path $WEB_CERT_PATH)) { return $false }
    try {
        $c = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2($WEB_CERT_PATH)
        return ($c.Subject -eq $c.Issuer -and $c.Subject -eq "CN=$UI_HOST")
    } catch { return $false }
}

# openssl.exe: the portable Git's copy, then PATH, then the copy bundled with
# whatever Git for Windows is on PATH (its \usr\bin and \mingw64\bin are not
# on PATH themselves - common on dev laptops that already had Git installed,
# where Step 2 skips its own portable C:\DART_Tools\git).
function Find-OpenSsl {
    $exe = Join-Path $TOOLS_ROOT "git\usr\bin\openssl.exe"
    if (Test-Path $exe) { return $exe }
    $sys = Get-Command openssl.exe -ErrorAction SilentlyContinue
    if ($sys) { return $sys.Source }
    $sysGit = Get-Command git.exe -ErrorAction SilentlyContinue
    if ($sysGit) {
        $gitRoot = Split-Path (Split-Path $sysGit.Source -Parent) -Parent
        foreach ($candidate in @("$gitRoot\usr\bin\openssl.exe", "$gitRoot\mingw64\bin\openssl.exe")) {
            if (Test-Path $candidate) { return $candidate }
        }
    }
    return $null
}

# Shared secret between Django and Airflow. Django reads the env var
# "django_airflow_secret_key" (lowercase) in settings.py, falling back to
# backend\Data_Recon_Backend\.env and then to the literal default below.
# It signs the X-Internal-Key on /scheduler/rotate_tokens and
# /scheduler/auto_load_tick, and signs the DAG-token JWTs - so if Airflow's
# copy differs from Django's by even one character, token exchange fails
# with a 401 and the DAGs stop being able to call back into Django.
#
# The default matches the dev team's .start_up_vm, which is also Django's
# own fallback, so an untouched deployment agrees on both sides. If the
# backend's committed .env sets a different value on a given VM, put THAT
# value here - verify against the running backend, don't assume.
$DJANGO_AIRFLOW_SECRET_KEY = Get-Cfg "DJANGO_AIRFLOW_SECRET_KEY" "thissecretkeywillbesharedbetweenDjangoandAirflow"

# The WSL2 distribution Airflow runs in. Top-level (not local to the Airflow
# step) so the -Clean handlers can target the same one.
#
# EVERY `wsl` call in this script must pass `-d $WSL_DISTRO`. Without it, wsl
# uses the machine's DEFAULT distro, which is not necessarily the one this
# script installed - so the script would `wsl --install -d Ubuntu-24.04` and
# then do all of its actual work somewhere else entirely.
#
# Found live 2026-09-10 on the EC2 host: three distros were registered
# (Ubuntu-26.04, Ubuntu-24.04, Ubuntu) with Ubuntu-26.04 as default. Airflow
# was installed into 24.04 but every `wsl bash` ran in 26.04, whose Python is
# 3.14 - and apache-airflow 3.1.2 requires >=3.10,<3.14, so pip rejected every
# published Airflow release with a "no matching distribution" error that looks
# like a network problem.
$WSL_DISTRO = Get-Cfg "WSL_DISTRO" "Ubuntu-24.04"

# Whether `-Clean` should also UNREGISTER the WSL distro (deleting the whole
# Linux filesystem), not just Airflow's own state inside it.
#
# Default false, deliberately. The Airflow clean already removes everything
# Airflow owns - both venvs, AIRFLOW_HOME artifacts, the repo checkout and
# the metadata schema - so a rebuild is genuinely clean without it. Removing
# the distro on top of that costs a multi-GB Ubuntu re-download plus a
# reinstall of ~80 Airflow packages on every iteration, which makes a
# debug loop far slower without testing anything extra.
#
# Set it to "true" when you suspect the distro ITSELF is damaged (a broken
# apt state, a corrupt WSL install, or a distro shipping a Python Airflow
# cannot use and no supported one available).
$CLEAN_WSL_DISTRO = (Get-Cfg "CLEAN_WSL_DISTRO" "false") -match '^\s*(?i:true|1|yes|y)\s*$'

# --- Airflow runtime settings ---------------------------------------------
# Default timezone, from the config (Config tab: Advanced -> drop-down).
#
# Airflow needs an IANA zone name. It does NOT accept 'ist': Airflow 3.1
# catches the InvalidTimezone and silently falls back to UTC (settings.py:
# `except Exception: TIMEZONE = utc`), so every VM configured with the old
# 'ist' default actually ran Airflow in UTC (checked 2026-10-14 against
# pendulum 3 and apache-airflow-core 3.1.2). Short names like EST are no
# better: 'EST' is a fixed UTC-5 with no daylight saving.
#
# So common abbreviations are translated to the real zone here, and anything
# else that is not a zone name gets a warning instead of a silent UTC.
# Changing the zone shifts every cron schedule and rendered logical date -
# treat it as a scheduling change.
function Resolve-AirflowTimezone([string]$value) {
    $v = "$value".Trim()
    if (-not $v) { return "Asia/Kolkata" }
    $v = ($v -split '\s+')[0]          # tolerate "Asia/Kolkata (IST)" style input
    $aliases = @{
        'ist' = 'Asia/Kolkata'
        'est' = 'America/New_York'; 'edt' = 'America/New_York'; 'et' = 'America/New_York'
        'cst' = 'America/Chicago';  'cdt' = 'America/Chicago';  'ct' = 'America/Chicago'
        'mst' = 'America/Denver';   'mdt' = 'America/Denver'
        'pst' = 'America/Los_Angeles'; 'pdt' = 'America/Los_Angeles'; 'pt' = 'America/Los_Angeles'
        'gmt' = 'UTC'; 'utc' = 'UTC'; 'bst' = 'Europe/London'
    }
    $key = $v.ToLowerInvariant()
    if ($aliases.ContainsKey($key)) {
        if ($aliases[$key] -cne $v) { Log-Info "Airflow timezone '$v' -> '$($aliases[$key])'." }
        return $aliases[$key]
    }
    if ($v -notmatch '^[A-Za-z_]+(/[A-Za-z0-9_+\-]+)+$' -and $v -ne 'UTC') {
        Log-Warn "Airflow timezone '$v' does not look like an IANA zone name (e.g. Asia/Kolkata). Airflow will silently fall back to UTC if it cannot parse it."
    }
    return $v
}
# GUI mode: take the Config tab's current value (Advanced fields are not
# otherwise re-read after the dialog closes). Silent mode: the config file.
$_tzRaw = if ($script:advTb -and $script:advTb.Contains("AIRFLOW_DEFAULT_TIMEZONE")) {
    $script:advTb["AIRFLOW_DEFAULT_TIMEZONE"].Text
} else {
    Get-Cfg "AIRFLOW_DEFAULT_TIMEZONE" "Asia/Kolkata"
}
$AIRFLOW_DEFAULT_TIMEZONE = Resolve-AirflowTimezone $_tzRaw

# --- Commit pinning -------------------------------------------------------
# Each repo can be pinned to an exact commit SHA instead of tracking its
# branch. Empty (the default) means 'branch HEAD' - identical to the
# previous behaviour.
#
# Tracking a branch makes a deployment irreproducible: two runs a day apart
# install different code from the same config, and a broken box can only be
# described as 'whatever UAT was on Tuesday'. Pinning makes the config a
# complete description of what is installed, which is what lets a rebuild
# be a rebuild rather than a fresh roll of the dice.
# When a fresh install ends clean but needs the WSL reboot, offer the
# restart and schedule DART-Resume-Setup.ps1 to finish Airflow at the next
# logon. Set false for the old behaviour (banner + run the step by hand).
$AUTO_RESUME_AFTER_RESTART = (Get-Cfg "AUTO_RESUME_AFTER_RESTART" "true") -match '^\s*(?i:true|1|yes|y)\s*$'

$COMMIT_BACKEND  = Get-Cfg "COMMIT_BACKEND"  ""
$COMMIT_FRONTEND = Get-Cfg "COMMIT_FRONTEND" ""
$COMMIT_DB       = Get-Cfg "COMMIT_DB"       ""
$COMMIT_AIRFLOW  = Get-Cfg "COMMIT_AIRFLOW"  ""
foreach ($cp in @(
        @{ n = 'Backend';  v = $COMMIT_BACKEND },
        @{ n = 'Frontend'; v = $COMMIT_FRONTEND },
        @{ n = 'Database'; v = $COMMIT_DB },
        @{ n = 'Airflow';  v = $COMMIT_AIRFLOW })) {
    if ($cp.v) { Log-Info "$($cp.n) is PINNED to commit $($cp.v) (branch tracking disabled for this repo)." }
}

# CORS for the Airflow REST API. ALLOW_ORIGINS alone is not enough: a browser
# preflights any request carrying Content-Type or a custom header with an
# OPTIONS call, and rejects the response unless the matching headers and
# methods are advertised too. The real request is then never sent, which
# surfaces as a bare CORS error in the console with nothing in Airflow's log.
$AIRFLOW_CORS_ALLOW_HEADERS = Get-Cfg "AIRFLOW_CORS_ALLOW_HEADERS" "origin, content-type, accept"
$AIRFLOW_CORS_ALLOW_METHODS = Get-Cfg "AIRFLOW_CORS_ALLOW_METHODS" "POST, GET, OPTIONS, DELETE"
$AIRFLOW_JWT_EXPIRATION     = Get-Cfg "AIRFLOW_JWT_EXPIRATION_TIME" "28800"

# SMTP for the AIRFLOW_CONN_SMTP_DART connection that DAG email tasks use.
# Each key DEFAULTS to the EMAIL_* value Django already uses, so by default
# there is one mail configuration on the box instead of two that can drift.
# Set the SMTP_* keys explicitly only when Airflow must send as a different
# identity or through a different relay than Django.
# Airflow's SMTP connection reuses Django's EMAIL_* settings directly.
#
# There used to be a parallel set of SMTP_* config keys here. Every one of
# them defaulted to the matching EMAIL_* value and every one was left blank,
# so they were pure aliases: a second place to look for the same setting,
# five extra GUI fields, and five chances for the two to silently disagree -
# in exchange for behaviour nobody was using. Removed 2026-09-12.
#
# If Airflow ever genuinely needs to send as a different identity than
# Django, add back the ONE key that differs, deliberately - not a parallel
# set that shadows the whole email configuration.
$SMTP_HOST      = $EMAIL_HOST
$SMTP_PORT      = $EMAIL_PORT
$SMTP_MAIL_FROM = $EMAIL_HOST_USER
$SMTP_PASSWORD  = $EMAIL_HOST_PASSWORD
$SMTP_STARTTLS  = $EMAIL_USE_TLS

# Kept: there is no EMAIL_* equivalent (Django has no EMAIL_USE_SSL here)
# and the connection URI needs an explicit ssl= value.
$SMTP_SSL       = Get-Cfg "SMTP_SSL" "False"

# DAG processor refresh interval - lowered to 30s so newly generated DAGs
# are scanned and appear in the UI quickly rather than waiting Airflow's 300s default.
$AIRFLOW_DAG_PROCESSOR_REFRESH_INTERVAL          = Get-Cfg "AIRFLOW_DAG_PROCESSOR_REFRESH_INTERVAL" "30"
$AIRFLOW_DAG_PROCESSOR_MIN_FILE_PROCESS_INTERVAL = Get-Cfg "AIRFLOW_DAG_PROCESSOR_MIN_FILE_PROCESS_INTERVAL" "30"

# Azure Blob Storage credentials for Airflow DAG WasbHook (AIRFLOW_CONN_BLOB_DART).
$AZURE_AC_NAME  = Get-Cfg "AZURE_AC_NAME"  "dartblobdevaccount"
$AZURE_BLOB_KEY = Get-Cfg "AZURE_BLOB_KEY" "eCJAdCZPqgqv4Bt4bQeL/BVi5i8W/CNyx2Ajde4q601PDCqD+znM4ImXAtYYnEhEZ2UKxQg0u5aj+AStALbddA=="

# Interface Uvicorn BINDS to - deliberately separate from $API_HOST, which is
# the address everything else CONNECTS to (nginx proxy_pass, the browser
# smoke test, seed_script). Those must stay 127.0.0.1; the listener must not.
#
# Binding to 127.0.0.1 means Django is reachable ONLY over true loopback.
# Every Windows-side component (nginx, FastAPI) is fine with that, but
# Airflow runs inside WSL2 - a separate network namespace whose traffic
# arrives on the vEthernet (WSL) adapter, not loopback. Found live
# 2026-09-09: a DAG calling /run_import/fetch_blob_file hit
# "Connection to 172.27.64.1 timed out" because nothing was listening on
# that interface.
#
# This is the exact same problem, and the exact same fix, as PostgreSQL's
# listen_addresses = '*' further down - Postgres was corrected for WSL2
# reachability, Uvicorn was missed. Exposure is still bounded by the
# Windows firewall rule (DART-Uvicorn-API-8000) and, on EC2, by the
# security group, which restricts 8000 to specific addresses.
$API_BIND_HOST = Get-Cfg "API_BIND_HOST" "0.0.0.0"

# Delete the Database repo checkout once Step 9 has finished building the
# database. Nothing downstream reads it: Step 9b is disabled, Step 9 itself
# re-clones before it runs, and it prefers our own az_exec.ps1 (shipped
# beside this script) over the repo's copy - so removing it costs nothing
# and keeps the DB team's SQL source off a delivered VM. No GUI field; set
# it to "false" in dart_deploy_config.json when you need the .sql files on
# the box to debug a build.
$DELETE_DB_REPO_AFTER_SETUP = (Get-Cfg "DELETE_DB_REPO_AFTER_SETUP" "true") -match '^\s*(?i:true|1|yes|y)\s*$'
$LOG_DIR        = Join-Path $INSTALL_ROOT "logs"
$AIRFLOW_REPO_ROOT = Join-Path $INSTALL_ROOT "airflow"
$AIRFLOW_REPO_DIR  = Join-Path $AIRFLOW_REPO_ROOT "Data-Recon-Airflow"

# ---------------------------------------------------------------------------
# Recon_Files (runtime media root)
#
# Lives at $INSTALL_ROOT level - a SIBLING of backend\, frontend\, Database\
# and airflow\, NOT a child of the backend checkout. It used to sit at
# $BACKEND_DIR\Recon_Files, which put runtime data (uploaded recon files,
# generated DAGs, Airflow's home) *inside* a git working tree: every
# Update-Or-Clone on the backend does `git reset --hard`, and any future
# .gitignore change or a switch to a source-protecting sparse clone (the
# frontend already does one) would put customer data at risk of being wiped
# with the checkout. Runtime state and source code now live side by side
# instead of nested.
#
# $RECON_FILES_DIR is the canonical location. $MEDIA_DIR_WIN is the location
# actually in effect (honours an explicitly-configured MEDIA_PATH, and
# resolves a drive-letter-less value like "/app/Recon_Files" the same way
# Windows itself would - relative to the current drive). Everything that
# needs the media root on disk - Step 1's .env, Airflow's AIRFLOW_HOME, the
# -Clean handler - reads $MEDIA_DIR_WIN so they can never drift apart.
# ---------------------------------------------------------------------------
$RECON_FILES_DIR        = "$INSTALL_ROOT\Recon_Files"
$RECON_FILES_LEGACY_DIR = "$BACKEND_DIR\Recon_Files"

# Normalise a MEDIA_PATH left over from the old layout. A dart_deploy_config
# .json saved before this change still holds the backend-nested path, and
# Get-Cfg would happily keep handing it back forever - silently defeating
# the move on every already-provisioned VM. Rewrite it here, once, loudly.
if ($MEDIA_PATH -match '[\\/]backend[\\/]Data_Recon_Backend[\\/]Recon_Files[\\/]?$') {
    Log-Warn "MEDIA_PATH in config still points inside the backend checkout ('$MEDIA_PATH')."
    Log-Warn "  Using the current layout instead: $RECON_FILES_DIR (Recon_Files is a sibling of backend\, not a child)."
    Log-Warn "  Save Config once to make this permanent in dart_deploy_config.json."
    $MEDIA_PATH = $RECON_FILES_DIR
}

# Resolve MEDIA_PATH to a real, absolute Windows directory. TrimEnd is
# applied to BOTH branches, not just the drive-lettered one: a configured
# "/app/Recon_Files/" would otherwise resolve to "C:\app\Recon_Files\" and
# every log line, comparison and -ne test against it would carry a stray
# trailing separator.
#
# $( ) , not ( ) : "(if ...)" PARSES on PowerShell 5.1 but blows up at
# runtime with "The term 'if' is not recognized as the name of a cmdlet" -
# inside plain parentheses `if` is read as a command name, not a statement.
# Only the $( ) subexpression operator accepts a statement here.
$MEDIA_DIR_WIN = $(if ($MEDIA_PATH -match '^[A-Za-z]:') {
    $MEDIA_PATH
} else {
    Join-Path $env:SystemDrive ($MEDIA_PATH.TrimStart('/', '\').Replace('/', '\'))
}).TrimEnd('\', '/')

# Windows path -> WSL2 /mnt/<drive>/... path. Airflow runs inside WSL2 and
# needs the same directory Windows-side Django writes to; this is the one
# place that translation happens.
# Distro names WSL accepts differ by Windows build and WSL version -
# "Ubuntu-24.04" is not present in every catalog, and when it is missing
# `wsl --install -d Ubuntu-24.04` fails and prints "use 'wsl --list --online'
# to list available distributions", i.e. it asks a human to go and pick one.
# These two helpers do that lookup automatically instead.
#
# Output is stripped of NUL bytes first: wsl.exe emits UTF-16LE, which
# PowerShell reads as a string with a NUL between every character, so naive
# matching against it silently finds nothing.
function Get-WslOnlineDistro {
    $raw = ((& wsl --list --online 2>&1 | Out-String) -replace "`0", '')
    $names = @()
    foreach ($line in ($raw -split "`r?`n")) {
        $t = $line.Trim()
        if (-not $t) { continue }
        # Skip the banner and the column header
        if ($t -match '^(NAME\b|The following|Install using)') { continue }
        $first = ($t -split '\s{2,}|\s+')[0]
        if ($first -match '^[A-Za-z][A-Za-z0-9._-]*$') { $names += $first }
    }
    return @($names | Select-Object -Unique)
}

# Pick the best distro actually offered by this machine's catalog.
# Deliberately picks 24.04 and does NOT reach for the newest
# release: Ubuntu 26.04 ships Python 3.14, which no released Airflow supports
# (needs >=3.10,<3.14), so "newest" is the wrong default here.
function Resolve-WslDistro($preferred) {
    $avail = Get-WslOnlineDistro
    if (-not $avail -or $avail.Count -eq 0) { return $null }
    # Only releases whose Python Airflow supports. The generic "Ubuntu" entry
    # used to be a fallback here, but it now points at 26.04 (Python 3.14),
    # so it is never picked - and 22.04 (Python 3.10) cannot import the DART DAGs. A missing 24.04 is reported instead.
    foreach ($cand in @($preferred, 'Ubuntu-24.04')) {
        if ($cand -and $cand -match '^Ubuntu-24\.04$' -and ($avail -contains $cand)) { return $cand }
    }
    return $null
}

# ---------------------------------------------------------------------------
# Make sure Airflow gets a WSL distro it can run on (Ubuntu 24.04)
# ---------------------------------------------------------------------------
# The distro used to be installed ONLY when WSL itself was missing. On a
# machine that already had WSL2 - e.g. a client with just Ubuntu 26.04, or
# WSL with no distro at all - the install was skipped and every later
# `wsl -d Ubuntu-24.04` failed with "no distribution with the supplied name",
# much of it hidden behind 2>$null.
#
# Ensure-WslDistro runs every time AirflowSetup finds WSL available:
#   - installs Ubuntu-24.04 ALONGSIDE whatever is there if it is missing;
#     other distros are never removed or upgraded and the default distro is
#     not changed (26.04 cannot be downgraded - side by side is the only way)
#   - checks what is really inside: Ubuntu 24.04, running as WSL 2, with
#     Python 3.12/3.13 (Airflow needs <3.14, the DART DAGs need >=3.12)
#   - 22.04 is no longer a fallback (Python 3.10 - see WslSupportedReleases);
#     when the configured distro is not 24.04 it switches to 24.04 and writes the
#     distro it settles on to WSL_DISTRO in the config, so DART-Start /
#     DART-Stop / DART-AutoStart target the same one
# 24.04 only. 22.04 used to be the fallback, but its Python is 3.10 and the
# DART DAGs need 3.12 (f-string syntax, PEP 701): an Airflow on 22.04 starts
# fine and then cannot import system_dag.py (EC2 2026-10-19).
$script:WslSupportedReleases = @('24.04')
$script:WslVirtErrorSeen = $false

# ---------------------------------------------------------------------------
# WSL 2 virtualization preflight
# ---------------------------------------------------------------------------
# `wsl --status` succeeding only proves wsl.exe is installed - it says nothing
# about whether WSL 2 can start a VM. A client VM (2026-10-16) had WSL
# installed but no nested virtualization: the feature-enable block was
# skipped, `wsl --install -d Ubuntu-24.04` failed with
# HCS_E_HYPERV_NOT_INSTALLED, 22.04 failed the same way, and the log ended
# with "check this machine is online" - pointing at the network, not at the
# hypervisor. So the hypervisor is checked on every run, not just a fresh one.
#
# States:
#   Ready            hypervisor running and VirtualMachinePlatform enabled
#   NeedsFeature     VirtualMachinePlatform not enabled (enable + restart)
#   NeedsRestart     enabled, restart still pending - one restart
#   HypervisorOff    enabled and restarted, CPU virtualization available, but
#                    the hypervisor is not running (bcdedit
#                    hypervisorlaunchtype off, or nested virtualization lost)
#   NoVirtualization no hypervisor and the CPU exposes no virtualization -
#                    nothing this script can fix (BIOS / nested virtualization)
#   Unknown          the feature state could not be read (not admin) - carry
#                    on and let the install report what happens
#
# HypervisorPresent is True on ANY virtual machine - it reports the cloud's
# own hypervisor, not the Windows one WSL 2 needs (seen on a fresh EC2 VM
# 2026-10-19: True with WSL not even installed). So on a VM it never proves
# WSL 2 can start, and NoVirtualization/HypervisorOff are only reached on
# physical machines. On a VM without nested virtualization the verdict comes
# from WSL's own HCS_E_HYPERV_NOT_INSTALLED error instead (Test-WslVirtError).
function Test-WslVirtualization {
    $r = [ordered]@{ State = 'Unknown'; Hypervisor = $null; CpuVirt = $null; Feature = '' }
    try { $r.Hypervisor = [bool](Get-CimInstance Win32_ComputerSystem -ErrorAction Stop).HypervisorPresent } catch { }
    # Reports False while a hypervisor is already running, so it is only
    # meaningful when HypervisorPresent is False - which is the only time it is used.
    try { $r.CpuVirt = [bool]((Get-CimInstance Win32_Processor -ErrorAction Stop | Select-Object -First 1).VirtualizationFirmwareEnabled) } catch { }
    try { $r.Feature = "$((Get-WindowsOptionalFeature -Online -FeatureName VirtualMachinePlatform -ErrorAction Stop).State)" } catch { }

    # NoVirtualization only once the feature is confirmed Enabled. Before that
    # (fresh machine, or feature state unreadable) the CPU flag alone is not
    # trusted to block: it is the one input this has not been verified against
    # on every VM type, and a wrong "no" would stop a working fresh install.
    # Enabling the feature first costs at most one restart; the next run then
    # gets here with the feature Enabled and reports it properly.
    if ($r.Hypervisor -eq $false -and $r.CpuVirt -eq $false -and $r.Feature -eq 'Enabled') { $r.State = 'NoVirtualization' }
    elseif ($r.Feature -eq 'EnablePending')                     { $r.State = 'NeedsRestart' }
    elseif ($r.Feature -and $r.Feature -ne 'Enabled')           { $r.State = 'NeedsFeature' }
    elseif ($r.Feature -eq 'Enabled' -and $r.Hypervisor)        { $r.State = 'Ready' }
    elseif ($r.Feature -eq 'Enabled' -and $r.Hypervisor -eq $false) { $r.State = 'HypervisorOff' }
    return [pscustomobject]$r
}

# Error text WSL prints when it cannot start a WSL 2 VM.
function Test-WslVirtError([string]$text) {
    # Specific error strings only - a plain "Virtual Machine Platform" also
    # appears in wsl --install's normal "Installing: Virtual Machine Platform"
    # progress output and must not trigger the no-virtualization message.
    return ($text -match 'HCS_E_HYPERV_NOT_INSTALLED|0x80370102|VIRTUAL_MACHINE_PLATFORM_REQUIRED|enable the Virtual Machine Platform|virtualization is enabled in the BIOS')
}

# "A specified logon session does not exist" (0x80070520): WSL refuses to run
# for an account that is not actually logged on in its own session. That is
# exactly the case when a standard user elevates with an administrator's
# password: the process runs AS the administrator inside the standard user's
# desktop (EC2 2026-10-19: Administrator on dart-test's session - wsl --update
# and wsl --install both failed this way). Restarting or retrying cannot fix it.
$script:WslLogonErr = $false
function Test-WslLogonSessionError([string]$text) {
    return ($text -match 'logon session does not exist|0x80070520')
}

function Get-DesktopSessionUser {
    # Owner of the desktop (explorer.exe) in this process's session; $null when
    # it cannot be read (-IncludeUserName needs elevation).
    try {
        $sess = (Get-Process -Id $PID).SessionId
        return (Get-Process explorer -IncludeUserName -ErrorAction Stop |
                Where-Object { $_.SessionId -eq $sess -and $_.UserName } | Select-Object -First 1).UserName
    } catch { return $null }
}

function Write-WslLogonHelp {
    $runUser  = "$env:USERDOMAIN\$env:USERNAME"
    $deskUser = Get-DesktopSessionUser
    Log-Err "WSL refused to run: 'A specified logon session does not exist'."
    if ($deskUser -and $deskUser -ne $runUser) {
        Log-Warn "  This setup is running as $runUser inside $deskUser's desktop (elevated with another account's password)."
    } else {
        Log-Warn "  This setup is running as $runUser, which is not logged on in its own desktop session (runas / remote shell / task)."
    }
    Log-Warn "  WSL - and so Airflow - only runs for an account that is actually logged on. Restarting or retrying will not help."
    Log-Warn "  Fix: sign out, log on to this machine (RDP) directly as $runUser, and run only this step:"
    Log-Warn "    .\VM-Windows-Bash-Script_V2.ps1 -Silent -StepList `"AirflowSetup`""
    Log-Warn "  Everything else (database, backend, frontend, Nginx) is already installed and is not repeated."
}

function Write-WslVirtHelp {
    Log-Err "WSL 2 cannot start a virtual machine on this computer - no hardware virtualization is available (HCS_E_HYPERV_NOT_INSTALLED)."
    Log-Warn "  This is not a network or distro problem, and the script cannot fix it. It needs one of:"
    Log-Warn "    Virtual machine - the host must expose nested virtualization to this VM:"
    Log-Warn "      AWS EC2: an instance type that supports it, with CPU option NestedVirtualization=enabled"
    Log-Warn "      Azure:   a VM size that supports nested virtualization"
    Log-Warn "      VMware:  'Expose hardware assisted virtualization to the guest OS'"
    Log-Warn "      Hyper-V: Set-VMProcessor -VMName <vm> -ExposeVirtualizationExtensions `$true (VM powered off)"
    Log-Warn "    Physical machine - enable Intel VT-x / AMD-V in the BIOS/UEFI."
    Log-Warn "  Then restart this machine and re-run only this step:"
    Log-Warn "    .\VM-Windows-Bash-Script_V2.ps1 -Silent -StepList `"AirflowSetup`""
    Log-Warn "  DART-Check-Wsl.ps1 shows the virtualization state without changing anything."
}

function Get-WslRegisteredDistro {
    # -q prints names only. With no distro at all wsl exits non-zero and prints
    # a sentence instead, which must not be read as a distro name.
    $raw = ((& wsl -l -q 2>&1 | Out-String) -replace "`0", '')
    if ($LASTEXITCODE -ne 0) { return @() }
    return @($raw -split "`r?`n" | ForEach-Object { $_.Trim() } | Where-Object { $_ -match '^[A-Za-z][A-Za-z0-9._-]*$' })
}

function Get-WslDistroWslVersion($distro) {
    $raw = ((& wsl -l -v 2>&1 | Out-String) -replace "`0", '')
    foreach ($line in ($raw -split "`r?`n")) {
        $parts = @(($line -replace '^\s*\*?\s*', '') -split '\s+' | Where-Object { $_ })
        if ($parts.Count -ge 3 -and $parts[0] -eq $distro) { return [int]$parts[-1] }
    }
    return 0
}

# Runs a short command in a distro as root, with a timeout - the first launch
# of a distro can sit on an interactive prompt, which would hang the script.
function Invoke-WslRootCmd($distro, [string[]]$cmd, [int]$timeoutSec = 120) {
    $job = Start-Job -ScriptBlock { param($d, $c) & wsl -d $d -u root -- @c 2>&1 } -ArgumentList $distro, $cmd
    $out = $null
    if (Wait-Job $job -Timeout $timeoutSec) { $out = ((Receive-Job $job | Out-String) -replace "`0", '') }
    Stop-Job $job -ErrorAction SilentlyContinue | Out-Null
    Remove-Job $job -Force -ErrorAction SilentlyContinue
    return $out
}

function Get-WslDistroInfo($distro) {
    $info = [ordered]@{ Ok = $false; Release = ''; Python = '' }
    $os = Invoke-WslRootCmd $distro @('cat', '/etc/os-release')
    if ($null -eq $os) { return $info }
    # Registered, but WSL 2 cannot start it - the error text comes back as
    # output and must not be parsed as an os-release of "unknown release".
    if (Test-WslVirtError $os) { $script:WslVirtErrorSeen = $true; return $info }
    if ($os -match '(?m)^VERSION_ID="?([0-9.]+)"?') { $info.Release = $Matches[1] }
    $py = Invoke-WslRootCmd $distro @('sh', '-c', 'command -v python3.12 || command -v python3.13 || true') 60
    if ($py -and $py.Trim()) { $info.Python = (($py.Trim() -split "`r?`n")[0] -split '/')[-1] }
    else {
        $v = Invoke-WslRootCmd $distro @('python3', '--version') 60
        if ($v -match 'Python 3\.(1[23])\b') { $info.Python = "python3 (3.$($Matches[1]))" }
    }
    $info.Ok = $true
    return $info
}

function Install-WslDistro($distro) {
    Log-Info "Installing WSL distro '$distro' (alongside any existing ones - this can take a few minutes)..."
    # Logged line by line as it arrives (the install takes minutes) and kept
    # for the error check below. Log-Info only writes to the host, so it does
    # not end up in $instOut.
    $instOut = @(& wsl --install -d $distro --no-launch 2>&1 | ForEach-Object { $t = ("$_" -replace "`0", '').Trim(); if ($t) { Log-Info "  $t"; $t } })
    $instExit = $LASTEXITCODE
    if (Test-WslVirtError ($instOut -join "`n")) { $script:WslVirtErrorSeen = $true }
    if (Test-WslLogonSessionError ($instOut -join "`n")) { $script:WslLogonErr = $true }
    if ($instExit -ne 0) {
        Log-Warn "'$distro' could not be installed (exit $instExit)."
        return $false
    }
    # First launch as root: completes the install without the interactive
    # UNIX username prompt.
    $ready = Invoke-WslRootCmd $distro @('echo', 'ready') 180
    if (Test-WslVirtError $ready) {
        $script:WslVirtErrorSeen = $true
        Log-Warn "'$distro' was registered but cannot start - WSL 2 has no virtualization (see below)."
        return $false
    }
    if ($ready -notmatch 'ready') {
        Log-Warn "'$distro' was installed but its first start did not finish within 180s."
        Log-Warn "  Run 'wsl -d $distro' once by hand to finish its first-time setup, then re-run AirflowSetup."
        return $false
    }
    Log-Ok "WSL distro '$distro' installed and initialized."
    return $true
}

function Save-CfgKey($key, $value) {
    if (-not (Test-Path $script:CONFIG_FILE)) { return }
    try {
        $merged = [ordered]@{}
        $prev = Get-Content $script:CONFIG_FILE -Raw -Encoding UTF8 | ConvertFrom-Json
        foreach ($p in $prev.PSObject.Properties) { $merged[$p.Name] = $p.Value }
        $merged[$key] = $value
        $merged | ConvertTo-Json -Depth 3 | Set-Content $script:CONFIG_FILE -Encoding UTF8
        Log-Ok "Saved $key=$value to $($script:CONFIG_FILE)."
    } catch {
        Log-Warn "Could not save $key to $($script:CONFIG_FILE): $($_.Exception.Message) - set it by hand."
    }
}

function Ensure-WslDistro {
    $registered = Get-WslRegisteredDistro
    Log-Info "Registered WSL distros: $(if ($registered.Count) { $registered -join ', ' } else { '(none)' })"
    $configured = $script:WSL_DISTRO
    $candidates = @($configured, 'Ubuntu-24.04') | Where-Object { $_ } | Select-Object -Unique

    foreach ($cand in $candidates) {
        # WSL will not run at all in this session - trying the next distro
        # would only repeat the same error.
        if ($script:WslLogonErr) { break }
        if ($registered -notcontains $cand) {
            if ($cand -notmatch '^Ubuntu-24\.04$') {
                Log-Warn "WSL_DISTRO '$cand' is not registered and is not a release this installer installs - trying Ubuntu-24.04 instead."
                continue
            }
            Log-Warn "'$cand' is not installed in WSL - installing it. Existing distros are left untouched and the default distro is not changed."
            if (-not (Install-WslDistro $cand)) { continue }
            $registered = Get-WslRegisteredDistro
        }

        $wslVer = Get-WslDistroWslVersion $cand
        if ($wslVer -eq 1) {
            Log-Warn "'$cand' runs as WSL 1 - converting it to WSL 2 (Airflow needs WSL 2)..."
            $convOut = @(& wsl --set-version $cand 2 2>&1 | ForEach-Object { $t = ("$_" -replace "`0", '').Trim(); if ($t) { Log-Info "  $t"; $t } })
            if (Test-WslVirtError ($convOut -join "`n")) { $script:WslVirtErrorSeen = $true }
            if ((Get-WslDistroWslVersion $cand) -ne 2) { Log-Warn "'$cand' could not be converted to WSL 2."; continue }
        } elseif ($wslVer -ne 2) {
            # 0 = its line in `wsl -l -v` could not be read. Used to fall
            # through and be accepted without ever confirming WSL 2.
            Log-Warn "Could not read the WSL version of '$cand' from 'wsl -l -v' - not using it without confirming WSL 2."
            & wsl -l -v 2>&1 | ForEach-Object { $t = ("$_" -replace "`0", '').Trim(); if ($t) { Log-Info "  $t" } }
            continue
        }

        $info = Get-WslDistroInfo $cand
        if (-not $info.Ok) {
            Log-Warn "'$cand' did not respond within the timeout - it may be stuck on first-time setup. Run 'wsl -d $cand' once by hand."
            continue
        }
        if ($script:WslSupportedReleases -notcontains $info.Release) {
            Log-Warn "'$cand' is Ubuntu $(if ($info.Release) { $info.Release } else { '(unknown release)' }) - Airflow is installed only into Ubuntu 24.04 (the DART DAGs need its Python 3.12). It is left as it is; trying the next option."
            continue
        }
        if (-not $info.Python) {
            Log-Warn "'$cand' (Ubuntu $($info.Release)) has no Python 3.12/3.13 yet - AirflowSetup installs python3.12 into it next."
        }

        Log-Ok "Airflow will use WSL distro '$cand' (Ubuntu $($info.Release), WSL 2$(if ($info.Python) { ", $($info.Python)" }))."
        if ($cand -ne $configured) {
            Log-Warn "WSL_DISTRO changes from '$configured' to '$cand' for this and every later run."
            # All WSL 2 distros share one network, so an Airflow still running
            # in the old distro keeps port 8080 - the new one cannot bind, and
            # "Airflow is up" would really be the old one (EC2 2026-10-19: the
            # 22.04 Airflow kept serving after 24.04 was chosen). After the
            # config switch DART-Stop no longer targets the old distro either.
            if ($configured -and ($registered -contains $configured)) {
                Log-Info "Stopping the previous Airflow distro '$configured' (wsl --terminate) so it releases port 8080. It is not removed."
                & wsl --terminate $configured 2>&1 | Out-Null
            }
            $script:WSL_DISTRO = $cand
            Save-CfgKey "WSL_DISTRO" $cand
        }
        return $true
    }

    if ($script:WslLogonErr) {
        Write-WslLogonHelp
        return $false
    }
    if ($script:WslVirtErrorSeen) {
        Write-WslVirtHelp
        return $false
    }
    Log-Err "No usable WSL distro for Airflow: Ubuntu 24.04 is not installed and could not be installed."
    Log-Warn "  Check this machine is online and 'wsl --list --online' lists Ubuntu-24.04, then re-run:"
    Log-Warn "    .\VM-Windows-Bash-Script_V2.ps1 -Silent -StepList `"AirflowSetup`""
    Log-Warn "  DART-Check-Wsl.ps1 shows the full picture without changing anything."
    return $false
}

function ConvertTo-WslPath($winPath) {
    $p   = $winPath.TrimEnd('\', '/')
    $drv = $p[0].ToString().ToLower()
    return "/mnt/$drv/" + $p.Substring(3).Replace('\', '/')
}

# Repo URLs - defined once, reused by CloneRepos and by every per-service
# step below that self-syncs its own repo before doing work.
#
# No PAT in the URL (changed 2026-10-14): git saves the clone URL in each
# repo's .git\config, so a PAT-embedded URL left the token on disk in every
# checkout. The PAT is now sent per command as an HTTP header (Get-GitAuth)
# and existing checkouts have their remote URL reset to these clean ones.
$BACKEND_REPO_URL  = "https://dev.azure.com/Donyati-Devops/DART/_git/Data-Recon-Backend"
$FRONTEND_REPO_URL = "https://dev.azure.com/Donyati-Devops/DART/_git/Data-Recon-Frontend"
$DB_REPO_URL       = "https://dev.azure.com/Donyati-Devops/DART/_git/Data-Recon-Database"
$AIRFLOW_REPO_URL  = "https://dev.azure.com/Donyati-Devops/DART/_git/Data-Recon-Airflow"

# Git auth args for any git command that talks to the server - clone, fetch,
# and (in the frontend's --filter=blob:none partial clone) checkout/reset/
# sparse-checkout, which download file contents on demand. Azure DevOps
# accepts Basic auth with an empty user name and the PAT as the password.
# Nothing is written to disk and git does not log request headers.
# Usage: git @(Get-GitAuth) fetch origin $branch
function Get-GitAuth {
    if ([string]::IsNullOrWhiteSpace($GIT_PAT)) { return @() }
    $b64 = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$GIT_PAT"))
    return @('-c', "http.extraHeader=Authorization: Basic $b64")
}

# Update-Or-Clone: pull/reset onto the configured branch's latest commit if
# the repo is already checked out, clone fresh otherwise. Defined at
# top-level (not inside the CloneRepos step) so every step below that needs
# its own repo current can call it directly, whether or not CloneRepos
# itself was in this run - "each service step always fetches latest on its
# configured branch before building on top of it" (2026-08-21 decision),
# not something you have to remember to run as a separate step first.
#
# `git fetch` + `reset --hard origin/<branch>` (not plain `git pull`)
# deliberately discards any local state and matches the remote branch tip
# exactly - correct here since these checkouts are deploy-only and never
# hand-edited; a merge-style pull could otherwise leave a conflict an
# unattended script can't resolve. `reset --hard` only touches TRACKED
# files, so untracked build output (venvs, node_modules, airflow-venv)
# survives an update untouched.
# Pin a checkout to an exact commit. No-op when $commit is empty.
#
# Checked out DETACHED on purpose. If the branch ref were moved to the
# pinned commit instead, a later `git reset --hard origin/<branch>` - which
# several steps do - would silently drag the checkout back to branch HEAD
# and undo the pin with no error. A detached HEAD cannot be moved that way,
# and `git status` states the SHA plainly.
function Checkout-Commit($repoDir, $commit, $label) {
    if ([string]::IsNullOrWhiteSpace($commit)) { return $true }
    if (!(Test-Path "$repoDir\.git")) {
        Log-Err "$label - cannot pin to commit '$commit': no git checkout at $repoDir."
        return $false
    }
    $commit = $commit.Trim()
    Push-Location $repoDir
    try {
        # Usually already present from the branch fetch. If not - a SHA on a
        # different branch, or newer than the fetched ref - ask the server
        # for it directly. Some servers refuse a bare-SHA fetch, so this is
        # attempted rather than assumed, and the checkout below reports the
        # real failure if it did not work.
        & git cat-file -e "$commit^{commit}" 2>$null
        if ($LASTEXITCODE -ne 0) {
            Log-Info "  $label - commit $commit not in the local clone; fetching it directly..."
            & git @(Get-GitAuth) fetch origin $commit 2>&1 | ForEach-Object { Log-Info "    $_" }
        }
        & git @(Get-GitAuth) checkout --detach $commit 2>&1 | ForEach-Object { Log-Info "  $_" }
        if ($LASTEXITCODE -ne 0) {
            Log-Err "$label - could not check out commit '$commit'."
            Log-Err "  Check the COMMIT_* value in dart_deploy_config.json is a real SHA in that repository."
            return $false
        }
        # Verify rather than trust the exit code - a wrong-but-valid ref
        # (a tag, a branch name) would also exit 0 while installing
        # something other than what the config asked for.
        $head = (& git rev-parse HEAD 2>$null)
        if ($head) { $head = $head.Trim() }
        if ($head -and $head.StartsWith($commit)) {
            Log-Ok "$label pinned to commit $($head.Substring(0, [Math]::Min(12, $head.Length)))"
            return $true
        }
        Log-Err "$label - HEAD is '$head' after checking out '$commit'. Refusing to treat that as pinned."
        return $false
    } finally {
        Pop-Location
    }
}

function Update-Or-Clone($repoDir, $branch, $repoUrl, $label, $commit) {
    if ([string]::IsNullOrWhiteSpace($GIT_PAT)) {
        if (Test-Path "$repoDir\.git") {
            Log-Warn "$label - GIT_PAT is empty, cannot sync to latest $branch. Using the existing local checkout as-is."
        } else {
            Log-Err "$label - GIT_PAT is empty and no local checkout exists at $repoDir. Enter a Git PAT in the Config tab first."
        }
        return
    }
    if (!(Test-Path "$repoDir\.git")) {
        Log-Info "Cloning $label (branch: $branch)..."
        git @(Get-GitAuth) clone -b $branch $repoUrl "$repoDir"
        if ($LASTEXITCODE -ne 0) { Log-Err "Failed to clone $label repository." }
        else {
            Log-Ok "$label cloned."
            [void](Checkout-Commit $repoDir $commit $label)
        }
    } else {
        Log-Info "Updating $label (branch: $branch)..."
        Push-Location $repoDir
        try {
            # Drop any PAT-embedded URL an older version of this script left
            # in .git\config; auth now comes from Get-GitAuth per command.
            git remote set-url origin $repoUrl 2>&1 | Out-Null
            git @(Get-GitAuth) fetch origin $branch 2>&1 | ForEach-Object { Log-Info "  $_" }
            if ($LASTEXITCODE -ne 0) {
                Log-Err "Failed to fetch $label - leaving existing checkout as-is."
            } elseif ($commit) {
                # Pinned: go straight to the SHA. Deliberately NOT preceded
                # by `reset --hard origin/<branch>` - that would move the
                # tree to branch HEAD first, so a failed pin would leave the
                # box running newer code than the config asked for.
                [void](Checkout-Commit $repoDir $commit $label)
            } else {
                git checkout $branch 2>&1 | Out-Null
                git reset --hard "origin/$branch" 2>&1 | ForEach-Object { Log-Info "  $_" }
                if ($LASTEXITCODE -ne 0) { Log-Err "Failed to update $label to latest $branch." }
                else { Log-Ok "$label updated to latest $branch." }
            }
        } finally {
            Pop-Location
        }
    }
}

# Extracted from Step 3 (NodeJS) 2026-08-25 so FrontendBuild can call it
# lazily - only when a real npm build actually turns out to be necessary
# (no pre-built "build"/"dist" folder tracked in the repo). Node.js is a
# ~30MB download + install that's now pure waste on any run where the repo
# already ships a pre-built frontend - installing it unconditionally at
# Step 3, long before FrontendBuild even checks whether it's needed, meant
# paying that cost every time regardless. The standalone "NodeJS" step
# still exists and still works exactly as before for anyone who wants to
# explicitly pre-install it (or run the full step-by-step sequence) - both
# just call this same function now, so there's one source of truth.
function Ensure-NodeJS {
    if (Test-Command "npm") {
        Log-Skip "Node.js/NPM"
    } else {
        Log-Info "Node.js not found. Installing into $TOOLS_ROOT..."
        $nodeUrl = "https://nodejs.org/dist/v20.11.0/node-v20.11.0-win-x64.zip"
        Invoke-WebRequest -Uri $nodeUrl -OutFile "$env:TEMP\node.zip"
        Expand-Archive -Path "$env:TEMP\node.zip" -DestinationPath "$env:TEMP\node_temp" -Force
        Move-Item -Path "$env:TEMP\node_temp\node-v20.11.0-win-x64" -Destination "$TOOLS_ROOT\nodejs" -Force
        Add-To-Path "$TOOLS_ROOT\nodejs"
        Log-Ok "Node.js installed."
    }
}

# ---- Initialise the deployment log file (before any step code runs) --------
if (!(Test-Path $LOG_DIR)) { New-Item -ItemType Directory -Path $LOG_DIR -Force | Out-Null }
$script:LOG_FILE = Join-Path $LOG_DIR ("deploy_" + (Get-Date -Format "yyyyMMdd_HHmmss") + ".log")
$_hdr = "=" * 70
Add-Content -Path $script:LOG_FILE -Value $_hdr                                                    -Encoding UTF8
Add-Content -Path $script:LOG_FILE -Value "  DART Deployment Log"                                  -Encoding UTF8
Add-Content -Path $script:LOG_FILE -Value ("  Started  : " + (Get-Date -Format "yyyy-MM-dd HH:mm:ss")) -Encoding UTF8
Add-Content -Path $script:LOG_FILE -Value ("  Script   : $PSCommandPath")                          -Encoding UTF8
Add-Content -Path $script:LOG_FILE -Value ("  InstRoot : $INSTALL_ROOT")                           -Encoding UTF8
Add-Content -Path $script:LOG_FILE -Value ("  ToolsRoot: $TOOLS_ROOT")                             -Encoding UTF8
Add-Content -Path $script:LOG_FILE -Value $_hdr                                                    -Encoding UTF8
# ---------------------------------------------------------------------------

if (!(Test-Path $TOOLS_ROOT)) { New-Item -ItemType Directory -Path $TOOLS_ROOT | Out-Null }

Write-Host ""
Write-Host "======================================" -ForegroundColor DarkCyan
Write-Host " DART Deployment Starting..." -ForegroundColor DarkCyan
Write-Host "======================================" -ForegroundColor DarkCyan
Write-Host ""
Log-Info "Deployment log: $script:LOG_FILE"

# ===========================================================================
# MANDATORY PRE-FLIGHT: Python - always ensure it exists at $PYTHON_DEST
# ===========================================================================
Log-Step "PreFlight-Python"
if (!(Test-Path "$PYTHON_DEST\python.exe")) {
    Log-Info "Python not found at $PYTHON_DEST. Installing via embeddable zip (no MSI)..."

    # -------------------------------------------------------------------
    # We use the embeddable zip instead of the MSI installer because the
    # MSI installer exits with code 1603 on VMs when registry entries
    # from a previous failed install are still present.  The embeddable
    # zip is just an archive - no Windows Installer, no registry, no UAC,
    # no 1603 errors, works in any automation context.
    # -------------------------------------------------------------------
    $pyEmbedUrl = "https://www.python.org/ftp/python/3.12.1/python-3.12.1-embed-amd64.zip"
    $getPipUrl  = "https://bootstrap.pypa.io/get-pip.py"
    $pyZip      = "$TOOLS_ROOT\python_embed.zip"
    $getPipPath = "$env:TEMP\get-pip.py"

    # Download the embeddable zip
    Log-Info "Downloading Python 3.12.1 embeddable zip..."
    Invoke-WebRequest -Uri $pyEmbedUrl -OutFile $pyZip -UseBasicParsing

    # Download complete - now safe to wipe any empty/partial PYTHON_DEST
    if (Test-Path $PYTHON_DEST) {
        Log-Info "Removing previous (failed/empty) Python directory..."
        Remove-Item $PYTHON_DEST -Recurse -Force
    }
    New-Item -ItemType Directory -Path $PYTHON_DEST -Force | Out-Null

    # Extract the embeddable zip
    Log-Info "Extracting Python to $PYTHON_DEST..."
    Expand-Archive -Path $pyZip -DestinationPath $PYTHON_DEST -Force
    Remove-Item $pyZip -Force -ErrorAction SilentlyContinue

    if (!(Test-Path "$PYTHON_DEST\python.exe")) {
        Log-Err "CRITICAL: python.exe not found after extraction. Zip may be corrupt."
    } else {
        # The embeddable package has site-packages disabled by default.
        # Enable it by uncommenting 'import site' in the ._pth file -
        # this is required for pip and venv to work.
        $pthFile = Get-ChildItem $PYTHON_DEST -Filter "python*._pth" |
                   Select-Object -First 1
        if ($pthFile) {
            (Get-Content $pthFile.FullName) -replace '#import site', 'import site' |
                Set-Content $pthFile.FullName
            Log-Info "Enabled site-packages in $($pthFile.Name)."
        } else {
            Log-Err "Warning: could not find ._pth file to enable site-packages."
        }

        # Bootstrap pip using get-pip.py (not included in the embeddable zip)
        Log-Info "Downloading get-pip.py..."
        Invoke-WebRequest -Uri $getPipUrl -OutFile $getPipPath -UseBasicParsing
        Log-Info "Installing pip..."
        & "$PYTHON_DEST\python.exe" $getPipPath --no-warn-script-location
        Remove-Item $getPipPath -Force -ErrorAction SilentlyContinue

        if (Test-Path "$PYTHON_DEST\Scripts\pip.exe") {
            # The embeddable zip does NOT include the venv module - install
            # virtualenv via pip as a drop-in replacement.
            Log-Info "Installing virtualenv (venv not available in embeddable zip)..."
            & "$PYTHON_DEST\Scripts\pip.exe" install virtualenv --quiet
            if ($LASTEXITCODE -eq 0) {
                Log-Ok "Python 3.12.1 (embeddable) + pip + virtualenv installed to $PYTHON_DEST."
            } else {
                Log-Err "CRITICAL: virtualenv install failed. BackendSetup will not be able to create .venv."
            }
        } else {
            Log-Err "CRITICAL: pip.exe not found after get-pip.py. Backend setup will not work."
        }
    }
} else {
    Log-Info "Python pre-flight: found at $PYTHON_DEST\python.exe."

    # Python exists but virtualenv may not be installed yet (e.g. on a re-run
    # where the previous session already had python.exe so the install block
    # above was skipped entirely). Always ensure virtualenv is present.
    $pipExe = "$PYTHON_DEST\Scripts\pip.exe"
    if (!(Test-Path $pipExe)) {
        Log-Info "pip not found - bootstrapping via get-pip.py..."
        $getPipPath = "$env:TEMP\get-pip.py"
        Invoke-WebRequest -Uri "https://bootstrap.pypa.io/get-pip.py" -OutFile $getPipPath -UseBasicParsing
        & "$PYTHON_DEST\python.exe" $getPipPath --no-warn-script-location
        Remove-Item $getPipPath -Force -ErrorAction SilentlyContinue
    }

    $virtualenvExe = "$PYTHON_DEST\Scripts\virtualenv.exe"
    if (!(Test-Path $virtualenvExe)) {
        Log-Info "virtualenv not found - installing now..."
        & "$PYTHON_DEST\Scripts\pip.exe" install virtualenv --quiet
        if ($LASTEXITCODE -eq 0) {
            Log-Ok "virtualenv installed to $PYTHON_DEST."
        } else {
            Log-Err "CRITICAL: virtualenv install failed. BackendSetup will not be able to create .venv."
        }
    } else {
        Log-Info "virtualenv already present at $virtualenvExe."
    }
}
$env:Path = "$PYTHON_DEST;$PYTHON_DEST\Scripts;$env:Path"
Add-To-Path $PYTHON_DEST
Add-To-Path "$PYTHON_DEST\Scripts"

# ===========================================================================
# Step Cleanup Functionality (Invoked when -Clean is passed)
# ===========================================================================
function Invoke-StepCleanup([string]$stepName) {
    Log-Info "[CLEAN] Running cleanup for step: $stepName ..."
    switch ($stepName) {
        "Prerequisites" {
            Remove-Item $PGPASSFILE -Force -ErrorAction SilentlyContinue
            Remove-Item (Join-Path $INSTALL_ROOT ".env") -Force -ErrorAction SilentlyContinue
            # Only a CA this installer downloaded (marker written next to
            # it); a client's own CA file named in SSLPATH is left alone.
            if (Test-Path "$SSLPATH.dart-downloaded") {
                Remove-Item $SSLPATH, "$SSLPATH.dart-downloaded" -Force -ErrorAction SilentlyContinue
            }
            Log-Ok "[CLEAN] Prerequisites artifacts removed (.pgpass, .env)."
        }
        "Git" {
            if (Test-Path (Join-Path $TOOLS_ROOT "git")) {
                Remove-Item (Join-Path $TOOLS_ROOT "git") -Recurse -Force -ErrorAction SilentlyContinue
                Log-Ok "[CLEAN] Portable Git removed from $TOOLS_ROOT\git."
            }
        }
        "NodeJS" {
            if (Test-Path (Join-Path $TOOLS_ROOT "nodejs")) {
                Remove-Item (Join-Path $TOOLS_ROOT "nodejs") -Recurse -Force -ErrorAction SilentlyContinue
                Log-Ok "[CLEAN] Node.js removed from $TOOLS_ROOT\nodejs."
            }
        }
        "Python" {
            if (Test-Path (Join-Path $TOOLS_ROOT "Python")) {
                Remove-Item (Join-Path $TOOLS_ROOT "Python") -Recurse -Force -ErrorAction SilentlyContinue
                Log-Ok "[CLEAN] Python removed from $TOOLS_ROOT\Python."
            }
        }
        "PostgreSQL" {
            $pgCtl = Join-Path $TOOLS_ROOT "postgres\bin\pg_ctl.exe"
            $pgData = Join-Path $TOOLS_ROOT "postgres\data"
            if (Test-Path $pgCtl) {
                & $pgCtl -D $pgData stop -m fast -s 2>$null
            }
            Stop-Process -Name "postgres", "pg_ctl" -Force -ErrorAction SilentlyContinue
            if (Test-Path $pgData) {
                Remove-Item $pgData -Recurse -Force -ErrorAction SilentlyContinue
                Log-Ok "[CLEAN] PostgreSQL data directory reset ($pgData)."
            }
        }
        "NginxInstall" {
            Stop-Process -Name "nginx" -Force -ErrorAction SilentlyContinue
            if (Test-Path (Join-Path $TOOLS_ROOT "nginx")) {
                Remove-Item (Join-Path $TOOLS_ROOT "nginx") -Recurse -Force -ErrorAction SilentlyContinue
                Log-Ok "[CLEAN] Nginx installation removed."
            }
        }
        "CloneRepos" {
            foreach ($repoFolder in @("backend\Data_Recon_Backend", "frontend\Data_Recon_Frontend", "Database\Data_Recon_Database", "airflow\Data-Recon-Airflow")) {
                $p = Join-Path $INSTALL_ROOT $repoFolder
                if (Test-Path $p) {
                    Remove-Item $p -Recurse -Force -ErrorAction SilentlyContinue
                    Log-Ok "[CLEAN] Removed cloned repo: $p"
                }
            }
        }
        "DatabaseSetup" {
            $psql = Join-Path $TOOLS_ROOT "postgres\bin\psql.exe"
            if (Test-Path $psql) {
                & $psql -h $DB_HOST -p $DB_PORT -U postgres -d postgres -c "DROP DATABASE IF EXISTS db_datarecon WITH (FORCE);" 2>&1 | Out-Null
                & $psql -h $DB_HOST -p $DB_PORT -U postgres -d postgres -c "DROP ROLE IF EXISTS usr_dr_mstr_rw, usr_dr_admin_rw, usr_dr_meta_rw, usr_dr_data_rw, usr_dr_audit_rw, usr_dr_ai_rw, usr_dr_air_rw, sqladminuser, dr_mgrtn_srvc, dr_mstr_srvc, rl_mstr_rw, rl_adm_rw, rl_meta_rw, rl_data_rw, rl_adt_rw, rl_mstr_r, rl_adm_r, rl_meta_r, rl_data_r, rl_adt_r, rl_mstr_e, rl_adm_e, rl_meta_e, rl_data_e, rl_adt_e;" 2>&1 | Out-Null
                Log-Ok "[CLEAN] Dropped database 'db_datarecon' and all application roles."
            }
        }
        "NginxConfig" {
            Stop-Process -Name "nginx" -Force -ErrorAction SilentlyContinue
            # Delete the HTTPS certificate only if this installer generated
            # it. This used to delete demo-dart.pem/.key unconditionally, so
            # a client's real certificate copied in under that name was lost
            # on every clean rebuild.
            if (Test-WebCertGenerated) {
                Remove-Item $WEB_CERT_PATH, $WEB_KEY_PATH, $WEB_CERT_SELFSIGNED_MARKER -Force -ErrorAction SilentlyContinue
                Log-Ok "[CLEAN] Self-signed SSL certificate removed, Nginx stopped."
            } elseif (Test-Path $WEB_CERT_PATH) {
                Log-Ok "[CLEAN] Nginx stopped. Kept $WEB_CERT_PATH - it was not generated by this installer."
            } else {
                Log-Ok "[CLEAN] Nginx stopped."
            }
        }
        "BackendSetup" {
            $venvPath = Join-Path $BACKEND_DIR "venv"
            $dotVenv  = Join-Path $BACKEND_DIR ".venv"
            if (Test-Path $venvPath) { Remove-Item $venvPath -Recurse -Force -ErrorAction SilentlyContinue }
            if (Test-Path $dotVenv)  { Remove-Item $dotVenv -Recurse -Force -ErrorAction SilentlyContinue }
            Log-Ok "[CLEAN] Backend virtual environment removed."
        }
        "FrontendBuild" {
            $nm = Join-Path $FRONTEND_DIR "node_modules"
            $b  = Join-Path $FRONTEND_DIR "build"
            if (Test-Path $nm) { Remove-Item $nm -Recurse -Force -ErrorAction SilentlyContinue }
            if (Test-Path $b)  { Remove-Item $b -Recurse -Force -ErrorAction SilentlyContinue }
            Log-Ok "[CLEAN] Frontend node_modules and build folder removed."
        }
        "StartBackend" {
            $portProc = Get-NetTCPConnection -LocalPort ([int]$API_PORT) -State Listen -ErrorAction SilentlyContinue
            if ($portProc) {
                foreach ($procId in ($portProc.OwningProcess | Select-Object -Unique)) {
                    Stop-Process -Id $procId -Force -ErrorAction SilentlyContinue
                }
            }
            Stop-Process -Name "uvicorn" -Force -ErrorAction SilentlyContinue
            Log-Ok "[CLEAN] Uvicorn / Django backend processes stopped on port $API_PORT."
        }
        "AirflowSetup" {
            # Drops the Alembic stamp as well as the schema, and reports what
            # actually happened instead of always claiming success.
            #
            # Two faults this had before:
            #  1. It only dropped the recon_airflow SCHEMA. Airflow's version
            #     stamp lives in public.alembic_version (and
            #     public.alembic_version_fab), which survived - so a "clean"
            #     left the metadata claiming a version the installed Airflow
            #     does not have, and the next db migrate failed with
            #     "Can't locate revision identified by ...". A clean that
            #     leaves the exact thing you are trying to reset is worse than
            #     no clean at all, because it looks like it worked.
            #  2. psql output went to Out-Null and success was logged
            #     unconditionally - so a missing psql.exe, a wrong postgres
            #     password (it is NOT always "admin" - see $INSTALL_ROOT\.pgpass)
            #     or a refused connection all still printed [CLEAN] success.
            #     Same false-success family as the hosts-file and firewall bugs.
            $psql = Join-Path $TOOLS_ROOT "postgres\bin\psql.exe"
            if (-not (Test-Path $psql)) {
                $sysPsql = Get-Command psql.exe -ErrorAction SilentlyContinue
                if ($sysPsql) { $psql = $sysPsql.Source }
            }
            if (-not (Test-Path $psql)) {
                Log-Warn "[CLEAN] psql.exe not found (looked in $TOOLS_ROOT\postgres\bin and on PATH) - Airflow metadata NOT reset."
                Log-Warn "        Airflow's alembic_version stamp is still in place; a later 'db migrate' may fail with 'Can't locate revision'."
            } else {
                $afCleanSql = "DROP SCHEMA IF EXISTS recon_airflow CASCADE; " +
                              "CREATE SCHEMA recon_airflow; " +
                              "GRANT ALL ON SCHEMA recon_airflow TO usr_dr_air_rw; " +
                              "DROP TABLE IF EXISTS public.alembic_version CASCADE; " +
                              "DROP TABLE IF EXISTS public.alembic_version_fab CASCADE;"
                $afCleanOut = & $psql -h $DB_HOST -p $DB_PORT -U postgres -d db_datarecon -v ON_ERROR_STOP=1 -c $afCleanSql 2>&1
                if ($LASTEXITCODE -eq 0) {
                    Log-Ok "[CLEAN] Airflow metadata reset (recon_airflow schema recreated, alembic_version dropped)."
                } else {
                    Log-Warn "[CLEAN] Airflow metadata reset FAILED (psql exit $LASTEXITCODE) - the schema and/or alembic_version stamp are still present:"
                    $afCleanOut | ForEach-Object { Log-Warn "        $_" }
                    Log-Warn "        Check the 'postgres' password in $INSTALL_ROOT\.pgpass - it is not necessarily 'admin'."
                }
            }
            wsl -d $WSL_DISTRO -u root bash -c "pkill -f airflow 2>/dev/null || true"
            # Derived from the real media root, not hardcoded. This line used
            # to spell out ".../DART_DEPLOY/backend/Data_Recon_Backend/
            # Recon_Files/..." literally, so it cleaned nothing at all on any
            # deployment whose INSTALL_ROOT wasn't named DART_DEPLOY - and
            # nothing anywhere once Recon_Files moved out of the backend.
            $mediaRootWslClean = ConvertTo-WslPath $MEDIA_DIR_WIN

            # AIRFLOW_HOME artifacts. Explicitly NOT the whole media root -
            # $MEDIA_DIR_WIN also holds media/ (uploaded recon files and the
            # DAG files Django generates), which is real application data and
            # must survive a clean.
            wsl -d $WSL_DISTRO -u root bash -c "rm -rf $mediaRootWslClean/logs $mediaRootWslClean/airflow.cfg $mediaRootWslClean/airflow.db $mediaRootWslClean/*.pid $mediaRootWslClean/webserver_config.py $mediaRootWslClean/simple_auth_manager_passwords.json.generated $mediaRootWslClean/standalone_admin_password.txt 2>/dev/null || true"
            Log-Ok "[CLEAN] Airflow state removed from AIRFLOW_HOME (logs, airflow.cfg/db, pid files, generated admin password) - media/ left intact."

            # BOTH venvs.
            #
            # The one that matters is $HOME/dart-airflow-venv on WSL's NATIVE
            # filesystem - and it was never removed. This block only deleted
            # $INSTALL_ROOT\airflow\...\airflow-venv, the old /mnt/c location
            # abandoned on 2026-08-21 for being slow. So the comment claimed
            # the venv was rebuilt fresh while the real one survived every
            # clean untouched - which is exactly how a venv built on an
            # unsupported Python 3.14 persisted across repeated "clean"
            # re-runs on the EC2 host (2026-09-10) and kept failing pip with
            # the same error. Same defect as the hardcoded Recon_Files path:
            # the cleanup was left pointing at a location the code had moved
            # away from.
            wsl -d $WSL_DISTRO -u root bash -c "rm -rf /root/dart-airflow-venv /home/*/dart-airflow-venv 2>/dev/null || true"
            Log-Ok "[CLEAN] Removed the WSL2 Airflow venv (\$HOME/dart-airflow-venv) so it is rebuilt on a supported Python."

            $airflowVenvPath = Join-Path $INSTALL_ROOT "airflow\Data-Recon-Airflow\airflow-venv"
            if (Test-Path $airflowVenvPath) {
                Remove-Item $airflowVenvPath -Recurse -Force -ErrorAction SilentlyContinue
                Log-Ok "[CLEAN] Removed the legacy /mnt/c airflow-venv ($airflowVenvPath)."
            }

            # The repo checkout - so the next run re-clones at the configured
            # branch rather than reusing a working tree that may have been
            # hand-edited while debugging.
            if (Test-Path $AIRFLOW_REPO_DIR) {
                Remove-Item $AIRFLOW_REPO_DIR -Recurse -Force -ErrorAction SilentlyContinue
                if (Test-Path $AIRFLOW_REPO_DIR) {
                    Log-Warn "[CLEAN] Could not fully remove $AIRFLOW_REPO_DIR - a file is probably still open."
                } else {
                    Log-Ok "[CLEAN] Removed the Airflow repo checkout ($AIRFLOW_REPO_DIR) - it will be re-cloned."
                }
            }

            # The distro itself - opt-in only. See $CLEAN_WSL_DISTRO.
            if ($CLEAN_WSL_DISTRO) {
                Log-Warn "[CLEAN] CLEAN_WSL_DISTRO=true - unregistering the WSL distro '$WSL_DISTRO' (this deletes the whole Linux filesystem and forces a full re-download next run)."
                & wsl --shutdown 2>&1 | Out-Null
                & wsl --unregister $WSL_DISTRO 2>&1 | ForEach-Object { Log-Info "  $_" }
                if ($LASTEXITCODE -eq 0) { Log-Ok "[CLEAN] WSL distro '$WSL_DISTRO' unregistered." }
                else { Log-Warn "[CLEAN] Could not unregister '$WSL_DISTRO' (exit $LASTEXITCODE) - it may already be gone." }
            } else {
                Log-Info "[CLEAN] WSL distro '$WSL_DISTRO' kept (set CLEAN_WSL_DISTRO=true in config to remove it as well)."
            }

            # Only claims what this part actually did. The database reset is
            # reported separately above, with its real outcome - it used to be
            # folded into this one blanket success line, which is how a failed
            # metadata reset still read as a clean [CLEAN] pass.
            Log-Ok "[CLEAN] Airflow processes terminated and temporary files cleaned."
        }
    }
}

if ($Clean) {
    Log-Step "Step-Clean"
    foreach ($stepName in $run.Keys) {
        if ($run[$stepName]) {
            Invoke-StepCleanup $stepName
        }
    }
    Log-Ok "Cleanup phase complete."

    # -Clean is a TEARDOWN, and it stops here.
    #
    # This block used to just end, so execution fell straight through into
    # Step 1 and re-installed everything it had only just deleted - a flag
    # named -Clean silently meaning "wipe, then reinstall". Found live
    # 2026-09-10: the operator wiped the box to inspect it, and watched the
    # script immediately start downloading Python and Git again.
    #
    # Wiping and reinstalling in one pass is still available - run the
    # script again without -Clean. Keeping them separate means a teardown
    # can never be mistaken for, or turn into, an install.
    Write-Host ""
    Write-Host "======================================" -ForegroundColor DarkCyan
    Write-Host "  CLEANUP COMPLETE - nothing reinstalled" -ForegroundColor Cyan
    Write-Host "======================================" -ForegroundColor DarkCyan
    Write-Host "  To install again, re-run WITHOUT -Clean:" -ForegroundColor Gray
    Write-Host "      .\VM-Windows-Bash-Script_V2.ps1 -Silent" -ForegroundColor Gray
    Write-Host ""
    Write-Host "  For a fully clean slate, also remove the roots first:" -ForegroundColor Gray
    Write-Host "      Remove-Item '$INSTALL_ROOT' -Recurse -Force" -ForegroundColor Gray
    Write-Host "      Remove-Item '$TOOLS_ROOT'   -Recurse -Force" -ForegroundColor Gray
    Write-Host ""
    if ($script:LOG_FILE) {
        Add-Content -Path $script:LOG_FILE -Value "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] [STEP   ] ========== Clean finished - exiting without installing ==========" -Encoding UTF8
    }
    exit 0
}

# ===========================================================================
# 1. Prerequisites - Copy Files & Set Environment Variables
# ===========================================================================
if ($run["Prerequisites"]) {
    Log-Step "Step-1-Prerequisites"

    # -----------------------------------------------------------------------
    # Disable IE Enhanced Security Configuration (docs section 6.2).
    # Purely a convenience for anyone browsing/downloading directly on the
    # VM over RDP - only affects Internet Explorer's default security zone,
    # harmless if IE is never used. Idempotent: checks the value first.
    # Folded in here so it no longer needs a separate manual step after RDP.
    # -----------------------------------------------------------------------
    try {
        $iescAdminKey = "HKLM:\SOFTWARE\Microsoft\Active Setup\Installed Components\{A509B1A7-37EF-4b3f-8CFC-4F3A74704073}"
        $iescUserKey  = "HKLM:\SOFTWARE\Microsoft\Active Setup\Installed Components\{A509B1A8-37EF-4b3f-8CFC-4F3A74704073}"
        $iescAlreadyOff = (Get-ItemProperty -Path $iescAdminKey -Name "IsInstalled" -ErrorAction SilentlyContinue).IsInstalled -eq 0
        if ($iescAlreadyOff) {
            Log-Skip "IE Enhanced Security Configuration (already disabled)"
        } else {
            Set-ItemProperty -Path $iescAdminKey -Name "IsInstalled" -Value 0 -ErrorAction SilentlyContinue
            Set-ItemProperty -Path $iescUserKey  -Name "IsInstalled" -Value 0 -ErrorAction SilentlyContinue
            Log-Ok "IE Enhanced Security Configuration disabled (takes effect next logon)."
        }
    } catch {
        Log-Warn "Could not disable IE Enhanced Security Configuration: $($_.Exception.Message)"
    }

    # -----------------------------------------------------------------------
    # Recon_Files (media root) - created HERE, not lazily by Step 15.
    # The .env written further down publishes MEDIA_PATH to Django, and
    # Django's dag_gen.py / file-upload views write into it long before
    # Airflow ever runs - so the directory has to exist from Step 1 onward,
    # not only on deployments that got as far as the Airflow step (which is
    # where the sole New-Item for it used to live).
    #
    # A pre-existing checkout from the old layout gets MOVED, not left
    # orphaned: that folder holds real uploaded recon files and generated
    # DAGs on an already-running VM, and silently starting a fresh empty one
    # next to it would look like data loss to whoever is using the app.
    # -----------------------------------------------------------------------
    if ((Test-Path $RECON_FILES_LEGACY_DIR) -and
        ($RECON_FILES_LEGACY_DIR -ne $MEDIA_DIR_WIN) -and
        !(Test-Path $MEDIA_DIR_WIN)) {
        try {
            Move-Item -Path $RECON_FILES_LEGACY_DIR -Destination $MEDIA_DIR_WIN -Force -ErrorAction Stop
            Log-Ok "Migrated existing media root: $RECON_FILES_LEGACY_DIR -> $MEDIA_DIR_WIN"
        } catch {
            Log-Warn "Could not move the old media root ($RECON_FILES_LEGACY_DIR) to $MEDIA_DIR_WIN : $($_.Exception.Message)"
            Log-Warn "  A file in it is probably still open (Airflow or the backend running?). Stop them and re-run this step, or move it by hand."
        }
    }
    if (!(Test-Path $MEDIA_DIR_WIN)) {
        New-Item -ItemType Directory -Path $MEDIA_DIR_WIN -Force | Out-Null
        Log-Ok "Media root created at $MEDIA_DIR_WIN"
    } else {
        Log-Info "Media root already present at $MEDIA_DIR_WIN"
    }

    Log-Info "Generating prerequisite files for DB_HOST='$DB_HOST'..."

    # -----------------------------------------------------------------------
    # .pgpass - GENERATED, not copied from anywhere.
    # Data-Recon-Backend's committed .pgpass looks tempting to reuse (it's
    # right there after CloneRepos) but its ~20 entries are the DEV TEAM'S
    # own hosts (localhost, dart-development-db-server.postgres.database
    # .azure.com, pgbouncer-test) with dev-only placeholder passwords - none
    # of that matches a client's own RDS endpoint, and even the *path* is
    # wrong (it clones into $BACKEND_DIR, not $INSTALL_ROOT, so a plain
    # "copy it in" wouldn't even find it before Step 8 runs). Generating it
    # here from the actual configured DB_HOST/DB_PORT is both more correct
    # and removes the dependency entirely.
    # ROLE_PW matches what az_exec.ps1 itself sets every usr_dr_* role's
    # password TO via -v ss=<RolePassword> during
    # 04_create_db_users_dataRecon.sql. Both now read DB_ROLE_PASSWORD from
    # config and az_exec receives it as -RolePassword, so they cannot drift.
    # DB_MASTER_PASSWORD is the one credential this script cannot invent -
    # it is whatever password the RDS instance's (or local Postgres's)
    # "postgres" superuser was actually given at provisioning time. Read
    # from config; Save Config once with the real value before deploying.
    # -----------------------------------------------------------------------
    # DB_ROLE_PASSWORD drives the usr_dr_* / dr_mstr_srvc role passwords.
    # It is passed to az_exec.ps1 (-RolePassword) so the password written
    # into .pgpass here and the password az_exec actually SETS on those
    # roles come from one value. They must match exactly: .pgpass is how
    # every later psql call authenticates, so a mismatch fails as
    # 'password authentication failed' long after the step that caused it.
    # Defaults to 'admin' - the previous hardcoded value - so leaving the
    # key unset behaves exactly as before.
    $ROLE_PW = Get-Cfg "DB_ROLE_PASSWORD" "admin"
    if ($ROLE_PW -eq 'admin') {
        Log-Warn "DB_ROLE_PASSWORD is still the default 'admin' - set a real value in dart_deploy_config.json before a production handover."
    }
    $dbMasterPassword = Get-Cfg "DB_MASTER_PASSWORD" ""
    if ([string]::IsNullOrWhiteSpace($dbMasterPassword)) {
        Log-Warn "DB_MASTER_PASSWORD is not set in config - the 'postgres' superuser line in .pgpass will be blank. Step 9 (Database Setup) needs this to authenticate as postgres; add DB_MASTER_PASSWORD to dart_deploy_config.json before running it."
    }
    $pgpassRoles = @("usr_dr_mstr_rw","usr_dr_admin_rw","usr_dr_meta_rw","usr_dr_data_rw","usr_dr_audit_rw","usr_dr_ai_rw","usr_dr_air_rw","dr_mstr_srvc")
    $pgpassLines = @("# Auto-generated by VM-Windows-Bash-Script_V2.ps1 - do not edit manually.")
    $hostsToAdd = if ($DB_HOST -in @("127.0.0.1", "localhost", "::1", "")) { @("127.0.0.1", "localhost") } else { @($DB_HOST) }
    foreach ($h in $hostsToAdd) {
        $pgpassLines += "$h`:$DB_PORT`:*:postgres:$dbMasterPassword"
        foreach ($r in $pgpassRoles) { $pgpassLines += "$h`:$DB_PORT`:*:$r`:$ROLE_PW" }
    }
    $pgpassFile = $PGPASSFILE
    $pgpassDir  = Split-Path $pgpassFile -Parent
    if (!(Test-Path $pgpassDir)) { New-Item -ItemType Directory -Path $pgpassDir -Force | Out-Null }
    [System.IO.File]::WriteAllLines($pgpassFile, [string[]]$pgpassLines, [System.Text.Encoding]::ASCII)
    $appDataPgDir = Join-Path $env:APPDATA "postgresql"
    if (!(Test-Path $appDataPgDir)) { New-Item -ItemType Directory -Path $appDataPgDir -Force | Out-Null }
    $appDataPgPass = Join-Path $appDataPgDir "pgpass.conf"
    [System.IO.File]::WriteAllLines($appDataPgPass, [string[]]$pgpassLines, [System.Text.Encoding]::ASCII)
    Log-Ok ".pgpass generated at $pgpassFile and $appDataPgPass (entries for: $($hostsToAdd -join ', '))."

    # -----------------------------------------------------------------------
    # root_ca.pem - AUTO-DOWNLOADED, not copied from anywhere.
    # Data-Recon-Backend's committed root_ca.pem is Microsoft's Azure
    # Postgres CA chain (issuer: "Microsoft RSA Root Certificate Authority
    # 2017") - wrong CA entirely for AWS RDS; SSLMODE=verify-full would fail
    # cert verification with it. AWS publishes their actual RDS combined CA
    # bundle at a stable public URL - fetch that instead whenever SSL
    # verification is actually needed (SSLMODE != disable).
    # -----------------------------------------------------------------------
    #
    # The CA goes to SSLPATH (default $INSTALL_ROOT\root_ca.pem), chosen by
    # where the database is:
    #   *.rds.amazonaws.com            -> AWS RDS global bundle
    #   *.postgres.database.azure.com  -> DigiCert Global Root G2 + Global
    #                                     Root CA + Microsoft RSA Root 2017
    #   anything else                  -> the client provides their CA file
    # A client's own file already at SSLPATH is never replaced. One this
    # installer downloaded (marker next to it) is refreshed every run, so
    # moving the DB from AWS to Azure does not keep the wrong CA.
    $rootCaFile   = $SSLPATH
    $rootCaMarker = "$rootCaFile.dart-downloaded"
    $dbIsLocal    = $DB_HOST -in @("127.0.0.1", "localhost", "::1", "")
    if ($SSLMODE -eq "disable") {
        Log-Info "SSLMODE=disable - no database CA file needed."
    } elseif ($dbIsLocal) {
        Log-Info "Database is local ('$DB_HOST') - no database CA file needed."
    } elseif ((Test-Path $rootCaFile) -and -not (Test-Path $rootCaMarker)) {
        Log-Skip "Database CA file (provided, at $rootCaFile)"
    } else {
        $caUrls = @()
        $caWhere = ''
        if ($DB_HOST -like '*.rds.amazonaws.com') {
            $caWhere = 'AWS RDS'
            $caUrls  = @("https://truststore.pki.rds.amazonaws.com/global/global-bundle.pem")
        } elseif ($DB_HOST -like '*.postgres.database.azure.com') {
            $caWhere = 'Azure Database for PostgreSQL'
            $caUrls  = @(
                "https://cacerts.digicert.com/DigiCertGlobalRootG2.crt.pem",
                "https://cacerts.digicert.com/DigiCertGlobalRootCA.crt.pem",
                "https://www.microsoft.com/pkiops/certs/Microsoft%20RSA%20Root%20Certificate%20Authority%202017.crt")
        }
        if (-not $caUrls) {
            Log-Err "SSLMODE=$SSLMODE but no database CA file at $rootCaFile."
            Log-Err "  '$DB_HOST' is not AWS RDS or Azure, so the CA cannot be downloaded automatically."
            Log-Err "  Ask the client for their database server's CA certificate (PEM), save it as $rootCaFile"
            Log-Err "  (or set SSLPATH to its path - no spaces), then re-run this step."
        } else {
            try {
                $pem = New-Object System.Text.StringBuilder
                foreach ($u in $caUrls) {
                    $bytes = (Invoke-WebRequest -Uri $u -UseBasicParsing).Content
                    if ($bytes -is [string]) { $bytes = [System.Text.Encoding]::ASCII.GetBytes($bytes) }
                    $text = [System.Text.Encoding]::ASCII.GetString($bytes)
                    if ($text -match '-----BEGIN CERTIFICATE-----') {
                        [void]$pem.AppendLine($text.Trim())
                    } else {
                        # DER (Microsoft publishes its root that way) -> PEM
                        $c = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2(,$bytes)
                        [void]$pem.AppendLine("-----BEGIN CERTIFICATE-----")
                        [void]$pem.AppendLine([Convert]::ToBase64String($c.RawData, 'InsertLineBreaks'))
                        [void]$pem.AppendLine("-----END CERTIFICATE-----")
                    }
                }
                [System.IO.File]::WriteAllText($rootCaFile, $pem.ToString().Replace("`r`n", "`n"), [System.Text.Encoding]::ASCII)
                Set-Content -Path $rootCaMarker -Value "Downloaded by VM-Windows-Bash-Script_V2.ps1 for $DB_HOST ($caWhere) on $(Get-Date -Format s)" -Encoding ASCII
                Log-Ok "Downloaded the $caWhere CA bundle to $rootCaFile."
            } catch {
                Log-Err "Failed to download the $caWhere CA bundle: $($_.Exception.Message)"
                Log-Err "  SSLMODE=$SSLMODE will fail without a valid CA file at $rootCaFile."
            }
        }
    }

    # NOTE: Data_Recon_Backend/.env ships committed in the repo and can
    # shadow the deployment .env written below (settings.py's env loader
    # walks up from settings.py and never overrides an already-set key, and
    # that file sits closer than $INSTALL_ROOT\.env). Per policy, this
    # installer applies no patches around repo issues - see ISSUE-B01 in
    # issues/patches.md. Fix at source: the dev team removes/gitignores that
    # committed .env across UAT branches (backend, frontend, etc.) and
    # rotates the secrets it contains.
    Log-Info "Writing .env file..."

    # When the database is running locally (127.0.0.1 / localhost) the portable
    # PostgreSQL install has SSL disabled (no server cert configured). If the
    # caller left SSLMODE=require the connection will always fail with:
    #   "server does not support SSL, but SSL was required"
    # Force it to 'disable' for local hosts automatically.
    $effectiveSslMode = $SSLMODE
    if ($DB_HOST -in @("127.0.0.1","localhost","::1") -and
        $SSLMODE -eq "require") {
        $effectiveSslMode = "disable"
        Log-Warn "DB_HOST is local ('$DB_HOST') but SSLMODE=require. Overriding to 'disable' (local PostgreSQL has no SSL certificate)."
    }
    Log-Info "Using SSLMODE=$effectiveSslMode for database connection."

    # -----------------------------------------------------------------------
    # ALLOWED_HOSTS - built from config, not hardcoded to a single hostname.
    #
    # This used to be the literal line "$UI_HOST,$VM_PUBLIC_IP,127.0.0.1,
    # localhost", so a deployment reachable under more than one name (a
    # vanity domain, an ALB DNS name, a second CNAME) had no way to add the
    # others except editing the script. Django rejects any Host it does not
    # recognise with a bare HTML 400 (DisallowedHost) before a view runs, so
    # the second name just looks broken.
    #
    # Entries are normalised (scheme, path and port stripped) because
    # ALLOWED_HOSTS takes bare hostnames - "https://x.com/" in it silently
    # matches nothing.
    #
    # De-duplicated as well: VM_PUBLIC_IP defaults to 127.0.0.1, which
    # previously produced "...,127.0.0.1,127.0.0.1,localhost".
    #
    # There was an EXTRA_ALLOWED_HOSTS key here for adding a Host that is
    # NOT a browser origin. Removed 2026-09-12 as client-facing confusion:
    # two near-identical host lists in one config invited edits to the
    # wrong one. CORS_ALLOWED_ORIGINS below now covers every hostname this
    # deployment answers to.
    #
    # If a caller ever needs a Host with no browser Origin - an ALB health
    # check hitting the instance IP, a server-to-server probe - it has to
    # be added another way. Add-AllowedHost() already does exactly that for
    # Airflow's WSL address at runtime, so use that, rather than
    # reintroducing a parallel config key.

    # CORS_ALLOWED_ORIGINS is folded in here as well.
    #
    # The two lists answer different questions - CORS is 'which origin may
    # the browser CALL us from', ALLOWED_HOSTS is 'which Host header will
    # we answer to' - but for a SPA served from the same domain as its API
    # the answer is the same hostname, and keeping them as two independent
    # lists meant adding a domain to one and forgetting the other.
    #
    # Found live 2026-09-11: dart-grange.donyati.com was present in CORS
    # but absent from ALLOWED_HOSTS, so every request through that domain
    # died with a bare HTML 400 (DisallowedHost) before reaching any view,
    # while the CORS configuration looked completely correct. Deriving one
    # from the other is what stops that recurring.
    #
    # Origins are normalised to bare hostnames - scheme, path AND port are
    # stripped. The port matters: Django splits it off the Host header
    # before matching (django.http.request.split_domain_port), so an entry
    # like 'host:8000' in ALLOWED_HOSTS never matches anything.
    $allowedHostsValue = (
        @($UI_HOST, $VM_PUBLIC_IP) +
        ($CORS_ALLOWED_ORIGINS -split ',') +
        @('127.0.0.1', 'localhost') |
            ForEach-Object { ($_ -replace '^\s*https?://', '' -replace '/.*$', '' -replace ':\d+$', '').Trim() } |
            Where-Object { $_ } |
            Select-Object -Unique
    ) -join ','
    if ($CORS_ALLOWED_ORIGINS.Trim()) {
        Log-Info "ALLOWED_HOSTS also includes the hostnames from CORS_ALLOWED_ORIGINS: $CORS_ALLOWED_ORIGINS"
    }
    Log-Info "ALLOWED_HOSTS = $allowedHostsValue"

    $ENV_FILE    = "$INSTALL_ROOT\.env"
    $envContent  = @"
DJANGO_SETTINGS_MODULE=Data_Recon_Main.settings
DEBUG=True
AUTHENTICATION_BACKENDS=django.contrib.auth.backends.AllowAllUsersModelBackend

# ALLOWED_HOSTS - settings.py defaults to '127.0.0.1,localhost' when this is
# unset, which does NOT include $UI_HOST. Nginx correctly forwards
# "Host: $UI_HOST" (proxy_set_header Host `$host;), but Django's own host
# validation then rejects it before the request ever reaches any view -
# Django auto-renders a bare HTML "Bad Request (400)" page for exactly this
# case, not a JSON error, since it happens before DRF's renderers ever run.
# Found live: every API call through the real domain (e.g. login) failed
# with a 400 + raw HTML body, while direct 127.0.0.1:8000 calls worked fine.
#
# VM_PUBLIC_IP is included for the identical reason - found live again
# 2026-08-22, testing an EC2 deployment from outside via its raw public IP
# (https://<public-ip>/, no DNS/hosts-file entry needed after the frontend's
# relative-URL fix): nginx forwarded "Host: <public-ip>" correctly, but
# Django still rejected it with DisallowedHost since only $UI_HOST/loopback
# were ever allow-listed. VM_PUBLIC_IP already existed as a config key
# (dart_deploy_config.json) but was never actually wired into ALLOWED_HOSTS
# until now. Left at its default "127.0.0.1" (a harmless duplicate of the
# loopback entry already here) on deployments that don't set it to a real
# public IP - only adds a real entry when there's a real value to add.
ALLOWED_HOSTS=$allowedHostsValue

# Database
HOST_ADDRESS=$DB_HOST
HOST_PORT=$DB_PORT

# CORS - settings.py actually reads the env var "CORS", NOT
# "CORS_ALLOWED_ORIGINS" (os.environ.get('CORS', "http://localhost:3000/,
# http://localhost:8000/").split(',')) - found live: this .env only ever
# wrote CORS_ALLOWED_ORIGINS, a name Django never looks at, so the real
# setting has been silently falling back to the localhost-only default
# regardless of what's configured here. Trailing slashes are also stripped
# per origin - a browser's Origin header never has one, and CORS_ALLOWED_
# ORIGINS requires an exact string match, so "https://host/" never matches
# a real "https://host" Origin header. CORS_ALLOWED_ORIGINS= is kept too in
# case anything else references it, but CORS= is the one that matters.
CORS=$(($CORS_ALLOWED_ORIGINS -split ',' | ForEach-Object { $_.Trim().TrimEnd('/') }) -join ',')
CORS_ALLOWED_ORIGINS=$CORS_ALLOWED_ORIGINS

# Email
EMAIL_BACKEND=$EMAIL_BACKEND
EMAIL_HOST=$EMAIL_HOST
EMAIL_PORT=$EMAIL_PORT
EMAIL_USE_TLS=$EMAIL_USE_TLS
EMAIL_HOST_USER=$EMAIL_HOST_USER
EMAIL_HOST_PASSWORD=$EMAIL_HOST_PASSWORD

# Media / Storage
MEDIA_PATH=$MEDIA_PATH
STORAGE_TYPE=$STORAGE_TYPE

# Frontend
# REACT_APP_URL was removed from here 2026-09-10 on the reasoning that
# REACT_APP_* is a Create React App build-time convention Django never reads,
# and that the React source uses REACT_APP_URI/REACT_APP_API instead of this
# name. That reasoning was correct about the FRONTEND and incomplete about
# the BACKEND: Data_Recon_App/utils/constants.py reads this exact variable
# name itself -
#     REACT_APP_URL = os.environ.get("REACT_APP_URL", "127.0.0.1:8000")
# - and uses it to build the invite-user and password-reset links Django puts
# in outgoing email (manage_users/functions/invite_user.py,
# manage_users/views.py: `REACT_APP_URL + 'register?token=...'` /
# `'reset?token=...'`). With the key absent, every one of those emails since
# 2026-09-10 has embedded a link built from the hardcoded fallback -
# "127.0.0.1:8000register?token=..." - no scheme, no slash, unusable outside
# the box itself. Restored here, sourced from dart_deploy_config.json's own
# REACT_APP_URL key (Get-Cfg, read into $REACT_APP_URL earlier in this step) -
# same source of truth the GUI's Config tab already edits.
#
# The frontend's OWN API base remains what it always was, set in the two
# real places for THAT purpose (this key here does not touch either):
#   frontend\Data_Recon_Frontend\.env  -> compiled into the bundle at build time
#   frontend\...\build\env.js          -> window.env, read at runtime
REACT_APP_URL=$REACT_APP_URL

# Misc
RETRIEVAL_LIMIT=$RETRIEVAL_LIMIT
SSLPATH=$SSLPATH
SSLMODE=$effectiveSslMode
PGPASSFILE=$PGPASSFILE

# FastAPI Integration (AI Auto Draft)
FASTAPI_BASE_URL=http://${FASTAPI_HOST}:${FASTAPI_PORT}
FASTAPI_INTERNAL_JWT_SECRET=$FASTAPI_INTERNAL_JWT_SECRET
FASTAPI_INTERNAL_JWT_ISSUER=django
FASTAPI_INTERNAL_JWT_AUDIENCE=fastapi
"@
    $envContent | Out-File -FilePath $ENV_FILE -Encoding utf8

    # The backend .env shadows the file just written (see Sync-BackendEnv),
    # so without this the rewrite above has no effect on the running site.
    $backendEnvFile = Join-Path $BACKEND_DIR ".env"
    if (Sync-BackendEnv $backendEnvFile $allowedHostsValue $CORS_ALLOWED_ORIGINS) {
        Log-Ok "Synced ALLOWED_HOSTS/CORS into the backend .env - it shadows $ENV_FILE."
        Log-Info "  $backendEnvFile"
        # Same shadowing problem, same fix, for the invite/reset email link
        # base (see the long comment above $ENV_FILE's own REACT_APP_URL
        # line). Writing $ENV_FILE alone is not enough - python-dotenv's
        # load_dotenv() walks up from settings.py, reaches this file FIRST,
        # and does not override a key it already set, so a stale value
        # committed here would keep winning over whatever $ENV_FILE says.
        [void](Set-EnvKey $backendEnvFile "REACT_APP_URL" $REACT_APP_URL)
        Log-Ok "Synced REACT_APP_URL into the backend .env too - it shadows $ENV_FILE for this key as well."
    } else {
        Log-Info "No backend .env yet ($backendEnvFile) - Step-11-BackendSetup syncs it once the repo is cloned."
    }

    Get-Content $ENV_FILE | Where-Object { $_ -match '=' -and $_ -notmatch '^#' } | ForEach-Object {
        $name, $value = $_.Split('=', 2)
        [System.Environment]::SetEnvironmentVariable($name.Trim(), $value.Trim(), "Process")
    }
    Log-Ok "Environment variables configured."
}

# ===========================================================================
# 2. Git Check & Install
# ===========================================================================
if ($run["Git"]) {
    Log-Step "Step-2-Git"
    if (Test-Command "git") {
        Log-Skip "Git"
    } else {
        Log-Info "Git not found. Installing Portable version..."
        $gitUrl = "https://github.com/git-for-windows/git/releases/download/v2.43.0.windows.1/PortableGit-2.43.0-64-bit.7z.exe"
        Invoke-WebRequest -Uri $gitUrl -OutFile "$env:TEMP\git_portable.exe"
        Start-Process -FilePath "$env:TEMP\git_portable.exe" -ArgumentList "-y -o`"$TOOLS_ROOT\git`"" -Wait
        Add-To-Path "$TOOLS_ROOT\git\bin"
        Log-Ok "Git installed."
    }
}

# ===========================================================================
# 3. Node.js & NPM Check & Install
# ===========================================================================
if ($run["NodeJS"]) {
    Log-Step "Step-3-NodeJS"
    # This step is now optional, not a hard prerequisite - FrontendBuild
    # (step 12) calls Ensure-NodeJS itself, lazily, only if it actually
    # ends up needing a real npm build (see that step). Keeping this as a
    # standalone step for anyone who wants Node pre-installed explicitly,
    # e.g. running the full step-by-step sequence in order.
    Ensure-NodeJS
}

# ===========================================================================
# 4. Python Force Reinstall (GUI checkbox)
# ===========================================================================
if ($run["Python"]) {
    Log-Step "Step-4-Python-Reinstall"
    if (Test-Path "$PYTHON_DEST\python.exe") {
        Log-Skip "Python (already installed at $PYTHON_DEST by pre-flight)"
    } else {
        Log-Info "Force reinstalling Python at $PYTHON_DEST via embeddable zip..."

        $pyEmbedUrl = "https://www.python.org/ftp/python/3.12.1/python-3.12.1-embed-amd64.zip"
        $getPipUrl  = "https://bootstrap.pypa.io/get-pip.py"
        $pyZip      = "$TOOLS_ROOT\python_embed.zip"
        $getPipPath = "$env:TEMP\get-pip.py"

        # Download first, then remove the old directory
        Log-Info "Downloading Python 3.12.1 embeddable zip..."
        Invoke-WebRequest -Uri $pyEmbedUrl -OutFile $pyZip -UseBasicParsing

        # Download complete - safe to wipe the old installation now
        if (Test-Path $PYTHON_DEST) {
            Remove-Item $PYTHON_DEST -Recurse -Force
            Log-Info "Removed existing Python at $PYTHON_DEST."
        }
        New-Item -ItemType Directory -Force -Path $PYTHON_DEST | Out-Null

        Log-Info "Extracting Python to $PYTHON_DEST..."
        Expand-Archive -Path $pyZip -DestinationPath $PYTHON_DEST -Force
        Remove-Item $pyZip -Force -ErrorAction SilentlyContinue

        if (!(Test-Path "$PYTHON_DEST\python.exe")) {
            Log-Err "Python reinstall failed - python.exe not found after extraction."
        } else {
            # Enable site-packages (required for pip and venv)
            $pthFile = Get-ChildItem $PYTHON_DEST -Filter "python*._pth" | Select-Object -First 1
            if ($pthFile) {
                (Get-Content $pthFile.FullName) -replace '#import site', 'import site' |
                    Set-Content $pthFile.FullName
            }

            # Bootstrap pip
            Log-Info "Downloading get-pip.py..."
            Invoke-WebRequest -Uri $getPipUrl -OutFile $getPipPath -UseBasicParsing
            & "$PYTHON_DEST\python.exe" $getPipPath --no-warn-script-location
            Remove-Item $getPipPath -Force -ErrorAction SilentlyContinue

            if (Test-Path "$PYTHON_DEST\Scripts\pip.exe") {
                Log-Info "Installing virtualenv (venv not available in embeddable zip)..."
                & "$PYTHON_DEST\Scripts\pip.exe" install virtualenv --quiet
                if ($LASTEXITCODE -eq 0) {
                    Log-Ok "Python reinstalled to $PYTHON_DEST (pip + virtualenv ready)."
                } else {
                    Log-Err "virtualenv install failed. BackendSetup will not be able to create .venv."
                }
                $env:Path = "$PYTHON_DEST;$PYTHON_DEST\Scripts;$env:Path"
            } else {
                Log-Err "Python reinstall failed - pip.exe not found after get-pip.py."
            }
        }
    }
}

# ===========================================================================
# 5. PostgreSQL 16 Check, Install & Start
# ===========================================================================
if ($run["PostgreSQL"]) {
    Log-Step "Step-5-PostgreSQL"
    $PG_ROOT = "$TOOLS_ROOT\postgres"
    $PG_BIN  = "$PG_ROOT\bin"
    $PG_DATA = "$PG_ROOT\data"
    $PG_ZIP  = "$TOOLS_ROOT\pg_16_binaries.zip"
    $PG_URL  = "https://get.enterprisedb.com/postgresql/postgresql-16.2-1-windows-x64-binaries.zip"

    # This step always gets you psql.exe/pg_dump.exe (every other step - the
    # DB build, the AI overlays, Airflow's schema setup - shells out to psql
    # regardless of where the database actually lives). Whether it ALSO
    # initialises and starts a local Postgres SERVER depends on DB_HOST: if
    # it's an RDS endpoint (or any non-local host), there's nothing to run
    # locally - RDS already IS the running server - so that part is skipped.
    $isLocalDb = $DB_HOST -in @("127.0.0.1", "localhost", "::1", "")
    if ($isLocalDb) {
        Log-Info "DB_HOST='$DB_HOST' is local - will install client tools AND run a local Postgres server."
    } else {
        Log-Info "DB_HOST='$DB_HOST' is remote (e.g. RDS) - will install client tools only; no local server needed."
    }

    Log-Info "Checking PostgreSQL 16 in $PG_ROOT..."
    if ((Test-Path "$PG_BIN\initdb.exe") -and (Test-Path "$PG_DATA\PG_VERSION")) {
        Log-Info "PostgreSQL 16 binaries and data cluster already present."
    } elseif (Test-Path "$PG_BIN\initdb.exe") {
        Log-Info "PostgreSQL 16 binaries present. Initializing database cluster at $PG_DATA..."
        try {
            if (Test-Path $PG_DATA) { Remove-Item $PG_DATA -Recurse -Force -ErrorAction SilentlyContinue }
            & "$PG_BIN\initdb.exe" -D $PG_DATA -U postgres --auth=trust -E UTF8 --locale=C
            if ($LASTEXITCODE -ne 0) { throw "initdb.exe exited with code $LASTEXITCODE" }
            Log-Ok "Data cluster initialized at $PG_DATA"
        } catch {
            Log-Err "Failed to initialize database cluster: $($_.Exception.Message)"
        }
    } else {
        Log-Info "PostgreSQL 16 not found. Installing..."
        try {
            # -------------------------------------------------------------------
            # Step A: Preserve the data cluster if it already exists so we
            #         don't lose an initialised database when wiping the binaries.
            # -------------------------------------------------------------------
            $dataAlreadyInit = Test-Path "$PG_DATA\PG_VERSION"
            if ($dataAlreadyInit) {
                Log-Info "Existing data cluster found at $PG_DATA - preserving it."
                $PG_DATA_BACKUP = "$TOOLS_ROOT\pg_data_backup"
                if (Test-Path $PG_DATA_BACKUP) { Remove-Item $PG_DATA_BACKUP -Recurse -Force }
                Move-Item -Path $PG_DATA -Destination $PG_DATA_BACKUP -Force
            }

            # -------------------------------------------------------------------
            # Step B: Remove the broken/partial PG_ROOT entirely so Move-Item
            #         has a clean, empty target.
            # -------------------------------------------------------------------
            if (Test-Path $PG_ROOT) {
                Log-Info "Removing incomplete PostgreSQL directory at $PG_ROOT..."
                Remove-Item $PG_ROOT -Recurse -Force
            }
            New-Item -ItemType Directory -Path $PG_ROOT -Force | Out-Null

            # -------------------------------------------------------------------
            # Step C: Download (reuse existing zip if it looks complete).
            # -------------------------------------------------------------------
            if ((Test-Path $PG_ZIP) -and ((Get-Item $PG_ZIP).Length -gt 1MB)) {
                Log-Info "Re-using existing zip at $PG_ZIP."
            } else {
                Log-Info "Downloading PostgreSQL 16 zip..."
                Invoke-WebRequest -Uri $PG_URL -OutFile $PG_ZIP -UserAgent "Mozilla/5.0"
            }

            # -------------------------------------------------------------------
            # Step D: Extract into a fresh temp folder.
            # -------------------------------------------------------------------
            $tempExtract = "$TOOLS_ROOT\pg_temp_extract"
            if (Test-Path $tempExtract) { Remove-Item $tempExtract -Recurse -Force }
            New-Item -ItemType Directory -Path $tempExtract -Force | Out-Null
            Log-Info "Extracting binaries..."
            Expand-Archive -Path $PG_ZIP -DestinationPath $tempExtract -Force

            $binPath = Get-ChildItem -Path $tempExtract -Recurse -Filter "initdb.exe" |
                       Select-Object -First 1 | ForEach-Object { $_.Directory.FullName }
            if ($null -eq $binPath) { throw "initdb.exe not found inside zip - download may be corrupt." }
            $actualSource = Split-Path $binPath -Parent   # parent of bin\ = pgsql root

            # -------------------------------------------------------------------
            # Step E: Move binaries into the now-empty PG_ROOT.
            # -------------------------------------------------------------------
            Log-Info "Moving binaries to $PG_ROOT..."
            Move-Item -Path "$actualSource\*" -Destination $PG_ROOT -Force
            if (!(Test-Path "$PG_BIN\initdb.exe")) {
                throw "initdb.exe still missing after move - check disk permissions on $PG_ROOT."
            }

            # -------------------------------------------------------------------
            # Step F: Restore preserved data dir (if we backed it up earlier).
            # -------------------------------------------------------------------
            if ($dataAlreadyInit) {
                Log-Info "Restoring existing data cluster to $PG_DATA..."
                Move-Item -Path $PG_DATA_BACKUP -Destination $PG_DATA -Force
            }

            # -------------------------------------------------------------------
            # Step G: Initialise cluster only if not already done, and only
            #         when the DB actually lives on this VM (remote/RDS has
            #         nothing to initialise here).
            # -------------------------------------------------------------------
            if (-not $isLocalDb) {
                Log-Info "DB_HOST is remote - skipping local cluster initialisation (initdb)."
            } elseif (Test-Path "$PG_DATA\PG_VERSION") {
                Log-Ok "Data cluster already initialised at $PG_DATA - skipping initdb."
            } else {
                Log-Info "Initializing Database Cluster in $PG_DATA..."
                if (Test-Path $PG_DATA) { Remove-Item $PG_DATA -Recurse -Force -ErrorAction SilentlyContinue }
                & "$PG_BIN\initdb.exe" -D $PG_DATA -U postgres --auth=trust -E UTF8 --locale=C
                if ($LASTEXITCODE -ne 0) { throw "initdb.exe exited with code $LASTEXITCODE" }
            }

            # Cleanup temp files
            if (Test-Path $PG_ZIP)      { Remove-Item $PG_ZIP      -Force -ErrorAction SilentlyContinue }
            if (Test-Path $tempExtract) { Remove-Item $tempExtract -Recurse -Force -ErrorAction SilentlyContinue }
            Log-Ok "PostgreSQL 16 installed and initialized at $PG_ROOT"
        } catch {
            Log-Err "Failed to install PostgreSQL 16: $($_.Exception.Message)"
        }
    }

    # -----------------------------------------------------------------------
    # ALWAYS apply these config changes - runs whether PG was freshly
    # installed above OR was already present from a previous run - but only
    # when this VM is actually running the Postgres SERVER (DB_HOST local).
    # A remote/RDS database has its own config; there's nothing on this VM
    # to configure or start.
    # Without this block, a pre-existing LOCAL installation keeps its
    # default settings (ssl=on, wrong auth) and logins will keep failing.
    # -----------------------------------------------------------------------
    if (-not $isLocalDb) {
        Log-Info "DB_HOST is remote - skipping local Postgres config/start. psql.exe/pg_dump.exe are on PATH and ready to use against $DB_HOST."
    } else {

    # Step H: postgresql.conf - disable SSL, and listen on all interfaces.
    # The portable binary build ships WITHOUT ssl certificates so the
    # compiled-in default 'ssl = on' causes psycopg connections to fail:
    #   "server does not support SSL, but SSL was required"
    #
    # listen_addresses defaults to 'localhost', which means Postgres binds
    # ONLY to true loopback (127.0.0.1/::1) and never accepts a connection
    # arriving on any other interface - including the vEthernet (WSL) adapter
    # WSL2 traffic actually arrives on. Every OTHER component (Django, nginx,
    # FastAPI) runs natively on Windows and reaches Postgres via genuine
    # loopback, so this never mattered until Airflow (which runs INSIDE WSL2,
    # a separate network namespace) needed to cross that boundary and hit
    # "connection timed out" at Step 15. Binding to '*' is acceptable here
    # because this is a single-purpose deployment VM, not a shared DB server -
    # pg_hba.conf below still gates who is actually allowed to authenticate.
    #
    # IMPORTANT: Use [System.IO.File]::WriteAllLines with ASCII encoding.
    # Set-Content / Out-File -Encoding UTF8 adds a 3-byte BOM on Windows
    # PowerShell 5.x which makes PostgreSQL crash with "syntax error line 1".
    $pgConf = Join-Path $PG_DATA "postgresql.conf"
    if (Test-Path $pgConf) {
        $pgConfLines = [System.IO.File]::ReadAllLines($pgConf, [System.Text.Encoding]::UTF8)
        $sslFound = $false; $listenFound = $false
        $pgConfLines = for ($i = 0; $i -lt $pgConfLines.Length; $i++) {
            if ($pgConfLines[$i] -match "^#?ssl\s*=") {
                "ssl = off"
                $sslFound = $true
            } elseif ($pgConfLines[$i] -match "^#?listen_addresses\s*=") {
                "listen_addresses = '*'"
                $listenFound = $true
            } else {
                $pgConfLines[$i]
            }
        }
        if (-not $sslFound)    { $pgConfLines += "ssl = off" }
        if (-not $listenFound) { $pgConfLines += "listen_addresses = '*'" }
        [System.IO.File]::WriteAllLines($pgConf, [string[]]$pgConfLines, [System.Text.Encoding]::ASCII)
        Log-Ok "postgresql.conf: ssl = off, listen_addresses = '*' applied (no BOM)."
    } else {
        Log-Warn "postgresql.conf not found at $pgConf. (Data cluster may not be initialized yet.)"
    }

    # Windows Firewall never filters true 127.0.0.1 loopback (Django/nginx/
    # FastAPI are unaffected either way), but WSL2 traffic arrives on a real
    # virtual NIC and IS subject to it. Without this rule, Airflow (inside
    # WSL2) gets a silent connection timeout to Postgres even after
    # listen_addresses is fixed above.
    $fwPgRule = "DART-Postgres-$DB_PORT"
    try {
        $existingPg = Get-NetFirewallRule -DisplayName $fwPgRule -ErrorAction SilentlyContinue
        if ($null -eq $existingPg) {
            New-NetFirewallRule -DisplayName $fwPgRule `
                -Direction Inbound -Protocol TCP -LocalPort ([int]$DB_PORT) `
                -Action Allow -Profile Any -ErrorAction Stop | Out-Null
            Log-Ok "Firewall rule created: allow inbound TCP port $DB_PORT ($fwPgRule) - needed for WSL2 (Airflow) to reach Postgres."
        } else {
            Log-Info "Firewall rule '$fwPgRule' already exists."
        }
    } catch {
        # -ErrorAction Stop above is mandatory, not cosmetic: the firewall
        # CIM provider reports "Access is denied" as a NON-terminating error
        # by default, so without Stop this catch never fires and the script
        # falls straight through to a false "Firewall rule created" Log-Ok -
        # found live on a standard (non-admin) Windows account.
        Log-Warn "Could not create Postgres firewall rule (needs admin rights): $($_.Exception.Message)"
        Log-Warn "Manually run as Administrator: New-NetFirewallRule -DisplayName '$fwPgRule' -Direction Inbound -Protocol TCP -LocalPort $DB_PORT -Action Allow"
    }

    # Step I: pg_hba.conf - explicit trust for loopback connections.
    # Ensures local connections never need a password or SSL negotiation.
    $pgHba = Join-Path $PG_DATA "pg_hba.conf"
    if (Test-Path $pgHba) {
        $hbaContent = @"
# TYPE  DATABASE        USER            ADDRESS                 METHOD
# Local connections (loopback) - trust auth, no SSL required
local   all             all                                     trust
host    all             all             127.0.0.1/32            trust
host    all             all             ::1/128                 trust
host    all             all             0.0.0.0/0               md5
"@
        [System.IO.File]::WriteAllText($pgHba, $hbaContent, [System.Text.Encoding]::ASCII)
        Log-Ok "pg_hba.conf: local trust auth applied (no BOM)."
    } else {
        Log-Warn "pg_hba.conf not found at $pgHba. (Data cluster may not be initialized yet.)"
    }

    Log-Info "Attempting to start PostgreSQL 16..."
    if ($null -eq $PG_BIN)  { $PG_BIN  = "$TOOLS_ROOT\postgres\bin" }
    if ($null -eq $PG_DATA) { $PG_DATA = "$TOOLS_ROOT\postgres\data" }
    $PG_CTL       = Join-Path $PG_BIN "pg_ctl.exe"
    # Started detached from this console and verified with a real handshake -
    # see Start-PgSafe. The old `& pg_ctl start -W` here attached postgres.exe
    # to the deploy window, so a Ctrl+C in it crashed the database (2026-10-14).
    if (-not (Start-PgSafe $PG_BIN $PG_DATA "$TOOLS_ROOT\postgres\server.log" "5432")) {
        Log-Err "PostgreSQL 16 is not running. Check logs at: $TOOLS_ROOT\postgres\server.log"
    }
    } # end of "if ($isLocalDb)" config/start block
}

# ===========================================================================
# 6. Nginx Check & Install
# ===========================================================================
if ($run["NginxInstall"]) {
    Log-Step "Step-6-NginxInstall"
    $NGINX_ROOT = "$TOOLS_ROOT\nginx"
    $NGINX_EXE  = "$NGINX_ROOT\nginx.exe"
    if (Test-Path $NGINX_EXE) {
        Log-Skip "Nginx"
    } else {
        Log-Info "Nginx not found. Downloading..."
        $nginxUrl = "https://nginx.org/download/nginx-1.24.0.zip"
        $nginxZip = "$INSTALL_ROOT\nginx.zip"
        Invoke-WebRequest -Uri $nginxUrl -OutFile $nginxZip
        Log-Info "Extracting Nginx to $NGINX_ROOT..."
        Expand-Archive -Path $nginxZip -DestinationPath "$INSTALL_ROOT\nginx_temp" -Force
        if (!(Test-Path $NGINX_ROOT)) { New-Item -ItemType Directory -Path $NGINX_ROOT -Force | Out-Null }
        $extractedDir = Get-ChildItem "$INSTALL_ROOT\nginx_temp\nginx-*" | Select-Object -First 1
        Move-Item -Path "$($extractedDir.FullName)\*" -Destination $NGINX_ROOT -Force
        Remove-Item $nginxZip -Force
        Remove-Item "$INSTALL_ROOT\nginx_temp" -Recurse -Force
        Log-Ok "Nginx installed to $NGINX_ROOT"
    }
}

# ===========================================================================
# 7. Visual Studio C++ Build Tools
# ===========================================================================
if ($run["VSBuildTools"]) {
    Log-Step "Step-7-VSBuildTools"
    $VS_INSTALL_PATH = "$TOOLS_ROOT\VSBuild"
    if (Test-Command "cl" -or (Test-Path "$VS_INSTALL_PATH\VC\Tools\MSVC")) {
        Log-Skip "Visual Studio Build Tools (C++)"
    } else {
        Log-Info "C++ Compiler missing. Installing VS Build Tools to $VS_INSTALL_PATH..."
        $vsUrl       = "https://aka.ms/vs/17/release/vs_buildtools.exe"
        $vsInstaller = "$env:TEMP\vs_buildtools.exe"
        Invoke-WebRequest -Uri $vsUrl -OutFile $vsInstaller
        Start-Process -FilePath $vsInstaller -ArgumentList "--installPath `"$VS_INSTALL_PATH`" --add Microsoft.VisualStudio.Workload.VCTools --passive --norestart --nocache" -Wait
        Log-Ok "Visual Studio Build Tools installation attempted."
    }
}

Log-Ok "System check and installation phase complete."

# ===========================================================================
# 8. Clone Repositories
# ===========================================================================
if ($run["CloneRepos"]) {
    Log-Step "Step-8-CloneRepos"
    if ([string]::IsNullOrWhiteSpace($GIT_PAT)) {
        Log-Err "CRITICAL: Git PAT is empty. Enter it in the Config tab before running Clone Repositories."
    } else {
        Log-Info "Cloning repositories..."
        New-Item -ItemType Directory -Force -Path $BACKEND_ROOT, $FRONTEND_ROOT, $DB_ROOT, $AIRFLOW_REPO_ROOT | Out-Null

        # Update-Or-Clone is defined at top-level (near $DB_DIR etc.) so the
        # per-service steps below (DatabaseSetup, BackendSetup, FrontendBuild,
        # FastAPISetup, AirflowSetup) can each call it directly too - every
        # step self-syncs its own repo to the configured branch's latest
        # commit before doing its work, whether or not CloneRepos itself is
        # part of this run.
        Update-Or-Clone $BACKEND_DIR $BRANCH_BACKEND $BACKEND_REPO_URL "Backend" $COMMIT_BACKEND
        Update-Or-Clone $DB_DIR $BRANCH_DB $DB_REPO_URL "Database" $COMMIT_DB

        # --- Frontend - NOT cloned here anymore (2026-08-25) ---
        # FrontendBuild now does its own source-protecting sparse clone (see
        # that step) - if this step also did a full Update-Or-Clone, running
        # CloneRepos before FrontendBuild would leave the full React source
        # checked out regardless, defeating the whole point. FrontendBuild
        # is safe to run standalone (like every other step already is) and
        # always decides for itself whether a full source clone is actually
        # needed.
        Log-Skip "Frontend clone (FrontendBuild handles this itself - source-protecting sparse clone)"

        # --- Database (AI branch, Auto_Draft_AI) - NOT cloned anymore ---
        # This used to feed the now-disabled Step 9b: recon_ai/V_Airflow
        # content pulled from a separate branch. mvp_main now ships that
        # same content directly as numbered overlay folders (see Step 9),
        # so this second clone was pure wasted time with nothing left that
        # reads from it. If Step 9b is ever re-enabled, restore this block.
        Log-Skip "Database AI branch clone (not needed - Step 9 covers recon_ai/V_Airflow from mvp_main directly)"

        # --- Airflow Repository ---
        Update-Or-Clone $AIRFLOW_REPO_DIR $BRANCH_AIRFLOW $AIRFLOW_REPO_URL "Airflow" $COMMIT_AIRFLOW

        Log-Ok "Repositories cloned."
    }
}

# ===========================================================================
# 9. Database Setup
#
# Runs the DB team's OWN setup script, straight from the freshly-cloned repo:
#     Database\Data_Recon_Database\setup_scripts\az_exec.ps1
#
# No patching, no injected grant stages, no re-ordering of the overlay
# folders. Whatever privileges, roles, grants and build order the repo
# defines is exactly what the database gets.
#
# If something is missing afterwards it is a REPO issue and belongs to the
# dev team to fix at source - not something this installer papers over.
# Known gaps found during testing are written up in issues\patches.md.
# ===========================================================================
if ($run["DatabaseSetup"]) {
    Log-Step "Step-9-DatabaseSetup"
    Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass -Force

    # -----------------------------------------------------------------------
    # Confirm before re-running against a database that already exists.
    #
    # The overlay folders start with create_db/02_create_database_dataRecon.sql,
    # which drops and recreates the database. On a fresh box that is exactly
    # right. On a box that has been in use it destroys every reconciliation,
    # user and result on it - and nothing in the previous flow asked first,
    # because a re-run of this step looks identical to a first run.
    #
    # Same pattern as the WSL restart checkpoint: a dialog that waits for a
    # click, a console fallback where there is no GUI, and nothing destructive
    # happens without an explicit answer. Answering No skips the step and lets
    # the rest of the run continue - the other steps do not touch the data.
    #
    # Set CONFIRM_DB_RESET to false in dart_deploy_config.json for unattended
    # rebuilds where losing the data IS the intent.
    $CONFIRM_DB_RESET = (Get-Cfg "CONFIRM_DB_RESET" "true") -match '^\s*(?i:true|1|yes|y)\s*$'
    $dbAlreadyExists  = $false
    if ($CONFIRM_DB_RESET) {
        $psqlProbe = Join-Path $TOOLS_ROOT "postgres\bin\psql.exe"
        if (Test-Path $psqlProbe) {
            $env:PGPASSWORD = Get-Cfg "DB_MASTER_PASSWORD" ""
            $prevEAPDb = $ErrorActionPreference
            $ErrorActionPreference = "Continue"
            $probeOut = & $psqlProbe -h $DB_HOST -p $DB_PORT -U postgres -d postgres -tAc `
                          "SELECT 1 FROM pg_database WHERE datname='db_datarecon'" 2>&1
            $ErrorActionPreference = $prevEAPDb
            # Only a clean "1" counts. If the probe cannot connect we do NOT
            # prompt - an unreachable server means there is no data at risk
            # yet, and blocking an unattended run on a dialog nobody is there
            # to answer would be worse than proceeding.
            $dbAlreadyExists = (($probeOut | Out-String).Trim() -eq '1')
        }
    }

    if ($dbAlreadyExists) {
        $dbMsg = @(
            "The database 'db_datarecon' ALREADY EXISTS on this machine.",
            "",
            "Step 9 re-runs the schema overlay scripts, which begin by dropping",
            "and recreating the database. Every reconciliation, user, group and",
            "result currently stored in it WILL BE LOST.",
            "",
            "Choose No to skip this step and leave the data untouched - the rest",
            "of the deployment will continue normally.",
            "",
            "Reset the database now?"
        ) -join "`n"

        Write-Host ""
        $bar = "=" * 70
        Write-Host $bar -ForegroundColor Red
        Write-Host "  EXISTING DATABASE FOUND - this step will DESTROY its contents" -ForegroundColor Red
        Write-Host $bar -ForegroundColor Red
        foreach ($l in ($dbMsg -split "`n")) { Write-Host "  $l" -ForegroundColor White }
        Write-Host $bar -ForegroundColor Red

        $dbChoice = $null
        try {
            Add-Type -AssemblyName System.Windows.Forms -ErrorAction Stop
            $dbChoice = [System.Windows.Forms.MessageBox]::Show($dbMsg, "DART - Database reset confirmation",
                          [System.Windows.Forms.MessageBoxButtons]::YesNo,
                          [System.Windows.Forms.MessageBoxIcon]::Warning,
                          [System.Windows.Forms.MessageBoxDefaultButton]::Button2)
            $dbChoice = ($dbChoice -eq [System.Windows.Forms.DialogResult]::Yes)
        } catch {
            # No GUI (bare SSH/WinRM). Ask on the console rather than assuming.
            $ans = Read-Host "Type RESET to drop and rebuild the database, anything else to skip"
            $dbChoice = ($ans -ceq 'RESET')
        }

        if (-not $dbChoice) {
            Log-Warn "Database reset DECLINED - skipping Step-9-DatabaseSetup. Existing data left untouched."
            Log-Warn "  To apply schema changes without a full rebuild, narrow DB_FOLDERS to the"
            Log-Warn "  new overlay folder only and re-run this step."
            $run["DatabaseSetup"] = $false
        } else {
            Log-Warn "Database reset CONFIRMED - existing contents of 'db_datarecon' will be destroyed."
        }
    }
}

if ($run["DatabaseSetup"]) {
    New-Item -ItemType Directory -Force -Path $DB_ROOT | Out-Null
    Update-Or-Clone $DB_DIR $BRANCH_DB $DB_REPO_URL "Database" $COMMIT_DB

    $customAzExec = Join-Path $_scriptDir "az_exec.ps1"
    $repoAzExec   = Join-Path $DB_DIR "setup_scripts\az_exec.ps1"

    $dbExecScript = if (Test-Path $customAzExec) { $customAzExec }
                    elseif (Test-Path $repoAzExec) { $repoAzExec }
                    else { $null }

    $env:LOG_DIR    = $LOG_DIR
    # The 'postgres' superuser password, from config - NOT a hardcoded
    # 'admin'. This is only a fallback for when PGPASSFILE cannot be read;
    # hardcoding it meant a deployment whose superuser password was
    # anything else silently fell back to a wrong credential here, and the
    # failure surfaced inside az_exec as an authentication error rather
    # than as the configuration mistake it actually was.
    $env:PGPASSWORD = Get-Cfg "DB_MASTER_PASSWORD" ""
    $env:PGPASSFILE = $PGPASSFILE

    # Ensure %APPDATA%\postgresql\pgpass.conf exists for Windows native psql.exe
    $appDataPgDir = Join-Path $env:APPDATA "postgresql"
    if (!(Test-Path $appDataPgDir)) { New-Item -ItemType Directory -Path $appDataPgDir -Force | Out-Null }
    $appDataPgPass = Join-Path $appDataPgDir "pgpass.conf"
    if (Test-Path $env:PGPASSFILE) {
        Copy-Item $env:PGPASSFILE $appDataPgPass -Force -ErrorAction SilentlyContinue
    }

    if (-not $dbExecScript) {
        Log-Err "CRITICAL: No DB setup script found (checked $customAzExec and $repoAzExec)."
        Log-Err "          Was Step 8 (Clone Repositories) run, and does branch '$BRANCH_DB' ship that file?"
    } else {
        if ($dbExecScript -ne $repoAzExec) {
            Log-Info "Running updated custom DB setup script: $dbExecScript"
        } else {
            Log-Info "Running the repo's DB setup script: $repoAzExec"
        }
        # -DbFolders only exists on OUR custom az_exec.ps1 (added alongside
        # DB_FOLDERS support) - the DB repo's own pristine copy at
        # $repoAzExec doesn't declare that parameter, and passing an unknown
        # named parameter is a hard bind error regardless of its value. Only
        # splat it in when the script being run actually supports it.
        $dbExecArgs = @{
            InstallRoot = $INSTALL_ROOT
            ToolsRoot   = $TOOLS_ROOT
            DbHost      = $DB_HOST
            DbPort      = $DB_PORT
        }
        $dbExecSupportsFolders = (Get-Command $dbExecScript).Parameters.ContainsKey('DbFolders')
        # Same guard as -DbFolders: the DB repo's pristine az_exec.ps1 does
        # not declare these, and passing an undeclared named parameter is a
        # hard bind error. Only splat them into OUR copy.
        $azParams = (Get-Command $dbExecScript).Parameters
        if ($azParams.ContainsKey('PgPassFile'))     { $dbExecArgs['PgPassFile']     = $PGPASSFILE }
        if ($azParams.ContainsKey('RolePassword'))   { $dbExecArgs['RolePassword']   = (Get-Cfg "DB_ROLE_PASSWORD" "admin") }
        if ($azParams.ContainsKey('MasterPassword')) { $dbExecArgs['MasterPassword'] = (Get-Cfg "DB_MASTER_PASSWORD" "") }
        if (-not $azParams.ContainsKey('RolePassword') -and (Get-Cfg "DB_ROLE_PASSWORD" "admin") -ne 'admin') {
            Log-Warn "DB_ROLE_PASSWORD is set, but $dbExecScript does not accept -RolePassword (running the DB repo's own script)."
            Log-Warn "  That script will set the roles to 'admin' while .pgpass carries your configured value - every later psql call would fail to authenticate."
        }
        if ($dbExecSupportsFolders) {
            $dbExecArgs['DbFolders'] = $DB_FOLDERS
        } elseif ($DB_FOLDERS) {
            Log-Warn "DB_FOLDERS is set but $dbExecScript does not support -DbFolders (running the DB repo's own script) - ignoring it and running ALL folders."
        }
        if ($DB_FOLDERS -and $dbExecSupportsFolders) {
            Log-Warn "DB_FOLDERS set in config - running only these overlay folders: $DB_FOLDERS (not a full install)."
        }
        # Tracked separately from $script:HadError, which is global and stays
        # $true for the rest of the run once ANY earlier step logged an error
        # - reading it here would refuse to clean up after a perfectly good
        # database build just because, say, the firewall rule in Step 5
        # couldn't be created.
        $dbSetupOk = $false
        try {
            Push-Location $DB_DIR
            & $dbExecScript @dbExecArgs
            if ($LASTEXITCODE -ne 0) {
                Log-Err "Database setup script exited with code $LASTEXITCODE - see the az_exec summary below."
            } else {
                Log-Ok "Database setup completed."
                $dbSetupOk = $true
            }
        } catch {
            Log-Err "Database setup failed: $($_.Exception.Message)"
        } finally {
            Pop-Location

            # Fold az_exec's own summary into the deployment log so a single
            # file shows the whole run (its pass/fail list is what the dev
            # team needs to triage any remaining repo issues).
            $azSummary = Get-ChildItem -Path (Join-Path $INSTALL_ROOT "logs") -Recurse -Filter "00_summary.log" `
                            -ErrorAction SilentlyContinue |
                         Sort-Object LastWriteTime -Descending | Select-Object -First 1
            if ($azSummary -and $script:LOG_FILE) {
                # Build the whole block in memory and append it in ONE call.
                # The previous version piped Get-Content into a per-line
                # Add-Content, which opens and closes the deploy log for every
                # single line - with a few hundred lines that reliably hits
                # "the process cannot access the file ... used by another
                # process" on Windows and floods the console with red. One
                # write, wrapped so a logging failure can never fail the step.
                try {
                    $block = @("--- az_exec summary ($($azSummary.FullName)) ---") +
                             @(Get-Content $azSummary.FullName -ErrorAction SilentlyContinue) +
                             @("--- end az_exec summary ---")
                    Add-Content -Path $script:LOG_FILE -Value $block -Encoding UTF8 -ErrorAction Stop
                } catch {
                    Log-Warn "Could not fold the az_exec summary into the deploy log: $($_.Exception.Message)"
                    Log-Warn "  The full DB build log is still at: $($azSummary.FullName)"
                }
            }

            # ---------------------------------------------------------------
            # Remove the Database repo checkout (source protection).
            #
            # The database is built at this point and the .sql source has no
            # further reader on the VM: Step 9b is disabled, and this step
            # re-clones the repo itself on every run, so a later re-run is
            # unaffected. The az_exec.ps1 actually executed above is
            # preferentially OUR copy from the scripts folder, which lives
            # outside $DB_ROOT and survives this.
            #
            # Deliberately gated on $dbSetupOk: a failed build is exactly
            # when someone needs to read the SQL that broke, and deleting it
            # would force a re-clone (and a working GIT_PAT) just to look.
            # Failure to delete is a WARNING, not an error - the database is
            # built and the deployment is fine; a locked file only means the
            # folder is still there.
            # ---------------------------------------------------------------
            if (-not $DELETE_DB_REPO_AFTER_SETUP) {
                Log-Info "Database source cleanup disabled (DELETE_DB_REPO_AFTER_SETUP=false) - leaving $DB_ROOT in place."
            } elseif (-not $dbSetupOk) {
                Log-Warn "Database setup did not complete cleanly - keeping $DB_ROOT so the failing .sql files can be inspected."
                Log-Warn "  Re-run this step once it's fixed and the folder will be removed automatically."
            } else {
                # $DB_AI_DIR's parent is included too: older runs of Step 8
                # cloned the Auto_Draft_AI branch into Database_AI\ for the
                # now-disabled Step 9b, and that checkout is still sitting on
                # any VM provisioned back then - same SQL source, same reason
                # to remove it.
                $dbSourceDirs = @($DB_ROOT, (Split-Path $DB_AI_DIR -Parent)) |
                                Where-Object { $_ -and (Test-Path $_) }
                foreach ($dir in $dbSourceDirs) {
                    try {
                        Remove-Item $dir -Recurse -Force -ErrorAction Stop
                        Log-Ok "Database source removed from the VM: $dir"
                    } catch {
                        Log-Warn "Could not remove $dir : $($_.Exception.Message)"
                        Log-Warn "  The database itself is built and working - only the .sql source is still on disk. Close anything holding a file open (VS Code, Explorer) and delete it manually."
                    }
                }
                if (-not $dbSourceDirs) {
                    Log-Info "No Database source left to remove (nothing at $DB_ROOT)."
                }
            }
        }
    }
}
# ===========================================================================
# 9b. AI Database Setup - recon_ai schema (AI_Changes, for FastAPI / AI Auto Draft)
#
# DISABLED - superseded by Step 9. As of the current mvp_main branch, the
# DB repo consolidated everything this step used to fetch from OTHER
# branches (V_SSO from db_shubham, V_Airflow + recon_ai from Auto_Draft_AI)
# directly into mvp_main itself, as numbered overlay folders
# (6_V_Airflow, 7_V_SSO, 8_AI_reconcile, etc.) sitting right next to
# 1_Golden_copy_V1. Step 9's patched az_exec.ps1 now auto-discovers and
# applies ALL of those numbered folders in one pass. Running this step too
# would re-apply the same SQL a second time (harmless but wasteful) and
# reaches into branches outside the "mvp_main only" DB policy.
#
# Block-commented rather than deleted: if a future mvp_main reorganisation
# drops the numbered-folder consolidation again, this is the fallback.
# To re-enable: remove the "<#" below and the matching "#>" at the end of
# this step (just above "10. Nginx Configuration & Restart"), and add back
# to the $components catalog near the top of the file:
#   [PSCustomObject]@{ Name = "AIDatabaseSetup"; Label = "9b. DB Overlays (recon_ai + V_SSO + V_Airflow + grants)" }
# ===========================================================================
<#
# Mirrors fastapi-airflow-local-setup.md: two psql batches against db_datarecon.
#   Batch 1 (create_db, as postgres): schema + role usr_dr_ai_rw + merge grants.
#   Batch 2 (recon_ai, as usr_dr_ai_rw): create/patch the recon_ai tables.
# Source lives on the Auto_Draft_AI branch ($DB_AI_DIR), cloned in Step 8.
if ($run["AIDatabaseSetup"]) {
    Log-Step "Step-9b-AIDatabaseSetup"
    $PSQL_AI  = Join-Path $TOOLS_ROOT "postgres\bin\psql.exe"
    $AI_ROOT  = Join-Path $DB_AI_DIR "AI_Changes"
    $AI_CDB   = Join-Path $AI_ROOT "create_db"
    $AI_RECON = Join-Path $AI_ROOT "recon_ai"

    if (!(Test-Path $PSQL_AI)) {
        Log-Err "psql.exe not found at $PSQL_AI. Run PostgreSQL step (5) first."
    } elseif (!(Test-Path $AI_ROOT)) {
        Log-Err "AI_Changes not found at $AI_ROOT. Was the DB AI branch cloned (Step 8)?"
    } else {
        $env:PGPASSFILE = $PGPASSFILE
        $prevEAPAi = $ErrorActionPreference
        $ErrorActionPreference = "Continue"

        # --- Batch 1: create_db as postgres ---
        Log-Info "AI_Changes batch 1 (create_db as postgres)..."
        & $PSQL_AI -h $DB_HOST -p $DB_PORT -d "db_datarecon" -U "postgres" `
            -f (Join-Path $AI_CDB "03_create_schema.sql") `
            -f (Join-Path $AI_CDB "04_create_db_users_dataRecon.sql") `
            -f (Join-Path $AI_CDB "06_grant_permissions.sql") `
            -f (Join-Path $AI_CDB "07_grant_merge_recon_admin.sql") `
            -f (Join-Path $AI_CDB "08_grant_merge_recon_master.sql") 2>&1 | Write-Host
        if ($LASTEXITCODE -eq 0) { Log-Ok "AI_Changes batch 1 applied." }
        else { Log-Warn "AI_Changes batch 1 had warnings (exit $LASTEXITCODE)." }

        # --- Batch 2: recon_ai objects as usr_dr_ai_rw (ownership matters) ---
        Log-Info "AI_Changes batch 2 (recon_ai as usr_dr_ai_rw)..."
        & $PSQL_AI -h $DB_HOST -p $DB_PORT -d "db_datarecon" -U "usr_dr_ai_rw" -v ON_ERROR_STOP=1 `
            -f (Join-Path $AI_RECON "1_create_recon_ai_tables.sql") `
            -f (Join-Path $AI_RECON "2_update_recon_ai_schema.sql") `
            -f (Join-Path $AI_RECON "3_add_ai_context_columns.sql") `
            -f (Join-Path $AI_RECON "4_bridge_mappings_was_kickout.sql") `
            -f (Join-Path $AI_RECON "5_add_process_steps_context_notes.sql") 2>&1 | Write-Host
        if ($LASTEXITCODE -eq 0) { Log-Ok "recon_ai schema applied." }
        else { Log-Err "AI_Changes batch 2 failed (exit $LASTEXITCODE)." }

        # Helper: run a .sql file as a role over local trust auth (no password needed locally)
        function Invoke-PsqlAs($role, $file) {
            if (!(Test-Path $file)) { Log-Warn "  skip (missing): $file"; return }
            & $PSQL_AI -h $DB_HOST -p $DB_PORT -d "db_datarecon" -U $role -f $file 2>&1 | Write-Host
        }

        # --- V_SSO overlay (db_shubham) : login SSO providers (get_sso_providers) ---
        Log-Info "V_SSO overlay (branch db_shubham)..."
        Push-Location $DB_DIR
        git remote set-url origin $DB_REPO_URL 2>&1 | Out-Null
        git @(Get-GitAuth) fetch origin db_shubham 2>&1 | Out-Null
        $ssoFiles = @(
            @("usr_dr_admin_rw", "V_SSO/recon_admin/25_create_master_filter_table.sql"),
            @("usr_dr_admin_rw", "V_SSO/recon_admin/29_create_sso_providers.sql"),
            @("usr_dr_admin_rw", "V_SSO/recon_admin/30_load_mstr_qry_tbl_part_5.sql"),
            @("usr_dr_admin_rw", "V_SSO/recon_admin_views/32_create_sso_providers_view.sql"),
            @("usr_dr_admin_rw", "V_SSO/recon_admin_views/33_create_sso_provider_config_view.sql"),
            @("usr_dr_admin_rw", "V_SSO/recon_admin_views/34_create_sso_user_password_view.sql"),
            @("usr_dr_mstr_rw",  "V_SSO/recon_master/1_create_sp_master.sql")
        )
        foreach ($sf in $ssoFiles) {
            $tmp = Join-Path $env:TEMP ("vsso_" + [IO.Path]::GetFileName($sf[1]))
            git show ("origin/db_shubham:" + $sf[1]) 2>$null | Out-File -FilePath $tmp -Encoding ascii
            if ((Test-Path $tmp) -and ((Get-Item $tmp).Length -gt 0)) { Invoke-PsqlAs $sf[0] $tmp }
            else { Log-Warn "  V_SSO file not found on db_shubham: $($sf[1])" }
        }
        Pop-Location
        # re-run the base grants so the new SSO objects are covered (locate 06_grant_permissions.sql
        # robustly - layout differs by branch: root vs Golden_copy_V1/create_db)
        $grant06 = Get-ChildItem -Path $DB_DIR -Recurse -Filter "06_grant_permissions.sql" -ErrorAction SilentlyContinue |
                   Where-Object { $_.FullName -notmatch "AI_Changes|V_SSO|V_Airflow" } | Select-Object -First 1
        if ($grant06) { & $PSQL_AI -h $DB_HOST -p $DB_PORT -d "db_datarecon" -U "postgres" -f $grant06.FullName 2>&1 | Out-Null }

        # --- V_Airflow overlay (Auto_Draft_AI) : recon_audit token tables for DAG runs ---
        Log-Info "V_Airflow token tables (tbl_dag_tokens / tbl_airflow_token)..."
        $vaRoot = Join-Path $DB_AI_DIR "V_Airflow"
        Invoke-PsqlAs "usr_dr_audit_rw" (Join-Path $vaRoot "recon_audit\9_create_tbl_airflow_token.sql")
        Invoke-PsqlAs "usr_dr_audit_rw" (Join-Path $vaRoot "recon_audit\10_create_tbl_dag_tokens.sql")
        Invoke-PsqlAs "usr_dr_audit_rw" (Join-Path $vaRoot "recon_audit\7_load_mstr_qry_tbl_part.sql")
        Invoke-PsqlAs "usr_dr_audit_rw" (Join-Path $vaRoot "recon_audit_functions\3_f_fetch_data.sql")
        Invoke-PsqlAs "postgres"        (Join-Path $vaRoot "create_db\06_grant_permissions.sql")

        # --- recon_audit token grants (airflow role reads; Django role mints) ---
        Log-Info "recon_audit token grants (usr_dr_air_rw + dr_mstr_srvc)..."
        & $PSQL_AI -h $DB_HOST -p $DB_PORT -d "db_datarecon" -U "postgres" -c `
"GRANT USAGE ON SCHEMA recon_audit TO usr_dr_air_rw, dr_mstr_srvc; GRANT SELECT,INSERT,UPDATE,DELETE ON recon_audit.tbl_dag_tokens, recon_audit.tbl_airflow_token TO usr_dr_air_rw, dr_mstr_srvc; GRANT USAGE,SELECT ON ALL SEQUENCES IN SCHEMA recon_audit TO usr_dr_air_rw, dr_mstr_srvc;" 2>&1 | Out-Null
        Log-Ok "DB overlays (V_SSO + V_Airflow + grants) applied."

        $ErrorActionPreference = $prevEAPAi
    }
}
#>

# ===========================================================================
# 10. Nginx Configuration & Restart
# ===========================================================================
if ($run["NginxConfig"]) {
    Log-Step "Step-10-NginxConfig"
    Log-Info "Configuring Nginx..."
    $NGINX_ROOT          = "$TOOLS_ROOT\nginx"
    $NGINX_CONF_DIR      = Join-Path $NGINX_ROOT "conf"
    $NGINX_LOGS_DIR      = Join-Path $NGINX_ROOT "logs"
    $NGINX_CONF_FILE     = Join-Path $NGINX_CONF_DIR "nginx.conf"
    $INSTALL_ROOT_FWD    = $INSTALL_ROOT.Replace('\', '/')
    # Nginx needs forward slashes; the paths are quoted in nginx.conf, so
    # spaces are fine here (unlike SSLPATH).
    $CERT                = $WEB_CERT_PATH.Replace('\', '/')
    $KEY                 = $WEB_KEY_PATH.Replace('\', '/')
    $FRONTEND_BUILD_PATH = ("$FRONTEND_DIR\build").Replace('\', '/')

    # -----------------------------------------------------------------------
    # HTTPS certificate & private key (WEB_CERT_FILE / WEB_KEY_FILE)
    # -----------------------------------------------------------------------
    # Used to be fixed to $INSTALL_ROOT\demo-dart.pem/.key, and a missing file
    # was always replaced by a self-signed one - so a client certificate with
    # any other name was silently ignored. Now:
    #   - default names, files missing -> self-signed, as before (+ marker so
    #                                     -Clean knows it may delete it)
    #   - client-named files missing   -> error, never self-signed
    #   - files present                -> checked before Nginx uses them
    $certLocalPath = $WEB_CERT_PATH
    $keyLocalPath  = $WEB_KEY_PATH
    $opensslExe    = Find-OpenSsl
    Log-Info "HTTPS certificate: $certLocalPath"
    Log-Info "HTTPS key:         $keyLocalPath"

    if (!(Test-Path $certLocalPath) -or !(Test-Path $keyLocalPath)) {
        if (-not $WEB_CERT_IS_DEFAULT) {
            Log-Err "HTTPS certificate or key not found:"
            if (!(Test-Path $certLocalPath)) { Log-Err "  missing: $certLocalPath (WEB_CERT_FILE)" }
            if (!(Test-Path $keyLocalPath))  { Log-Err "  missing: $keyLocalPath (WEB_KEY_FILE)" }
            Log-Err "  A self-signed certificate is NOT generated when WEB_CERT_FILE/WEB_KEY_FILE name the client's own files."
            Log-Err "  Copy the files there (or fix the names in dart_deploy_config.json), then re-run this step (NginxConfig)."
        } elseif (-not $opensslExe) {
            Log-Err "openssl.exe not found (portable Git, PATH, Git for Windows) - cannot auto-generate the SSL certificate."
            Log-Err "Nginx will fail to start without a cert at $certLocalPath / $keyLocalPath - install openssl or provide these files manually, then re-run this step (NginxConfig)."
        } else {
            Log-Info "SSL certificate/key not found - auto-generating self-signed SSL certificate for '$UI_HOST'..."
            try {
                $opensslOutput = & $opensslExe req -x509 -nodes -days 3650 -newkey rsa:2048 `
                    -keyout $keyLocalPath -out $certLocalPath `
                    -subj "/CN=$UI_HOST" 2>&1
                # This used to Log-Ok unconditionally the moment openssl.exe
                # was found, without checking it actually produced both
                # output files - found live: nginx failed later with
                # "cannot load certificate ... no such file or directory"
                # while this step had already logged success. Verify the
                # real files exist before claiming success.
                if ((Test-Path $certLocalPath) -and (Test-Path $keyLocalPath)) {
                    Set-Content -Path $WEB_CERT_SELFSIGNED_MARKER -Value "Self-signed by VM-Windows-Bash-Script_V2.ps1 for $UI_HOST on $(Get-Date -Format s). -Clean may delete this certificate." -Encoding ASCII
                    Log-Ok "Self-signed SSL certificate and private key auto-generated at $INSTALL_ROOT."
                    Log-Warn "Browsers will warn about this certificate. For a client, put their real certificate in place - see docs\07-ssl-domain-and-certificates.md."
                } else {
                    Log-Err "openssl ran but did not produce both $certLocalPath and $keyLocalPath. Output: $($opensslOutput -join ' ')"
                    Log-Err "Nginx will fail to start without these - fix and re-run this step (NginxConfig)."
                }
            } catch {
                Log-Err "Could not auto-generate SSL certificate: $($_.Exception.Message)"
                Log-Err "Nginx will fail to start without a cert at $certLocalPath / $keyLocalPath."
            }
        }
    }

    # Check the files before Nginx gets them. Each problem below otherwise
    # shows up only as "nginx failed to start" or a browser error.
    if ((Test-Path $certLocalPath) -and (Test-Path $keyLocalPath)) {
        $certText = "$(Get-Content $certLocalPath -Raw -ErrorAction SilentlyContinue)"
        $keyText  = "$(Get-Content $keyLocalPath  -Raw -ErrorAction SilentlyContinue)"
        $certExt  = [System.IO.Path]::GetExtension($certLocalPath).ToLower()
        if ($certExt -in @('.pfx', '.p12')) {
            Log-Err "$certLocalPath is a PFX/PKCS#12 file - Nginx cannot read it. Convert it to PEM (it asks for the PFX password):"
            Log-Err "  openssl pkcs12 -in `"$certLocalPath`" -clcerts -nokeys -out `"$INSTALL_ROOT\dart-web.pem`""
            Log-Err "  openssl pkcs12 -in `"$certLocalPath`" -nocerts -nodes  -out `"$INSTALL_ROOT\dart-web.key`""
            Log-Err "  then set WEB_CERT_FILE=dart-web.pem and WEB_KEY_FILE=dart-web.key and re-run this step."
        } elseif (-not $certText.Trim()) {
            Log-Err "$certLocalPath is empty."
        } elseif (-not $keyText.Trim()) {
            Log-Err "$keyLocalPath is empty."
        } elseif ($certText -notmatch '-----BEGIN CERTIFICATE-----') {
            Log-Err "$certLocalPath is not a PEM certificate (binary DER .cer/.crt?). Nginx needs PEM. Convert it:"
            Log-Err "  openssl x509 -inform der -in `"$certLocalPath`" -out `"$INSTALL_ROOT\dart-web.pem`""
        } elseif ($keyText -notmatch '-----BEGIN [A-Z ]*PRIVATE KEY-----') {
            Log-Err "$keyLocalPath is not a PEM private key."
        } elseif ($keyText -match 'ENCRYPTED') {
            Log-Err "$keyLocalPath is password-protected. Nginx on Windows cannot ask for the password and will not start. Remove it:"
            Log-Err "  openssl pkey -in `"$keyLocalPath`" -out `"$INSTALL_ROOT\dart-web.key`"   (asks for the password once)"
            Log-Err "  then set WEB_KEY_FILE=dart-web.key and re-run this step."
        } elseif (-not $opensslExe) {
            Log-Warn "openssl.exe not found - skipping the certificate checks (key match, expiry, hostname)."
        } else {
            # -passin pass: makes openssl fail instead of waiting for a password.
            $certPub = (& $opensslExe x509 -in $certLocalPath -noout -pubkey 2>$null) -join "`n"
            $keyPub  = (& $opensslExe pkey -in $keyLocalPath -pubout -passin pass: 2>$null) -join "`n"
            $certReadable = [bool]$certPub
            if (-not $certPub -or -not $keyPub) {
                Log-Err "openssl could not read the $(if (-not $certPub) { 'certificate' } else { 'private key' }) - check it is a valid, complete PEM file."
            } elseif ($certPub -ne $keyPub) {
                Log-Err "The private key does not belong to the certificate (public keys differ). Nginx will not start."
                Log-Err "  cert: $certLocalPath"
                Log-Err "  key:  $keyLocalPath"
            } else {
                Log-Ok "Certificate and private key match."
            }

            if ($certReadable) {
                $certSubject = ((& $opensslExe x509 -in $certLocalPath -noout -subject 2>$null) -join ' ') -replace '^subject=\s*', ''
                $certIssuer  = ((& $opensslExe x509 -in $certLocalPath -noout -issuer  2>$null) -join ' ') -replace '^issuer=\s*', ''
                $certEnd     = ((& $opensslExe x509 -in $certLocalPath -noout -enddate 2>$null) -join ' ') -replace '^notAfter=', ''
                Log-Info "  subject: $certSubject"
                Log-Info "  issuer:  $certIssuer"
                Log-Info "  expires: $certEnd"

                & $opensslExe x509 -in $certLocalPath -noout -checkend 0 2>$null | Out-Null
                if ($LASTEXITCODE -ne 0) {
                    Log-Err "The HTTPS certificate has EXPIRED ($certEnd). Browsers will refuse it - get a renewed certificate."
                } else {
                    & $opensslExe x509 -in $certLocalPath -noout -checkend 2592000 2>$null | Out-Null
                    if ($LASTEXITCODE -ne 0) { Log-Warn "The HTTPS certificate expires within 30 days ($certEnd)." }
                }

                $hostCheck = (& $opensslExe x509 -in $certLocalPath -noout -checkhost $UI_HOST 2>$null) -join ' '
                if ($hostCheck -match 'does NOT match') {
                    Log-Warn "The certificate does not cover UI_HOST '$UI_HOST' - browsers will show a name mismatch."
                    Log-Warn "  Use a certificate issued for '$UI_HOST' (or a wildcard for its domain), or fix UI_HOST."
                } elseif ($hostCheck -match 'does match') {
                    Log-Ok "Certificate covers '$UI_HOST'."
                }

                $certCount = ([regex]::Matches($certText, '-----BEGIN CERTIFICATE-----')).Count
                if ($certCount -eq 1 -and $certSubject -ne $certIssuer) {
                    Log-Warn "The certificate file holds only the server certificate, no intermediate CA."
                    Log-Warn "  Some browsers and most API clients then fail with 'unable to verify'. Append the CA bundle"
                    Log-Warn "  from the certificate provider to $certLocalPath (server certificate first)."
                }
            }
        }
    }

    if (!(Test-Path $NGINX_CONF_DIR)) { New-Item -ItemType Directory -Path $NGINX_CONF_DIR -Force | Out-Null }
    if (!(Test-Path $NGINX_LOGS_DIR)) { New-Item -ItemType Directory -Path $NGINX_LOGS_DIR -Force | Out-Null }

    Log-Info "Creating main nginx configuration..."
    # Hardened to match the UAT nginx config (2026-08-21): rate limiting, security
    # headers incl. CSP with the SSO identity-provider allowlist (Oracle IDCS,
    # Microsoft Entra/Azure AD, AWS, Google - needed if the frontend makes
    # browser-side fetch/XHR calls to these IdPs, e.g. MSAL-style silent token
    # renewal; without a matching connect-src the browser silently blocks those
    # calls via CSP with nothing in our server logs to point at it), hidden-file
    # / sensitive-extension blocking, threat logging, bad-bot/IP blocklists,
    # buffer & timeout hardening, and per-location OPTIONS preflight handling.
    $mainNginxConfig = @"
worker_processes auto;
# worker_rlimit_nofile: not supported on Windows
error_log "logs/error.log" warn;
pid       "logs/nginx.pid";

events {
    use               select;
    worker_connections 1024;
}

http {
    include      mime.types;
    default_type application/octet-stream;
    server_tokens off;
    sendfile      on;
    map_hash_bucket_size 64;
    map_hash_max_size 512;

    log_format secure_main
        '`$remote_addr - `$remote_user [`$time_local] "`$request" '
        '`$status `$body_bytes_sent "`$http_referer" "`$http_user_agent" '
        'upstream_response_time="`$upstream_response_time" '
        'ssl_protocol="`$ssl_protocol" ssl_cipher="`$ssl_cipher" '
        'req_id="`$request_id"';

    access_log "logs/access.log" secure_main;

    # Buffer & Timeout Hardening
    client_body_buffer_size     16k;
    client_header_buffer_size   1k;
    large_client_header_buffers 4 8k;
    client_max_body_size        1000M;
    client_body_timeout         12s;
    client_header_timeout       12s;
    send_timeout                10s;
    keepalive_timeout           15s;
    keepalive_requests          100;

    # TLS
    ssl_protocols             TLSv1.2 TLSv1.3;
    ssl_prefer_server_ciphers on;
    ssl_ciphers               'ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-GCM-SHA256:ECDHE-ECDSA-AES256-GCM-SHA384:ECDHE-RSA-AES256-GCM-SHA384:ECDHE-ECDSA-CHACHA20-POLY1305:ECDHE-RSA-CHACHA20-POLY1305';
    ssl_session_cache         shared:SSL:10m;
    ssl_session_timeout       1d;
    ssl_session_tickets       off;

    # Rate Limiting
    limit_req_zone  `$binary_remote_addr zone=api_limit:10m  rate=20r/s;
    limit_conn_zone `$binary_remote_addr zone=conn_limit:10m;

    # CORS Map
    map `$http_origin `$cors_allowed_origin {
        default "";
        "https://$UI_HOST"   "`$http_origin";
        "https://localhost"  "`$http_origin";
        "https://127.0.0.1"  "`$http_origin";
    }

    # IP Block List
    geo `$blocked_ip {
        default 0;
        # 45.33.32.156 1;
    }

    # Bad Bot Detection
    map `$http_user_agent `$bad_bot {
        default   0;
        ~*masscan 1; ~*sqlmap 1; ~*nikto 1; ~*nmap 1;
        ""        1;
    }

    # Threat Log (4xx/5xx only)
    map `$status `$is_threat { default 0; ~^[45] 1; }
    log_format threat_log '`$time_local|`$remote_addr|`$status|"`$request"';
    access_log "logs/threat.log" threat_log if=`$is_threat;

    # HTTP -> HTTPS Redirect
    #  server {
          # listen      80;
          #  server_name $UI_HOST;
          # return 301  https://`$host`$request_uri;
     # }

    # Main HTTPS Server
    server {
        listen      $UI_PORT ssl;
        server_name $UI_HOST localhost 127.0.0.1;

        ssl_certificate     "$CERT";
        ssl_certificate_key "$KEY";

        if (`$blocked_ip) { return 444; }
        if (`$bad_bot)    { return 444; }

        # Server-level security headers
        add_header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;
        add_header X-Frame-Options        "SAMEORIGIN"                       always;
        add_header X-Content-Type-Options "nosniff"                          always;
        add_header X-XSS-Protection       "1; mode=block"                    always;
        add_header Referrer-Policy        "strict-origin-when-cross-origin"  always;
        add_header Permissions-Policy     "geolocation=(), microphone=(), camera=()" always;
        # This value MUST stay on ONE line. nginx keeps newlines that appear
        # inside a quoted config string, so splitting it for readability emits
        # the header as an HTTP/1.1 obs-fold (CRLF + leading whitespace).
        # HTTP/1.1 tolerates that; HTTP/2 forbids it outright. Found live
        # 2026-09-08 behind the ALB: curl over HTTP/1.1 returned 200 while
        # every browser failed the whole page with ERR_HTTP2_PROTOCOL_ERROR,
        # because browsers negotiate h2 with the ALB and it forwarded the
        # illegal folded header. The give-away in the response was the CSP
        # reading "https: //dart-grange.donyati.com" - a fold landing mid-URL.
        add_header Content-Security-Policy "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self' https://$UI_HOST https://*.identity.oraclecloud.com https://login.microsoftonline.com https://*.amazonaws.com https://accounts.google.com;" always;
        # These URLs are for SSO requests (Oracle IDCS, Microsoft Entra/Azure AD, AWS, Google)

        # Request ID
        set `$req_id `$request_id;
        if (`$http_x_request_id) { set `$req_id `$http_x_request_id; }
        add_header X-Request-ID `$req_id always;

        # /api/ - Django
        location /api/ {
            limit_req  zone=api_limit burst=50 nodelay;
            limit_conn conn_limit 20;

            if (`$request_method = OPTIONS) {
                add_header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;
                add_header X-Frame-Options        "SAMEORIGIN"    always;
                add_header X-Content-Type-Options "nosniff"       always;
                add_header 'Access-Control-Allow-Origin'  `$cors_allowed_origin always;
                add_header 'Access-Control-Allow-Methods' 'GET, POST, OPTIONS' always;
                add_header 'Access-Control-Allow-Headers'
                    'DNT,User-Agent,X-Requested-With,Cache-Control,Content-Type,Authorization' always;
                add_header 'Access-Control-Max-Age' 1728000;
                add_header 'Content-Length' 0; return 204;
            }

            add_header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;
            add_header X-Frame-Options        "SAMEORIGIN"                       always;
            add_header X-Content-Type-Options "nosniff"                          always;
            add_header X-XSS-Protection       "1; mode=block"                    always;
            add_header Referrer-Policy        "strict-origin-when-cross-origin"  always;
            add_header 'Access-Control-Allow-Origin'  `$cors_allowed_origin        always;
            add_header 'Access-Control-Allow-Methods' 'GET, POST, OPTIONS'        always;
            add_header 'Access-Control-Allow-Headers'
                'DNT,User-Agent,X-Requested-With,Cache-Control,Content-Type,Authorization' always;
            add_header X-Request-ID `$req_id always;

            proxy_pass         http://${API_HOST}:${API_PORT}/;
            proxy_http_version 1.1;
            proxy_set_header   Upgrade           `$http_upgrade;
            proxy_set_header   Connection        'upgrade';
            proxy_set_header   Host              `$host;
            proxy_set_header   X-Real-IP         `$remote_addr;
            proxy_set_header   X-Forwarded-For   `$proxy_add_x_forwarded_for;
            proxy_set_header   X-Forwarded-Proto `$scheme;
            proxy_set_header   X-Request-ID      `$req_id;
            proxy_cache_bypass `$http_upgrade;
            proxy_read_timeout 300s;
            access_log "logs/api_access.log" secure_main;
        }

        # /fastapi/ - FastAPI
        location /fastapi/ {
            limit_req  zone=api_limit burst=30 nodelay;
            limit_conn conn_limit 15;

            if (`$request_method = OPTIONS) {
                add_header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;
                add_header X-Frame-Options        "SAMEORIGIN"    always;
                add_header X-Content-Type-Options "nosniff"       always;
                add_header 'Access-Control-Allow-Origin'  `$cors_allowed_origin always;
                add_header 'Access-Control-Allow-Methods' 'GET, POST, OPTIONS' always;
                add_header 'Access-Control-Allow-Headers'
                    'DNT,User-Agent,X-Requested-With,Cache-Control,Content-Type,Authorization' always;
                add_header 'Access-Control-Max-Age' 1728000;
                add_header 'Content-Length' 0; return 204;
            }

            add_header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;
            add_header X-Frame-Options        "SAMEORIGIN"                       always;
            add_header X-Content-Type-Options "nosniff"                          always;
            add_header X-XSS-Protection       "1; mode=block"                    always;
            add_header Referrer-Policy        "strict-origin-when-cross-origin"  always;
            add_header 'Access-Control-Allow-Origin'  `$cors_allowed_origin        always;
            add_header 'Access-Control-Allow-Methods' 'GET, POST, OPTIONS'        always;
            add_header 'Access-Control-Allow-Headers'
                'DNT,User-Agent,X-Requested-With,Cache-Control,Content-Type,Authorization' always;
            add_header X-Request-ID `$req_id always;

            proxy_pass         http://${FASTAPI_HOST}:${FASTAPI_PORT}/;
            proxy_http_version 1.1;
            proxy_set_header   Upgrade           `$http_upgrade;
            proxy_set_header   Connection        'upgrade';
            proxy_set_header   Host              `$host;
            proxy_set_header   X-Real-IP         `$remote_addr;
            proxy_set_header   X-Forwarded-For   `$proxy_add_x_forwarded_for;
            proxy_set_header   X-Forwarded-Proto `$scheme;
            proxy_set_header   X-Request-ID      `$req_id;
            proxy_cache_bypass `$http_upgrade;
            proxy_read_timeout 300s;
            access_log "logs/fastapi_access.log" secure_main;
        }

        # Frontend Static
        location / {
            root $FRONTEND_BUILD_PATH;
            index index.html;
            try_files `$uri `$uri/ /index.html;
        }

        # Case-insensitive hidden file block (dotfiles - .git, .env, etc.)
        location ~* /\. {
            deny all; return 404;
            access_log off; log_not_found off;
        }

        location ~* \.(env|log|bak|sql|conf|config|yml|yaml)$ {
            deny all; return 404;
        }
    }
}
"@

    $mainNginxConfig | Out-File -FilePath $NGINX_CONF_FILE -Encoding ascii -Force
    Log-Ok "Nginx configuration files created."

    # -----------------------------------------------------------------------
    # Hosts file - map the UI hostname to 127.0.0.1 so the domain resolves
    # locally on this VM (both for the browser AND for React API calls).
    # Without this entry, local-dart.donyati.com has no DNS and times out.
    # -----------------------------------------------------------------------
    # -ErrorAction Stop is mandatory here, not cosmetic - exactly the same
    # trap as the firewall rules below. Add-Content reports "Access to the
    # path ... is denied" as a NON-terminating error by default, so without
    # Stop the catch never fires and execution falls straight through to the
    # Log-Ok - reporting "Hosts file: added ..." on a run where the write was
    # refused and the entry is definitively NOT in the file. Found live
    # 2026-09-08 on a standard (non-admin) Windows account: the access-denied
    # error and the green success line were printed one after the other.
    #
    # This one matters more than it looks. $UI_HOST is a real, publicly
    # resolvable name (local-dart.donyati.com currently answers 103.214.61.44
    # via donyati.com's DNS), so a missing hosts entry does NOT produce an
    # obvious "can't resolve" failure - the browser and the React app quietly
    # reach that external address instead of the Nginx on this machine, and
    # the deployment looks broken for reasons that point nowhere near DNS.
    $hostsFile = "$env:SystemRoot\System32\drivers\etc\hosts"
    try {
        $hostsContent = Get-Content $hostsFile -Raw -Encoding ASCII -ErrorAction Stop
        if ($hostsContent -notmatch [regex]::Escape($UI_HOST)) {
            $hostsEntry = "`r`n127.0.0.1    $UI_HOST"
            Add-Content -Path $hostsFile -Value $hostsEntry -Encoding ASCII -ErrorAction Stop
            Log-Ok "Hosts file: added '127.0.0.1  $UI_HOST'"
        } else {
            Log-Info "Hosts file already contains entry for $UI_HOST."
        }
    } catch {
        Log-Warn "Could not update hosts file (needs admin rights): $($_.Exception.Message)"
        Log-Warn "  '$UI_HOST' will NOT point at this machine. It still resolves publicly, so the"
        Log-Warn "  browser will silently reach that external address instead of this Nginx - the UI"
        Log-Warn "  and every API call will appear broken with no DNS error to explain it."
        Log-Warn "  Fix: run this deployment from an elevated PowerShell, or add the line by hand to"
        Log-Warn "  $hostsFile :"
        Log-Warn "    127.0.0.1    $UI_HOST"
    }

    # -----------------------------------------------------------------------
    # Windows Firewall - open the HTTPS port so Nginx is reachable.
    # Without this rule the browser gets ERR_CONNECTION_TIMED_OUT.
    # -----------------------------------------------------------------------
    $fwRuleName = "DART-Nginx-HTTPS-$UI_PORT"
    try {
        $existingRule = Get-NetFirewallRule -DisplayName $fwRuleName -ErrorAction SilentlyContinue
        if ($null -eq $existingRule) {
            New-NetFirewallRule -DisplayName $fwRuleName `
                -Direction Inbound -Protocol TCP -LocalPort ([int]$UI_PORT) `
                -Action Allow -Profile Any -ErrorAction Stop | Out-Null
            Log-Ok "Firewall rule created: allow inbound TCP port $UI_PORT ($fwRuleName)"
        } else {
            Log-Info "Firewall rule '$fwRuleName' already exists."
        }
    } catch {
        # -ErrorAction Stop is required - the firewall CIM provider reports
        # "Access is denied" as non-terminating by default, so without Stop
        # this catch never fires and a false Log-Ok prints regardless.
        Log-Warn "Could not create firewall rule (needs admin rights): $($_.Exception.Message)"
        Log-Warn "Manually run as Administrator: New-NetFirewallRule -DisplayName '$fwRuleName' -Direction Inbound -Protocol TCP -LocalPort $UI_PORT -Action Allow"
    }

    # Also open the backend API port so direct API access works
    $fwApiRule = "DART-Uvicorn-API-$API_PORT"
    try {
        $existingApi = Get-NetFirewallRule -DisplayName $fwApiRule -ErrorAction SilentlyContinue
        if ($null -eq $existingApi) {
            New-NetFirewallRule -DisplayName $fwApiRule `
                -Direction Inbound -Protocol TCP -LocalPort ([int]$API_PORT) `
                -Action Allow -Profile Any -ErrorAction Stop | Out-Null
            Log-Ok "Firewall rule created: allow inbound TCP port $API_PORT ($fwApiRule)"
        } else {
            Log-Info "Firewall rule '$fwApiRule' already exists."
        }
    } catch {
        Log-Warn "Could not create API firewall rule (needs admin rights): $($_.Exception.Message)"
        Log-Warn "Manually run as Administrator: New-NetFirewallRule -DisplayName '$fwApiRule' -Direction Inbound -Protocol TCP -LocalPort $API_PORT -Action Allow"
    }

    $NGINX_EXE = Join-Path $NGINX_ROOT "nginx.exe"
    if (Test-Path $NGINX_EXE) {
        Log-Info "Restarting Nginx..."
        Stop-Process -Name "nginx" -ErrorAction SilentlyContinue
        Start-Sleep -Seconds 2
        if (Test-Path (Join-Path $NGINX_ROOT "logs/nginx.pid")) {
            Remove-Item (Join-Path $NGINX_ROOT "logs/nginx.pid") -Force
        }
        Push-Location $NGINX_ROOT
        $nginxTest = & .\nginx.exe -t 2>&1
        if ($LASTEXITCODE -eq 0) {
            # -WindowStyle Hidden: nginx has no interactive console content
            # worth watching (unlike Uvicorn's --reload logs), and a visible
            # window here is a real, observed failure mode - found live,
            # nginx started cleanly (no error/crash in error.log) and was
            # simply gone later with zero shutdown entry logged, most
            # consistent with its console window having been closed among
            # several other windows now open on the same desktop (Uvicorn,
            # the Airflow WSL window, this script's own window).
            Start-Process -FilePath ".\nginx.exe" -WorkingDirectory $NGINX_ROOT -WindowStyle Hidden

            # This used to Log-Ok unconditionally right after Start-Process,
            # with no check that nginx actually stayed up - verify for real.
            Start-Sleep -Seconds 2
            if (Get-Process nginx -ErrorAction SilentlyContinue) {
                Log-Ok "Nginx is running on $VM_PUBLIC_IP"
            } else {
                Log-Err "nginx.exe was launched but is not running 2s later - check $NGINX_ROOT\logs\error.log."
            }
        } else {
            Log-Err "Nginx configuration test failed: $nginxTest"
        }
        Pop-Location
    } else {
        Log-Err "nginx.exe not found at $NGINX_EXE"
    }
}

# ===========================================================================
# 11. Backend Setup - Python venv + pip install
# ===========================================================================
if ($run["BackendSetup"]) {
    Log-Step "Step-11-BackendSetup"
    New-Item -ItemType Directory -Force -Path $BACKEND_ROOT | Out-Null
    Update-Or-Clone $BACKEND_DIR $BRANCH_BACKEND $BACKEND_REPO_URL "Backend" $COMMIT_BACKEND
    Log-Info "Setting up Python virtual environment..."
    if (!(Test-Path "$BACKEND_DIR")) {
        Log-Err "CRITICAL: Backend directory not found at $BACKEND_DIR. Was the repository cloned?"
    } else {
        Set-Location "$BACKEND_DIR"
        $PYTHON_EXE = $null
        if (Test-Path "$PYTHON_DEST\python.exe") {
            $PYTHON_EXE = "$PYTHON_DEST\python.exe"
            Log-Info "Using installed Python: $PYTHON_EXE"
        } else {
            try {
                $pyVer = & python --version 2>&1
                if ($pyVer -match "Python \d") {
                    $PYTHON_EXE = "python"
                    Log-Info "Using system Python ($pyVer)"
                }
            } catch { }
        }

        if (-not $PYTHON_EXE) {
            Log-Err "CRITICAL: Python not found. Run section 4 (Python Install) first."
        } else {
            if (!(Test-Path ".venv")) {
                # Safety net: ensure virtualenv is installed before trying to
                # use it. Pre-flight should have done this, but guard here too.
                $virtualenvExe = "$PYTHON_DEST\Scripts\virtualenv.exe"
                if (!(Test-Path $virtualenvExe)) {
                    Log-Info "virtualenv not found - installing now..."
                    & "$PYTHON_DEST\Scripts\pip.exe" install virtualenv --quiet
                    if ($LASTEXITCODE -ne 0) {
                        Log-Err "CRITICAL: virtualenv install failed (exit $LASTEXITCODE). Cannot create .venv."
                    }
                }

                Log-Info "Creating virtual environment with virtualenv..."
                & $PYTHON_EXE -m virtualenv .venv
                if ($LASTEXITCODE -ne 0) {
                    Log-Err "CRITICAL: virtualenv exited with code $LASTEXITCODE."
                }
            }
            $VENV_PYTHON = Join-Path $BACKEND_DIR ".venv\Scripts\python.exe"
            if (!(Test-Path $VENV_PYTHON)) {
                Log-Err "CRITICAL: virtualenv creation failed. python.exe not found at $VENV_PYTHON."
            } else {
                Log-Info "Installing/Updating dependencies via $VENV_PYTHON..."

                # --- Upgrade pip ---
                & $VENV_PYTHON -m pip install --upgrade pip
                if ($LASTEXITCODE -ne 0) { Log-Err "pip upgrade failed (exit $LASTEXITCODE). Continuing..." }

                # --- Core runtime packages ---
                & $VENV_PYTHON -m pip install uvicorn gunicorn
                if ($LASTEXITCODE -ne 0) { Log-Err "Failed to install uvicorn/gunicorn (exit $LASTEXITCODE)." }

                # --- requirements.txt (all project dependencies) ---
                if (Test-Path "requirements.txt") {
                    Log-Info "Installing requirements.txt..."
                    & $VENV_PYTHON -m pip install -r requirements.txt
                    if ($LASTEXITCODE -ne 0) {
                        Log-Err "pip install -r requirements.txt FAILED (exit $LASTEXITCODE). Check if VS C++ Build Tools (step 7) are installed - psycopg requires them."
                    } else {
                        Log-Ok "Backend dependencies installed."
                    }
                } else {
                    Log-Err "requirements.txt NOT FOUND in $BACKEND_DIR. Python libraries were NOT installed."
                }

                # --- Force psycopg[binary] to replace bare psycopg ---
                # psycopg3 needs libpq to connect to PostgreSQL. It can use:
                #   psycopg-c      -> C extension compiled at install time (needs VS Build Tools)
                #   psycopg-binary -> pre-built wheel with libpq bundled (no external deps)
                #   pure Python    -> needs libpq.dll on the system PATH
                #
                # requirements.txt installs bare 'psycopg' which picks none of the above
                # on a fresh Windows VM (no compiler, no libpq on PATH).  Installing
                # psycopg[binary] forces the self-contained wheel that always works.
                Log-Info "Installing psycopg[binary] (bundles libpq - no external dependencies)..."
                & $VENV_PYTHON -m pip install "psycopg[binary]" --force-reinstall --quiet
                if ($LASTEXITCODE -ne 0) {
                    Log-Err "psycopg[binary] install FAILED (exit $LASTEXITCODE). Django cannot connect to PostgreSQL."
                } else {
                    Log-Ok "psycopg[binary] installed - PostgreSQL driver ready."
                }
            }
        }
    }

    # The repo checkout may ship its own .env, which shadows
    # INSTALL_ROOT\.env. Sync the authoritative keys FROM that file now
    # that the checkout exists. Read back from disk rather than reusing
    # $allowedHostsValue, because that variable is only computed inside
    # Step-1 and this step can run alone via -StepList.
    $rootEnvFile    = Join-Path $INSTALL_ROOT ".env"
    $backendEnvFile = Join-Path $BACKEND_DIR ".env"
    if ((Test-Path $rootEnvFile) -and (Test-Path $backendEnvFile)) {
        $rootLines = @(Get-Content $rootEnvFile)
        $ahLine = $rootLines | Where-Object { $_ -cmatch '^\s*ALLOWED_HOSTS\s*=' }        | Select-Object -First 1
        $coLine = $rootLines | Where-Object { $_ -cmatch '^\s*CORS_ALLOWED_ORIGINS\s*=' } | Select-Object -First 1
        $ahVal = if ($ahLine) { ($ahLine -replace '^\s*ALLOWED_HOSTS\s*=', '').Trim() }        else { '' }
        $coVal = if ($coLine) { ($coLine -replace '^\s*CORS_ALLOWED_ORIGINS\s*=', '').Trim() } else { '' }
        if (Sync-BackendEnv $backendEnvFile $ahVal $coVal) {
            Log-Ok "Backend .env synced from $rootEnvFile"
            Log-Info "  ALLOWED_HOSTS=$ahVal"
        } else {
            Log-Warn "Could not sync the backend .env - ALLOWED_HOSTS missing from $rootEnvFile. Run -StepList 'Prerequisites' first."
        }
    }
}

# ===========================================================================
# 12. Frontend Build
# ===========================================================================
if ($run["FrontendBuild"]) {
    Log-Step "Step-12-FrontendBuild"
    New-Item -ItemType Directory -Force -Path $FRONTEND_ROOT | Out-Null

    # ---------------------------------------------------------------------
    # Source-protecting clone (2026-08-25): if this is a fresh checkout,
    # clone SPARSE + blob-filtered - only root-level files (package.json
    # etc. - cone mode always includes these) plus "build"/"dist" if either
    # is tracked. The React application source (src/, everything else)
    # never touches disk unless there's genuinely no pre-built output to
    # use instead (see the widen-if-needed fallback below). Verified live
    # against the real Azure DevOps repo: a locally-committed "build/"
    # folder materializes correctly under this setup while "src/" stays
    # completely absent.
    #
    # An EXISTING checkout (sparse or full, from before this change) is
    # just fetched + reset in place, same as Update-Or-Clone does for the
    # other three repos - deliberately NOT retroactively narrowed if it was
    # already full, so an existing install doesn't have files pulled out
    # from under it on the next run.
    $frontendIsCloned = Test-Path (Join-Path $FRONTEND_DIR ".git")
    if (-not $frontendIsCloned) {
        Log-Info "Sparse-cloning Frontend (branch: $BRANCH_FRONTEND) - source-protecting: ONLY 'build'/'dist' fetched, nothing else (not even root-level loose files - non-cone pattern mode, not cone mode)..."
        git @(Get-GitAuth) clone --filter=blob:none --no-checkout --sparse -b $BRANCH_FRONTEND $FRONTEND_REPO_URL $FRONTEND_DIR 2>&1 | ForEach-Object { Log-Info "  $_" }
        if ($LASTEXITCODE -ne 0) {
            Log-Err "Failed to sparse-clone Frontend repository."
        } else {
            Push-Location $FRONTEND_DIR
            try {
                # Non-cone mode, not cone mode: cone mode (git sparse-checkout
                # init --cone / set build dist) always materializes root-level
                # loose files (package.json, README.md, webpack.config.js,
                # etc.) in addition to whatever directories you list - that's
                # cone mode's defined behavior, not a bug, but it means real
                # files land on disk beyond just build/dist. Non-cone mode
                # takes explicit gitignore-style patterns instead and has no
                # such automatic inclusion, so /build/ and /dist/ are truly
                # the only things that can reach disk - confirmed live
                # 2026-08-25.
                # Partial clone (--filter=blob:none): these download file
                # contents on demand, so they need auth too.
                git @(Get-GitAuth) sparse-checkout init --no-cone 2>&1 | Out-Null
                git @(Get-GitAuth) sparse-checkout set /build/ /dist/ 2>&1 | Out-Null
                git @(Get-GitAuth) checkout $BRANCH_FRONTEND 2>&1 | ForEach-Object { Log-Info "  $_" }
                Log-Ok "Frontend sparse-cloned (source-protected, build/dist only)."
                # Pin AFTER the sparse rules are set, so the pinned commit
                # is materialised under the same build/dist-only filter.
                [void](Checkout-Commit $FRONTEND_DIR $COMMIT_FRONTEND "Frontend")
            } finally {
                Pop-Location
            }
        }
    } else {
        Log-Info "Updating Frontend (branch: $BRANCH_FRONTEND)..."
        Push-Location $FRONTEND_DIR
        try {
            # Drop any PAT-embedded URL an older version of this script left
            # in .git\config; auth now comes from Get-GitAuth per command.
            git remote set-url origin $FRONTEND_REPO_URL 2>&1 | Out-Null
            git @(Get-GitAuth) fetch origin $BRANCH_FRONTEND 2>&1 | ForEach-Object { Log-Info "  $_" }
            if ($LASTEXITCODE -ne 0) {
                Log-Err "Failed to fetch Frontend - leaving existing checkout as-is."
            } else {
                if ($COMMIT_FRONTEND) {
                    [void](Checkout-Commit $FRONTEND_DIR $COMMIT_FRONTEND "Frontend")
                } else {
                    git @(Get-GitAuth) checkout $BRANCH_FRONTEND 2>&1 | Out-Null
                    git @(Get-GitAuth) reset --hard "origin/$BRANCH_FRONTEND" 2>&1 | ForEach-Object { Log-Info "  $_" }
                    if ($LASTEXITCODE -ne 0) { Log-Err "Failed to update Frontend to latest $BRANCH_FRONTEND." }
                    else { Log-Ok "Frontend updated to latest $BRANCH_FRONTEND." }
                }

                # Re-tighten to build/dist-only on every update, but ONLY if
                # this checkout is still sparse. If it was already widened to
                # full (no pre-built folder existed, real source was needed
                # to build - see the "widen" block below), leave it alone;
                # narrowing it back down here would strip files an
                # in-progress npm build still depends on. This purely
                # upgrades any older checkout that was sparse-cloned back
                # when cone mode was used (which also pulled root-level loose
                # files) to the current build/dist-only non-cone pattern.
                $sparseMarkerUpd = Join-Path $FRONTEND_DIR ".git\info\sparse-checkout"
                if (Test-Path $sparseMarkerUpd) {
                    git @(Get-GitAuth) sparse-checkout init --no-cone 2>&1 | Out-Null
                    git @(Get-GitAuth) sparse-checkout set /build/ /dist/ 2>&1 | Out-Null
                }
            }
        } finally {
            Pop-Location
        }
    }

    Log-Info "Building frontend..."
    if (!(Test-Path "$FRONTEND_DIR")) {
        Log-Err "CRITICAL: Frontend directory not found at $FRONTEND_DIR. Was the repository cloned?"
    } else {
        # ---------------------------------------------------------------
        # Skip npm entirely if the repo itself ships a pre-built folder -
        # checked via `git ls-files`, NOT Test-Path. A prior LOCAL build
        # also leaves a "build" folder sitting right here (git-ignored,
        # survives an update-in-place since that only touches tracked
        # files) - Test-Path alone couldn't tell "the dev team committed a
        # pre-built dist/build folder" apart from "we already built here
        # ourselves last time", and would wrongly skip real rebuilds after
        # every local run. `git ls-files` only returns something for files
        # actually tracked in the repo, so it only fires for the genuine
        # "repo ships pre-built output" case - and works whether the
        # checkout above ended up sparse or full.
        # Checks "dist" first (Vite-style convention), then "build" (CRA,
        # what this repo's own npm run build already produces) - whichever
        # the dev team's build pipeline happens to commit.
        $prebuiltCandidate = $null
        foreach ($candidate in @("dist", "build")) {
            $tracked = git -C $FRONTEND_DIR ls-files -- $candidate 2>$null
            if ($tracked) { $prebuiltCandidate = $candidate; break }
        }

        if ($prebuiltCandidate) {
            Log-Skip "npm install/build (repo ships a pre-built '$prebuiltCandidate' folder, tracked in git)"
            $prebuiltPath = Join-Path $FRONTEND_DIR $prebuiltCandidate
            $buildPath    = Join-Path $FRONTEND_DIR "build"
            if ($prebuiltCandidate -ne "build") {
                # Nginx's root is hardcoded to "$FRONTEND_DIR\build" (see
                # NginxConfig) - normalize whatever the repo calls it into
                # that exact path rather than making NginxConfig aware of
                # multiple possible folder names.
                if (Test-Path $buildPath) { Remove-Item $buildPath -Recurse -Force -ErrorAction SilentlyContinue }
                Copy-Item $prebuiltPath $buildPath -Recurse -Force
                Log-Info "Copied '$prebuiltCandidate' -> 'build' (Nginx's root is fixed to `$FRONTEND_DIR\build`)."
            }
            Log-Ok "Frontend build (pre-built) ready. Output at: $buildPath"
            Log-Warn "Pre-built output is used as-is - this installer's own REACT_APP_URI/API/URL .env values were NOT applied (they'd have no effect on an already-compiled bundle). Whatever the build pipeline that produced this baked in is what's live - confirm it used relative paths (not an absolute UI_HOST), or it will hit the same hardcoded-hostname problem this script's own build path was fixed for on 2026-08-22."
        } else {
            # No pre-built output anywhere in the repo - the only way to get
            # a working app is a real build, which needs the actual source.
            # If the checkout above ended up sparse, this is the ONE point
            # where application source is deliberately allowed onto disk -
            # `sparse-checkout disable` restores the full working tree,
            # transparently fetching the blobs the earlier --filter=blob:none
            # clone deferred (standard git partial-clone behavior, not a
            # special case this script has to handle itself).
            $sparseMarker = Join-Path $FRONTEND_DIR ".git\info\sparse-checkout"
            if (Test-Path $sparseMarker) {
                Log-Warn "No pre-built 'build'/'dist' found in the repo - the full source is needed to build it. Widening the sparse checkout now (this is the only case where application source reaches disk)."
                git @(Get-GitAuth) -C $FRONTEND_DIR sparse-checkout disable 2>&1 | ForEach-Object { Log-Info "  $_" }
            }

            # Node.js is only actually needed here, on this exact path - a
            # real npm build. Installing it eagerly at Step 3, long before
            # this check even ran, meant paying that cost (download +
            # extract) on every single run, including every one where a
            # pre-built folder made it completely unnecessary. Lazy, same
            # reasoning as the source-protecting sparse clone above.
            Ensure-NodeJS
        # -------------------------------------------------------------------
        # Write the frontend .env with the CORRECT variable names before
        # building. The React source uses REACT_APP_URI (ui base) and
        # REACT_APP_API (api endpoint) - NOT REACT_APP_URL. The repo's
        # committed .env points to production (dart.donyati.com). We
        # overwrite it here with the local-deployment values from config.
        #
        # RELATIVE, not absolute - these get compiled directly into the
        # static JS bundle at `npm run build` time (React env vars are
        # inlined, not read at runtime), so an absolute "https://$UI_HOST/"
        # only works when the browser can actually resolve $UI_HOST - which
        # it can't unless that machine has a matching hosts-file entry or
        # real DNS. Found live 2026-08-22: the app was reachable and loaded
        # fine from the EC2's public IP directly, but every single API call
        # (including login) silently failed, because the compiled bundle
        # was still trying to reach the literal hostname "local-dart.donyati
        # .com", which is not publicly resolvable. Relative paths resolve
        # against whatever origin the page was actually loaded from - the
        # same build now works correctly whether accessed via UI_HOST, the
        # raw public IP, or anything else pointed at this Nginx, with no
        # DNS/hosts-file dependency at all. Verified every REACT_APP_API/URL
        # consumer in the frontend only ever uses these as a fetch/axios
        # base URL (never an absolute-URL-required context like an OAuth
        # redirect_uri or postMessage targetOrigin), so this is safe.
        # ---------------------------------------------------------------
        $uiBase  = "/"
        $apiBase = "/api/"

        $frontendEnvContent = @"
# Auto-generated by VM-Windows-Bash-Script_V2.ps1 - do not edit manually.
# Source of truth: dart_deploy_config.json / Config tab in the GUI.
REACT_APP_URI=$uiBase
REACT_APP_API=$apiBase
REACT_APP_URL=$apiBase
"@
        $frontendEnvFile = Join-Path $FRONTEND_DIR ".env"
        $frontendEnvContent | Out-File -FilePath $frontendEnvFile -Encoding utf8 -Force
        Log-Info "Frontend .env written:"
        Log-Info "  REACT_APP_URI = $uiBase"
        Log-Info "  REACT_APP_API = $apiBase"
        Log-Info "  REACT_APP_URL = $apiBase"

        Set-Location $FRONTEND_DIR
        Log-Info "Running npm install..."
        npm install 2>&1 | Write-Host
        Log-Info "Running npm run build..."
        npm run build 2>&1 | Write-Host
        if ($LASTEXITCODE -ne 0) {
            Log-Err "Frontend build failed with exit code $LASTEXITCODE."
        } else {
            Log-Ok "Frontend build complete. Output at: $FRONTEND_DIR\build"
        }
        }

        # -----------------------------------------------------------------
        # Regenerate build\env.js regardless of which path produced it.
        # The frontend's build script (`npx react-inject-env set`) writes a
        # RUNTIME env file separate from the compiled JS bundle - loaded via
        # <script src="env.js"> in index.html, read as `window.env` at
        # page-load time, not inlined into the bundle at compile time like
        # REACT_APP_* normally is. This is actually a better mechanism than
        # the compile-time .env approach above (a plain file write fixes it,
        # no rebuild needed) - but it still needs correct values written
        # into it. Found live 2026-08-25: the dev team's committed pre-built
        # "build" folder shipped with real, already-wrong dev-placeholder
        # values (REACT_APP_API: "http://localhost:8000/",
        # REACT_APP_URL: "https://demo-dart.donyati.com/" - not even the
        # same hostname as UI_HOST) baked into this exact file - the
        # hardcoded-hostname problem fixed 2026-08-22 for the compile-time
        # path, recurring here through a completely different mechanism.
        # Overwritten unconditionally, after both branches above, so this
        # is correct whether the pre-built path or the real npm-build path
        # produced build\ - relative, for the identical reason the .env
        # values above are relative.
        # Written UNCONDITIONALLY - created when absent, not just overwritten
        # when already present.
        #
        # The old `if (Test-Path $buildEnvJsFile)` guard meant this only ever
        # fired for builds that happened to ship an env.js, and the pre-built
        # dist/ the frontend repo commits does NOT. index.html still loads
        # <script src="/env.js"> (twice), so with the file missing nginx's SPA
        # fallback answered with index.html and the browser parsed an HTML
        # document as JavaScript on every page load - leaving window.env
        # undefined. Confirmed live 2026-09-10: GET /env.js returned 1638
        # bytes starting "<!doctype html>".
        #
        # That mattered, because this file is the ONE lever that can correct
        # the API base URL without a rebuild. With it silently absent, a
        # pre-built bundle carrying an absolute origin (2026-09-09:
        # "https://32.192.83.125/api/") could only be fixed by patching the
        # compiled JS by hand - which any later deploy then reverted.
        $buildEnvJsFile = Join-Path $FRONTEND_DIR "build\env.js"
        $buildDirForEnvJs = Split-Path $buildEnvJsFile -Parent
        if (Test-Path $buildDirForEnvJs) {
            $buildEnvJsContent = @"
window.env = {
  "REACT_APP_URI": "/",
  "REACT_APP_API": "/api/",
  "REACT_APP_URL": "/api/"
}
"@
            # ASCII + WriteAllText: Out-File -Encoding utf8 on Windows
            # PowerShell 5.x prepends a BOM, and a BOM ahead of "window.env"
            # makes the browser fail to parse the script.
            [System.IO.File]::WriteAllText($buildEnvJsFile, $buildEnvJsContent, (New-Object System.Text.UTF8Encoding($false)))
            Log-Ok "build\env.js written with relative paths (runtime window.env override - applies without a rebuild, unlike the compiled bundle)."
        } else {
            Log-Warn "Frontend build folder not found at $buildDirForEnvJs - skipped writing env.js."
        }
    }
}

# ===========================================================================
# 13. Start Backend (Uvicorn)
# ===========================================================================
if ($run["StartBackend"]) {
    Log-Step "Step-13-StartBackend"
    Log-Info "Clearing port $API_PORT..."
    $proc = Get-NetTCPConnection -LocalPort ([int]$API_PORT) -ErrorAction SilentlyContinue
    if ($proc) {
        # Get-NetTCPConnection can return several rows for one port (e.g. a
        # stale TIME_WAIT entry alongside the real listener) - dedupe PIDs,
        # and -ErrorAction SilentlyContinue on the stop itself: found live,
        # a harmless race where the owning process had already exited by the
        # time Stop-Process ran threw a scary-looking red error even though
        # the end state (port free) was already correct either way.
        $procIds = $proc.OwningProcess | Select-Object -Unique
        foreach ($ownerId in $procIds) {
            Stop-Process -Id $ownerId -Force -ErrorAction SilentlyContinue
        }
        Log-Info "Port $API_PORT cleared."
    }

    if (!(Test-Path "$BACKEND_DIR")) {
        Log-Err "CRITICAL: Cannot start backend - $BACKEND_DIR not found."
    } else {
        # Ensure PostgreSQL bin (libpq.dll) is on PATH so psycopg pure-Python
        # fallback can find it if psycopg[binary] was not installed.
        $PG_BIN_DIR = "$TOOLS_ROOT\postgres\bin"
        if (Test-Path $PG_BIN_DIR) {
            $env:Path = "$PG_BIN_DIR;$env:Path"
            Log-Info "Added PostgreSQL bin to PATH: $PG_BIN_DIR"
        }

        # Always resolve VENV_PYTHON here so StartBackend works even if
        # BackendSetup was skipped or ran in a previous session.
        $VENV_PYTHON = Join-Path $BACKEND_DIR ".venv\Scripts\python.exe"

        $VENV_ACTIVATE = Join-Path $BACKEND_DIR ".venv\Scripts\Activate.ps1"
        if (!(Test-Path $VENV_ACTIVATE)) {
            Log-Err "Virtual environment (.venv) not found in $BACKEND_DIR. Run step 11 (Backend Setup) first."
            return
        }

        # The Django project root is the subdirectory that contains manage.py.
        # asgi.py lives at:  $BACKEND_DIR\Data_Recon_Main\Data_Recon_Main\asgi.py
        # Uvicorn must be launched from $BACKEND_DIR\Data_Recon_Main\ so that
        # Python can resolve the import "Data_Recon_Main.asgi" correctly.
        $DJANGO_PROJECT_DIR = Join-Path $BACKEND_DIR "Data_Recon_Main"
        if (!(Test-Path "$DJANGO_PROJECT_DIR\manage.py")) {
            Log-Err "CRITICAL: manage.py not found in $DJANGO_PROJECT_DIR. Repository may not be cloned correctly."
            return
        }

        Log-Info "Launching Uvicorn from $DJANGO_PROJECT_DIR"
        Log-Info "  URL : http://${API_HOST}:${API_PORT}"
        Log-Info "  ASGI: Data_Recon_Main.asgi:application"

        # MUST run detached via Start-Process, like Nginx/Airflow/FastAPI
        # all correctly do - Uvicorn never exits on its own, so a direct `&`
        # call here blocks this script forever, and any step after
        # StartBackend in the same invocation (e.g. -StepList
        # "StartBackend,AirflowSetup") would never run. Found live: this was
        # the only one of the four persistent-server steps that didn't
        # background itself, silently forcing every combined multi-step run
        # to be split into separate invocations by hand.
        # DJANGO_SETTINGS_MODULE is set inside the child window's own
        # session (`$env:...` is backtick-escaped so it's NOT expanded by
        # this script - it needs to run in the new window, not here).
        # --host $API_BIND_HOST (0.0.0.0), NOT $API_HOST - see the comment on
        # $API_BIND_HOST. Binding to loopback only makes Django unreachable
        # from Airflow inside WSL2, which arrives on the vEthernet adapter.
        $uvicornCmd = "`$env:DJANGO_SETTINGS_MODULE = 'Data_Recon_Main.settings'; & `"$VENV_PYTHON`" -m uvicorn Data_Recon_Main.asgi:application --host $API_BIND_HOST --port $API_PORT --reload"
        Start-Process powershell `
            -ArgumentList "-NoExit", "-Command", "Set-Location '$DJANGO_PROJECT_DIR'; $uvicornCmd" `
            -WindowStyle Normal
        Log-Ok "Uvicorn launched in a new window -> http://${API_HOST}:${API_PORT}"
    }
}

# ===========================================================================
# 14. FastAPI (AI Auto Draft) Setup & Start
#
# Part of the default run - checked by default in the GUI, included in a
# bare -Silent run with no -StepList, same as every other step.
# ===========================================================================
if ($run["FastAPISetup"]) {
    Log-Step "Step-14-FastAPISetup"
    # FastAPI lives inside the Backend repo checkout ("AI Auto Draft"
    # subfolder) - syncing means updating $BACKEND_DIR, same repo/branch
    # BackendSetup uses. Safe to call even if BackendSetup already did this
    # in the same run - Update-Or-Clone is a no-op fetch when already current.
    New-Item -ItemType Directory -Force -Path $BACKEND_ROOT | Out-Null
    Update-Or-Clone $BACKEND_DIR $BRANCH_BACKEND $BACKEND_REPO_URL "Backend" $COMMIT_BACKEND
    $FASTAPI_DIR = Join-Path $BACKEND_DIR "AI Auto Draft"

    if (!(Test-Path $FASTAPI_DIR)) {
        Log-Err "CRITICAL: FastAPI directory not found at '$FASTAPI_DIR'."
        Log-Err "          Ensure the backend repository was cloned (Step 8) and 'AI Auto Draft' subfolder exists."
    } else {
        # --- Write FastAPI .env - ONLY if it doesn't already exist ---
        # This file is not committed to the repo, and app/config.py's
        # Settings hard-requires several values (AZURE_OPENAI_API_KEY/
        # ENDPOINT, AZURE_STORAGE_CONNECTION_STRING, or the full AWS_* set
        # depending on CLOUD_PROVIDER) that this installer has no source of
        # truth for - they're operator-supplied, not deploy-config-derived.
        #
        # Previously this step regenerated the file on every run, which
        # tried copying AZURE_OPENAI_* from Data_Recon_Backend/.env (a
        # DIFFERENT repo's file, not really FastAPI's to inherit from) -
        # and, more importantly, silently clobbered whatever an operator had
        # since hand-edited into THIS file (a real value, a switch to
        # CLOUD_PROVIDER=aws, etc.) back to defaults on the next FastAPISetup
        # run. Reverted 2026-08-22 per instruction: this file is the
        # operator's to fill in by hand, once, and this step must never
        # overwrite it again after that.
        $fastapiEnvFile = Join-Path $FASTAPI_DIR ".env"
        if (Test-Path $fastapiEnvFile) {
            Log-Skip "FastAPI .env already exists at $fastapiEnvFile - not touching it (edit it directly for any changes)."
        } else {
            $fastapiEnvContent = @"
DATABASE_HOST=$DB_HOST
DATABASE_PORT=$DB_PORT
DATABASE_NAME=db_datarecon
DATABASE_USER=usr_dr_meta_rw
DATABASE_PASSWORD=$AIRFLOW_PG_PASSWORD
FASTAPI_INTERNAL_JWT_SECRET=$FASTAPI_INTERNAL_JWT_SECRET
FASTAPI_INTERNAL_JWT_ISSUER=django
FASTAPI_INTERNAL_JWT_AUDIENCE=fastapi
FASTAPI_BIND_HOST=$FASTAPI_HOST
FASTAPI_PORT=$FASTAPI_PORT
CLOUD_PROVIDER=azure
AZURE_OPENAI_API_KEY=
AZURE_OPENAI_ENDPOINT=
AZURE_OPENAI_DEPLOYMENT_NAME=
AZURE_OPENAI_API_VERSION=
AZURE_STORAGE_CONNECTION_STRING=
"@
            $fastapiEnvContent | Out-File -FilePath $fastapiEnvFile -Encoding utf8 -Force
            Log-Info "FastAPI .env created at: $fastapiEnvFile"
            Log-Warn "AZURE_OPENAI_*/AZURE_STORAGE_CONNECTION_STRING (or the AWS_* equivalents if using CLOUD_PROVIDER=aws) are blank - fill them in by hand before FastAPI will start. This file will NOT be overwritten on future runs."
        }

        # --- Create virtual environment ---
        $FASTAPI_VENV = Join-Path $FASTAPI_DIR ".venv"
        if (!(Test-Path $FASTAPI_VENV)) {
            Log-Info "Creating FastAPI virtual environment..."
            # Must be the system Python, not Django's own .venv python - the
            # `virtualenv` PACKAGE only ever gets installed at the system
            # Python level (BackendSetup uses it there to create Django's
            # .venv in the first place; it's never pip-installed inside the
            # resulting venv itself). Found live: this used to try Django's
            # venv python first - it exists (so the old fallback never
            # triggered), but always fails with "No module named virtualenv"
            # since that specific venv never has the package.
            $baseVenvPython = "$PYTHON_DEST\python.exe"
            if (!(Test-Path $baseVenvPython)) { $baseVenvPython = Join-Path $BACKEND_DIR ".venv\Scripts\python.exe" }
            & $baseVenvPython -m virtualenv $FASTAPI_VENV
            if ($LASTEXITCODE -ne 0) {
                Log-Err "CRITICAL: Failed to create FastAPI virtual environment (exit $LASTEXITCODE)."
            }
        } else {
            Log-Info "FastAPI virtual environment already exists at $FASTAPI_VENV."
        }

        $FASTAPI_VENV_PYTHON = Join-Path $FASTAPI_DIR ".venv\Scripts\python.exe"
        if (!(Test-Path $FASTAPI_VENV_PYTHON)) {
            Log-Err "CRITICAL: FastAPI venv python.exe not found at $FASTAPI_VENV_PYTHON. Skipping package install."
        } else {
            # --- Upgrade pip ---
            Log-Info "Upgrading pip in FastAPI venv..."
            & $FASTAPI_VENV_PYTHON -m pip install --upgrade pip --quiet

            # --- Install FastAPI core dependencies (from pyproject.toml) ---
            Log-Info "Installing FastAPI (AI Auto Draft) dependencies..."
            $fastapiPkgs = @(
                "fastapi>=0.109.0",
                "uvicorn[standard]>=0.27.0",
                "python-multipart>=0.0.6",
                "pandas>=2.1.4",
                "openpyxl>=3.1.2",
                "pydantic",
                "pydantic-settings",
                "python-dotenv",
                "sqlalchemy",
                "psycopg2-binary",
                # Separate from psycopg2-binary above, and both are genuinely
                # needed - app/core/database.py and app/api/v1/merge/routes.py
                # use SQLAlchemy with a "postgresql+psycopg2" connection
                # string (needs psycopg2), but app/core/fetch_query.py and
                # update_query.py call `psycopg.AsyncConnection.connect(...)`
                # directly (needs psycopg v3, a different package with a
                # different import name - NOT provided by psycopg2-binary).
                # Missing this caused a silent, total FastAPI startup
                # failure: "ModuleNotFoundError: No module named 'psycopg'"
                # on the very first import chain - found live 2026-08-21.
                "psycopg[binary]",
                "alembic",
                "requests",
                "PyJWT",
                "numpy>=2.1",
                "azure-identity",
                "azure-storage-blob",
                "azure-core",
                "langchain",
                "langchain-openai",
                "langchain-core",
                "langgraph",
                "openai",
                "azure-search-documents",
                # AWS mode (CLOUD_PROVIDER=aws) - app/core/s3_storage.py does
                # `__import__("boto3").client(...)` directly, and nothing else
                # in this list pulls it in transitively. Missing this produced
                # "ModuleNotFoundError: No module named 'boto3'" on the very
                # first request that touched BlobStorageClient - found live
                # 2026-08-21, on a machine actually using AWS mode (real S3 +
                # Bedrock credentials, not Azure).
                "boto3"
            )
            & $FASTAPI_VENV_PYTHON -m pip install @fastapiPkgs --quiet
            if ($LASTEXITCODE -ne 0) {
                Log-Err "FastAPI dependency install FAILED (exit $LASTEXITCODE)."
                Log-Warn "Azure AI/LangChain packages may require additional setup. Core FastAPI may still work."
            } else {
                Log-Ok "FastAPI dependencies installed."
            }

            # --- Clear port if occupied ---
            Log-Info "Clearing port $FASTAPI_PORT before starting FastAPI..."
            $existingFaProc = Get-NetTCPConnection -LocalPort ([int]$FASTAPI_PORT) -ErrorAction SilentlyContinue
            if ($existingFaProc) {
                Stop-Process -Id $existingFaProc.OwningProcess -Force -ErrorAction SilentlyContinue
                Start-Sleep -Seconds 1
                Log-Info "Port $FASTAPI_PORT cleared."
            }

            # --- Open Windows Firewall for FastAPI port ---
            $fwFastApi = "DART-FastAPI-$FASTAPI_PORT"
            try {
                $existingFwFa = Get-NetFirewallRule -DisplayName $fwFastApi -ErrorAction SilentlyContinue
                if ($null -eq $existingFwFa) {
                    New-NetFirewallRule -DisplayName $fwFastApi `
                        -Direction Inbound -Protocol TCP -LocalPort ([int]$FASTAPI_PORT) `
                        -Action Allow -Profile Any | Out-Null
                    Log-Ok "Firewall rule created: allow inbound TCP $FASTAPI_PORT ($fwFastApi)"
                } else {
                    Log-Info "Firewall rule '$fwFastApi' already exists."
                }
            } catch {
                Log-Warn "Could not create FastAPI firewall rule: $($_.Exception.Message)"
            }

            # --- Launch FastAPI in a new console window ---
            Log-Info "Launching FastAPI (AI Auto Draft) on ${FASTAPI_HOST}:${FASTAPI_PORT}..."

            # Generated-launcher-file pattern (same one DART-Uvicorn-Launcher.ps1
            # already uses, see Step 13) - NOT an inline -Command string. "AI Auto
            # Draft" has a space in it: embedding `"$FASTAPI_VENV_PYTHON`" (manually
            # quoted) inside a string that itself gets wrapped again by
            # Start-Process's own -ArgumentList quoting, then re-parsed a THIRD
            # time by the child powershell.exe's -Command, collides - the middle
            # layer's auto-quoting doesn't escape the quotes already inside the
            # string, so the embedded `"` characters terminate the outer quote
            # early and "AI" ends up parsed as a bare, unrecognized command.
            # Found live 2026-08-21: "C:\...\AI : The term 'C:\...\AI' is not
            # recognized...". Writing a real .ps1 file and launching it with
            # -File sidesteps all of that - it's parsed once, normally, as a
            # script file, never flattened into a nested command-line string.
            $faLauncherPath = Join-Path $INSTALL_ROOT "DART-FastAPI-Launcher.ps1"
            $faLines = @()
            $faLines += '# Auto-generated by VM-Windows-Bash-Script_V2.ps1 (Step 14)'
            $faLines += "Set-Location '$FASTAPI_DIR'"
            # Pre-flight .env check, printed IN THIS WINDOW before uvicorn even
            # tries to start - this .env is not committed to the repo (it's
            # generated by FastAPISetup, or hand-edited afterward), and a
            # missing/empty required value crashes FastAPI on import with a
            # multi-screen pydantic traceback that doesn't say what to actually
            # do about it. Found live 2026-08-21 (see BUG-024) - this surfaces
            # the same information as a short, actionable message first.
            $faLines += "`$envPath = '$FASTAPI_DIR\.env'"
            $faLines += 'if (-not (Test-Path $envPath)) {'
            $faLines += '    Write-Host ""'
            $faLines += '    Write-Host "======================================================" -ForegroundColor Red'
            $faLines += '    Write-Host " WARNING: FastAPI .env not found:" -ForegroundColor Red'
            $faLines += '    Write-Host "   $envPath" -ForegroundColor Red'
            $faLines += '    Write-Host " This file is NOT committed to the repo - it is generated" -ForegroundColor Red'
            $faLines += '    Write-Host " by FastAPISetup (Step 14), or must be created by hand." -ForegroundColor Red'
            $faLines += '    Write-Host " FastAPI will fail to start without it." -ForegroundColor Red'
            $faLines += '    Write-Host "======================================================" -ForegroundColor Red'
            $faLines += '    Write-Host ""'
            $faLines += '} else {'
            $faLines += '    $envLines = Get-Content $envPath'
            $faLines += "    `$checkKeys = @('AZURE_OPENAI_API_KEY','AZURE_OPENAI_ENDPOINT','AZURE_STORAGE_CONNECTION_STRING')"
            $faLines += '    $missingKeys = @()'
            $faLines += '    foreach ($k in $checkKeys) {'
            $faLines += '        $line = $envLines | Where-Object { $_ -match "^\s*$k\s*=" } | Select-Object -First 1'
            $faLines += "        if (-not `$line -or (`$line -replace '^[^=]*=','').Trim() -eq '') { `$missingKeys += `$k }"
            $faLines += '    }'
            $faLines += '    if ($missingKeys.Count -gt 0) {'
            $faLines += '        Write-Host ""'
            $faLines += '        Write-Host "======================================================" -ForegroundColor Yellow'
            $faLines += '        Write-Host " WARNING: these .env values are empty/missing:" -ForegroundColor Yellow'
            $faLines += '        foreach ($k in $missingKeys) { Write-Host "   - $k" -ForegroundColor Yellow }'
            $faLines += '        Write-Host " File: $envPath" -ForegroundColor Yellow'
            $faLines += '        Write-Host " FastAPI'+"'"+'s Settings validation requires all of these" -ForegroundColor Yellow'
            $faLines += '        Write-Host " (when CLOUD_PROVIDER=azure) and WILL crash on startup" -ForegroundColor Yellow'
            $faLines += '        Write-Host " without real values. Edit the file above, then re-run" -ForegroundColor Yellow'
            $faLines += '        Write-Host " this window. See test/issues/BUG-024 for background." -ForegroundColor Yellow'
            $faLines += '        Write-Host "======================================================" -ForegroundColor Yellow'
            $faLines += '        Write-Host ""'
            $faLines += '    }'
            $faLines += '}'
            $faLines += "Write-Host `"[Launcher] Starting FastAPI on ${FASTAPI_HOST}:${FASTAPI_PORT} ...`" -ForegroundColor Cyan"
            $faLines += "& '$FASTAPI_VENV_PYTHON' -m uvicorn $FASTAPI_APP --host $FASTAPI_HOST --port $FASTAPI_PORT --reload"
            [System.IO.File]::WriteAllLines($faLauncherPath, $faLines, [System.Text.Encoding]::UTF8)
            Log-Info "FastAPI launcher written to: $faLauncherPath"

            Start-Process powershell `
                -ArgumentList "-ExecutionPolicy", "Bypass", "-NoExit", "-File", $faLauncherPath `
                -WorkingDirectory $FASTAPI_DIR `
                -WindowStyle Normal
            Log-Ok "FastAPI launched  -> http://${FASTAPI_HOST}:${FASTAPI_PORT}"
            Log-Ok "Nginx proxy route -> https://$UI_HOST/fastapi/"
        }
    }
}

# ===========================================================================
# 15. Apache Airflow Setup (WSL2)
# ===========================================================================
if ($run["AirflowSetup"]) {
    Log-Step "Step-15-AirflowSetup"

    # --- Check WSL2 availability, self-install if missing -----------------
    # Mirrors the exact CLI sequence from docs/01-instacnesetup.md section 7
    # (Hyper-V + VirtualMachinePlatform + WSL features -> reboot -> wsl
    # --update -> wsl --set-default-version 2 -> wsl --install -d Ubuntu-24.04
    # --no-launch -> wsl --status / wsl -l -v), just with visible per-step
    # progress and no forced/unattended reboot (this can be running over
    # RDP/SSH - killing the session mid-script is worse than stopping and
    # telling the operator to restart and re-run).
    #
    # The distro first-run initialization is additionally timeout-guarded
    # via a background job, since an interactive prompt there (UNIX
    # username/password) would otherwise hang the whole script indefinitely
    # - the same class of silent-hang bug already found and fixed twice in
    # this step for PostgreSQL (pg_ctl restart/start).
    # $WSL_DISTRO is defined at top level (see the "Derive all paths" block) so the
    # -Clean handlers can target the same distro. Do not redefine it here.
    #
    # The virtualization preflight (Test-WslVirtualization) runs on EVERY
    # run: wsl.exe being installed does not mean WSL 2 can start a VM, and
    # that case used to skip straight to a distro install that could only fail.
    $wslNeedsReboot = $false
    $null = & wsl --status 2>&1
    $wslPresent = ($LASTEXITCODE -eq 0)
    $wslVirt = Test-WslVirtualization
    $_yn = { param($v) if ($null -eq $v) { 'unknown' } elseif ($v) { 'yes' } else { 'no' } }
    Log-Info ("WSL 2 preflight: wsl.exe {0}, hypervisor detected {1}, CPU virtualization {2}, VirtualMachinePlatform {3} -> virtualization {4}" -f `
        $(if ($wslPresent) { 'installed' } else { 'not installed' }), (& $_yn $wslVirt.Hypervisor), (& $_yn $wslVirt.CpuVirt),
        $(if ($wslVirt.Feature) { $wslVirt.Feature } else { 'unknown' }), $wslVirt.State)
    $wslReady = $wslPresent

    if ($wslVirt.State -eq 'NoVirtualization') {
        $wslReady = $false
        Write-WslVirtHelp
    }
    elseif ($wslVirt.State -eq 'NeedsRestart') {
        # Enabled earlier, restart not done yet. Not repeated as a feature
        # install - a restart is the only thing missing.
        $wslReady = $false
        $wslNeedsReboot = $true
        $script:NeedsRestart = $true
        Log-Pause "Restart required to finish installing WSL2" @(
            "VirtualMachinePlatform is enabled but waiting for a restart -",
            "WSL 2 cannot start a VM until then. This is a one-time checkpoint.",
            "",
            "1. Restart-Computer -Force   (or restart from the AWS/RDP console)",
            "2. Reconnect, then re-run just this step:",
            "     powershell -ExecutionPolicy Bypass -File .\VM-Windows-Bash-Script_V2.ps1 -Silent -StepList `"AirflowSetup`""
        )
    }
    elseif ($wslVirt.State -eq 'HypervisorOff') {
        # Feature enabled and restarted, CPU virtualization available, but the
        # hypervisor is not running. Not flagged as a restart: a restart alone
        # does not change this, and auto-resume would loop on it.
        $wslReady = $false
        $_hvLaunch = ((& bcdedit /enum '{current}' 2>$null | Out-String) -split "`r?`n" | Where-Object { $_ -match '^\s*hypervisorlaunchtype' }) -join ''
        Log-Err "VirtualMachinePlatform is enabled but the Windows hypervisor is not running - WSL 2 cannot start."
        if ($_hvLaunch -match 'Off') {
            Log-Warn "  The boot configuration has it switched off ($($_hvLaunch.Trim())). Fix, then restart:"
            Log-Warn "    bcdedit /set hypervisorlaunchtype auto"
        } else {
            Log-Warn "  Restart this machine once. If this message comes back after a restart, run DART-Check-Wsl.ps1"
            Log-Warn "  and check that nested virtualization (VM) or VT-x/AMD-V (physical) is enabled."
        }
        Log-Warn "  Then re-run:  .\VM-Windows-Bash-Script_V2.ps1 -Silent -StepList `"AirflowSetup`""
    }
    elseif (-not $wslPresent -or $wslVirt.State -eq 'NeedsFeature') {
        if ($wslPresent) {
            Log-Warn "WSL is installed but VirtualMachinePlatform (needed by WSL 2) is not enabled - enabling it now (required for Apache Airflow)."
        } else {
            Log-Warn "WSL2 is not installed on this machine - installing it now (required for Apache Airflow)."
        }

        # Step 7.1 - enable Hyper-V, Virtual Machine Platform, WSL
        # Each result is checked: with -ErrorAction SilentlyContinue a failed
        # enable (no admin, feature blocked by policy) still logged "enabled".
        # Microsoft-Hyper-V is optional - WSL 2 only needs VirtualMachinePlatform -
        # and does not exist on every edition, so its failure is only a warning.
        $wslFeatFailed = $false
        $wslFeatures = @("Microsoft-Hyper-V", "VirtualMachinePlatform", "Microsoft-Windows-Subsystem-Linux")
        for ($fi = 0; $fi -lt $wslFeatures.Count; $fi++) {
            $feat = $wslFeatures[$fi]
            Log-Info "[WSL $($fi+1)/5] Enabling Windows feature: $feat ..."
            $featResult = $null; $featErr = ''
            try { $featResult = Enable-WindowsOptionalFeature -Online -FeatureName $feat -All -NoRestart -ErrorAction Stop }
            catch { $featErr = $_.Exception.Message }
            if ($featErr -or -not $featResult) {
                if (-not $featErr) { $featErr = 'no result returned' }
                if ($feat -eq 'Microsoft-Hyper-V') {
                    Log-Warn "  --> $feat could not be enabled ($featErr) - optional for WSL 2, continuing."
                } else {
                    Log-Err "  --> $feat could NOT be enabled: $featErr"
                    $wslFeatFailed = $true
                }
                continue
            }
            if ($featResult.RestartNeeded) { $wslNeedsReboot = $true }
            $suffix = if ($featResult.RestartNeeded) { " (restart required)" } else { "" }
            Log-Ok "  --> $feat enabled$suffix"
        }

        if ($wslFeatFailed) {
            $wslReady = $false
            $wslNeedsReboot = $false
            Log-Err "WSL 2 could not be set up - a required Windows feature failed to enable (see above)."
            Log-Warn "  Run this script as Administrator. If it still fails, the feature is blocked by policy - ask IT to enable"
            Log-Warn "  VirtualMachinePlatform and Microsoft-Windows-Subsystem-Linux, then restart and re-run AirflowSetup."
        }
        elseif ($wslNeedsReboot) {
            $wslReady = $false
            # Not a failure - Windows genuinely cannot finish enabling
            # Hyper-V/WSL2 without a real restart, and the script deliberately
            # does not force one itself (would kill the RDP/SSH session
            # you're running this from). Steps 1-13 already succeeded and are
            # idempotent, so only AirflowSetup needs to be re-run afterward.
            $script:NeedsRestart = $true
            Log-Pause "Restart required to finish installing WSL2" @(
                "Hyper-V / WSL2 / VirtualMachinePlatform were just enabled but",
                "need one restart before they're usable - this is a normal,",
                "one-time checkpoint, not an error.",
                "",
                "1. Restart-Computer -Force   (or restart from the AWS/RDP console)",
                "2. Reconnect, then re-run just this step:",
                "     powershell -ExecutionPolicy Bypass -File .\VM-Windows-Bash-Script_V2.ps1 -Silent -StepList `"AirflowSetup`"",
                "",
                "Everything already completed (steps 1-13) will not be repeated."
            )
        } else {
            # Step 7.2 - update WSL kernel, set default version 2
            Log-Info "[WSL 4/5] Updating WSL kernel components and setting default version 2..."
            # Output is kept (and still logged line by line) so a refusal to run
            # at all can be told apart from an install problem - see
            # Test-WslLogonSessionError.
            $wslUpdOut = @(& wsl --update 2>&1 | ForEach-Object { $t = ("$_" -replace "`0", '').Trim(); if ($t) { Log-Info "  $t"; $t } })
            $wslUpdOut += @(& wsl --set-default-version 2 2>&1 | ForEach-Object { $t = ("$_" -replace "`0", '').Trim(); if ($t) { Log-Info "  $t"; $t } })
            if (Test-WslLogonSessionError ($wslUpdOut -join "`n")) { $script:WslLogonErr = $true }

            # Step 7.3 - install Ubuntu
            $instExit = 0
            if (-not $script:WslLogonErr) {
                Log-Info "[WSL 5/5] Installing $WSL_DISTRO (this can take a few minutes)..."
                $instOut = @(& wsl --install -d $WSL_DISTRO --no-launch 2>&1 | ForEach-Object { $t = ("$_" -replace "`0", '').Trim(); if ($t) { Log-Info "  $t"; $t } })
                $instExit = $LASTEXITCODE
                if (Test-WslLogonSessionError ($instOut -join "`n")) { $script:WslLogonErr = $true }
            }

            if ($script:WslLogonErr) {
                # Not a catalog, network or restart problem - retrying any of
                # those, as the old messages suggested, cannot help.
                $wslReady = $false
                Write-WslLogonHelp
            } else {
                # The exit code used to be ignored entirely, so a distro name this
                # machine's catalog does not offer produced WSL's "use
                # 'wsl --list --online' and pick one" message, and the script
                # carried on regardless - initialising a distro that was never
                # installed, then failing much later with something unrelated.
                # Look the catalog up and retry automatically rather than handing
                # the operator a manual step.
                if ($instExit -ne 0) {
                    Log-Warn "'$WSL_DISTRO' could not be installed (exit $instExit) - it may not exist in this machine's distro catalog."
                    Log-Info "Querying available distributions (wsl --list --online)..."
                    $resolvedDistro = Resolve-WslDistro $WSL_DISTRO
                    if (-not $resolvedDistro) {
                        Log-Err "Could not read the distro catalog - is this machine online, and is WSL healthy?"
                        Log-Warn "  Run 'wsl --list --online' manually to see what is available, then set WSL_DISTRO in dart_deploy_config.json."
                    } elseif ($resolvedDistro -eq $WSL_DISTRO) {
                        Log-Err "'$WSL_DISTRO' IS listed as available but the install still failed - this is a WSL or network problem, not a wrong name."
                        Log-Warn "  Try 'wsl --update' and re-run. If WSL reports REGDB_E_CLASSNOTREG, repair it with 'wsl --install --no-distribution'."
                    } else {
                        Log-Warn "Falling back to '$resolvedDistro' (chosen from the catalog; only 24.04 qualifies - 22.04 ships Python 3.10, too old for the DART DAGs, and newer releases ship 3.14, which Airflow does not support)."
                        $WSL_DISTRO = $resolvedDistro
                        & wsl --install -d $WSL_DISTRO --no-launch 2>&1 | ForEach-Object { Log-Info "  $_" }
                        if ($LASTEXITCODE -ne 0) {
                            Log-Err "Fallback distro '$WSL_DISTRO' also failed to install (exit $LASTEXITCODE)."
                        } else {
                            Log-Ok "Installed '$WSL_DISTRO'."
                            Save-CfgKey "WSL_DISTRO" $WSL_DISTRO
                        }
                    }
                }

                Log-Info "  --> Initializing $WSL_DISTRO first-run as root (avoids the interactive username prompt)..."
                $wslInitJob = Start-Job -ScriptBlock { param($d) & wsl -d $d -u root -- echo "ready" } -ArgumentList $WSL_DISTRO
                if (Wait-Job $wslInitJob -Timeout 120) {
                    # Check the answer: a failed `wsl -d` also finishes quickly,
                    # and this used to report "initialized" for a distro that had
                    # never been installed.
                    $initOut = ((Receive-Job $wslInitJob 2>&1 | Out-String) -replace "`0", '')
                    if ($initOut -match 'ready') {
                        Log-Ok "  --> $WSL_DISTRO initialized."
                    } else {
                        Log-Err "  --> $WSL_DISTRO did not start: $($initOut.Trim())"
                    }
                } else {
                    Log-Err "$WSL_DISTRO first-run initialization did not finish within 120s - it may be stuck on an interactive setup prompt."
                    Log-Warn "Open a terminal and run 'wsl -d $WSL_DISTRO' once manually to complete first-time setup, then re-run this step."
                }
                Stop-Job $wslInitJob -ErrorAction SilentlyContinue | Out-Null
                Remove-Job $wslInitJob -Force -ErrorAction SilentlyContinue

                # Step 7.4 - verify
                Start-Sleep -Seconds 2
                $null = & wsl --status 2>&1
                $wslReady = ($LASTEXITCODE -eq 0)
                if ($wslReady) {
                    Log-Ok "WSL2 installed and ready."
                    & wsl -l -v 2>&1 | ForEach-Object { Log-Info "  $_" }
                } else {
                    Log-Err "WSL2 install did not complete cleanly."
                    Log-Warn "Restart this machine, then re-run:"
                    Log-Warn "  .\VM-Windows-Bash-Script_V2.ps1 -Silent -StepList `"AirflowSetup`""
                }
            }
        }
    }

    if ($wslReady) {
        # Every run, not only a fresh install: on a machine that already had
        # WSL with default version 1, a newly installed Ubuntu would come up
        # as WSL 1 and need converting.
        $dvOut = @(& wsl --set-default-version 2 2>&1 | ForEach-Object { ("$_" -replace "`0", '').Trim() } | Where-Object { $_ })
        if ($LASTEXITCODE -ne 0) {
            $dvOut | ForEach-Object { Log-Warn "  $_" }
            if (Test-WslVirtError ($dvOut -join "`n")) { $script:WslVirtErrorSeen = $true }
            Log-Warn "Could not set the default WSL version to 2 - continuing; the distro check below still requires WSL 2."
        } else {
            Log-Info "Default WSL version: 2."
        }
    }

    if (-not $wslReady) {
        # Skip this generic fallback when a branch above already printed a
        # specific, actionable message (restart banner, no virtualization,
        # hypervisor off, feature failed) - showing both back to back was
        # confusing.
        if (-not $wslNeedsReboot -and -not $wslFeatFailed -and -not $script:WslLogonErr -and $wslVirt.State -notin @('NoVirtualization', 'HypervisorOff')) {
            Log-Warn "Apache Airflow requires WSL2 on Windows. To enable WSL2 manually, see docs/01-instacnesetup.md section 7:"
            Log-Warn "  1. Enable-WindowsOptionalFeature -Online -FeatureName Microsoft-Hyper-V,VirtualMachinePlatform,Microsoft-Windows-Subsystem-Linux -All -NoRestart"
            Log-Warn "  2. Restart-Computer -Force"
            Log-Warn "  3. wsl --update; wsl --set-default-version 2; wsl --install -d $WSL_DISTRO --no-launch"
        }
        if (-not $wslNeedsReboot) { Log-Warn "Skipping Airflow setup." }
    } elseif (-not (Ensure-WslDistro)) {
        Log-Warn "Skipping Airflow setup - no supported WSL distro (see above)."
    } else {
        Log-Info "WSL2 is available. Proceeding with Airflow setup in '$WSL_DISTRO'..."

        New-Item -ItemType Directory -Force -Path $AIRFLOW_REPO_ROOT | Out-Null
        Update-Or-Clone $AIRFLOW_REPO_DIR $BRANCH_AIRFLOW $AIRFLOW_REPO_URL "Airflow" $COMMIT_AIRFLOW

        # -------------------------------------------------------------------
        # WSL2-to-Windows-Postgres connectivity - self-contained, runs
        # regardless of which OTHER steps were selected in this invocation.
        #
        # NOT an AWS Security Group issue: this traffic never leaves the
        # machine. WSL2 and the Windows host share one Hyper-V virtual
        # switch on the same EC2 instance; Security Groups only govern the
        # instance's external network interface. This is purely local:
        #
        #   1. Postgres defaults to listen_addresses='localhost' - it binds
        #      ONLY true loopback (127.0.0.1/::1), never the vEthernet (WSL)
        #      adapter WSL2 traffic actually arrives on.
        #   2. Windows Firewall never filters true 127.0.0.1 loopback, so
        #      Django/nginx/FastAPI (all native Windows) are unaffected -
        #      but WSL2 crosses a real virtual NIC and IS subject to it.
        #
        # This used to live only in Step 5 (PostgreSQL), which is correct
        # for a first-time full run - but a partial re-run that selects only
        # AirflowSetup (exactly what happens when Step 15 is the one that
        # failed and gets retried alone) would skip Step 5 entirely and
        # silently carry the bug forward. Checking/fixing it here too closes
        # that gap: idempotent, a few hundred ms if already correct, and it
        # only touches anything when DB_HOST is actually local.
        # -------------------------------------------------------------------
        $airflowDbIsLocal = $DB_HOST -in @("127.0.0.1", "localhost", "::1", "")
        if ($airflowDbIsLocal) {
            $pgDataAf = Join-Path $TOOLS_ROOT "postgres\data"
            $pgConfAf = Join-Path $pgDataAf "postgresql.conf"
            if (Test-Path $pgConfAf) {
                $confLines = [System.IO.File]::ReadAllLines($pgConfAf, [System.Text.Encoding]::UTF8)
                $alreadyListening = $confLines | Where-Object { $_ -match "^\s*listen_addresses\s*=\s*'\*'" }
                if ($alreadyListening) {
                    Log-Skip "PostgreSQL listen_addresses (already '*' - WSL2 can reach it)"
                } else {
                    $listenFoundAf = $false
                    $confLines = for ($i = 0; $i -lt $confLines.Length; $i++) {
                        if ($confLines[$i] -match "^#?listen_addresses\s*=") {
                            "listen_addresses = '*'"
                            $listenFoundAf = $true
                        } else {
                            $confLines[$i]
                        }
                    }
                    if (-not $listenFoundAf) { $confLines += "listen_addresses = '*'" }
                    [System.IO.File]::WriteAllLines($pgConfAf, [string[]]$confLines, [System.Text.Encoding]::ASCII)
                    Log-Ok "PostgreSQL: listen_addresses = '*' applied so WSL2 (Airflow) can reach it."

                    $pgCtlAf = Join-Path $TOOLS_ROOT "postgres\bin\pg_ctl.exe"
                    if (Test-Path $pgCtlAf) {
                        # -m fast is mandatory here, not cosmetic. pg_ctl restart
                        # defaults to "smart" shutdown mode, which waits
                        # INDEFINITELY for every existing client to disconnect on
                        # its own before it will even stop the server - on a
                        # single-purpose deployment VM with no other tenants,
                        # that produces exactly a silent multi-minute hang the
                        # moment anything (even a previous failed Airflow
                        # attempt) is still holding a connection. Found live:
                        # this exact line hung for 5+ minutes on first run.
                        # "fast" disconnects existing sessions immediately -
                        # matches the mode the script's own PostgreSQL cleanup
                        # step already uses ($pgCtl -D $pgData stop -m fast -s).
                        # Detached (Invoke-PgCtlDetached): a restart run with `&`
                        # leaves the new postmaster attached to this console.
                        $rcAf = Invoke-PgCtlDetached $pgCtlAf @('restart', '-D', $pgDataAf, '-m', 'fast', '-w', '-t', '60', '-l', (Join-Path $TOOLS_ROOT "postgres\server.log")) 90
                        if ($rcAf -eq 0) { Log-Ok "PostgreSQL restarted to apply listen_addresses." }
                        else { Log-Warn "pg_ctl restart returned '$rcAf' - the readiness check below will start PostgreSQL if needed." }
                    }
                }
            } else {
                Log-Warn "postgresql.conf not found at $pgConfAf - was PostgreSQL (Step 5) ever run? Airflow's DB connection will likely fail."
            }

            $fwPgRuleAf = "DART-Postgres-$DB_PORT"
            $existingPgAf = Get-NetFirewallRule -DisplayName $fwPgRuleAf -ErrorAction SilentlyContinue
            if ($null -eq $existingPgAf) {
                try {
                    New-NetFirewallRule -DisplayName $fwPgRuleAf `
                        -Direction Inbound -Protocol TCP -LocalPort ([int]$DB_PORT) `
                        -Action Allow -Profile Any -ErrorAction Stop | Out-Null
                    Log-Ok "Firewall rule created: allow inbound TCP port $DB_PORT ($fwPgRuleAf) - needed for WSL2 (Airflow) to reach Postgres."
                } catch {
                    Log-Warn "Could not create Postgres firewall rule (needs admin rights): $($_.Exception.Message)"
                    Log-Warn "Manually run as Administrator: New-NetFirewallRule -DisplayName '$fwPgRuleAf' -Direction Inbound -Protocol TCP -LocalPort $DB_PORT -Action Allow"
                }
            } else {
                Log-Skip "Firewall rule $fwPgRuleAf (already exists)"
            }

            # Config-correctness is not the same thing as running. The
            # "already '*'" skip branch above only proves the FILE is right -
            # it says nothing about whether postgres.exe is actually up right
            # now. Found live: after an interrupted `pg_ctl restart` (e.g. a
            # Ctrl+C during the old "smart" mode hang this same block used to
            # cause), Postgres was left fully stopped - not just unreachable
            # from WSL2, but "Connection refused" even on 127.0.0.1 loopback.
            # The rest of this step would have run for several more minutes
            # (venv setup, pip install) before failing at the DB migration,
            # instead of catching it here in a few seconds.
            # Real handshake, not "port LISTENING": on 2026-10-14 the port
            # was held by an orphaned postgres.exe after the postmaster died,
            # this check said "already running", and the GRANT below then hung.
            # Start-PgSafe detects that, cleans it up and starts detached.
            if (-not (Start-PgSafe (Join-Path $TOOLS_ROOT "postgres\bin") (Join-Path $TOOLS_ROOT "postgres\data") (Join-Path $TOOLS_ROOT "postgres\server.log") "$DB_PORT")) {
                Log-Err "PostgreSQL is not accepting connections - Airflow's DB migration will fail. Check $TOOLS_ROOT\postgres\server.log."
            }
        }

        # Derive paths
        $AIRFLOW_REPO_DIR = Join-Path $INSTALL_ROOT "airflow\Data-Recon-Airflow"
        $drvLower        = $INSTALL_ROOT[0].ToString().ToLower()
        $installRootWsl  = "/mnt/$drvLower/" + $INSTALL_ROOT.Substring(3).Replace('\', '/')
        $airflowRepoWsl  = "$installRootWsl/airflow/Data-Recon-Airflow"
        
        # AIRFLOW_HOME and MEDIA_PATH both point at the ONE media root the
        # rest of the deployment already uses ($MEDIA_DIR_WIN, resolved from
        # MEDIA_PATH near the top of this script) - Airflow and Django have
        # to agree on this directory, since Django generates the DAG files
        # Airflow then reads. This used to be a second, independently
        # hardcoded copy of the backend-nested path; deriving it means a
        # change to MEDIA_PATH can no longer leave the two pointing at
        # different folders.
        $reconFilesWin   = $MEDIA_DIR_WIN
        if (!(Test-Path $reconFilesWin)) { New-Item -ItemType Directory -Path $reconFilesWin -Force | Out-Null }
        $airflowHomeWsl  = ConvertTo-WslPath $reconFilesWin
        $airflowDagsWsl  = "$airflowHomeWsl/media/6-DAG/dags"
        $airflowDbConn   = "postgresql+psycopg2://${AIRFLOW_PG_USER}:${AIRFLOW_PG_PASSWORD}@${DB_HOST}/db_datarecon?options=-csearch_path%3Drecon_airflow"

        # --- venv location: native WSL2 filesystem, NOT /mnt/c/... ---
        # Found live 2026-08-21: airflow-venv used to live inside the repo
        # checkout at $airflowRepoWsl (i.e. under /mnt/c/DART_DEPLOY/... -
        # the Windows filesystem, reached through WSL2's cross-OS DrvFs
        # layer). Every single `airflow` CLI invocation was taking 90-140s
        # of pure wait (confirmed: `python3 -c "import airflow"` ALONE took
        # 1m32s wall-clock with only ~14s of actual CPU time - user+sys vs
        # real time proved it was I/O wait, not CPU work, not `db migrate`,
        # not telemetry - importing airflow touches thousands of files
        # across its provider packages, and each file op crossing the DrvFs
        # boundary carries enough latency to compound into 90+ seconds).
        # This is a well-documented WSL2 characteristic, not fixable by
        # code changes to what Airflow does - the fix is putting the venv
        # somewhere Python can actually read it fast: native WSL2 (ext4)
        # storage. $HOME is used (not a literal path) since the WSL2
        # username isn't known in advance across machines - $HOME/... is
        # correct however account's home dir is named.
        $afNativeVenvWsl = '$HOME/dart-airflow-venv'

        # --- Fast path: skip apt-get/pip entirely if Airflow is already installed ---
        # Every AirflowSetup run used to unconditionally do `apt-get update`,
        # a full `pip install` across ~80 packages, and `airflow db migrate`,
        # even when the venv already exists and nothing changed - meaning
        # DART-Start.ps1 (which just delegates to this same step) paid the
        # full "install from scratch" cost every single time you just wanted
        # to (re)start an already-installed Airflow. Found live 2026-08-21
        # ("it always installs with 6 steps, we just need it up and
        # running"). A single fast local check (does the native venv's
        # airflow binary already exist and run?) lets a start-only run skip
        # straight to launching, while a genuinely fresh machine still gets
        # the full install untouched.
        #
        # Outer PowerShell string is single-quoted deliberately - $HOME must
        # NOT be interpolated by PowerShell (it isn't a PowerShell variable
        # here), it needs to reach bash literally so BASH expands it at
        # runtime. Same reasoning as $afNativeVenvWsl above.
        $afAlreadyInstalled = $false
        $afCheckOut = wsl -d $WSL_DISTRO bash -c 'test -x "$HOME/dart-airflow-venv/bin/airflow" && echo EXISTS' 2>$null
        if ($afCheckOut -match "EXISTS") { $afAlreadyInstalled = $true }
        if ($afAlreadyInstalled) {
            Log-Skip "Airflow venv + packages (already installed at $afNativeVenvWsl) - going straight to (re)start."
        }

        # --- One-time migration: remove a stale pre-fix venv on /mnt/c ---
        # Only matters on a machine that already ran AirflowSetup before
        # this fix landed. Untracked directory (never git-tracked, matches
        # the same reasoning `git reset --hard` already relies on
        # elsewhere in this step), safe to remove outright - a fresh venv
        # gets rebuilt at the native path below regardless of whether this
        # old one is cleaned up or not.
        $afOldVenvCheck = wsl -d $WSL_DISTRO bash -c "test -d '$airflowRepoWsl/airflow-venv' && echo EXISTS" 2>$null
        if ($afOldVenvCheck -match "EXISTS") {
            Log-Warn "Removing stale airflow-venv from the old /mnt/c location (slow DrvFs path) - moving to native WSL2 storage at $afNativeVenvWsl for performance."
            wsl -d $WSL_DISTRO bash -c "rm -rf '$airflowRepoWsl/airflow-venv'" 2>$null
        }

        # --- Run Airflow DB schema SQL and explicit grants for usr_dr_air_rw ---
        $PsqlExeAirflow = Join-Path $TOOLS_ROOT "postgres\bin\psql.exe"
        if (Test-Path $PsqlExeAirflow) {
            Log-Info "Configuring PostgreSQL recon_airflow schema and permissions for $AIRFLOW_PG_USER..."
            # lock_timeout + -w + PGCONNECT_TIMEOUT: this used to wait forever,
            # silently, when a still-running Airflow held sessions on the
            # recon_airflow tables (or on a hidden password prompt) - Airflow
            # never started and the log just stopped here. Found live
            # 2026-10-14. Now it fails within 30s with a logged error instead.
            $afGrantSql = "SET lock_timeout = '30s'; CREATE SCHEMA IF NOT EXISTS recon_airflow; GRANT USAGE, CREATE ON SCHEMA recon_airflow TO ${AIRFLOW_PG_USER}; GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA recon_airflow TO ${AIRFLOW_PG_USER}; GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA recon_airflow TO ${AIRFLOW_PG_USER}; ALTER DEFAULT PRIVILEGES IN SCHEMA recon_airflow GRANT ALL PRIVILEGES ON TABLES TO ${AIRFLOW_PG_USER}; ALTER DEFAULT PRIVILEGES IN SCHEMA recon_airflow GRANT ALL PRIVILEGES ON SEQUENCES TO ${AIRFLOW_PG_USER}; GRANT USAGE ON SCHEMA recon_audit TO ${AIRFLOW_PG_USER};"
            $prevEAPAf = $ErrorActionPreference
            $ErrorActionPreference = "Continue"
            $prevPgConnTimeout = $env:PGCONNECT_TIMEOUT
            $env:PGCONNECT_TIMEOUT = "10"
            & $PsqlExeAirflow -h $DB_HOST -p $DB_PORT -d "db_datarecon" -U "postgres" -w -c $afGrantSql 2>&1 | ForEach-Object { Log-Info "  psql: $_" }
            $afGrantExit = $LASTEXITCODE
            $env:PGCONNECT_TIMEOUT = $prevPgConnTimeout
            $ErrorActionPreference = $prevEAPAf
            # This used to Log-Ok unconditionally, regardless of whether psql
            # actually connected - found live: it printed "verified" right
            # after a "Connection refused" one line above it, while the
            # grants had not been applied at all. Check the real exit code.
            if ($afGrantExit -eq 0) {
                Log-Ok "Airflow PostgreSQL schema permissions verified."
            } else {
                Log-Err "Failed to configure recon_airflow schema/permissions (psql exit $afGrantExit) - see the psql output just above. Airflow's DB migration will likely fail next."
                Log-Err "  'canceling statement due to lock timeout' = Airflow is still running in WSL2: run DART-Stop.ps1 (or wsl -d $WSL_DISTRO -u root bash -c `"pkill -f '[a]irflow'`"), then start again."
            }
        }

        # --- Open Windows Firewall for PostgreSQL Port and WSL virtual adapter ---
        # Name matches $fwPgRule/$fwPgRuleAf ("DART-Postgres-$DB_PORT") used
        # in Step 5 and earlier in this step - this used to be spelled
        # "DART-PostgreSQL-..." (extra "SQL"), which meant the Get-
        # NetFirewallRule existence check here never found the rule those
        # other two blocks had already created, and this block would try
        # (and, before the fix below, silently fail or double-create) a
        # separate rule every single run.
        $fwPg = "DART-Postgres-$DB_PORT"
        Set-NetFirewallProfile -DisabledInterfaceAliases "vEthernet (WSL)" -ErrorAction SilentlyContinue
        New-NetFirewallRule -DisplayName "Allow-WSL-All" -Direction Inbound -InterfaceAlias "vEthernet (WSL)" -Action Allow -Profile Any -ErrorAction SilentlyContinue | Out-Null
        try {
            $existingFwPg = Get-NetFirewallRule -DisplayName $fwPg -ErrorAction SilentlyContinue
            if ($null -eq $existingFwPg) {
                New-NetFirewallRule -DisplayName $fwPg `
                    -Direction Inbound -Protocol TCP -LocalPort ([int]$DB_PORT) `
                    -Action Allow -Profile Any -ErrorAction Stop | Out-Null
                Log-Ok "Windows Firewall configured to allow WSL2 to connect to PostgreSQL ($DB_PORT)."
            } else {
                Log-Skip "Firewall rule $fwPg (already exists)"
            }
        } catch {
            # This used to be a bare `catch { }` with an unconditional Log-Ok
            # right after it - found live: it printed "configured" straight
            # after a real "Access is denied" CIM error, on a standard
            # (non-admin) Windows account. Report it honestly instead.
            Log-Warn "Could not create Postgres firewall rule (needs admin rights): $($_.Exception.Message)"
            Log-Warn "Manually run as Administrator: New-NetFirewallRule -DisplayName '$fwPg' -Direction Inbound -Protocol TCP -LocalPort $DB_PORT -Action Allow"
        }

        # --- Ensure pg_hba.conf accepts connections from WSL virtual network ---
        $pgHba = Join-Path $TOOLS_ROOT "postgres\data\pg_hba.conf"
        if (Test-Path $pgHba) {
            $hbaContent = Get-Content $pgHba -Raw -ErrorAction SilentlyContinue
            if ($hbaContent -notmatch "0\.0\.0\.0/0") {
                Add-Content -Path $pgHba -Value "`nhost    all             all             0.0.0.0/0               trust"
                $pgCtl = Join-Path $TOOLS_ROOT "postgres\bin\pg_ctl.exe"
                if (Test-Path $pgCtl) {
                    & $pgCtl -D (Join-Path $TOOLS_ROOT "postgres\data") reload 2>$null
                }
            }
        }

        # --- Ensure system packages in WSL2 without sudo password prompts ---
        # Also best-effort install a pinned Python 3.12/3.13 build alongside
        # whatever python3 the distro defaults to. No released Apache
        # Airflow version supports Python 3.14 yet - found live: on a distro
        # whose default `python3` was already 3.14, `python3 -m venv` picked
        # it up silently, and every single apache-airflow version on PyPI
        # then got rejected by pip on Requires-Python, minutes into the
        # install. Ignoring apt failures here (2>/dev/null || true) since
        # not every package name exists in every Ubuntu release's repos -
        # the venv-creation step below re-detects whatever actually landed.
        if ($afAlreadyInstalled) {
            Log-Skip "[Airflow 1/6] WSL2 Ubuntu packages (already installed)"
        } else {
            Log-Info "[Airflow 1/6] Installing WSL2 Ubuntu packages (python3-venv, pip, libpq-dev)..."
            wsl -d $WSL_DISTRO -u root bash -c "apt-get update -qq && apt-get install -y -qq python3-venv python3-pip git libpq-dev; for v in python3.12 python3.13; do apt-get install -y -qq `$v `${v}-venv 2>/dev/null || true; done"
        }

        # --- Write WSL bash setup script to TEMP ---
        $wslScriptPath = Join-Path $env:TEMP "dart_airflow_setup.sh"
        $wslDrv        = $wslScriptPath[0].ToString().ToLower()
        $wslScriptWsl  = "/mnt/$wslDrv/" + $wslScriptPath.Substring(3).Replace('\', '/')

        # Built conditionally so a fast "just start it" run skips the actual
        # `pip install` entirely - the expensive part (~80 packages resolved
        # even when every one is already satisfied). Venv *creation* above
        # stays bash-level idempotent (`if [ ! -d airflow-venv ]`) either way.
        $afPipInstallBlock = if ($afAlreadyInstalled) {
@"
echo '[Airflow 3/6] Airflow already installed - skipping pip install.'
"@
        } else {
@"
echo '[Airflow 3/6] Installing Airflow & Provider packages via pip...'
echo '  --> Installing core Airflow (postgres, celery, redis)...'
pip install --upgrade pip --no-warn-script-location

# Pin the extras to the SAME version requirements.txt pins.
#
# "apache-airflow[postgres,celery,redis]" with no version is a second,
# unconstrained requirement for a package requirements.txt already pins. If
# the resolver ever satisfies that with a newer Airflow, `airflow db migrate`
# stamps public.alembic_version with the NEWER release's head - and every
# later run on the pinned version dies with:
#     alembic.util.exc.CommandError: Can't locate revision identified by '...'
# because the older package does not ship that migration. Seen on the UAT VM
# 2026-08-25: metadata at the 3.2.0 head, venv on 3.1.2.
#
# Reading the version out of requirements.txt keeps that file the single
# source of truth rather than hardcoding it here in a second place.
AF_VER=`$(grep -iE '^[[:space:]]*apache-airflow[[:space:]]*==' requirements.txt 2>/dev/null | head -1 | sed -E 's/.*==[[:space:]]*//' | tr -d '[:space:]')
if [ -n "`$AF_VER" ]; then
    echo "  --> Pinning Airflow extras to `$AF_VER (from requirements.txt)"
    AF_SPEC="apache-airflow[postgres,celery,redis]==`$AF_VER"
else
    echo "  --> WARNING: requirements.txt does not pin apache-airflow - installing extras unpinned."
    echo "      A newer Airflow may be resolved and migrate the metadata DB past this deployment's version."
    AF_SPEC="apache-airflow[postgres,celery,redis]"
fi

pip install -r requirements.txt "`$AF_SPEC" \
    apache-airflow-providers-microsoft-azure \
    apache-airflow-providers-http \
    apache-airflow-providers-smtp \
    apache-airflow-providers-postgres --no-warn-script-location
echo '  --> All packages installed successfully.'
"@
        }

        # -------------------------------------------------------------------
        # DART DAG environment - LOWERCASE variable names.
        #
        # These are NOT Airflow settings. The repo's own DAG code reads them
        # directly, e.g. dags/system_dag.py:
        #   os.environ['AIRFLOW_CONN_DB_CONN_STR'] =
        #     f"postgres://{os.environ.get('airflow_pg_user')}:..."
        #     f"@{os.environ.get('postgresql_url_lcl')}:5432/db_datarecon"
        #
        # os.environ.get() returns None when unset, and an f-string renders
        # that as the literal text "None" - so without these the DAGs build
        # "postgres://None:None@None:5432/db_datarecon" and fail with a DNS
        # lookup for a host called "None". Found live 2026-09-09 on the EC2
        # deployment, on the first real DAG run.
        #
        # Airflow's OWN metadata connection (AIRFLOW__DATABASE__SQL_ALCHEMY_CONN)
        # was always correct, which is why the scheduler, the UI and db
        # migrate all worked while every DAG failed - the two connections are
        # built from completely separate sources.
        #
        # The dev team's .start_up_vm exports these; this installer builds its
        # own environment instead (that file is hardcoded to a dev machine -
        # /mnt/e/... paths, CeleryExecutor+Redis we don't run, and their Azure
        # database), so anything it defines has to be reproduced here or it is
        # silently missing. Values come from config, not hardcoded.
        #
        # _lcl and _rmt both point at the same local Postgres: per the dev
        # team (2026-09-09) no DAG needs a second remote database today.
        # az_blob_container is deliberately omitted - Django only reads it
        # when STORAGE_TYPE=azure, and generated sensors hardcode
        # strg_type='local'.
        # -------------------------------------------------------------------
        # --- airflow_admin_password: prefer the password Airflow ALREADY generated ---
        # `airflow standalone` mints a random admin password on first setup and
        # writes it to simple_auth_manager_passwords.json.generated inside
        # AIRFLOW_HOME, then reuses that file on every later start. So the value
        # is unknowable on a truly first run, but known on every run after -
        # which is the common case (restarts, re-runs of this step).
        #
        # Without this the export was literally airflow_admin_password="" and any
        # DAG authenticating back to the Airflow API got a 401. Config still wins
        # if AIRFLOW_ADMIN_PASSWORD is set explicitly, so a deployment that wants
        # a deterministic password can pin one.
        $afAdminPassword = $AIRFLOW_ADMIN_PASSWORD
        if ([string]::IsNullOrWhiteSpace($afAdminPassword)) {
            $afExistingPwFile = Join-Path $reconFilesWin "simple_auth_manager_passwords.json.generated"
            if (Test-Path $afExistingPwFile) {
                try {
                    $afExistingPw = Get-Content $afExistingPwFile -Raw | ConvertFrom-Json
                    if ($afExistingPw.PSObject.Properties.Name -contains $AIRFLOW_ADMIN_USER) {
                        $afAdminPassword = $afExistingPw.$AIRFLOW_ADMIN_USER
                        Log-Info "Reusing Airflow's previously generated admin password for '$AIRFLOW_ADMIN_USER'."
                    }
                } catch {
                    Log-Warn "Could not parse $afExistingPwFile - airflow_admin_password will be empty this run: $($_.Exception.Message)"
                }
            } else {
                Log-Info "No generated Airflow password yet (first run) - airflow_admin_password starts empty and is synced after launch."
            }
        }

        $afDartEnv = @(
            "postgresql_url=`"`$DB_HOST_WSL`"",
            "postgresql_url_lcl=`"`$DB_HOST_WSL`"",
            "postgresql_url_rmt=`"`$DB_HOST_WSL`"",
            "airflow_pg_user=`"$AIRFLOW_PG_USER`"",
            "airflow_pg_password=`"$AIRFLOW_PG_PASSWORD`"",
            "airflow_dart_user=`"dr_mstr_srvc`"",
            "airflow_api_endpoint=`"http://localhost:$AIRFLOW_PORT`"",
            "airflow_api_version=`"/api/v2`"",
            "airflow_admin_user=`"$AIRFLOW_ADMIN_USER`"",
            "airflow_admin_password=`"$afAdminPassword`"",
            "django_airflow_secret_key=`"$DJANGO_AIRFLOW_SECRET_KEY`"",
            # api_auth_task() (dags/user_tasks/tasks.py, Data-Recon-Airflow
            # UAT commit 96237c9) reads these directly and raises
            # AirflowFailException if either is unset - previously hardcoded
            # in that file, now required here. Same default seed credentials
            # already used elsewhere in this script (see the auth smoke test
            # below). mail_sender in the same commit also now reads
            # SMTP_MAIL_FROM as a bare var, not just via the composed
            # AIRFLOW_CONN_SMTP_DART URI below.
            "DART_API_EMAIL=`"recon@admin.com`"",
            "DART_API_PASSWORD=`"recon@123`"",
            "SMTP_MAIL_FROM=`"$SMTP_MAIL_FROM`""
        )
        # Same list, rendered for the two places Airflow's environment is
        # built - the setup script (newline-separated) and the standalone
        # launch command (&&-chained). Built from one array so they cannot
        # drift apart.
        $afDartEnvBlock  = ($afDartEnv | ForEach-Object { "export $_" }) -join "`n"
        $afDartEnvInline = ($afDartEnv | ForEach-Object { "export $_ && " }) -join ""

        # Airflow's OWN settings (AIRFLOW__*), built from one array and
        # rendered into both export sites - exactly like $afDartEnv above.
        #
        # These were previously written out by hand at each site, and the
        # two had already drifted: ACCESS_CONTROL_ALLOW_ORIGINS and
        # JWT_EXPIRATION_TIME were set in the setup script but NOT in the
        # standalone launch below. The launch is what actually runs the
        # api-server, so the process serving the UI ran with no CORS
        # origins at all. Building both from one array is what stops that
        # class of bug recurring.
        #
        # Values are double-quoted for bash: the header and method lists
        # contain spaces, and the SMTP URI contains '&', which bash would
        # otherwise read as 'run this in the background'.
        $smtpTlsVal = $(if ($SMTP_STARTTLS -match '^\s*(?i:true|1|yes|y)\s*$') { 'True' } else { 'False' })
        $smtpSslVal = $(if ($SMTP_SSL      -match '^\s*(?i:true|1|yes|y)\s*$') { 'True' } else { 'False' })

        # Percent-encode the two values that land in the URI's userinfo.
        # Both routinely contain characters that are structural there: '@'
        # in the sender would split userinfo from host, and '/', ':' or '#'
        # in a password truncates it silently - which surfaces much later
        # as an SMTP auth failure rather than as a parse error.
        #
        # Done here in PowerShell rather than with a python3 subshell inside
        # the bash string, because $(...) would have to survive two layers
        # of quoting (PowerShell here-string, then bash) to reach python
        # intact. EscapeDataString also encodes '/', which Python's
        # urllib.parse.quote leaves alone by default and which is not legal
        # unencoded in userinfo.
        $smtpPassEnc = [uri]::EscapeDataString([string]$SMTP_PASSWORD)
        $smtpFromEnc = [uri]::EscapeDataString([string]$SMTP_MAIL_FROM)
        if (-not $SMTP_PASSWORD) {
            Log-Warn "SMTP password is empty - set EMAIL_HOST_PASSWORD in dart_deploy_config.json."
            Log-Warn "  AIRFLOW_CONN_SMTP_DART is still exported, but any DAG email task will fail to authenticate."
        }
        $afSmtpUri = "smtp://${smtpFromEnc}:${smtpPassEnc}@${SMTP_HOST}:${SMTP_PORT}?tls=$smtpTlsVal&ssl=$smtpSslVal&disable_ssl=true"

        # Azure Blob connection for Airflow DAG WasbHook
        $azureBlobKeyEnc = [uri]::EscapeDataString([string]$AZURE_BLOB_KEY)
        $afBlobUri       = "wasb://@${AZURE_AC_NAME}.blob.core.windows.net?extra__wasb__account_name=${AZURE_AC_NAME}&extra__wasb__account_key=${azureBlobKeyEnc}"

        # Standard Airflow database, filesystem, and API connection URIs
        #
        # DB_HOST_WSL is a BASH variable, resolved at runtime inside WSL (it
        # becomes 127.0.0.1, or the Windows host IP when Postgres is not
        # reachable on WSL's own loopback - see the detection block in the
        # setup script below). It must therefore stay LITERAL in these
        # strings for bash to expand, which is what the backtick does.
        #
        # Written unescaped, PowerShell expands it instead - and since no
        # PowerShell variable of that name exists, it silently becomes an
        # empty string. That produced 'http://:8000/' and
        # 'postgres://user:pw@:5432/db_datarecon', which Airflow stores as
        # host-less connections and renders back as 'http://@:8000'. DAG
        # tasks then died with:
        #     InvalidURL: Invalid URL 'http://@:8000/run_import/upload':
        #     No host supplied
        # - found live 2026-09-11. It is not a network or DAG-logic fault:
        # requests rejects the string in prepare_url before opening a socket.
        #
        # AIRFLOW__DATABASE__SQL_ALCHEMY_CONN below already escapes it
        # correctly, which is why Airflow itself starts and schedules fine
        # while only the DAG's own connections are broken - the scheduler
        # running is not evidence that these three are right.
        $afLocalDbUri  = "postgres://${AIRFLOW_PG_USER}:${AIRFLOW_PG_PASSWORD}@`${DB_HOST_WSL}:${DB_PORT}/db_datarecon"
        $afRemoteDbUri = "postgres://${AIRFLOW_PG_USER}:${AIRFLOW_PG_PASSWORD}@`${DB_HOST_WSL}:${DB_PORT}/db_datarecon"
        # airflowHomeWsl IS a PowerShell variable - it stays interpolated.
        $afFsUri       = "file://${airflowHomeWsl}/"
        $afApiUri      = "http://`${DB_HOST_WSL}:${API_PORT}/"

        $afCfgEnv = @(
            "STORAGE_TYPE=`"$STORAGE_TYPE`"",
            "AIRFLOW__CORE__LOAD_EXAMPLES=False",
            "AIRFLOW__CORE__EXECUTOR=LocalExecutor",
            "AIRFLOW__CORE__DEFAULT_TIMEZONE=`"$AIRFLOW_DEFAULT_TIMEZONE`"",
            "AIRFLOW__DAG_PROCESSOR__REFRESH_INTERVAL=$AIRFLOW_DAG_PROCESSOR_REFRESH_INTERVAL",
            "AIRFLOW__DAG_PROCESSOR__MIN_FILE_PROCESS_INTERVAL=$AIRFLOW_DAG_PROCESSOR_MIN_FILE_PROCESS_INTERVAL",
            "AIRFLOW__API__ACCESS_CONTROL_ALLOW_ORIGINS='https://$UI_HOST,http://localhost:$API_PORT'",
            "AIRFLOW__API__ACCESS_CONTROL_ALLOW_HEADERS=`"$AIRFLOW_CORS_ALLOW_HEADERS`"",
            "AIRFLOW__API__ACCESS_CONTROL_ALLOW_METHODS=`"$AIRFLOW_CORS_ALLOW_METHODS`"",
            "AIRFLOW__API_AUTH__JWT_EXPIRATION_TIME=$AIRFLOW_JWT_EXPIRATION",
            "AIRFLOW_CONN_SMTP_DART=`"$afSmtpUri`"",
            "AIRFLOW_CONN_FS_DART=`"$afFsUri`"",
            "AIRFLOW_CONN_API_DART=`"$afApiUri`"",
            "AIRFLOW_CONN_LOCAL_DB=`"$afLocalDbUri`"",
            "AIRFLOW_CONN_REMOTE_DB=`"$afRemoteDbUri`"",
            "AZURE_AC_NAME=`"$AZURE_AC_NAME`"",
            "AZURE_BLOB_KEY=`"$AZURE_BLOB_KEY`"",
            "AIRFLOW_CONN_BLOB_DART=`"$afBlobUri`""
        )
        $afCfgEnvBlock  = ($afCfgEnv | ForEach-Object { "export $_" }) -join "`n"
        $afCfgEnvInline = ($afCfgEnv | ForEach-Object { "export $_ && " }) -join ""

        $wslSetupScript = @"
#!/bin/bash
set -e

echo '====================================================='
echo '  DART Airflow Setup in WSL2'
echo '====================================================='
cd $airflowRepoWsl

echo '[Airflow 2/6] Setting up Python virtual environment (native WSL2 storage - not /mnt/c)...'

# An EXISTING venv must be checked too, not just trusted.
#
# The version selection below only ever ran when the venv was absent, so a
# venv built against an unsupported Python was reused forever - and pip then
# failed on every single Airflow release with "Requires-Python", which reads
# like a network or index problem rather than a Python-version one.
#
# Found live 2026-09-10: after wiping WSL, the fresh distro's default python3
# was 3.14. A venv got created against it, and `apache-airflow==3.1.2`
# (Requires-Python >=3.10,<3.14) could not be installed at all. Removing an
# incompatible venv here lets the block below rebuild it on a supported
# interpreter.
if [ -d "$afNativeVenvWsl" ]; then
    VENV_MM=`$("$afNativeVenvWsl/bin/python" -c 'import sys;print("%d.%d"%sys.version_info[:2])' 2>/dev/null)
    # 3.10/3.11 are rebuilt too: Airflow itself runs on them, but the DART
    # DAG code uses Python 3.12 syntax (quotes reused inside f-strings,
    # PEP 701) - on 3.10 system_dag.py fails to import with
    # "SyntaxError: f-string: unmatched '('" (EC2 2026-10-19, Ubuntu 22.04).
    case "`$VENV_MM" in
        3.12|3.13)
            echo "  --> Existing venv uses Python `$VENV_MM (supported)" ;;
        *)
            echo "  --> Existing venv uses Python `${VENV_MM:-unknown} - DART needs 3.12-3.13 (Airflow >=3.10,<3.14 and the DART DAGs >=3.12) - rebuilding it"
            rm -rf "$afNativeVenvWsl" ;;
    esac
fi

if [ ! -d "$afNativeVenvWsl" ]; then
    # Pick a Python DART supports (3.12-3.13: Airflow <3.14, DAGs >=3.12) rather than
    # trusting whatever `python3` defaults to - found live: a distro whose
    # default python3 was already 3.14 silently produced a venv that no
    # released Airflow version can install into at all (every version on
    # PyPI got rejected on Requires-Python). Prefer 3.12 (widest provider
    # support); Step 1 of this Airflow setup already best-effort installed
    # these candidates as root, so this just picks whichever landed.
    PYVER=""
    for cand in python3.12 python3.13; do
        if command -v `$cand >/dev/null 2>&1; then PYVER=`$cand; break; fi
    done
    if [ -z "`$PYVER" ]; then
        # No explicitly-versioned interpreter found. Before falling back to
        # bare `python3`, check that IT is in range - because creating a venv
        # on an unsupported interpreter guarantees failure later, at pip, with
        # an error that reads like a network or index problem:
        #     ERROR: No matching distribution found for apache-airflow==X.Y.Z
        #
        # The old code fell back to python3 unconditionally with only a
        # warning. Combined with the venv revalidation above that becomes a
        # loop: the bad venv is deleted, recreated on the same bad
        # interpreter, and fails again every run. Better to stop here and say
        # exactly what is wrong and how to fix it.
        SYS_MM=`$(python3 -c 'import sys;print("%d.%d"%sys.version_info[:2])' 2>/dev/null)
        case "`$SYS_MM" in
            3.12|3.13)
                PYVER=python3
                echo "  --> Using python3 (`$SYS_MM)" ;;
            *)
                echo "  --> ERROR: this distro has no Python that Airflow supports."
                echo "      Found python3 = `${SYS_MM:-unknown}; DART needs 3.12-3.13 (Airflow >=3.10,<3.14, DART DAGs >=3.12)."
                echo "      Install a supported interpreter, e.g.:"
                echo "          sudo apt-get update && sudo apt-get install -y python3.12 python3.12-venv"
                echo "      Or point the deployment at a distro that ships one by setting"
                echo "      WSL_DISTRO in dart_deploy_config.json (currently: $WSL_DISTRO)."
                exit 1 ;;
        esac
    else
        echo "  --> Using `$PYVER (`$(`$PYVER --version 2>&1))"
    fi
    `$PYVER -m venv "$afNativeVenvWsl"
    echo "  --> Created fresh venv at $afNativeVenvWsl (native WSL2 filesystem, not /mnt/c - avoids the DrvFs import-speed penalty)"
else
    echo "  --> $afNativeVenvWsl already exists"
fi

source "$afNativeVenvWsl/bin/activate"

$afPipInstallBlock

echo '[Airflow 4/6] Configuring directories and environment variables...'
mkdir -p $airflowDagsWsl
mkdir -p $airflowHomeWsl/logs
mkdir -p $airflowHomeWsl/logs/dag_processor_manager
mkdir -p $airflowHomeWsl/logs/scheduler
mkdir -p $airflowHomeWsl/media/6-DAG/dags

# Detect Windows Host IP from WSL2
HOST_IP=`$(ip route show default 2>/dev/null | awk '{print `$3}')
if [ -z "`$HOST_IP" ]; then
    HOST_IP=`$(grep -m 1 nameserver /etc/resolv.conf 2>/dev/null | awk '{print `$2}')
fi

DB_HOST_WSL="127.0.0.1"
if python3 -c "import socket; s=socket.socket(); s.settimeout(2); exit(0 if s.connect_ex(('127.0.0.1', $DB_PORT))==0 else 1)" 2>/dev/null; then
    DB_HOST_WSL="127.0.0.1"
elif [ -n "`$HOST_IP" ] && python3 -c "import socket; s=socket.socket(); s.settimeout(2); exit(0 if s.connect_ex(('`$HOST_IP', $DB_PORT))==0 else 1)" 2>/dev/null; then
    DB_HOST_WSL="`$HOST_IP"
else
    DB_HOST_WSL="`$HOST_IP"
fi
echo "  --> Detected PostgreSQL at: `$DB_HOST_WSL:$DB_PORT"

export AIRFLOW_HOME=$airflowHomeWsl
export AIRFLOW__CORE__DAGS_FOLDER=$airflowDagsWsl
export MEDIA_PATH=$airflowHomeWsl
export AIRFLOW__DATABASE__SQL_ALCHEMY_CONN="postgresql+psycopg2://${AIRFLOW_PG_USER}:${AIRFLOW_PG_PASSWORD}@`$DB_HOST_WSL:${DB_PORT}/db_datarecon?options=-csearch_path%3Drecon_airflow"
$afCfgEnvBlock

# Logging - set EXPLICITLY, not left to Airflow's default.
#
# Nothing here configured logging at all before: the script created
# `$AIRFLOW_HOME/logs` and then trusted Airflow to choose the same path. That
# is only true while nothing else says otherwise - and the Airflow repo ships
# a ~90KB airflow.cfg whose [logging] section can, so where task logs land
# depended on which config Airflow happened to load. When the writer
# (scheduler/task) and the reader (api-server) disagree, the UI shows an
# empty log pane with no error anywhere: the file exists, just not where the
# UI looks. Env vars beat airflow.cfg, so pinning it here makes both ends
# agree regardless of which cfg is present.
export AIRFLOW__LOGGING__BASE_LOG_FOLDER=$airflowHomeWsl/logs
export AIRFLOW__LOGGING__DAG_PROCESSOR_MANAGER_LOG_LOCATION=$airflowHomeWsl/logs/dag_processor_manager/dag_processor_manager.log

# DART DAG environment (lowercase - read by the repo's DAG code, not by Airflow)
$afDartEnvBlock

echo '[Airflow 5/6] Running database migrations against PostgreSQL...'
airflow db migrate
echo '  --> Database schema migration complete.'

if [ -f airflow_db_connections.json ]; then
    echo '[Airflow 6/6] Importing Airflow connections...'
    airflow connections import airflow_db_connections.json 2>/dev/null || true
fi

# Wiring DART DAGs
echo '  --> Wiring DART system DAGs, user tasks, and API_DART endpoint...'
cp -rf $airflowRepoWsl/dags/. $airflowDagsWsl/ 2>/dev/null || true
for sp in $afNativeVenvWsl/lib/python*/site-packages; do
    printf '%s\n%s\n' "$airflowRepoWsl/dags" "$airflowDagsWsl" > "`$sp/dart_dags.pth"
done
# Re-run safe. The delete used to be fully silenced, so when it failed the
# add stopped the whole setup under set -e with only "A connection with
# conn_id=API_DART already exists" (EC2 2026-10-19, second AirflowSetup run).
# Now the delete's reason is shown, and an existing API_DART is kept with a
# warning instead of failing the run - AIRFLOW_CONN_API_DART (exported above)
# takes precedence over the DB entry at runtime anyway.
del_out=`$(airflow connections delete API_DART 2>&1) || echo "  [INFO] API_DART not deleted: `$(echo "`$del_out" | tail -1)"
# airflow connections add API_DART --conn-uri "http://`$DB_HOST_WSL:$API_PORT" 2>/dev/null || true
if ! add_out=`$(airflow connections add API_DART --conn-uri "http://127.0.0.1:$API_PORT" 2>&1); then
    if echo "`$add_out" | grep -q 'already exists'; then
        echo '  [WARN] API_DART already exists in the Airflow DB and could not be replaced - keeping it (the AIRFLOW_CONN_API_DART env var is used at runtime).'
    else
        echo "`$add_out"
        exit 1
    fi
fi

# SMTP_DART must also live in the Airflow DB, not only in the
# AIRFLOW_CONN_SMTP_DART env var. Airflow 3.1 runs DAG-level
# on_success/on_failure callbacks in the dag-processor, which resolves
# connections from the metadata DB, so the env var alone gives
# "conn_id SMTP_DART isn't defined" and no workflow emails (root cause
# of the AWS email outage, 2026-10-13). Same URI as the env var, which is
# exported above via afCfgEnvBlock. Delete + add so a re-run picks up a
# changed SMTP password.
airflow connections delete SMTP_DART 2>/dev/null || true
if [ -n "`$AIRFLOW_CONN_SMTP_DART" ]; then
    airflow connections add SMTP_DART --conn-uri "`$AIRFLOW_CONN_SMTP_DART" >/dev/null
    echo '  --> SMTP_DART connection stored in the Airflow DB.'
else
    echo '  [WARN] AIRFLOW_CONN_SMTP_DART is empty - SMTP_DART not stored; workflow emails will fail.'
fi

echo '====================================================='
echo '  Airflow Setup Completed Successfully!'
echo '====================================================='
"@
        $wslSetupScriptUnix = $wslSetupScript -replace "`r`n", "`n"
        [System.IO.File]::WriteAllText($wslScriptPath, $wslSetupScriptUnix, (New-Object System.Text.UTF8Encoding($false)))

        Log-Info "Executing Airflow setup in WSL2..."
        wsl -d $WSL_DISTRO bash -c "tr -d '\r' < '$wslScriptWsl' | bash"
        if ($LASTEXITCODE -eq 0) {
            Log-Ok "Airflow install and db migrate completed."

            # --- Start Airflow standalone in a new WSL2 window ---
            $afStartCmd = "cd $airflowRepoWsl && source $afNativeVenvWsl/bin/activate && " +
                "HOST_IP=`$(ip route show default 2>/dev/null | awk '{print `$3}'); " +
                "DB_HOST_WSL='127.0.0.1'; " +
                "if [ -n `"`$HOST_IP`" ] && ! nc -z -w 1 127.0.0.1 $DB_PORT 2>/dev/null; then DB_HOST_WSL=`$HOST_IP; fi; " +
                "export AIRFLOW_HOME=$airflowHomeWsl && " +
                "export AIRFLOW__CORE__DAGS_FOLDER=$airflowDagsWsl && " +
                "export MEDIA_PATH=$airflowHomeWsl && " +
                "export AIRFLOW__DATABASE__SQL_ALCHEMY_CONN=`"postgresql+psycopg2://${AIRFLOW_PG_USER}:${AIRFLOW_PG_PASSWORD}@`$DB_HOST_WSL:${DB_PORT}/db_datarecon?options=-csearch_path%3Drecon_airflow`" && " +
                # Airflow's own settings, from the same array as the setup
                # script above so the two cannot drift. This launch runs
                # the api-server, so CORS and JWT matter HERE.
                $afCfgEnvInline +
                # Logging pinned here too - this is the launch that actually
                # runs the scheduler and api-server, so if only the setup
                # script above set it the running processes would fall back
                # to Airflow's default and the UI would show empty logs.
                "export AIRFLOW__LOGGING__BASE_LOG_FOLDER=$airflowHomeWsl/logs && " +
                "export AIRFLOW__LOGGING__DAG_PROCESSOR_MANAGER_LOG_LOCATION=$airflowHomeWsl/logs/dag_processor_manager/dag_processor_manager.log && " +
                # Lowercase DART DAG variables - this is the launch that
                # actually runs the scheduler, so omitting them here is what
                # produces the "None" host at DAG-parse time even when the
                # setup script above had them.
                $afDartEnvInline +
                "airflow standalone"
            # -d $WSL_DISTRO: this is the launch that actually runs Airflow, so
            # it must land in the same distro the venv was built in. Without it
            # the scheduler starts in the machine's default distro, where that
            # venv does not exist.
            Start-Process wsl -ArgumentList "-d", $WSL_DISTRO, "bash", "-c", $afStartCmd -WindowStyle Normal
            Log-Ok "Airflow standalone launched in a new WSL2 window."
            Log-Ok "Airflow UI          -> http://localhost:$AIRFLOW_PORT"

            # --- Sync Airflow's REAL admin password into Django's .env ---
            # `airflow standalone` auto-generates a random admin password on
            # every fresh setup (simple_auth_manager_passwords.json.generated,
            # inside AIRFLOW_HOME - Airflow 3.x's simple auth manager, not the
            # old standalone_admin_password.txt the log line here used to
            # reference, which doesn't even exist with this Airflow version).
            # Django's Recon_Scheduler (token_manager.py) authenticates to
            # Airflow's own /auth/token using AIRFLOW_ADMIN_USER/PASSWORD from
            # C:\DART_DEPLOY\.env - a static/config value can never match a
            # freshly-regenerated random password, which is exactly what
            # produced a 401 on every /auth/token call (list_workflows and
            # friends) - found live 2026-08-22. Read Airflow's actual
            # generated password once the file exists, and write it into
            # Django's own .env so the two can never drift out of sync -
            # genuine fix, not a one-time hardcoded value.
            # -----------------------------------------------------------------
            # Add the address Airflow calls Django on to ALLOWED_HOSTS.
            #
            # Airflow lives inside WSL2 and reaches Django across the vEthernet
            # (WSL) adapter, so its requests carry a Host header of the Windows
            # host's WSL-side IP (e.g. 172.27.64.1) - never localhost. Django
            # rejects any host not in ALLOWED_HOSTS with a bare HTML 400
            # (DisallowedHost) before a view ever runs, so a DAG hitting
            # /run_import/... just sees an opaque 400 with nothing in the app
            # logs to explain it.
            #
            # That IP is assigned by WSL2 and CHANGES on reboot, which is why it
            # cannot simply be written into config once by hand. Detect it at the
            # moment Airflow starts and record it, so the next backend restart
            # picks it up automatically.
            # `cut -d' ' -f3`, not `awk '{print $3}'`: the awk form needs a $3
            # that has to survive PowerShell expansion, wsl.exe argument
            # quoting AND bash - three layers, each with its own escaping.
            # cut needs no $ at all.
            #
            # The output is then stripped of NUL bytes and CRs before use.
            # wsl.exe frequently emits UTF-16LE, which PowerShell reads as a
            # string with a NUL between every character - so a perfectly good
            # "172.27.64.1" arrives as "1`0 7`0 2`0 ..." and fails the IPv4
            # regex below, silently skipping the ALLOWED_HOSTS update. That is
            # exactly what happened on the first live run (2026-09-09): the
            # password sync in the same block worked, this did not.
            $wslHostIp = $null
            try {
                $wslRaw = (& wsl -d $WSL_DISTRO -u root bash -c "ip route show default | cut -d' ' -f3" 2>$null | Out-String)
                $wslHostIp = ($wslRaw -replace "`0", "" -replace "`r", "").Trim()
                if ($wslHostIp -match '(\d{1,3}(?:\.\d{1,3}){3})') { $wslHostIp = $Matches[1] }
            } catch { $wslHostIp = $null }

            $mainEnvForHosts = Join-Path $INSTALL_ROOT ".env"
            if ($wslHostIp -match '^\d{1,3}(\.\d{1,3}){3}$') {
                if (Add-AllowedHost $mainEnvForHosts $wslHostIp) {
                    Log-Ok "Added Airflow's WSL2 host address '$wslHostIp' to ALLOWED_HOSTS in $mainEnvForHosts - restart the backend to apply."
                } else {
                    Log-Info "ALLOWED_HOSTS already contains Airflow's WSL2 host address '$wslHostIp'."
                }
            } else {
                Log-Warn "Could not determine the WSL2 host IP Airflow will call Django on (got '$wslHostIp')."
                Log-Warn "  If DAG tasks fail with a plain HTML 400, add that address to ALLOWED_HOSTS in $mainEnvForHosts by hand."
            }

            $afPasswordFile = Join-Path $reconFilesWin "simple_auth_manager_passwords.json.generated"
            Log-Info "Waiting for Airflow to generate its admin password file..."
            $afPwWaited = 0
            $afPwJson   = $null
            do {
                Start-Sleep -Seconds 2
                $afPwWaited += 2
                if (Test-Path $afPasswordFile) {
                    try { $afPwJson = Get-Content $afPasswordFile -Raw | ConvertFrom-Json } catch { $afPwJson = $null }
                }
            } while (-not $afPwJson -and $afPwWaited -lt 90)

            if ($afPwJson -and ($afPwJson.PSObject.Properties.Name -contains $AIRFLOW_ADMIN_USER)) {
                $realAirflowPassword = $afPwJson.$AIRFLOW_ADMIN_USER
                $mainEnvFile = Join-Path $INSTALL_ROOT ".env"
                if (Test-Path $mainEnvFile) {
                    # Written in BOTH cases. Django's settings.py reads the
                    # LOWERCASE name (os.environ.get("airflow_admin_password")).
                    # Python normalises env keys on Windows so the uppercase pair
                    # happens to resolve there too, but that is a Windows-only
                    # accident - the lowercase keys are what the code actually
                    # asks for, so write them explicitly rather than relying on
                    # it. The uppercase pair is kept for anything already reading
                    # those names.
                    [void](Set-EnvKey $mainEnvFile "AIRFLOW_ADMIN_USER"     $AIRFLOW_ADMIN_USER)
                    [void](Set-EnvKey $mainEnvFile "AIRFLOW_ADMIN_PASSWORD" $realAirflowPassword)
                    [void](Set-EnvKey $mainEnvFile "airflow_admin_user"     $AIRFLOW_ADMIN_USER)
                    [void](Set-EnvKey $mainEnvFile "airflow_admin_password" $realAirflowPassword)
                    Log-Ok "Synced Airflow's real admin password into $mainEnvFile (both AIRFLOW_ADMIN_* and airflow_admin_*) - restart the backend (StartBackend / DART-Start.ps1) to pick it up."
                } else {
                    Log-Warn "Could not sync Airflow admin password - $mainEnvFile not found. Add AIRFLOW_ADMIN_USER/PASSWORD to it manually: $afPasswordFile"
                }
            } else {
                Log-Warn "Could not read Airflow's generated admin password from $afPasswordFile after ${afPwWaited}s - Django's Airflow API calls (list_workflows, etc.) will likely 401 until this is synced manually."
            }

            # --- Open Windows Firewall for Airflow port ---
            $fwAirflow = "DART-Airflow-$AIRFLOW_PORT"
            try {
                $existingFwAf = Get-NetFirewallRule -DisplayName $fwAirflow -ErrorAction SilentlyContinue
                if ($null -eq $existingFwAf) {
                    New-NetFirewallRule -DisplayName $fwAirflow `
                        -Direction Inbound -Protocol TCP -LocalPort ([int]$AIRFLOW_PORT) `
                        -Action Allow -Profile Any -ErrorAction Stop | Out-Null
                    Log-Ok "Firewall rule created: allow inbound TCP $AIRFLOW_PORT ($fwAirflow)"
                } else {
                    Log-Info "Firewall rule '$fwAirflow' already exists."
                }
            } catch {
                Log-Warn "Could not create Airflow firewall rule (needs admin rights): $($_.Exception.Message)"
                Log-Warn "Manually run as Administrator: New-NetFirewallRule -DisplayName '$fwAirflow' -Direction Inbound -Protocol TCP -LocalPort $AIRFLOW_PORT -Action Allow"
            }
        } else {
            Log-Err "Airflow WSL2 setup failed (exit $LASTEXITCODE)."
            Log-Warn "Manual fallback: wsl bash '$airflowRepoWsl/.start_up_vm'"
        }
        Remove-Item $wslScriptPath -Force -ErrorAction SilentlyContinue
    }
}

# ===========================================================================
# 16. VS Code Install (+ Extensions)
# ===========================================================================
if ($run["VSCodeInstall"]) {
    Log-Step "Step-16-VSCodeInstall"
    $VSCODE_EXE = "$env:LOCALAPPDATA\Programs\Microsoft VS Code\Code.exe"
    $VSCODE_SYS = "C:\Program Files\Microsoft VS Code\Code.exe"
    if ((Test-Path $VSCODE_EXE) -or (Test-Path $VSCODE_SYS)) {
        Log-Skip "Visual Studio Code"
        $codeCmd = if (Test-Path $VSCODE_EXE) { $VSCODE_EXE } else { $VSCODE_SYS }
    } else {
        Log-Info "Visual Studio Code not found. Downloading installer..."
        $vsCodeUrl       = "https://update.code.visualstudio.com/latest/win32-x64-user/stable"
        $vsCodeInstaller = "$env:TEMP\VSCodeSetup.exe"
        try {
            Invoke-WebRequest -Uri $vsCodeUrl -OutFile $vsCodeInstaller -UseBasicParsing
            Log-Info "Installing VS Code silently..."
            Start-Process -FilePath $vsCodeInstaller -ArgumentList "/verysilent /mergetasks=!runcode,addcontextmenufiles,addcontextmenufolders,associatewithfiles,addtopath" -Wait
            if (Test-Path $VSCODE_EXE) {
                Log-Ok "Visual Studio Code installed successfully."
                $codeCmd = $VSCODE_EXE
            } else {
                Log-Err "VS Code installer ran but Code.exe not found at expected path."
                $codeCmd = $null
            }
        } catch {
            Log-Err "Failed to download/install VS Code: $_"
            $codeCmd = $null
        }
    }

    # --- Install recommended extensions ---
    if ($null -ne $codeCmd) {
        # Extension installs MUST go through the CLI wrapper (bin\code.cmd),
        # never Code.exe directly. Code.exe is the GUI binary; calling it
        # with --install-extension can, on a machine where VS Code has never
        # run before (no user-data dir seeded yet), open the actual main
        # window instead of behaving as a one-shot CLI - and since `&` blocks
        # until the child process exits, and a GUI window doesn't exit
        # itself, the whole script hangs indefinitely with zero further
        # output. Found live on the Grange Insurance VM - same silent-hang
        # failure class already fixed twice for PostgreSQL and once for WSL2
        # distro init in this script.
        $vscodeRoot   = Split-Path $codeCmd -Parent
        $codeCliCmd   = Join-Path $vscodeRoot "bin\code.cmd"

        if (!(Test-Path $codeCliCmd)) {
            Log-Warn "VS Code CLI wrapper not found at $codeCliCmd - skipping extension installs (Code.exe alone is unsafe to call unattended)."
        } else {
            $extensions = @(
                "ms-python.python",
                "ms-python.vscode-pylance",
                "ms-python.debugpy",
                "dbaeumer.vscode-eslint",
                "esbenp.prettier-vscode",
                "eamodio.gitlens",
                "ms-azuretools.vscode-docker",
                "mtxr.sqltools",
                "mtxr.sqltools-driver-pg"
            )
            Log-Info "Installing VS Code extensions..."

            function Install-VsCodeExtension($cli, $extName, $timeoutSec) {
                $job = Start-Job -ScriptBlock {
                    param($c, $n)
                    & $c --install-extension $n --force 2>&1
                } -ArgumentList $cli, $extName
                $completed = $false
                if (Wait-Job $job -Timeout $timeoutSec) {
                    Receive-Job $job | Out-Null
                    $completed = ($job.State -eq "Completed")
                } else {
                    Stop-Job $job -ErrorAction SilentlyContinue | Out-Null
                }
                Remove-Job $job -Force -ErrorAction SilentlyContinue
                return $completed
            }

            foreach ($ext in $extensions) {
                # Timeout-guarded even with the CLI wrapper - defense in
                # depth so a future edge case here can never hang silently
                # again either. One retry with a longer budget: found live
                # that the largest extension (ms-python.python, which bundles
                # a full language server + native binaries) can miss a 60s
                # window on a cold marketplace connection - especially when
                # it's the first extension call in the loop - while every
                # smaller extension right after it succeeds comfortably.
                if (Install-VsCodeExtension $codeCliCmd $ext 60) {
                    Write-Host "  [OK] $ext" -ForegroundColor Green
                } elseif (Install-VsCodeExtension $codeCliCmd $ext 120) {
                    Write-Host "  [OK] $ext (retry)" -ForegroundColor Green
                } else {
                    Write-Host "  [WARN] Could not install $ext (timed out twice) - skipping" -ForegroundColor Yellow
                }
            }
            Log-Ok "VS Code extension installation complete."
        }

        # --- Open the whole install root, not just Backend ---
        # Was pointed at $BACKEND_DIR alone - opened only
        # backend\Data_Recon_Backend, with frontend\, Database\, and
        # airflow\ (siblings under $INSTALL_ROOT, not children of
        # $BACKEND_DIR) invisible in that VS Code window. Found live
        # 2026-08-21 ("it always opens the backend code only"). $INSTALL_ROOT
        # is the actual parent of all four component checkouts.
        if (Test-Path "$INSTALL_ROOT") {
            Log-Info "Opening install root (backend + frontend + Database + airflow) in VS Code..."
            Start-Process $codeCmd -ArgumentList "`"$INSTALL_ROOT`""
        }
    }
}

# ===========================================================================
# 17. Launch Browser & Test App URL
# ===========================================================================
if ($run["BrowserTest"]) {
    Log-Step "Step-17-BrowserTest"
    $APP_URL  = "https://$UI_HOST"
    $API_TEST = "http://${API_HOST}:${API_PORT}"

    Log-Info "Waiting 6 seconds for services to stabilise..."
    Start-Sleep -Seconds 6

    Log-Info "Checking backend API on $API_TEST ..."
    $apiUp = Test-NetConnection -ComputerName $API_HOST -Port ([int]$API_PORT) -WarningAction SilentlyContinue
    if ($apiUp.TcpTestSucceeded) {
        Log-Ok "Backend API port $API_PORT is reachable."
    } else {
        Log-Warn "Backend API port $API_PORT not yet reachable. Uvicorn may still be starting."
    }

    Log-Info "Checking frontend on $APP_URL ..."
    $nginxUp = Test-NetConnection -ComputerName "localhost" -Port ([int]$UI_PORT) -WarningAction SilentlyContinue
    if ($nginxUp.TcpTestSucceeded) {
        Log-Ok "Nginx port $UI_PORT is open."
        # Both HTTPS checks below use curl.exe (bundled since Windows 10
        # 1803 / Server 2019 at $env:SystemRoot\System32\curl.exe), not
        # Invoke-WebRequest. Found live: Invoke-WebRequest / .NET's
        # HttpWebRequest fails against this server's TLS behavior every
        # time with "The underlying connection was closed: An unexpected
        # error occurred on a send" - even though the app is completely
        # healthy (verified: curl.exe gets a clean HTTP 200 with the full
        # page against the exact same URL at the exact same moment).
        # -SkipCertificateCheck is also PS7+-only, another reason
        # Invoke-WebRequest was unreliable here on Windows PowerShell 5.1.
        $curlExe = "$env:SystemRoot\System32\curl.exe"
        if (!(Test-Path $curlExe)) {
            Log-Warn "curl.exe not found at $curlExe - skipping HTTPS probes."
        } else {
            $curlCode = & $curlExe -s -k -o NUL -w "%{http_code}" $APP_URL --max-time 15 2>&1
            if ($curlCode -match "^\d{3}$" -and $curlCode -ne "000") {
                Log-Ok "App responded - HTTP $curlCode. Application is UP."
            } else {
                Log-Info "HTTP probe: no response (curl: $curlCode)."
                Log-Info "This may be normal if the domain resolves externally, or if '$UI_HOST' has no hosts-file entry on this machine."
            }

            # --- Login smoke test ---
            # Verifies the full request path end-to-end (Nginx -> Uvicorn ->
            # Django -> Postgres) with the default seeded credentials, not
            # just "is the port open". A 400/500 with an HTML body here
            # (instead of DRF's normal JSON error shape) almost always means
            # Nginx or Django's own CSRF/generic-error page answered BEFORE
            # the request ever reached the actual login view - a different
            # failure class than "wrong credentials", which comes back as
            # JSON.
            Log-Info "Smoke-testing login (POST /api/recon_security/auth_user)..."
            $loginUrl   = "$APP_URL/api/recon_security/auth_user"
            $loginBody  = (@{ email = "recon@admin.com"; password = "recon@123" } | ConvertTo-Json -Compress)
            # Body goes through a temp file (--data @file), NOT an inline -d
            # argument. Found live: PowerShell mangles embedded double-quotes
            # crossing into a native exe's argument list, so curl received a
            # corrupted body and DRF failed with "JSON parse error - Expecting
            # property name enclosed in double quotes" - a false negative that
            # looked like an app bug but was actually this script's own
            # argument-passing bug.
            $loginBodyFile = Join-Path $env:TEMP "dart_login_smoketest.json"
            [System.IO.File]::WriteAllText($loginBodyFile, $loginBody, (New-Object System.Text.UTF8Encoding($false)))
            $marker     = "___HTTP_CODE___"
            $curlRawArr = & $curlExe -s -k -X POST $loginUrl -H "Content-Type: application/json" `
                              --data "@$loginBodyFile" --max-time 15 -w "`n$marker%{http_code}" 2>&1
            Remove-Item $loginBodyFile -Force -ErrorAction SilentlyContinue
            $curlRaw    = ($curlRawArr -join "`n")
            $markerIdx  = $curlRaw.LastIndexOf($marker)

            if ($markerIdx -lt 0) {
                # curl itself never completed (DNS failure, connect refused,
                # timeout) - no marker means no HTTP transaction happened at
                # all, not an app-level error.
                Log-Warn "Login smoke test FAILED - no HTTP response at all (curl: $curlRaw)."
                Log-Warn "This means the request never reached Nginx - not a login/validation error. Check: is Nginx actually running ($TOOLS_ROOT\nginx\logs\error.log), and does '$UI_HOST' resolve to 127.0.0.1 in the hosts file."
            } else {
                $respBody = $curlRaw.Substring(0, $markerIdx).TrimEnd("`r", "`n")
                $respCode = $curlRaw.Substring($markerIdx + $marker.Length).Trim()
                if ($respCode -eq "200") {
                    Log-Ok "Login smoke test passed - HTTP 200, default credentials accepted."
                } else {
                    $bodyPreview = $respBody.Substring(0, [Math]::Min(300, $respBody.Length))
                    Log-Warn "Login smoke test FAILED - HTTP $respCode. Response: $bodyPreview"
                    if ($respBody.TrimStart().StartsWith("<")) {
                        if ($respBody -match "(?i)nginx") {
                            Log-Warn "Response looks like Nginx's own error page, not Django/DRF JSON - the request likely never reached Uvicorn. Check $TOOLS_ROOT\nginx\logs\error.log for the real reason (common causes: request header size limits, malformed request line)."
                        } else {
                            Log-Warn "Response is HTML, not JSON - likely Django's own error page (CSRF rejection, or a generic DEBUG=False 400/500), not a normal DRF validation error. Check the Uvicorn console window for a traceback, and confirm this view is CSRF-exempt for POST if it uses SessionAuthentication."
                        }
                    } elseif ($respBody) {
                        Log-Warn "Response looks like JSON - the field/validation error DRF reported is in the body above."
                    } else {
                        Log-Warn "Empty response body with HTTP $respCode - check the Uvicorn console window for what happened."
                    }
                    Log-Warn "Default credentials used: recon@admin.com / recon@123 - if these were never seeded in this DB, that alone would also produce a 400/401 here."
                }
            }
        }
    } else {
        Log-Warn "Nginx port $UI_PORT not reachable locally. Check nginx logs at $TOOLS_ROOT\nginx\logs\error.log"
    }

    Log-Info "Opening $APP_URL in the default browser..."
    Start-Process $APP_URL
    Log-Ok "Browser launched -> $APP_URL"
}

# ===========================================================================
# 18. Seed Demo Data (creates a real demo recon via live API calls)
#
# Runs seed_script.ps1 (auth -> roles/groups -> recon -> dimensions ->
# import CSVs -> bridge -> transform -> report) against the running backend.
# Part of the default run - checked by default in the GUI, included in a
# bare -Silent run with no -StepList, same as every other step. Re-running
# this repeatedly will keep hitting the same recon_name ("DART_Seed_Recon")
# - seed_script.ps1's own 409-is-ok handling covers most of that, but it's
# worth knowing this isn't a no-op on a machine that's already been seeded.
# ===========================================================================
if ($run["SeedData"]) {
    Log-Step "Step-18-SeedData"

    $seedScript   = Join-Path $_scriptDir "seed_script.ps1"
    $seedMediaSrc = Join-Path (Split-Path $_scriptDir -Parent) "media"

    if (!(Test-Path $seedScript)) {
        Log-Err "seed_script.ps1 not found at $seedScript - skipping."
    } else {
        Log-Info "Checking backend API on ${API_HOST}:${API_PORT} before seeding..."
        $seedApiUp = $false
        for ($i = 0; $i -lt 15; $i++) {
            if (Get-NetTCPConnection -LocalPort ([int]$API_PORT) -State Listen -ErrorAction SilentlyContinue) {
                $seedApiUp = $true
                break
            }
            Start-Sleep -Seconds 1
        }

        if (-not $seedApiUp) {
            Log-Err "Backend is not listening on port $API_PORT after 15s - run StartBackend first. Skipping seed."
        } else {
            # SEED_MEDIA_ROOT is this step's own, self-contained variable -
            # deliberately NOT $MEDIA_PATH. $MEDIA_PATH is shared with Django
            # (settings.py) and gets independently re-set inside WSL2 for
            # Airflow (see the "export MEDIA_PATH=..." lines earlier in this
            # step) - reusing that name/value here risked this step being
            # confused with, or accidentally coupled to, either of those.
            # This resolves the real on-disk location on its own terms: a
            # MEDIA_PATH value with no drive letter (e.g. "/app/Recon_Files/")
            # resolves on Windows relative to the current drive - replicated
            # explicitly here instead of depending on that quirk implicitly.
            $SEED_MEDIA_ROOT = if ($MEDIA_PATH -match '^[A-Za-z]:') {
                $MEDIA_PATH
            } else {
                Join-Path $env:SystemDrive ($MEDIA_PATH.TrimStart('/').Replace('/', '\'))
            }

            # Deploy the seed CSVs from the repo (windows_deploy/media/) into
            # the real runtime media root.
            $seedTargetDir = Join-Path (Join-Path $SEED_MEDIA_ROOT "media") "Seeded_Recon_files"
            if (!(Test-Path $seedTargetDir)) {
                New-Item -ItemType Directory -Path $seedTargetDir -Force | Out-Null
            }
            if (Test-Path $seedMediaSrc) {
                Copy-Item (Join-Path $seedMediaSrc "*.csv") $seedTargetDir -Force
                Log-Ok "Seed CSV files copied to $seedTargetDir"
            } else {
                Log-Err "Seed media source folder not found at $seedMediaSrc - seed_script.ps1 will likely fail to find its CSVs."
            }

            Log-Info "Running seed_script.ps1 against http://${API_HOST}:${API_PORT} ..."
            & $seedScript -BaseUrl "http://${API_HOST}:${API_PORT}" -MediaPath $SEED_MEDIA_ROOT
            if ($LASTEXITCODE -eq 0) {
                Log-Ok "Demo recon seeded successfully."
            } else {
                Log-Err "seed_script.ps1 exited with code $LASTEXITCODE - see output above for which step failed."
            }
        }
    }
}

# ===========================================================================
# Summary
# ===========================================================================
Log-Step "Summary"
if ($script:HadError) {
    Log-Err "DART DEPLOYMENT COMPLETED WITH ERRORS - see log for details"
} elseif ($script:NeedsAction) {
    Log-Warn "DART DEPLOYMENT PAUSED - action needed (see ACTION NEEDED banner above), not an error. Restart and re-run as instructed."
} else {
    Log-Ok  "DART DEPLOYMENT COMPLETE - No errors recorded"
}

# Write closing footer to the log file
if ($script:LOG_FILE) {
    $_hdr = "=" * 70
    $ts   = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    Add-Content -Path $script:LOG_FILE -Value ""                                      -Encoding UTF8
    Add-Content -Path $script:LOG_FILE -Value $_hdr                                   -Encoding UTF8
    Add-Content -Path $script:LOG_FILE -Value "  Deployment ended : $ts"              -Encoding UTF8
    Add-Content -Path $script:LOG_FILE -Value "  HadError         : $script:HadError" -Encoding UTF8
    Add-Content -Path $script:LOG_FILE -Value $_hdr                                   -Encoding UTF8
}

Write-Host ""
Write-Host "======================================" -ForegroundColor DarkCyan
if ($script:HadError) {
    Write-Host "  FINISHED WITH ERRORS" -ForegroundColor Red
} else {
    Write-Host "  FINISHED SUCCESSFULLY" -ForegroundColor Green
}
Write-Host "  Full log: $script:LOG_FILE" -ForegroundColor Cyan
Write-Host "======================================" -ForegroundColor DarkCyan

# Placed AFTER the summary and the log footer, deliberately.
# Restart-Computer -Force below does not return, so anything after it never
# runs. With this block above the footer, the ONE run that actually reboots
# was the one whose log ended mid-sentence - no 'Deployment ended', no final
# status - which is exactly the run you most want a complete log for.
# ===========================================================================
# Auto-resume after the WSL restart
# ===========================================================================
# Only when the run was otherwise CLEAN. If anything errored, the reboot is
# not the last thing standing between here and a working box, and rebooting
# would just hide the error behind a restart.
if ($AUTO_RESUME_AFTER_RESTART -and $script:NeedsRestart -and -not $script:HadError) {
    $resumeScript = Join-Path $_scriptDir "DART-Resume-Setup.ps1"
    $taskName     = "DART-Resume-Setup"
    if (-not (Test-Path $resumeScript)) {
        Log-Warn "AUTO_RESUME is on but DART-Resume-Setup.ps1 is missing from $_scriptDir - falling back to the manual instructions above."
    } else {
        try {
            # AtLogon + Interactive, NOT AtStartup. A task in session 0
            # cannot run WSL (same constraint DART-Start.ps1 documents) and
            # would have no window to show progress in. Highest run level:
            # the Airflow step needs admin.
            #
            # Which account logs back in? Normally the one running this. But a
            # standard user who clicked Yes and typed an administrator's
            # credentials is running this AS that administrator, while the
            # desktop - and the next logon - is theirs. A task bound to the
            # administrator then never fires (EC2 2026-10-19, dart-test), and
            # one bound to the standard user cannot run Highest. So in that case
            # the task is bound to the desktop user at a normal run level and
            # DART-Resume-Setup.ps1 elevates itself (UAC prompt), the same way
            # the first run did.
            $_runUser  = "$env:USERDOMAIN\$env:USERNAME"
            $_deskUser = $null
            try {
                $_sess = (Get-Process -Id $PID).SessionId
                $_deskUser = (Get-Process explorer -IncludeUserName -ErrorAction Stop |
                              Where-Object { $_.SessionId -eq $_sess -and $_.UserName } | Select-Object -First 1).UserName
            } catch { }
            $_otherUser = ($_deskUser -and $_deskUser -ne $_runUser)
            $_taskUser  = if ($_otherUser) { $_deskUser } else { $_runUser }
            $_runLevel  = if ($_otherUser) { 'Limited' } else { 'Highest' }

            $act  = New-ScheduledTaskAction -Execute "powershell.exe" `
                        -Argument "-ExecutionPolicy Bypass -NoProfile -File `"$resumeScript`"" `
                        -WorkingDirectory $_scriptDir
            $trg  = New-ScheduledTaskTrigger -AtLogOn -User $_taskUser
            # 2 minutes of slack: at logon the desktop, network stack and
            # service control manager are still settling, and PostgreSQL
            # starting into that is how a resume fails for no real reason.
            $trg.Delay = "PT2M"
            $prin = New-ScheduledTaskPrincipal -UserId $_taskUser -LogonType Interactive -RunLevel $_runLevel
            $set  = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable -ExecutionTimeLimit (New-TimeSpan -Hours 2)
            Register-ScheduledTask -TaskName $taskName -Action $act -Trigger $trg -Principal $prin -Settings $set -Force -ErrorAction Stop | Out-Null
            Log-Ok "Auto-resume scheduled - Airflow setup will continue by itself at your next logon."
            # Tells a not-yet-elevated DART-AutoStart (which may not be allowed
            # to read this task) to stand aside, so the first logon asks for the
            # admin password once, not twice. DART-Resume-Setup removes it.
            try { Set-Content -Path (Join-Path $INSTALL_ROOT ".resume_pending") -Value (Get-Date -Format s) -Encoding ASCII } catch { }
            if ($_otherUser) {
                Log-Info "  Setup is running as $_runUser but the desktop belongs to $_deskUser - the resume task is set for $_deskUser's next logon."
                Log-Info "  About 2 minutes after logging back in as $_deskUser, a DART box asks for the administrator password ($_runUser) again."
            }
            $script:ResumeArmed = $true
        } catch {
            Log-Warn "Could not register the auto-resume task: $($_.Exception.Message)"
            Log-Warn "  After restarting, run: .\VM-Windows-Bash-Script_V2.ps1 -Silent -StepList `"AirflowSetup`""
        }
    }

    if ($script:ResumeArmed) {
        # Popup waits for a click - nothing reboots on its own. A deploy box
        # can have someone else connected, and an unannounced restart is not
        # ours to take.
        $msg = @(
            "All installation steps completed with no errors.",
            "",
            "Windows needs ONE restart to finish enabling WSL2, which Apache",
            "Airflow runs on.",
            "",
            "When you log back in, Airflow setup continues AUTOMATICALLY and",
            "then restarts every service. You do not need to run anything.",
            "",
            "Restart now?"
        )
        if ($_otherUser) {
            $msg = $msg[0..($msg.Count - 2)] + @(
                "Log back in as $_deskUser. About 2 minutes later a DART box",
                "asks for the administrator password ($_runUser) again -",
                "click OK and enter it, as you did for this setup.",
                "",
                "Restart now?")
        }
        $msg = $msg -join "`n"
        $choice = $null
        try {
            Add-Type -AssemblyName System.Windows.Forms -ErrorAction Stop
            $choice = [System.Windows.Forms.MessageBox]::Show($msg, "DART - Restart required",
                        [System.Windows.Forms.MessageBoxButtons]::YesNo,
                        [System.Windows.Forms.MessageBoxIcon]::Information)
            $choice = ($choice -eq [System.Windows.Forms.DialogResult]::Yes)
        } catch {
            # No GUI available (a bare SSH/WinRM session). Fall back to the
            # console rather than rebooting unasked.
            Write-Host ""
            Write-Host $msg -ForegroundColor White
            $ans = Read-Host "Restart now? [y/N]"
            $choice = ($ans -match '^\s*(?i:y|yes)\s*$')
        }

        if ($choice) {
            Log-Ok "Restarting now - log back in and setup will continue on its own."
            Start-Sleep -Seconds 3
            Restart-Computer -Force
        } else {
            Log-Warn "Restart postponed. The auto-resume task is already scheduled:"
            Log-Warn "  restart whenever you like and it continues at your next logon."
            Log-Warn "  To cancel it: .\DART-Resume-Setup.ps1 -Unregister"
        }
    }
}


# ===========================================================================
# Restart the services so the run's changes are actually live
# ===========================================================================
# A FIRST install gets this for free: it ends at the WSL reboot, and
# DART-Resume-Setup.ps1 does stop -> verify-stopped -> start at the next
# logon. A SECOND run gets nothing - there is no reboot, no scheduled task,
# and most steps Log-Skip because their work is already done. So CloneRepos
# and BackendSetup update the code on disk, Uvicorn keeps running the module
# it imported hours ago, and the deployment reports success while serving the
# previous build.
#
# Same stop -> verify -> start sequence DART-Resume-Setup.ps1 uses, and for
# the same reason: DART-Start.ps1 SKIPS any service whose port is already
# occupied, so starting without a confirmed stop silently keeps the old
# process alive.
#
# Skipped when a reboot is pending - the resume task owns the restart in that
# case, and stopping services here would only slow the reboot down.
$RESTART_SERVICES_AFTER_RUN = (Get-Cfg "RESTART_SERVICES_AFTER_RUN" "true") -match '^\s*(?i:true|1|yes|y)\s*$'

# Two independent guards against re-entry, because this script is called BY
# the very script this block calls.
#
#   -NoServiceRestart : passed explicitly by DART-Start.ps1's three
#                       delegation sites.
#   DART_RESTART_IN_PROGRESS : env var set below before DART-Stop/DART-Start
#                       are invoked. Child processes inherit it, so any
#                       nested invocation of this script - through any path,
#                       including ones added later - skips its own restart.
#
# One guard would do for the paths that exist today. Both are here because
# the failure mode is an infinite loop that spawns processes, which is a bad
# thing to rediscover the next time a call site is added.
if ($env:DART_RESTART_IN_PROGRESS -eq "1") {
    Log-Info "Service restart skipped - this run was invoked from inside a restart cycle."
}
elseif ($NoServiceRestart) {
    Log-Info "Service restart skipped (-NoServiceRestart)."
}
elseif ($RESTART_SERVICES_AFTER_RUN -and -not $script:NeedsRestart) {
    Log-Step "Restart-Services"
    $env:DART_RESTART_IN_PROGRESS = "1"
    $stopScript   = Join-Path $_scriptDir "DART-Stop.ps1"
    $startScript  = Join-Path $_scriptDir "DART-Start.ps1"
    $statusScript = Join-Path $_scriptDir "DART-Status.ps1"

    if (-not (Test-Path $startScript)) {
        Log-Warn "DART-Start.ps1 not found next to this script - services NOT restarted."
        Log-Warn "  Anything updated by this run is still on disk but not loaded by the running services."
    } else {
        if (Test-Path $stopScript) {
            Log-Info "Stopping services..."
            & powershell.exe -ExecutionPolicy Bypass -File $stopScript
        } else {
            Log-Warn "DART-Stop.ps1 not found - starting without a clean stop. A service still holding"
            Log-Warn "  its port will be skipped and keep running the previous code."
        }

        # Verify rather than trust. A port still held here means DART-Start
        # will skip that service, which is exactly the silent-stale-process
        # case this whole block exists to prevent.
        if (Test-Path $statusScript) {
            & powershell.exe -ExecutionPolicy Bypass -File $statusScript -ExpectStopped | Out-Null
            if ($LASTEXITCODE -ne 0) {
                Log-Warn "Something is still listening after the stop - waiting 15s and stopping once more..."
                Start-Sleep -Seconds 15
                if (Test-Path $stopScript) { & powershell.exe -ExecutionPolicy Bypass -File $stopScript }
            }
        }

        Log-Info "Starting services..."
        & powershell.exe -ExecutionPolicy Bypass -File $startScript
        Log-Ok "Services restarted - this run's changes are now live."
        Log-Info "Verify with: .\DART-Status.ps1"
    }
    Remove-Item Env:\DART_RESTART_IN_PROGRESS -ErrorAction SilentlyContinue
}
elseif ($RESTART_SERVICES_AFTER_RUN -and $script:NeedsRestart) {
    Log-Info "Services not restarted here - a reboot is pending and the resume task handles it."
}

# Exit code, so a caller can act on the outcome instead of scraping text.
# DART-Resume-Setup.ps1 depends on this to tell 'Airflow failed' from
# 'Airflow finished but flagged something'.
#   0 = clean
#   1 = one or more steps errored
#   2 = no errors, but an ACTION NEEDED banner was raised (e.g. restart)
if ($script:HadError)         { exit 1 }
elseif ($script:NeedsAction)  { exit 2 }
else                          { exit 0 }
