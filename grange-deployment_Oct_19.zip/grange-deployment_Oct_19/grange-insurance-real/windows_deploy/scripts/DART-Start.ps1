param(
    [string]$ConfigFile = "",

    # Launch Uvicorn / FastAPI / Airflow in VISIBLE console windows instead
    # of as background Scheduled Tasks.
    [switch]$Interactive,

    # Start everything EXCEPT Airflow.
    [switch]$SkipAirflow
)

# ---------------------------------------------------------------------------
# Administrator check - same as VM-Windows-Bash-Script_V2.ps1.
#
# Without admin rights the DART-Uvicorn / DART-FastAPI / DART-AutoStart
# scheduled tasks cannot be registered (RunLevel Highest), so every service
# silently falls back to a plain window that dies at logoff and does not come
# back after a restart. A person running this by hand is asked up front:
# Yes relaunches elevated (UAC prompt), No cancels.
#
# Not prompted (warning only), because nobody is there to click:
#  - the installer's end-of-run restart (DART_RESTART_IN_PROGRESS=1);
#  - a non-interactive session (scheduled task "run whether logged on or not").
# DART-AutoStart and DART-Resume-Setup run as Highest, so they are already
# elevated and never reach the prompt.
# ---------------------------------------------------------------------------
$_isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole(
    [Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $_isAdmin -and ($env:DART_RESTART_IN_PROGRESS -eq "1" -or -not [Environment]::UserInteractive)) {
    Write-Host "[WARN] Not running as Administrator - scheduled tasks cannot be registered; services will not survive logoff or restart." -ForegroundColor Yellow
}
elseif (-not $_isAdmin) {
    Add-Type -AssemblyName System.Windows.Forms
    $_adminMsg = "DART-Start needs Administrator rights.`n`n" +
                 "It is used to register the DART scheduled tasks, so the backend,`n" +
                 "FastAPI and Airflow keep running after logoff and start again`n" +
                 "after a restart.`n`n" +
                 "Yes  - restart DART-Start as Administrator (Windows will ask for permission)`n" +
                 "No   - cancel`n`n" +
                 "If you do not have an administrator account, click No and ask your IT team."
    $_adminAns = [System.Windows.Forms.MessageBox]::Show($_adminMsg, "DART-Start - Administrator rights required",
        [System.Windows.Forms.MessageBoxButtons]::YesNo, [System.Windows.Forms.MessageBoxIcon]::Warning)
    if ($_adminAns -ne [System.Windows.Forms.DialogResult]::Yes) {
        Write-Host "DART-Start cancelled - Administrator rights were not granted." -ForegroundColor Yellow
        exit 0
    }
    if (-not $PSCommandPath) {
        Write-Host "[FAIL] Save the script to a file first, then run it again." -ForegroundColor Red
        exit 1
    }

    # Pass this run's parameters on. An elevated process starts in System32,
    # so a relative -ConfigFile is made absolute first.
    $_relaunchArgs = @('-NoExit', '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', "`"$PSCommandPath`"")
    foreach ($_p in $PSBoundParameters.GetEnumerator()) {
        if ($_p.Value -is [switch]) {
            if ($_p.Value.IsPresent) { $_relaunchArgs += "-$($_p.Key)" }
        } else {
            $_v = "$($_p.Value)"
            if ($_p.Key -eq 'ConfigFile' -and $_v) { $_v = (Resolve-Path -LiteralPath $_v -ErrorAction SilentlyContinue).Path; if (-not $_v) { $_v = "$($_p.Value)" } }
            $_relaunchArgs += "-$($_p.Key)", "`"$_v`""
        }
    }
    # Always 64-bit Windows PowerShell (from ISE x86, System32 is redirected
    # and wsl.exe would not be found).
    $_psExe = Join-Path $env:WINDIR 'Sysnative\WindowsPowerShell\v1.0\powershell.exe'
    if (-not (Test-Path $_psExe)) { $_psExe = Join-Path $env:WINDIR 'System32\WindowsPowerShell\v1.0\powershell.exe' }
    try {
        Start-Process -FilePath $_psExe -ArgumentList $_relaunchArgs -Verb RunAs -ErrorAction Stop | Out-Null
        Write-Host "DART-Start restarted in a new Administrator window. This window can be closed." -ForegroundColor Green
        exit 0
    } catch {
        [System.Windows.Forms.MessageBox]::Show("Could not start DART-Start as Administrator:`n$($_.Exception.Message)`n`nDART-Start has been cancelled.",
            "DART-Start", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Error) | Out-Null
        Write-Host "DART-Start cancelled - could not start as Administrator: $($_.Exception.Message)" -ForegroundColor Yellow
        exit 1
    }
}

# ===========================================================================
#  DART-Start.ps1
#  Starts all DART services in the correct order:
#    1. PostgreSQL
#    2. Nginx    (Reverse proxy)
#    3. Uvicorn  (Django backend - launched as a Scheduled Task)
#    4. FastAPI  (AI Auto Draft - launched as a Scheduled Task)
#    5. Airflow  (WSL2 standalone - launched as a Scheduled Task, delegates
#                 its actual setup/start to VM-Windows-Bash-Script_V2.ps1)
# ===========================================================================

#     # INSTALL_ROOT/TOOLS_ROOT read from dart_deploy_config.json, same as
    # VM-Windows-Bash-Script_V2.ps1 - this used to be hardcoded to "C:\DARTV1"
    # (a different, predecessor layout), which doesn't exist on this deployment
    # at all (it's actually C:\DART_DEPLOY) - .env loading, BACKEND_DIR, and
    # deployment-log tailing were all silently pointing at a nonexistent path.
    # Reading from config instead of re-hardcoding a (currently correct, but
    # equally driftable) path fixes this and prevents it recurring.
    $_scriptDir = if ($PSScriptRoot) { $PSScriptRoot } else { (Get-Location).Path }
    $cfgPath = if ($ConfigFile -and (Test-Path $ConfigFile)) { $ConfigFile } else { Join-Path $_scriptDir "dart_deploy_config.json" }
    $cfg = $null
    if (Test-Path $cfgPath) {
        try { $cfg = Get-Content $cfgPath -Raw -Encoding UTF8 | ConvertFrom-Json } catch { }
    }
    function Get-Cfg($key, $default) {
        if ($cfg -and $cfg.PSObject.Properties.Name -contains $key -and $cfg.$key) { return $cfg.$key }
        return $default
    }

    $INSTALL_ROOT = Get-Cfg "INSTALL_ROOT" "C:\DART_DEPLOY"
    $TOOLS_ROOT   = Get-Cfg "TOOLS_ROOT"   "C:\DART_Tools"
    $UI_HOST      = Get-Cfg "UI_HOST"      "local-dart.donyati.com"
    $PG_BIN       = "$TOOLS_ROOT\postgres\bin"
    $PG_DATA      = "$TOOLS_ROOT\postgres\data"
    $NGINX_ROOT   = "$TOOLS_ROOT\nginx"
    $BACKEND_DIR  = "$INSTALL_ROOT\backend\Data_Recon_Backend"
    $DJANGO_DIR   = "$BACKEND_DIR\Data_Recon_Main"
    $VENV_PYTHON  = "$BACKEND_DIR\.venv\Scripts\python.exe"
    $ENV_FILE     = "$INSTALL_ROOT\.env"

    function Write-Step  ($msg) { Write-Host "" ; Write-Host "[$(Get-Date -Format 'HH:mm:ss')] >>> $msg" -ForegroundColor Cyan }
    function Write-OK    ($msg) { Write-Host "[$(Get-Date -Format 'HH:mm:ss')] [OK]   $msg" -ForegroundColor Green }
    function Write-WARN  ($msg) { Write-Host "[$(Get-Date -Format 'HH:mm:ss')] [WARN] $msg" -ForegroundColor Yellow }
    function Write-FAIL  ($msg) { Write-Host "[$(Get-Date -Format 'HH:mm:ss')] [FAIL] $msg" -ForegroundColor Red }
    function Write-INFO  ($msg) { Write-Host "[$(Get-Date -Format 'HH:mm:ss')] [INFO] $msg" -ForegroundColor Gray }

    # ---------------------------------------------------------------------------
    # Session-independent launch via Scheduled Task
    # ---------------------------------------------------------------------------
    # Found live 2026-09-04: Uvicorn/FastAPI/Airflow were all launched as plain
    # child processes/windows of the interactive RDP session running this
    # script. When that RDP session disconnected (confirmed via Event Viewer,
    # Microsoft-Windows-TerminalServices-LocalSessionManager/Operational -
    # repeated "Session N has been disconnected" events) - and on this box a
    # disconnected session eventually gets auto-logged-off - every child
    # console window tied to that session died with it: FastAPI and Airflow
    # (WSL2 - confirmed via `wsl -l -v` showing "Stopped") vanished outright,
    # and Uvicorn's process was left orphaned mid-request, alive but
    # permanently hung (matches a Postgres "unexpected EOF on client
    # connection with an open transaction" log line at the same moment).
    # Nginx (a real detached binary, launched -WindowStyle Hidden) and
    # PostgreSQL (a proper pg_ctl-managed background service) never had this
    # problem because neither was ever tied to the interactive session.
    #
    # Fix: launch these three under Task Scheduler instead, with "run whether
    # user is logged on or not" (LogonType Password). A task registered this
    # way executes in its own session-independent context - immune to RDP
    # disconnects, reconnects, and logoffs alike, the same way Nginx/Postgres
    # already are. Registration happens once per machine (needs the account's
    # password, asked interactively via Get-Credential the first time); every
    # later run just finds the task already registered and starts it, no
    # password needed again. Falls back to the old plain-window behavior if
    # registration isn't possible (e.g. this run itself is non-interactive and
    # can't prompt) so a first-ever run never hard-fails.
    $script:_taskCred = $null
    function Start-AsScheduledTask($TaskName, $LauncherPath, $WorkingDirectory) {
        # -Interactive: skip the scheduled task entirely and report failure, so
        # every caller falls through to its existing windowed Start-Process
        # path. Reuses the fallback that is already there rather than
        # duplicating a second launch route per service.
        if ($Interactive) {
            Write-INFO "-Interactive: launching '$TaskName' in a visible window instead of a background task."
            return $false
        }

        $existing = Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue
        if ($existing) {
            # DART-Stop.ps1 DISABLES these tasks, because their
            # -RestartCount policy otherwise resurrects a killed service and
            # the port never frees. Re-enable before starting, or a stopped
            # deployment could never be started again.
            if ($existing.State -eq 'Disabled') {
                Enable-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue | Out-Null
                Write-INFO "Scheduled task '$TaskName' was disabled by DART-Stop - re-enabled."
            }
            Write-INFO "Scheduled task '$TaskName' already registered - starting it..."
            Start-ScheduledTask -TaskName $TaskName
            return $true
        }

        Write-WARN "Scheduled task '$TaskName' not registered yet - one-time setup needed so it survives RDP disconnect/logoff."
        if (-not $script:_taskCred) {
            Write-INFO "Enter the credentials DART's background services should run as (usually this same account) - asked once per machine:"
            $script:_taskCred = Get-Credential -UserName "$env:USERDOMAIN\$env:USERNAME" -Message "Account to run DART background services as (Task Scheduler, survives RDP disconnect/logoff)"
        }
        if (-not $script:_taskCred) {
            Write-FAIL "No credentials given - cannot register '$TaskName'. Falling back to a plain window for this run (will NOT survive an RDP disconnect)."
            return $false
        }

        $action    = New-ScheduledTaskAction -Execute "powershell.exe" -Argument "-ExecutionPolicy Bypass -NoProfile -File `"$LauncherPath`"" -WorkingDirectory $WorkingDirectory
        $principal = New-ScheduledTaskPrincipal -UserId $script:_taskCred.UserName -LogonType Password -RunLevel Highest
        $settings  = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries `
                        -ExecutionTimeLimit ([TimeSpan]::Zero) -RestartCount 3 -RestartInterval (New-TimeSpan -Minutes 1) `
                        -MultipleInstances IgnoreNew
        $task      = New-ScheduledTask -Action $action -Principal $principal -Settings $settings

        try {
            Register-ScheduledTask -TaskName $TaskName -InputObject $task `
                -User $script:_taskCred.UserName -Password $script:_taskCred.GetNetworkCredential().Password -Force | Out-Null
            Write-OK "Scheduled task '$TaskName' registered (runs whether logged on or not)."
            Start-ScheduledTask -TaskName $TaskName
            return $true
        } catch {
            Write-FAIL "Could not register scheduled task '$TaskName': $($_.Exception.Message)"
            Write-WARN "Falling back to a plain window for this run (will NOT survive an RDP disconnect)."
            return $false
        }
    }

    Write-Host ""
    Write-Host "==========================================" -ForegroundColor DarkCyan
    Write-Host "   DART  -  Start All Services"            -ForegroundColor Cyan
    Write-Host "   $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')" -ForegroundColor DarkGray
    Write-Host "==========================================" -ForegroundColor DarkCyan

    # ---------------------------------------------------------------------------
    # Sync Airflow's generated admin password into .env BEFORE anything starts
    # ---------------------------------------------------------------------------
    # Ordering bug this fixes: .env was loaded here, Uvicorn started further
    # down with that environment, and Airflow - which writes the CURRENT
    # generated password into .env - only ran at the very end. So Django was
    # permanently one restart behind: it kept whatever password was in .env
    # before Airflow last regenerated one, and settings.py fell back to its
    # hardcoded default when the key was missing entirely.
    #
    # `airflow standalone` mints the password once and reuses the same file on
    # later starts, so on any run after the first the current value is already
    # on disk here and can be applied up front. Reported live 2026-09-10:
    # Recon_Files\simple_auth_manager_passwords.json.generated held
    # {"admin": "..."} while Django was still authenticating with an older one.
    #
    # settings.py reads the LOWERCASE name:
    #     os.environ.get("airflow_admin_password", "<default>")
    # Both cases are written - Python normalises env keys on Windows so the
    # uppercase pair resolves too, but the lowercase one is what the code
    # actually asks for.
    $MEDIA_FOR_AF = Get-Cfg "MEDIA_PATH" "$INSTALL_ROOT\Recon_Files"
    if ($MEDIA_FOR_AF -match '[\\/]backend[\\/]Data_Recon_Backend[\\/]Recon_Files[\\/]?$') {
        $MEDIA_FOR_AF = "$INSTALL_ROOT\Recon_Files"
    }
    $afPwFile  = Join-Path $MEDIA_FOR_AF "simple_auth_manager_passwords.json.generated"
    $afAdmin   = Get-Cfg "AIRFLOW_ADMIN_USER" "admin"

    # BOTH .env files, every start.
    #
    # backend\Data_Recon_Backend\.env ships committed in the repo and sits
    # CLOSER to settings.py than $INSTALL_ROOT\.env. Django's loader walks up
    # from settings.py and does not override an already-set key, so whichever
    # it reaches first wins - writing only the deployment .env can leave the
    # app reading a stale password from the backend-local one and falling back
    # to the hardcoded default in settings.py. Tracked as ISSUE-B01.
    if ((Test-Path $afPwFile)) {
        try {
            $afPwJson = Get-Content $afPwFile -Raw | ConvertFrom-Json
            if ($afPwJson.PSObject.Properties.Name -contains $afAdmin) {
                $afRealPw = $afPwJson.$afAdmin
                $afTargets = @($ENV_FILE, (Join-Path $INSTALL_ROOT "backend\Data_Recon_Backend\.env")) |
                             Where-Object { Test-Path $_ }
                foreach ($target in $afTargets) {
                    $envLines = @(Get-Content $target)
                    $curLine  = $envLines | Where-Object { $_ -cmatch '^\s*airflow_admin_password\s*=' } | Select-Object -First 1
                    $current  = if ($curLine) { ($curLine -replace '^\s*airflow_admin_password\s*=', '').Trim() } else { $null }
                    if ($current -ceq $afRealPw) {
                        Write-INFO "Airflow admin password already current in $target"
                        continue
                    }
                    foreach ($pair in @(
                        @('airflow_admin_user',     $afAdmin),
                        @('airflow_admin_password', $afRealPw),
                        @('AIRFLOW_ADMIN_USER',     $afAdmin),
                        @('AIRFLOW_ADMIN_PASSWORD', $afRealPw)
                    )) {
                        $k = $pair[0]; $v = $pair[1]; $hit = $false
                        $envLines = foreach ($line in $envLines) {
                            if ($line -cmatch "^\s*$([regex]::Escape($k))\s*=") { $hit = $true; "$k=$v" } else { $line }
                        }
                        if (-not $hit) { $envLines = @($envLines) + "$k=$v" }
                    }
                    [System.IO.File]::WriteAllLines($target, [string[]]$envLines, (New-Object System.Text.UTF8Encoding($false)))
                    Write-OK "Synced Airflow's current admin password into $target"
                }
            }
        } catch {
            Write-WARN "Could not sync the Airflow admin password from $afPwFile : $($_.Exception.Message)"
        }
    } elseif (-not (Test-Path $afPwFile)) {
        Write-INFO "No Airflow password file yet at $afPwFile - it is generated the first time Airflow starts."
    }

    # ---------------------------------------------------------------------------
    # Sync Airflow live WSL2 IP (airflow_base_url) into .env BEFORE Uvicorn starts
    # ---------------------------------------------------------------------------
    # On Windows Server 2022, WSL2 localhostForwarding (connecting to localhost:8080 or
    # 127.0.0.1:8080 from Windows host) drops connections with "Empty reply from server"
    # (httpcore.RemoteProtocolError: Server disconnected without sending a response).
    # Django must connect directly to the WSL2 virtual machine internal IP (hostname -I).
    # That IP is dynamically assigned by Hyper-V and changes across WSL restarts and
    # machine reboots, so detect and sync it into .env right here before Uvicorn starts.
    $AIRFLOW_PORT = Get-Cfg "AIRFLOW_PORT" "8080"
    $wslDistro    = Get-Cfg "WSL_DISTRO"   "Ubuntu-24.04"
    try {
        $wslRawVm = (& wsl -d $wslDistro -u root bash -c "hostname -I | cut -d' ' -f1" 2>$null | Out-String)
        $wslVmIp  = ($wslRawVm -replace "`0", "" -replace "`r", "").Trim()
        if ($wslVmIp -match '^\d{1,3}(\.\d{1,3}){3}$') {
            $afLiveUrl = "http://${wslVmIp}:${AIRFLOW_PORT}/api/v2"
            $afTargets = @($ENV_FILE, (Join-Path $INSTALL_ROOT "backend\Data_Recon_Backend\.env")) |
                         Where-Object { Test-Path $_ }
            foreach ($target in $afTargets) {
                $envLines = @(Get-Content $target)
                $curLine  = $envLines | Where-Object { $_ -cmatch '^\s*airflow_base_url\s*=' } | Select-Object -First 1
                $current  = if ($curLine) { ($curLine -replace '^\s*airflow_base_url\s*=', '').Trim() } else { $null }
                if ($current -ceq $afLiveUrl) {
                    Write-INFO "Airflow base URL already current in $target ($afLiveUrl)"
                    continue
                }
                foreach ($pair in @(
                    @('airflow_base_url', $afLiveUrl),
                    @('AIRFLOW_BASE_URL', $afLiveUrl)
                )) {
                    $k = $pair[0]; $v = $pair[1]; $hit = $false
                    $envLines = foreach ($line in $envLines) {
                        if ($line -cmatch "^\s*$([regex]::Escape($k))\s*=") { $hit = $true; "$k=$v" } else { $line }
                    }
                    if (-not $hit) { $envLines = @($envLines) + "$k=$v" }
                }
                [System.IO.File]::WriteAllLines($target, [string[]]$envLines, (New-Object System.Text.UTF8Encoding($false)))
                Write-OK "Synced Airflow API base URL '$afLiveUrl' into $target"
            }
        }
    } catch {
        Write-WARN "Could not detect WSL2 IP for airflow_base_url: $($_.Exception.Message)"
    }

    # ---------------------------------------------------------------------------
    # Add Airflow's calling address (the WSL2 default gateway) to ALLOWED_HOSTS
    # ---------------------------------------------------------------------------
    # The reverse direction of the block above: DAG tasks call Django at the
    # Windows host's WSL-side IP (e.g. http://172.25.240.1:8000), so that is
    # the Host header Django sees. Missing from ALLOWED_HOSTS = a bare HTML 400
    # DisallowedHost on every DAG task. Found live 2026-10-19: the installer
    # had written the IP into $ENV_FILE only, while the backend-local .env
    # (which wins, see ISSUE-B01 above) still lacked it. The IP changes on
    # reboot, so it is checked on every start, in BOTH files, before Uvicorn.
    try {
        $wslRawGw = (& wsl -d $wslDistro -u root bash -c "ip route show default | cut -d' ' -f3" 2>$null | Out-String)
        $wslGwIp  = ($wslRawGw -replace "`0", "" -replace "`r", "").Trim()
        if ($wslGwIp -match '(\d{1,3}(?:\.\d{1,3}){3})') { $wslGwIp = $Matches[1] }
        if ($wslGwIp -match '^\d{1,3}(\.\d{1,3}){3}$') {
            $ahTargets = @($ENV_FILE, (Join-Path $INSTALL_ROOT "backend\Data_Recon_Backend\.env")) |
                         Where-Object { Test-Path $_ }
            foreach ($target in $ahTargets) {
                $envLines = @(Get-Content $target)
                $curLine  = $envLines | Where-Object { $_ -match '^\s*ALLOWED_HOSTS\s*=' } | Select-Object -First 1
                $hosts    = if ($curLine) { @(($curLine -replace '^\s*ALLOWED_HOSTS\s*=', '') -split ',' | ForEach-Object { $_.Trim() } | Where-Object { $_ }) } else { @() }
                if ($hosts -contains $wslGwIp) {
                    Write-INFO "ALLOWED_HOSTS already contains Airflow's WSL2 host address $wslGwIp in $target"
                    continue
                }
                $newLine = "ALLOWED_HOSTS=" + ((@($hosts) + $wslGwIp) -join ',')
                if ($curLine) {
                    $done = $false
                    $envLines = foreach ($line in $envLines) {
                        if (-not $done -and $line -match '^\s*ALLOWED_HOSTS\s*=') { $done = $true; $newLine } else { $line }
                    }
                } else {
                    $envLines = @($envLines) + $newLine
                }
                [System.IO.File]::WriteAllLines($target, [string[]]$envLines, (New-Object System.Text.UTF8Encoding($false)))
                Write-OK "Added Airflow's WSL2 host address $wslGwIp to ALLOWED_HOSTS in $target"
            }
        } else {
            Write-WARN "Could not detect Airflow's WSL2 host address (got '$wslGwIp') - if DAG tasks fail with DisallowedHost, add it to ALLOWED_HOSTS in both .env files."
        }
    } catch {
        Write-WARN "Could not detect Airflow's WSL2 host address for ALLOWED_HOSTS: $($_.Exception.Message)"
    }

    # ---------------------------------------------------------------------------
    # Load environment variables from .env
    # ---------------------------------------------------------------------------
    Write-Step "Loading environment from $ENV_FILE"

    if (Test-Path $ENV_FILE) {
        Get-Content $ENV_FILE |
            Where-Object { $_ -match '=' -and $_ -notmatch '^\s*#' } |
            ForEach-Object {
                $parts = $_.Split('=', 2)
                $k = $parts[0].Trim()
                $v = $parts[1].Trim().Trim("'").Trim('"')
                Set-Item "env:$k" $v
            }
        Write-OK "Environment variables loaded."
    } else {
        Write-FAIL ".env file not found at $ENV_FILE"
        Write-WARN "Django may fail to start without required environment variables."
    }

    # Add PostgreSQL bin to PATH (needed for psycopg libpq lookup)
    $env:PATH = "$PG_BIN;$env:PATH"

    # ---------------------------------------------------------------------------
    # 1. Start PostgreSQL
    # ---------------------------------------------------------------------------
    Write-Step "Starting PostgreSQL"

    # PostgreSQL must NEVER share this console window. `& pg_ctl start` from
    # here attached postgres.exe to it, so a Ctrl+C in this window - or
    # closing it - killed the database. Found live 2026-10-14: a backend died
    # mid-COMMIT with 0xC000013A (STATUS_CONTROL_C_EXIT), a second Ctrl+C
    # killed the postmaster, and an orphaned child kept port 5432 LISTENING
    # with no server behind it - so the old "port is listening" check said
    # "already running" while every connection hung.
    #
    # Now: readiness = pg_isready (a real handshake), an orphaned listener is
    # cleaned up, and pg_ctl runs via Start-Process in its own hidden console.
    # No -Wait: in Windows PowerShell it waits for the whole process tree,
    # i.e. for postgres.exe itself, forever.
    $pgCtl     = "$PG_BIN\pg_ctl.exe"
    $pgIsReady = "$PG_BIN\pg_isready.exe"
    $pgLog     = "$TOOLS_ROOT\postgres\server.log"
    function Get-PgReadyCode {
        # 0 = accepting, 1 = rejecting (starting up / recovering), 2 = no response
        if (-not (Test-Path $pgIsReady)) {
            if (Get-NetTCPConnection -LocalPort 5432 -State Listen -ErrorAction SilentlyContinue) { return 0 } else { return 2 }
        }
        & $pgIsReady -h 127.0.0.1 -p 5432 -t 5 *> $null
        return $LASTEXITCODE
    }

    $pgCode = Get-PgReadyCode
    $pgSw   = [System.Diagnostics.Stopwatch]::StartNew()
    while ($pgCode -eq 1 -and $pgSw.Elapsed.TotalSeconds -lt 90) {
        Write-INFO "PostgreSQL is starting up / recovering - waiting..."
        Start-Sleep -Seconds 3
        $pgCode = Get-PgReadyCode
    }

    if ($pgCode -eq 0) {
        Write-OK "PostgreSQL is running and accepting connections on port 5432."
    } elseif (-not (Test-Path $pgCtl)) {
        Write-FAIL "pg_ctl.exe not found at $pgCtl"
    } elseif (-not (Test-Path "$PG_DATA\PG_VERSION")) {
        Write-FAIL "Data cluster missing at $PG_DATA - run the deployment script first."
    } else {
        & $pgCtl status -D $PG_DATA *> $null
        if ($LASTEXITCODE -eq 0) {
            # Postmaster alive but not answering - never kill a live server.
            Write-FAIL "PostgreSQL is running (pg_ctl status) but not answering on port 5432. Check: $pgLog"
        } else {
            $pgOrphans = @(Get-Process postgres -ErrorAction SilentlyContinue | Where-Object { $_.Path -and $_.Path -like "$PG_BIN*" })
            if ($pgOrphans.Count) {
                Write-WARN "Port 5432 is held by $($pgOrphans.Count) orphaned postgres.exe process(es) with no running server (postmaster died) - stopping them."
                $pgOrphans | Stop-Process -Force -ErrorAction SilentlyContinue
                Start-Sleep -Seconds 2
            }
            if ((Test-Path "$PG_DATA\postmaster.pid") -and -not (Get-Process postgres -ErrorAction SilentlyContinue)) {
                Remove-Item "$PG_DATA\postmaster.pid" -Force -ErrorAction SilentlyContinue
            }

            Write-INFO "Starting PostgreSQL from $PG_DATA (detached from this window)..."
            $pgProc = Start-Process -FilePath $pgCtl -ArgumentList @('start', '-D', "`"$PG_DATA`"", '-l', "`"$pgLog`"", '-w', '-t', '90') -WindowStyle Hidden -PassThru
            $null = $pgProc.Handle
            if (-not $pgProc.WaitForExit(120000)) { Write-WARN "pg_ctl start did not return within 120s - checking the server directly." }

            $pgSw = [System.Diagnostics.Stopwatch]::StartNew()
            do {
                $pgCode = Get-PgReadyCode
                if ($pgCode -eq 0) { break }
                Start-Sleep -Seconds 2
            } while ($pgSw.Elapsed.TotalSeconds -lt 30)

            if ($pgCode -eq 0) { Write-OK "PostgreSQL is running and accepting connections on port 5432." }
            else               { Write-FAIL "PostgreSQL did not become ready. Check: $pgLog" }
        }
    }

    # ---------------------------------------------------------------------------
    # 2. Start Nginx
    # ---------------------------------------------------------------------------
    Write-Step "Starting Nginx"

    $ngxExe  = "$NGINX_ROOT\nginx.exe"
    $ngxProc = Get-Process -Name nginx -ErrorAction SilentlyContinue

    # Check BOTH process name AND ports 80/443 before attempting to start.
    # Using only the process name missed the case where nginx exited but left
    # its port bound (or a previous stale start wrote a bad PID file), causing
    # a second nginx.exe to fail to bind and silently die.
    $port80  = Get-NetTCPConnection -LocalPort 80  -State Listen -ErrorAction SilentlyContinue
    $port443 = Get-NetTCPConnection -LocalPort 443 -State Listen -ErrorAction SilentlyContinue

    if ($ngxProc -and ($port80 -or $port443)) {
        # Normal: process exists and has its port(s) - already running.
        # Built as a list + join instead of three chained if(){} blocks inside
        # one $(...) - PowerShell's parser rejects statements placed back-to-back
        # with no separator inside a subexpression (found live 2026-08-28: threw
        # "Unexpected token '$('" at this exact line and cascaded into bogus
        # errors on every line after it, since the parser then treated the rest
        # of the file's string literals as real code).
        $activePorts = @()
        if ($port80)  { $activePorts += '80' }
        if ($port443) { $activePorts += '443' }
        Write-OK "Nginx already running ($($ngxProc.Count) process(es)) and listening on port(s) $($activePorts -join ',')."
    } elseif ($ngxProc -and -not ($port80 -or $port443)) {
        # Nginx process exists but isn't listening yet (still starting up) -
        # don't launch a second copy; just warn and move on.
        Write-WARN "Nginx process found (PID: $($ngxProc[0].Id)) but ports 80/443 not yet active - skipping relaunch."
    } elseif (-not $ngxProc -and ($port80 -or $port443)) {
        # Port is occupied by something OTHER than nginx (or a crashed nginx
        # whose process is gone but port is still TIME_WAIT / held by another
        # program). Launching nginx here would cause an immediate bind failure.
        $occupier80  = if ($port80)  { $port80[0].OwningProcess  } else { 'N/A' }
        $occupier443 = if ($port443) { $port443[0].OwningProcess } else { 'N/A' }
        Write-FAIL "Port conflict detected - cannot start Nginx:"
        if ($port80)  { Write-FAIL "  Port  80 is held by PID $occupier80  ($(try{(Get-Process -Id $occupier80 -EA SilentlyContinue).ProcessName}catch{'unknown'}))" }
        if ($port443) { Write-FAIL "  Port 443 is held by PID $occupier443 ($(try{(Get-Process -Id $occupier443 -EA SilentlyContinue).ProcessName}catch{'unknown'}))" }
        Write-WARN "Stop the conflicting process(es) and re-run DART-Start.ps1."
    } elseif (-not (Test-Path $ngxExe)) {
        Write-FAIL "nginx.exe not found at $ngxExe"
    } else {
        # Clean state - no nginx process and ports are free. Safe to start.
        $pidFile = "$NGINX_ROOT\logs\nginx.pid"
        if (Test-Path $pidFile) {
            Remove-Item $pidFile -Force
            Write-INFO "Removed stale PID file."
        }

        Push-Location $NGINX_ROOT
        $prevEAP = $ErrorActionPreference
        $ErrorActionPreference = "Continue"
        $testResult = & .\nginx.exe -t 2>&1
        $ErrorActionPreference = $prevEAP
        Pop-Location

        if ($LASTEXITCODE -ne 0) {
            Write-FAIL "Nginx configuration test FAILED - not starting."
            Write-FAIL "  $testResult"
        } else {
            # -WindowStyle Hidden: nginx has no interactive console content
            # worth watching, and a visible window here is a real, observed
            # failure mode - found live in this same engagement, nginx's own
            # console window got closed among several other open windows
            # (Uvicorn's, the Airflow WSL window), killing it silently with no
            # crash/error logged anywhere.
            Start-Process -FilePath $ngxExe -WorkingDirectory $NGINX_ROOT -WindowStyle Hidden
            Start-Sleep -Seconds 2

            $ngxCheck  = Get-Process -Name nginx -ErrorAction SilentlyContinue
            $portCheck = Get-NetTCPConnection -LocalPort 443 -State Listen -ErrorAction SilentlyContinue
            if ($ngxCheck -and $portCheck) { Write-OK "Nginx is running on port 443." }
            elseif ($ngxCheck)             { Write-WARN "Nginx started but port 443 not yet active." }
            else                           { Write-FAIL "Nginx failed to start." }
        }
    }

    # ---------------------------------------------------------------------------
    # 3. Start Uvicorn (launched in a separate window so this script can finish)
    # ---------------------------------------------------------------------------
    Write-Step "Starting Uvicorn (Django backend)"

    $uvActive = Get-NetTCPConnection -LocalPort 8000 -State Listen -ErrorAction SilentlyContinue

    if ($uvActive) {
        $uvPid  = $uvActive.OwningProcess | Select-Object -First 1
        $uvName = try { (Get-Process -Id $uvPid -ErrorAction SilentlyContinue).ProcessName } catch { 'unknown' }
        # WARN, not OK. An already-occupied port is not the same as a healthy
        # backend: the process holding it was started with whatever .env said
        # AT THAT TIME, and Django only reads .env at startup. Reporting this
        # as [OK] is how a stale Uvicorn survives repeated DART-Stop/Start
        # cycles while the operator watches config changes appear in .env and
        # have no effect - seen on 2026-09-09 (ALLOWED_HOSTS) and again on
        # 2026-09-10 (airflow_admin_password), both times costing real time.
        Write-WARN "Port 8000 already in use by PID $uvPid ($uvName) - skipping Uvicorn launch."
        $uvStarted = (Get-Process -Id $uvPid -ErrorAction SilentlyContinue).StartTime
        if ($uvStarted) { Write-WARN "  That process started at $uvStarted - it does NOT pick up any .env change made since." }
        Write-WARN "  If you changed .env (hostname, CORS, Airflow password), kill it and re-run:"
        Write-WARN "    taskkill /PID $uvPid /T /F"
    } elseif (-not (Test-Path $VENV_PYTHON)) {
        Write-FAIL "Python venv not found at $VENV_PYTHON - run step 11 of the deployment script first."
    } else {
        # Write a self-contained launcher script.
        # This avoids Start-Process quoting issues and ensures .env is always loaded
        # even when the launcher is run standalone.
        $launcherPath = "$INSTALL_ROOT\DART-Uvicorn-Launcher.ps1"

        $lines = @()
        $lines += '# Auto-generated by DART-Start.ps1'
        $lines += "`$ENV_FILE = '$ENV_FILE'"
        $lines += 'if (Test-Path $ENV_FILE) {'
        $lines += '    Get-Content $ENV_FILE | Where-Object { $_ -match "=" -and $_ -notmatch "^\s*#" } | ForEach-Object {'
        $lines += '        $parts = $_.Split("=", 2)'
        $lines += '        $k = $parts[0].Trim()'
        $lines += "        `$v = `$parts[1].Trim().Trim([char]39).Trim([char]34)"
        $lines += '        Set-Item "env:$k" $v'
        $lines += '    }'
        $lines += '    Write-Host "[Launcher] Environment loaded." -ForegroundColor Green'
        $lines += '} else {'
        $lines += '    Write-Host "[Launcher] WARNING: .env not found." -ForegroundColor Red'
        $lines += '}'
        $lines += "`$env:DJANGO_SETTINGS_MODULE = 'Data_Recon_Main.settings'"
        $lines += "`$env:PATH = '$PG_BIN;' + `$env:PATH"
        $lines += "Set-Location '$DJANGO_DIR'"
        # Bind address and port come from config, and the bind defaults to
        # 0.0.0.0 - NOT 127.0.0.1, which is what this used to hardcode.
        #
        # Loopback-only means Airflow (running inside WSL2, a separate network
        # namespace whose traffic arrives on the vEthernet adapter) cannot
        # reach Django at all. Found live 2026-09-09: a DAG calling
        # /run_import/fetch_blob_file failed with "Connection to 172.27.64.1
        # timed out". VM-Windows-Bash-Script_V2.ps1 binds via $API_BIND_HOST
        # for the same reason; this launcher has to match, otherwise a plain
        # DART-Start.ps1 restart silently reintroduces the bug after the main
        # script has already fixed it.
        $API_BIND_HOST = Get-Cfg "API_BIND_HOST" "0.0.0.0"
        $API_PORT      = Get-Cfg "API_PORT"      "8000"
        $lines += "Write-Host `"[Launcher] Starting Uvicorn on ${API_BIND_HOST}:${API_PORT} ...`" -ForegroundColor Cyan"
        $lines += "& '$VENV_PYTHON' -m uvicorn Data_Recon_Main.asgi:application --host $API_BIND_HOST --port $API_PORT --reload"

        [System.IO.File]::WriteAllLines($launcherPath, $lines, [System.Text.Encoding]::UTF8)
        Write-INFO "Launcher written to: $launcherPath"

        if ((Start-AsScheduledTask -TaskName "DART-Uvicorn" -LauncherPath $launcherPath -WorkingDirectory $DJANGO_DIR) -eq $false) {
            # Fallback: same plain visible window as before - won't survive an
            # RDP disconnect, but keeps this run working if task registration
            # itself wasn't possible (e.g. no interactive prompt available).
            Start-Process powershell -ArgumentList "-ExecutionPolicy", "Bypass", "-NoExit", "-File", $launcherPath `
                -WorkingDirectory $DJANGO_DIR
        }

        Write-INFO "Waiting for Uvicorn to become ready..."
        $waited = 0
        do {
            Start-Sleep -Seconds 1
            $waited++
            $uvCheck = Get-NetTCPConnection -LocalPort 8000 -State Listen -ErrorAction SilentlyContinue
        } while (-not $uvCheck -and $waited -lt 15)

        if ($uvCheck) { Write-OK "Uvicorn is listening on port 8000." }
        else          { Write-WARN "Port 8000 not yet active after 15s - check the Uvicorn window for errors." }
    }

    # ---------------------------------------------------------------------------
    # 4. Start FastAPI (AI Auto Draft)
    # ---------------------------------------------------------------------------
    Write-Step "Starting FastAPI (AI Auto Draft)"

    $FASTAPI_HOST = Get-Cfg "FASTAPI_HOST" "127.0.0.1"
    $FASTAPI_PORT = Get-Cfg "FASTAPI_PORT" "5000"
    $FASTAPI_APP  = Get-Cfg "FASTAPI_APP"  "app.main:app"
    $FASTAPI_DIR  = Join-Path $BACKEND_DIR "AI Auto Draft"
    $FASTAPI_VENV_PYTHON = Join-Path $FASTAPI_DIR ".venv\Scripts\python.exe"

    $faActive = Get-NetTCPConnection -LocalPort ([int]$FASTAPI_PORT) -State Listen -ErrorAction SilentlyContinue
    if ($faActive) {
        $faPid  = $faActive.OwningProcess | Select-Object -First 1
        $faName = try { (Get-Process -Id $faPid -ErrorAction SilentlyContinue).ProcessName } catch { 'unknown' }
        Write-OK "Port $FASTAPI_PORT already in use by PID $faPid ($faName) - skipping FastAPI launch."
    } elseif (-not (Test-Path $FASTAPI_VENV_PYTHON)) {
        Write-FAIL "FastAPI venv not found at $FASTAPI_VENV_PYTHON - run step 14 (FastAPISetup) of the deployment script first."
    } else {
        Write-INFO "Launching FastAPI on ${FASTAPI_HOST}:${FASTAPI_PORT} ..."

        # Same generated-launcher-file pattern as Uvicorn above - "AI Auto Draft"
        # has a space in it, and the old inline -Command string (manually
        # quoting the python.exe path, then re-wrapped again by Start-Process's
        # own -ArgumentList quoting, then re-parsed a third time by the child
        # powershell.exe) collided - the embedded quotes terminated the outer
        # quote early and "AI" got parsed as a bare, unrecognized command.
        # Found live 2026-08-21. Writing a real .ps1 file and launching it with
        # -File sidesteps the whole nested-quoting problem, same reason Uvicorn
        # does this already.
        $faLauncherPath = "$INSTALL_ROOT\DART-FastAPI-Launcher.ps1"
        $faLines = @()
        $faLines += '# Auto-generated by DART-Start.ps1'
        $faLines += "Set-Location '$FASTAPI_DIR'"
        # Pre-flight .env check, printed IN THIS WINDOW before uvicorn even tries
        # to start - this .env is not committed to the repo (it's generated by
        # FastAPISetup, or hand-edited afterward), and a missing/empty required
        # value crashes FastAPI on import with a multi-screen pydantic traceback
        # that doesn't say what to actually do about it. Found live 2026-08-21
        # (see BUG-024) - this surfaces the same information as a short,
        # actionable message first.
        $faLines += "`$envPath = '$FASTAPI_DIR\.env'"
        $faLines += 'if (-not (Test-Path $envPath)) {'
        $faLines += '    Write-Host ""'
        $faLines += '    Write-Host "======================================================" -ForegroundColor Red'
        $faLines += '    Write-Host " WARNING: FastAPI .env not found:" -ForegroundColor Red'
        $faLines += '    Write-Host "   $envPath" -ForegroundColor Red'
        $faLines += '    Write-Host " This file is NOT committed to the repo - it is generated" -ForegroundColor Red'
        $faLines += '    Write-Host " by FastAPISetup (Step 14), or must be created by hand." -ForegroundColor Red'
        $faLines += '    Write-Host " FastAPI will fail to start without it." -ForegroundColor Red'
        $faLines += '    Write-Host "======================================================" -ForegroundColor Red'
        $faLines += '    Write-Host ""'
        $faLines += '} else {'
        $faLines += '    $envLines = Get-Content $envPath'
        $faLines += "    `$checkKeys = @('AZURE_OPENAI_API_KEY','AZURE_OPENAI_ENDPOINT','AZURE_STORAGE_CONNECTION_STRING')"
        $faLines += '    $missingKeys = @()'
        $faLines += '    foreach ($k in $checkKeys) {'
        $faLines += '        $line = $envLines | Where-Object { $_ -match "^\s*$k\s*=" } | Select-Object -First 1'
        $faLines += '        if (-not $line -or ($line.Split("=")[1].Trim() -eq "")) { $missingKeys += $k }'
        $faLines += '    }'
        $faLines += '    if ($missingKeys.Count -gt 0) {'
        $faLines += '        Write-Host ""'
        $faLines += '        Write-Host "======================================================" -ForegroundColor Yellow'
        $faLines += '        Write-Host " WARNING: these .env values are empty/missing:" -ForegroundColor Yellow'
        $faLines += '        foreach ($k in $missingKeys) { Write-Host "   - $k" -ForegroundColor Yellow }'
        $faLines += '        Write-Host " File: $envPath" -ForegroundColor Yellow'
        $faLines += '        Write-Host " FastAPI Settings validation requires all of these" -ForegroundColor Yellow'
        $faLines += '        Write-Host " (when CLOUD_PROVIDER=azure) and WILL crash on startup" -ForegroundColor Yellow'
        $faLines += '        Write-Host " without real values. Edit the file above, then re-run" -ForegroundColor Yellow'
        $faLines += '        Write-Host " this window. See test/issues/BUG-024 for background." -ForegroundColor Yellow'
        $faLines += '        Write-Host "======================================================" -ForegroundColor Yellow'
        $faLines += '        Write-Host ""'
        $faLines += '    }'
        $faLines += '}'
        $faLines += "Write-Host `"[Launcher] Starting FastAPI on ${FASTAPI_HOST}:${FASTAPI_PORT} ...`" -ForegroundColor Cyan"
        $faLines += "& '$FASTAPI_VENV_PYTHON' -m uvicorn $FASTAPI_APP --host $FASTAPI_HOST --port $FASTAPI_PORT --reload"

        [System.IO.File]::WriteAllLines($faLauncherPath, $faLines, [System.Text.Encoding]::UTF8)
        Write-INFO "Launcher written to: $faLauncherPath"

        if ((Start-AsScheduledTask -TaskName "DART-FastAPI" -LauncherPath $faLauncherPath -WorkingDirectory $FASTAPI_DIR) -eq $false) {
            # Fallback: same plain visible window as before - won't survive an
            # RDP disconnect, but keeps this run working if task registration
            # itself wasn't possible (e.g. no interactive prompt available).
            Start-Process powershell -ArgumentList "-ExecutionPolicy", "Bypass", "-NoExit", "-File", $faLauncherPath `
                -WorkingDirectory $FASTAPI_DIR
        }

        Write-INFO "Waiting for FastAPI to become ready..."
        $waited = 0
        do {
            Start-Sleep -Seconds 1
            $waited++
            $faCheck = Get-NetTCPConnection -LocalPort ([int]$FASTAPI_PORT) -State Listen -ErrorAction SilentlyContinue
        } while (-not $faCheck -and $waited -lt 15)

        if ($faCheck) { Write-OK "FastAPI is listening on port $FASTAPI_PORT." }
        else          { Write-WARN "Port $FASTAPI_PORT not yet active after 15s - check the FastAPI window for errors." }
    }

    # ---------------------------------------------------------------------------
    # 5. Start Apache Airflow (WSL2)
    # ---------------------------------------------------------------------------
    if ($SkipAirflow) {
        Write-Step "Skipping Apache Airflow (-SkipAirflow)"
        Write-INFO "Airflow not started - requested by the caller."
    } else {
    Write-Step "Starting Apache Airflow (WSL2)"

    $AIRFLOW_PORT = Get-Cfg "AIRFLOW_PORT" "8080"
    $afDistro     = Get-Cfg "WSL_DISTRO"   "Ubuntu-24.04"

    # 1s TCP probe. Test-NetConnection takes ~5s on a closed port, so the
    # wait loops below - which counted 2s per pass - under-reported the real
    # elapsed time ~3x ("120s elapsed" after 5.5 minutes). Found live 2026-10-14.
    function Test-TcpPort([string]$TcpHost, [int]$Port, [int]$TimeoutMs = 1000) {
        $tc = New-Object System.Net.Sockets.TcpClient
        try {
            $ar = $tc.BeginConnect($TcpHost, $Port, $null, $null)
            return ($ar.AsyncWaitHandle.WaitOne($TimeoutMs) -and $tc.Connected)
        } catch { return $false } finally { $tc.Close() }
    }

    # Every wsl call targets the configured distro (-d) and is timeout-guarded:
    # without -d it runs in the machine's DEFAULT distro, which is not
    # necessarily the one Airflow lives in.
    function Invoke-AfWsl([string]$Cmd, [int]$TimeoutSec = 15) {
        # --exec: run bash directly. Without it wsl hands the joined command line
        # to the distro's login shell, which parses it a second time - a ';' loop
        # then dies with a syntax error, hidden by 2>$null. Found live 2026-10-16:
        # DART-Stop's TERM/KILL never ran and Airflow survived every stop.
        $j = Start-Job -ScriptBlock { param($d, $c) & wsl -d $d -u root --exec bash -c $c 2>$null } -ArgumentList $afDistro, $Cmd
        $out = if (Wait-Job $j -Timeout $TimeoutSec) { Receive-Job $j } else { Stop-Job $j -ErrorAction SilentlyContinue; $null }
        Remove-Job $j -Force -ErrorAction SilentlyContinue
        return (($out | Out-String) -replace "`0", "" -replace "`r", "").Trim()
    }

    # Airflow is "up" if the port answers on Windows localhost OR directly on
    # the WSL2 VM IP. On Windows Server 2022 localhost forwarding into WSL2 is
    # unreliable (see the airflow_base_url sync above), so checking localhost
    # alone reported a RUNNING Airflow as down - and the setup was then re-run
    # on top of it. Found live 2026-10-14.
    function Test-AirflowUp([string]$WslIp) {
        if (Get-NetTCPConnection -LocalPort ([int]$AIRFLOW_PORT) -State Listen -ErrorAction SilentlyContinue) { return $true }
        if (Test-TcpPort "127.0.0.1" ([int]$AIRFLOW_PORT)) { return $true }
        if ($WslIp -and (Test-TcpPort $WslIp ([int]$AIRFLOW_PORT))) { return $true }
        return $false
    }

    $afWslIp = Invoke-AfWsl "hostname -I | cut -d' ' -f1" 10
    if ($afWslIp -notmatch '^\d{1,3}(\.\d{1,3}){3}$') { $afWslIp = $null }

    $afActive = Test-AirflowUp $afWslIp

    if ($afActive) {
        Write-OK "Airflow already listening on port $AIRFLOW_PORT$(if ($afWslIp) { " (WSL2 IP $afWslIp)" })."
    } else {
        # Not answering on the port, but Airflow processes still alive in WSL2
        # (survived a DART-Stop that targeted the wrong distro, or a half-
        # started earlier run). They hold sessions on the recon_airflow
        # tables, and AirflowSetup's GRANT ... ON ALL TABLES then waited on
        # them forever - Airflow never got as far as starting. Found live
        # 2026-10-14. Stop them first so setup starts from a clean state.
        # '[a]irflow' so the pattern never matches the bash running pkill.
        $afStale = Invoke-AfWsl "pgrep -af '[a]irflow' || true" 10
        if ($afStale) {
            Write-WARN "Airflow processes are running in WSL2 ($afDistro) but port $AIRFLOW_PORT is not answering - stopping them before setup:"
            $afStale -split "`n" | Select-Object -First 6 | ForEach-Object { Write-INFO "    $($_.Substring(0, [Math]::Min(110, $_.Length)))" }
            Invoke-AfWsl "pkill -TERM -f '[a]irflow'; for i in `$(seq 1 20); do pgrep -f '[a]irflow' >/dev/null || exit 0; sleep 1; done; pkill -KILL -f '[a]irflow'; exit 0" 40 | Out-Null
            if (Invoke-AfWsl "pgrep -f '[a]irflow' || true" 10) { Write-WARN "Some Airflow processes are still running in WSL2 - setup may block on them." }
            else { Write-OK "Stale Airflow processes stopped." }
        }

        # Delegated, not reimplemented here: the actual launch command is a
        # fairly involved WSL2 bash one-liner (host-IP detection, several
        # AIRFLOW__* env exports, the DB connection string) that already lives
        # in, and is kept correct in, VM-Windows-Bash-Script_V2.ps1's own
        # AirflowSetup step. Hand-copying it here would be exactly the kind of
        # duplicated logic that goes stale the next time that command changes -
        # calling the main script's own -StepList "AirflowSetup" (itself fully
        # idempotent - it skips venv/pip work already done, self-heals the
        # Postgres/firewall connectivity, and just (re)launches the standalone
        # server) keeps this permanently in sync with it instead.
        $mainScript = Join-Path $_scriptDir "VM-Windows-Bash-Script_V2.ps1"
        if (!(Test-Path $mainScript)) {
            Write-FAIL "VM-Windows-Bash-Script_V2.ps1 not found next to this script - cannot start Airflow."
        } else {
            # Run AirflowSetup DIRECTLY in this session - no scheduled task.
            #
            # The DART-Airflow scheduled task ran in session 0, where wsl.exe
            # often cannot start, and its only progress signal was a port poll:
            # a hung setup step (2026-10-14: GRANT waiting on a leftover Airflow)
            # looked exactly like "still starting" until a long timeout, then a
            # second in-session retry ran anyway. Running it here shows every
            # setup step live in this window, and when it returns, Airflow has
            # been launched (AirflowSetup starts `airflow standalone` in its
            # own WSL window and waits for the admin-password file).
            #
            # Trade-off: Airflow belongs to this logon session - it survives an
            # RDP disconnect, not a log-off.
            #
            # -NoServiceRestart is mandatory: the deploy script ends with its own
            # stop/start cycle, which calls THIS script - without the switch,
            # starting Airflow restarts everything, forever (live 2026-09-16).
            $afOldTask = Get-ScheduledTask -TaskName "DART-Airflow" -ErrorAction SilentlyContinue
            if ($afOldTask) {
                # Left over from the old scheduled-task launch - keep it from
                # starting a second, competing setup.
                Stop-ScheduledTask    -TaskName "DART-Airflow" -ErrorAction SilentlyContinue
                Disable-ScheduledTask -TaskName "DART-Airflow" -ErrorAction SilentlyContinue | Out-Null
                Write-INFO "Old scheduled task 'DART-Airflow' disabled - Airflow now starts in this session."
            }

            Write-INFO "Running VM-Windows-Bash-Script_V2.ps1 -StepList `"AirflowSetup`" in this session..."
            & powershell -ExecutionPolicy Bypass -File $mainScript -Silent -NoServiceRestart -StepList "AirflowSetup"
            $afSetupExit = $LASTEXITCODE

            # Setup has returned, so the remaining wait is only the api-server
            # binding its port (DB migrate already ran inside setup).
            $afBudget   = 120
            Write-INFO "AirflowSetup finished (exit $afSetupExit) - waiting up to ${afBudget}s for port $AIRFLOW_PORT..."
            $afClock    = [System.Diagnostics.Stopwatch]::StartNew()   # real time, not a per-pass counter
            $afNextNote = 30
            $waited     = 0
            do {
                if (-not $afWslIp) {
                    $afWslIp = Invoke-AfWsl "hostname -I | cut -d' ' -f1" 5
                    if ($afWslIp -notmatch '^\d{1,3}(\.\d{1,3}){3}$') { $afWslIp = $null }
                }
                $afCheck = Test-AirflowUp $afWslIp
                if ($afCheck) { break }
                Start-Sleep -Seconds 2
                $waited = [int]$afClock.Elapsed.TotalSeconds
                if ($waited -ge $afNextNote) { Write-INFO "  ...still waiting (${waited}s)"; $afNextNote += 30 }
            } while ($waited -lt $afBudget)

            if ($afCheck) {
                Write-OK "Airflow is up on port $AIRFLOW_PORT$(if ($afWslIp) { " - UI: http://${afWslIp}:$AIRFLOW_PORT" })."
                Write-WARN "  Airflow runs in this logon session: it survives an RDP disconnect, not a log-off."
            } else {
                Write-FAIL "Airflow did not open port $AIRFLOW_PORT within ${afBudget}s of setup finishing."
                Write-WARN "  Check, in order:"
                Write-WARN "   1. the AirflowSetup output above - the first [ERROR] line is the cause"
                Write-WARN "   2. the Airflow WSL window it opened - api-server/scheduler errors show there"
                Write-WARN "   3. wsl -d $afDistro bash -c `"pgrep -af airflow`"  - is anything running?"
                Write-WARN "   4. latest log: $INSTALL_ROOT\logs\deploy_*.log"
            }
        }
    }
    }   # end if (-not $SkipAirflow)

    # ---------------------------------------------------------------------------
    # Summary
    # ---------------------------------------------------------------------------
    Write-Host ""
    Write-Host "==========================================" -ForegroundColor DarkCyan
    Write-Host "   DART startup complete."                  -ForegroundColor Green
    Write-Host ""
    Write-Host "   Frontend : https://$UI_HOST/" -ForegroundColor Cyan
    Write-Host "   Backend  : http://127.0.0.1:8000/"          -ForegroundColor Cyan
    Write-Host "   FastAPI  : http://${FASTAPI_HOST}:${FASTAPI_PORT}/" -ForegroundColor Cyan
    Write-Host "   Airflow  : http://$(if ($afWslIp) { $afWslIp } else { 'localhost' }):$AIRFLOW_PORT/" -ForegroundColor Cyan
    Write-Host ""
    Write-Host "   Run DART-Status.ps1 to verify all services." -ForegroundColor DarkGray
    Write-Host "==========================================" -ForegroundColor DarkCyan
    Write-Host ""

    # ---------------------------------------------------------------------------
    # Start again after every restart (DART-AutoStart task, AtLogon)
    # ---------------------------------------------------------------------------
    # Registered here rather than only by the installer so boxes installed
    # before this existed pick it up on their next start. -Register is called
    # every time: it is silent when the task is already right, and corrects a
    # task bound to the wrong account (an administrator's, when a standard
    # user elevated - that one never fires at the standard user's logon).
    # AUTO_START_AT_LOGON=false opts out (and removes nothing - use
    # DART-AutoStart.ps1 -Unregister for that).
    if ((Get-Cfg "AUTO_START_AT_LOGON" "true") -match '^\s*(?i:true|1|yes|y)\s*$') {
        $autoStartScript = Join-Path $_scriptDir "DART-AutoStart.ps1"
        if (Test-Path $autoStartScript) {
            & $autoStartScript -Register | ForEach-Object { Write-Host $_ }
        } else {
            Write-WARN "DART-AutoStart.ps1 not found next to this script - services will NOT start by themselves after a restart."
        }
    }
