# ===========================================================================
#  DART - RESUME SETUP AFTER RESTART
#
#  Runs automatically at logon after the reboot that finishes enabling WSL2.
#  Registered by VM-Windows-Bash-Script_V2.ps1 when every step completed with
#  no errors and the only outstanding item was that restart.
#
#  What it does, in order:
#     1. Runs DART-Start.ps1 -SkipAirflow, then WAITS (up to 60s) for
#        PostgreSQL to accept connections. The backend is started too, not
#        just the database - the DAGs call Django on API_PORT. Airflow is
#        skipped because it is the thing not set up yet; starting it here
#        would just burn the start-up budget on a service that cannot exist.
#     2. Runs ONLY -StepList "AirflowSetup". Steps 1-14 already completed
#        before the reboot and are not repeated.
#     3. On success: DART-Stop -> DART-Status -> DART-Start, so the box comes
#        back with every service freshly started and verified.
#     4. Unregisters itself - but ONLY after a clean run.
#
#  On failure it deliberately KEEPS the task registered and leaves the window
#  open with the error. The failure this most often catches is the apt/DNS
#  stall inside WSL, which is transient - retrying at the next logon fixes it
#  without anyone being told to run anything. A permanent failure retries and
#  logs each time rather than failing silently.
#
#  AtLogon + Interactive, never AtStartup: a task in session 0 cannot run WSL
#  (see DART-Start.ps1 for the same constraint) and would have no window to
#  show progress in.
#
#  Usage:
#     .\DART-Resume-Setup.ps1              # what the scheduled task runs
#     .\DART-Resume-Setup.ps1 -Unregister  # cancel the pending auto-resume
# ===========================================================================
param(
    [string]$ConfigFile = "",
    [switch]$Unregister
)

$TASK_NAME = "DART-Resume-Setup"
$_scriptDir = if ($PSScriptRoot) { $PSScriptRoot } else { (Get-Location).Path }

$cfgPath = if ($ConfigFile -and (Test-Path $ConfigFile)) { $ConfigFile } else { Join-Path $_scriptDir "dart_deploy_config.json" }
$cfg = $null
if (Test-Path $cfgPath) { try { $cfg = Get-Content $cfgPath -Raw -Encoding UTF8 | ConvertFrom-Json } catch { } }
function Get-Cfg($k, $d) { if ($cfg -and $cfg.PSObject.Properties.Name -contains $k -and "$($cfg.$k)" -ne "") { return "$($cfg.$k)" }; return $d }

$INSTALL_ROOT = Get-Cfg "INSTALL_ROOT" "C:\DART_DEPLOY"
$TOOLS_ROOT   = Get-Cfg "TOOLS_ROOT"   "C:\DART_Tools"
$DB_PORT      = [int](Get-Cfg "DB_PORT" "5432")
$LOG_DIR      = Join-Path $INSTALL_ROOT "logs"
$RESUME_LOG   = Join-Path $LOG_DIR ("resume_{0}.log" -f (Get-Date -Format "yyyyMMdd_HHmmss"))

function Say($m, $c = "Gray") {
    Write-Host $m -ForegroundColor $c
    try { Add-Content -Path $RESUME_LOG -Value ("[{0}] {1}" -f (Get-Date -Format "HH:mm:ss"), $m) -Encoding UTF8 } catch { }
}
function Head($m) {
    Write-Host ""
    Write-Host ("=" * 70) -ForegroundColor DarkCyan
    Write-Host "  $m" -ForegroundColor Cyan
    Write-Host ("=" * 70) -ForegroundColor DarkCyan
    try { Add-Content -Path $RESUME_LOG -Value "`n=== $m ===" -Encoding UTF8 } catch { }
}

if (-not (Test-Path $LOG_DIR)) { New-Item -ItemType Directory -Path $LOG_DIR -Force | Out-Null }

# --- -Unregister: cancel a pending resume ---------------------------------
if ($Unregister) {
    if (Get-ScheduledTask -TaskName $TASK_NAME -ErrorAction SilentlyContinue) {
        Unregister-ScheduledTask -TaskName $TASK_NAME -Confirm:$false
        Say "Auto-resume cancelled - '$TASK_NAME' unregistered." "Yellow"
    } else {
        Say "No pending auto-resume task found." "Gray"
    }
    exit 0
}

Head "DART - resuming setup after restart"
Say "This window is running automatically. You do not need to type anything." "Gray"
Say "Log: $RESUME_LOG" "DarkGray"

# ===========================================================================
# 1. Bring the stack up BEFORE Airflow setup runs
# ===========================================================================
# Not just PostgreSQL. Airflow's setup and its DAGs call Django on API_PORT
# (that is what AIRFLOW_CONN_API_DART points at), so the backend has to be
# listening too, not only the database.
#
# -SkipAirflow because Airflow is precisely what has NOT been set up yet -
# starting it here would spend the whole start-up budget waiting on a service
# that cannot exist. Step 4 does a normal, Airflow-inclusive start once the
# setup has actually completed.
Head "1/4  Starting services (PostgreSQL + backend, Airflow skipped)"

$startScript = Join-Path $_scriptDir "DART-Start.ps1"
if (Test-Path $startScript) {
    & powershell.exe -ExecutionPolicy Bypass -File $startScript -SkipAirflow
} else {
    Say "  [WARN] DART-Start.ps1 not found - falling back to starting PostgreSQL directly" "Yellow"
    $pgCtl  = Join-Path $TOOLS_ROOT "postgres\bin\pg_ctl.exe"
    $pgData = Join-Path $TOOLS_ROOT "postgres\data"
    # Own hidden console: `& pg_ctl start` here would attach postgres.exe to
    # this window, and a Ctrl+C in it would kill the database (2026-10-14).
    if (Test-Path $pgCtl) { Start-Process -FilePath $pgCtl -ArgumentList @('start', '-D', "`"$pgData`"", '-l', "`"$(Join-Path $TOOLS_ROOT 'postgres\resume.log')`"") -WindowStyle Hidden | Out-Null }
}

# Verify rather than trust: DART-Start returns whether or not the port came
# up, and starting the Airflow step against a database that is not accepting
# connections fails in a way that reads as an Airflow bug, not a timing one.
function Test-PgUp { [bool](Get-NetTCPConnection -LocalPort $DB_PORT -State Listen -ErrorAction SilentlyContinue) }
$deadline = (Get-Date).AddSeconds(60)
while (-not (Test-PgUp) -and (Get-Date) -lt $deadline) { Start-Sleep -Seconds 3 }

if (Test-PgUp) {
    Say "  [OK]   PostgreSQL listening on $DB_PORT" "Green"
} else {
    Say "  [FAIL] PostgreSQL did not come up within 60s." "Red"
    Say "         Airflow setup needs it. Task kept - it will retry at your next logon." "Yellow"
    Read-Host "`nPress Enter to close"
    exit 1
}

# The backend is a warning, not a gate: Airflow SETUP itself does not call
# Django - only the DAGs do, at run time - so a backend that is slow to come
# up should not block the install. Step 4 restarts everything anyway.
$API_PORT = [int](Get-Cfg "API_PORT" "8000")
if (Get-NetTCPConnection -LocalPort $API_PORT -State Listen -ErrorAction SilentlyContinue) {
    Say "  [OK]   Backend listening on $API_PORT" "Green"
} else {
    Say "  [WARN] Backend is not listening on $API_PORT yet - continuing." "Yellow"
    Say "         DAG tasks need it, but Airflow setup does not. Step 4 restarts everything." "DarkGray"
}

# ===========================================================================
# 2. Airflow setup - the only step that did not run before the reboot
# ===========================================================================
Head "2/4  Running Airflow setup (this takes several minutes)"

$deployScript = Join-Path $_scriptDir "VM-Windows-Bash-Script_V2.ps1"
if (-not (Test-Path $deployScript)) {
    Say "  [FAIL] Deploy script not found at $deployScript" "Red"
    Read-Host "`nPress Enter to close"
    exit 1
}

# -NoServiceRestart: the deploy script ends with its own stop/start cycle, and
# steps 3 and 4 below are that cycle done properly - with a verified stop and a
# retry. Without the switch the services are restarted twice per resume: once
# inside this call, once by this script. Not a loop (the deploy script's guards
# prevent that), just several wasted minutes on the one run the operator is
# sitting and watching.
& powershell.exe -ExecutionPolicy Bypass -File $deployScript -Silent -NoServiceRestart -StepList "AirflowSetup"
$afExit = $LASTEXITCODE
Say "  AirflowSetup exit code: $afExit" "DarkGray"

# 0 = clean, 2 = completed but flagged an ACTION NEEDED banner, 1 = errors.
if ($afExit -eq 1) {
    Head "Airflow setup FAILED"
    Say "  The '$TASK_NAME' task has been KEPT registered on purpose." "Yellow"
    Say "  It will retry automatically the next time you log in." "Yellow"
    Say "" "Gray"
    Say "  If this keeps failing, the usual cause is the apt/DNS stall inside" "Gray"
    Say "  WSL. Check it directly with:" "Gray"
    Say "    wsl -d Ubuntu-24.04 -u root -- bash -lc 'getent ahostsv4 archive.ubuntu.com'" "DarkGray"
    Say "" "Gray"
    Say "  To stop the automatic retries:  .\DART-Resume-Setup.ps1 -Unregister" "DarkGray"
    Read-Host "`nPress Enter to close"
    exit 1
}

Say "  [OK]   Airflow setup completed" "Green"

# ===========================================================================
# 3. Stop everything and confirm it really stopped
# ===========================================================================
Head "3/4  Restarting all services (stop -> verify -> start)"

$stopScript   = Join-Path $_scriptDir "DART-Stop.ps1"
$statusScript = Join-Path $_scriptDir "DART-Status.ps1"

if (Test-Path $stopScript) {
    Say "  running DART-Stop..." "Gray"
    & powershell.exe -ExecutionPolicy Bypass -File $stopScript
} else { Say "  [WARN] DART-Stop.ps1 not found - skipping" "Yellow" }

if (Test-Path $statusScript) {
    Say "  running DART-Status to confirm everything stopped..." "Gray"
    & powershell.exe -ExecutionPolicy Bypass -File $statusScript -ExpectStopped
    $stoppedOk = ($LASTEXITCODE -eq 0)
} else {
    $stoppedOk = $true
    Say "  [WARN] DART-Status.ps1 not found - skipping the stopped check" "Yellow"
}

if (-not $stoppedOk) {
    # One retry, then start anyway. A lingering listener is usually a socket
    # in TIME_WAIT or a child that needed a moment; refusing to start would
    # leave the box down, which is worse than starting with a warning.
    Say "  [WARN] Something is still listening - waiting 15s and stopping once more..." "Yellow"
    Start-Sleep -Seconds 15
    if (Test-Path $stopScript) { & powershell.exe -ExecutionPolicy Bypass -File $stopScript }
    if (Test-Path $statusScript) {
        & powershell.exe -ExecutionPolicy Bypass -File $statusScript -ExpectStopped
        if ($LASTEXITCODE -ne 0) { Say "  [WARN] Still not fully stopped - starting anyway, check DART-Status afterwards." "Yellow" }
        else { Say "  [OK]   All services stopped" "Green" }
    }
} else {
    Say "  [OK]   All services stopped" "Green"
}

# ===========================================================================
# 4. Start everything again
# ===========================================================================
Head "4/4  Starting services"
if (Test-Path $startScript) {
    & powershell.exe -ExecutionPolicy Bypass -File $startScript
} else {
    Say "  [FAIL] DART-Start.ps1 not found at $startScript" "Red"
}

# ===========================================================================
# Done - only now is it safe to remove the task
# ===========================================================================
if (Get-ScheduledTask -TaskName $TASK_NAME -ErrorAction SilentlyContinue) {
    Unregister-ScheduledTask -TaskName $TASK_NAME -Confirm:$false
    Say "Auto-resume task removed - this will not run again." "DarkGray"
}

Head "DART setup COMPLETE"
Say "  Airflow setup finished and all services were restarted." "Green"
Say "  Log: $RESUME_LOG" "DarkGray"
Say "" "Gray"
Say "  Check anything with:  .\DART-Status.ps1" "DarkGray"
Read-Host "`nPress Enter to close"
exit 0
