# ==============================================================================
# az_exec.ps1  --  Database Setup Executor (Converted from az_exec.sh)
#
# Loops over the numbered overlay folders in the Data_Recon_Database repository:
#   1_Golden_copy_V1
#   2_Transformation_enhancement
#   3_Report_filter_enhancement
#   4_Bug_fixes
#   5_AI_create_db
#   6_V_Airflow
#   7_V_SSO
#   8_AI_reconcile
#   10_Multi_cloud_storage       (added 2026-08-21 - PR 2610 "Multi cloud changes",
#                                 mvp_main commit a9d1b20; create_db/ + normal
#                                 roleMap-named subfolders, same shape as 1-8)
#   12_Airflow_bugfixes
#   13_Airflow_external_source   (added 2026-09-16 - mvp_main commit 39c9800,
#                                 PR 3541; recon_master + recon_admin +
#                                 recon_admin_functions subfolders, 9 scripts.
#                                 Despite the name it is NOT the same shape as
#                                 the old 9_Airflow_external_source, which was
#                                 flat - this one is a normal roleMap folder.)
#
# There is no 11 in the repo at commit 39c9800. 9_Airflow_external_source was
# removed 2026-09-16 - not used by this deployment.
#
# IMPORTANT, if a folder is ever added back here: this script only executes SQL
# it finds in a `create_db/` subfolder or in a roleMap-named subfolder
# (recon_master, recon_admin, recon_meta, ...). It has NO pass for loose .sql
# files sitting at the folder root. A flat folder is therefore processed
# silently - the banner prints, nothing runs, no error is raised and the
# pass/fail counts do not move. 9_Airflow_external_source was a flat folder and
# its entry here used to claim a "loose .sql files" pass handles that case; no
# such pass exists in the code. Check a new folder's shape before adding it.
#
# Runs create_db scripts, schema objects under dedicated roles, views, and grants.
# ==============================================================================
param(
    [string]$InstallRoot = "C:\DARTV1",
    [string]$ToolsRoot   = "C:\DART_Tools",
    [string]$DbHost      = "localhost",
    [string]$DbPort      = "5432",
    # Comma-separated subset of overlay folder names to run, e.g.
    # "1_Golden_copy_V1,4_Bug_fixes" - matches dart_deploy_config.json's
    # DB_FOLDERS key (read and passed through by the caller). Empty/omitted
    # means "run all 8 folders in order", identical to the original,
    # unconditional behavior - this is purely additive.
    [string]$DbFolders   = "",
    # Password set on every usr_dr_* / dr_mstr_srvc role, and passed to
    # 04_create_db_users_dataRecon.sql as psql variable 'ss'. MUST match
    # what the caller wrote into .pgpass, or every later psql call fails
    # to authenticate. Defaults to the previously hardcoded 'admin'.
    [string]$RolePassword   = "admin",
    # 'postgres' superuser password - fallback used only when PGPASSFILE
    # is unreadable. Was hardcoded 'admin'.
    [string]$MasterPassword = ""
)

$ErrorActionPreference = "Stop"

# ==============================
# Derived paths
# ==============================
$PSQL_BIN   = Join-Path $ToolsRoot   "postgres\bin"
$PSQL_EXE   = Join-Path $PSQL_BIN    "psql.exe"
$LOG_ROOT   = Join-Path $InstallRoot "logs"
$PGPASSFILE = Join-Path $InstallRoot ".pgpass"
$DBROOT     = Join-Path $InstallRoot "Database\Data_Recon_Database"

$hostnm = $DbHost
$port   = [int]$DbPort
$dbname = "db_datarecon"

# ==============================
# Bootstrap: log directory
# ==============================
if (!(Test-Path $LOG_ROOT)) { New-Item -ItemType Directory -Path $LOG_ROOT -Force | Out-Null }

$RUN_STAMP   = Get-Date -Format "yyyyMMdd_HHmmss"
$LOG_DIR     = Join-Path $LOG_ROOT ("run_" + $RUN_STAMP)
New-Item -ItemType Directory -Path $LOG_DIR -Force | Out-Null

# Master summary log for this run
$SUMMARY_LOG = Join-Path $LOG_DIR "00_summary.log"

# ==============================
# Pass / Fail counters
# ==============================
$script:PassCount = 0
$script:FailCount = 0
$script:SkipCount = 0
$script:Results   = @()   # collects [Status, Script, Duration, Message] rows

# ==============================
# Logging helpers
# ==============================
function Write-SummaryLog([string]$line) {
    Add-Content -Path $SUMMARY_LOG -Value $line -Encoding UTF8
}

function Log-DB([string]$msg) {
    $ts   = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $line = "[$ts] [INFO   ] $msg"
    Write-Host $line -ForegroundColor Cyan
    Write-SummaryLog $line
}

function Log-DB-Ok([string]$msg) {
    $ts   = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $line = "[$ts] [SUCCESS] $msg"
    Write-Host $line -ForegroundColor Green
    Write-SummaryLog $line
}

function Log-DB-Err([string]$msg) {
    $ts   = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $line = "[$ts] [ERROR  ] $msg"
    Write-Host $line -ForegroundColor Red
    Write-SummaryLog $line
}

function Log-DB-Warn([string]$msg) {
    $ts   = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $line = "[$ts] [WARNING] $msg"
    Write-Host $line -ForegroundColor Yellow
    Write-SummaryLog $line
}

function Log-DB-Step([string]$msg) {
    $ts   = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $line = "[$ts] [STEP   ] ========== $msg =========="
    Write-Host ""
    Write-Host $line -ForegroundColor DarkCyan
    Write-SummaryLog ""
    Write-SummaryLog $line
}

# ==============================
# Write log header
# ==============================
$_hdr = "=" * 70
Write-SummaryLog $_hdr
Write-SummaryLog "  DART Database Setup Log (az_exec.ps1)"
Write-SummaryLog ("  Started  : " + (Get-Date -Format "yyyy-MM-dd HH:mm:ss"))
Write-SummaryLog ("  DB Host  : ${hostnm}:${port}")
Write-SummaryLog ("  Database : $dbname")
Write-SummaryLog ("  Log Dir  : $LOG_DIR")
Write-SummaryLog $_hdr

Log-DB "InstallRoot  : $InstallRoot"
Log-DB "ToolsRoot    : $ToolsRoot"
Log-DB "DB host      : ${hostnm}:${port}"
Log-DB "Database     : $dbname"
Log-DB "Summary log  : $SUMMARY_LOG"
Log-DB "Detail logs  : $LOG_DIR"

# ==============================
# Pre-flight checks
# ==============================
Log-DB-Step "Pre-flight Checks"
$env:PGPASSFILE = $PGPASSFILE
$env:PGPASSWORD = $MasterPassword
Log-DB "Using PGPASSFILE: $PGPASSFILE"

if (!(Test-Path $PGPASSFILE)) {
    Log-DB-Warn "PGPASSFILE not found at: $PGPASSFILE (falling back to the configured MasterPassword)"
}
if (!(Test-Path $PSQL_EXE)) {
    # Fallback to system PATH if psql.exe is not in ToolsRoot
    $sysPsql = Get-Command psql.exe -ErrorAction SilentlyContinue
    if ($sysPsql) {
        $PSQL_EXE = $sysPsql.Source
        Log-DB "Using psql from system PATH: $PSQL_EXE"
    } else {
        Log-DB-Err "psql.exe not found at: $PSQL_EXE"
        throw "psql.exe not found at: $PSQL_EXE"
    }
}
if (!(Test-Path $DBROOT)) {
    Log-DB-Err "Database scripts root not found: $DBROOT"
    throw "Database root not found: $DBROOT"
}
Log-DB-Ok "Pre-flight checks passed."

# ==============================
# Helper Functions
# ==============================
function Reset-Log([string]$LogName) {
    $logPath = Join-Path $LOG_DIR $LogName
    if (Test-Path $logPath) { Remove-Item $logPath -Force }
    return $logPath
}

function Run-PsqlFile {
    param(
        [Parameter(Mandatory=$true)][string]$SqlFilePath,
        [Parameter(Mandatory=$true)][string]$User,
        [Parameter(Mandatory=$true)][string]$Database,
        [Parameter(Mandatory=$true)][string]$LogPath,
        [string]$ExtraArgs = "",
        [switch]$AllowErrors
    )

    if (!(Test-Path $SqlFilePath)) {
        $msg = "SQL file not found: $SqlFilePath"
        Log-DB-Err $msg
        $script:FailCount++
        $script:Results += [PSCustomObject]@{
            Status   = "FAIL"
            Script   = (Split-Path $SqlFilePath -Leaf)
            Duration = "0s"
            Message  = "File not found"
        }
        return
    }

    $scriptName = Split-Path $SqlFilePath -Leaf
    $startTime  = Get-Date
    Log-DB "  --> $scriptName  (db=$Database  user=$User)"

    $prevEAP = $ErrorActionPreference
    $ErrorActionPreference = "Continue"

    $cmdArgs = @("-h", $hostnm, "-p", "$port", "-d", $Database, "-U", $User, "-f", $SqlFilePath, "-L", $LogPath)
    if ($ExtraArgs) {
        $cmdArgs += ($ExtraArgs -split " ")
    }

    $output = & $PSQL_EXE $cmdArgs 2>&1
    $exitCode = $LASTEXITCODE
    $ErrorActionPreference = $prevEAP

    $elapsed = [math]::Round(((Get-Date) - $startTime).TotalSeconds, 1)

    if ($output) {
        foreach ($ol in $output) {
            Write-SummaryLog ("         | " + $ol)
        }
    }

    if ($exitCode -ne 0) {
        Log-DB-Warn "  <-- WARN (exit=$exitCode): $scriptName  (${elapsed}s)"
        $script:FailCount++
        $script:Results += [PSCustomObject]@{
            Status   = "WARN"
            Script   = $scriptName
            Duration = "${elapsed}s"
            Message  = "exit $exitCode"
        }
    } else {
        Log-DB-Ok "  <-- OK : $scriptName  (${elapsed}s)"
        $script:PassCount++
        $script:Results += [PSCustomObject]@{
            Status   = "OK"
            Script   = $scriptName
            Duration = "${elapsed}s"
            Message  = ""
        }
    }
}

function Run-PsqlFolder {
    param(
        [Parameter(Mandatory=$true)][string]$FolderPath,
        [Parameter(Mandatory=$true)][string]$User,
        [Parameter(Mandatory=$true)][string]$LogName,
        [switch]$AllowErrors
    )

    $folderName = Split-Path $FolderPath -Leaf

    if (!(Test-Path $FolderPath)) {
        return
    }

    $sqlFiles = Get-ChildItem -Path $FolderPath -Filter *.sql | Sort-Object Name
    if ($sqlFiles.Count -eq 0) {
        return
    }

    Log-DB "  Subfolder : $folderName  ($($sqlFiles.Count) file(s))"
    $logPath = Reset-Log $LogName

    foreach ($f in $sqlFiles) {
        Run-PsqlFile -SqlFilePath $f.FullName -User $User -Database $dbname -LogPath $logPath -AllowErrors:$AllowErrors
    }
}

# ==============================================================================
# Main Overlay Execution Loop (Direct conversion of az_exec.sh)
# ==============================================================================
$defaultFolderList = @(
    "1_Golden_copy_V1",
    "2_Transformation_enhancement",
    "3_Report_filter_enhancement",
    "4_Bug_fixes",
    "5_AI_create_db",
    "6_V_Airflow",
    "7_V_SSO",
    "8_AI_reconcile",
    "10_Multi_cloud_storage",
    "12_Airflow_bugfixes",
    "13_Airflow_external_source"
)

if ($DbFolders) {
    $folderList = $DbFolders -split "," | ForEach-Object { $_.Trim() } | Where-Object { $_ }
    Log-DB-Warn "DB_FOLDERS override active - running a SUBSET of overlay folders: $($folderList -join ', ')"
    Log-DB-Warn "This is a partial run, not a full install - only use this when you specifically know these folders are enough (e.g. re-applying one release's changes on top of an already-built database)."
} else {
    $folderList = $defaultFolderList
}

$roleMap = [ordered]@{
    "recon_master"           = "usr_dr_mstr_rw"
    "recon_admin"            = "usr_dr_admin_rw"
    "recon_admin_functions"  = "usr_dr_admin_rw"
    "recon_meta"             = "usr_dr_meta_rw"
    "recon_meta_functions"   = "usr_dr_meta_rw"
    "recon_data"             = "usr_dr_data_rw"
    "recon_data_functions"   = "usr_dr_data_rw"
    "recon_audit"            = "usr_dr_audit_rw"
    "recon_audit_functions"  = "usr_dr_audit_rw"
    "recon_admin_views"      = "usr_dr_admin_rw"
    "recon_meta_views"       = "usr_dr_meta_rw"
    "recon_data_views"       = "usr_dr_data_rw"
    "recon_audit_views"      = "usr_dr_audit_rw"
    "recon_ai"               = "usr_dr_ai_rw"
}

Log-DB-Step "Executing Database Setup Across All Folders"

foreach ($dir in $folderList) {
    $dirPath = Join-Path $DBROOT $dir
    if (!(Test-Path $dirPath)) {
        Log-DB-Warn "Directory $dir does not exist at $dirPath - skipping."
        continue
    }

    Log-DB-Step "Processing Folder: $dir"

    # 1. create_db scripts
    $createDbDir = Join-Path $dirPath "create_db"
    if (Test-Path $createDbDir) {
        $cLog = Reset-Log ($dir + "_create_db.log")
        $f02 = Join-Path $createDbDir "02_create_database_dataRecon.sql"
        if (Test-Path $f02) {
            Run-PsqlFile -SqlFilePath $f02 -User "postgres" -Database "postgres" -LogPath $cLog -AllowErrors
        }

        $f03 = Join-Path $createDbDir "03_create_schema.sql"
        if (Test-Path $f03) {
            Run-PsqlFile -SqlFilePath $f03 -User "postgres" -Database $dbname -LogPath $cLog -AllowErrors
        }

        $f04 = Join-Path $createDbDir "04_create_db_users_dataRecon.sql"
        if (Test-Path $f04) {
            Run-PsqlFile -SqlFilePath $f04 -User "postgres" -Database $dbname -LogPath $cLog -ExtraArgs "-v ss=$RolePassword" -AllowErrors
        }

        # Explicitly ensure all required application roles have LOGIN attribute and the configured -RolePassword
        #
        # The dollar-quote delimiter here MUST be two literal $ characters
        # with nothing between them ("$$"). In a PowerShell double-quoted
        # string that requires two separately-escaped dollars: `$`$ - NOT
        # `$\$` (a single escaped $, a literal backslash, then a bare $).
        # The backslash version sends Postgres `DO $\$ BEGIN ... END $\$;`,
        # which fails to parse as a dollar-quote tag at all - found live via
        # "ERROR: syntax error at or near "$"" on 1_Golden_copy_V1.
        # DECLARE r record; is mandatory, not stylistic - this Postgres 16.2
        # build does not implicitly infer the loop variable as a record for
        # a bare `FOR r IN SELECT ... LOOP` with no DECLARE section, and
        # fails at parse time with "loop variable of loop over rows must be
        # a record variable or list of scalar variables" - found live,
        # reproduced directly against this exact database. This was hidden
        # behind the dollar-quote escaping bug above until that was fixed;
        # fixing one revealed the other.
        # Single quotes doubled for the SQL literal. format()'s %L quotes
        # the VALUE, but the value itself is written into this string
        # first, so an apostrophe in the password would close the literal
        # early and produce a syntax error - or, worse, parse as SQL.
        $rolePwSql = $RolePassword.Replace("'", "''")
        $roleFixSql = "DO `$`$ DECLARE r record; BEGIN FOR r IN SELECT unnest(ARRAY['usr_dr_mstr_rw','usr_dr_admin_rw','usr_dr_meta_rw','usr_dr_data_rw','usr_dr_audit_rw','usr_dr_ai_rw','usr_dr_air_rw','dr_mstr_srvc','dr_mgrtn_srvc','sqladminuser']) AS r_name LOOP IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = r.r_name) THEN EXECUTE format('ALTER ROLE %I WITH LOGIN PASSWORD %L', r.r_name, '$rolePwSql'); ELSE EXECUTE format('CREATE ROLE %I WITH LOGIN PASSWORD %L', r.r_name, '$rolePwSql'); END IF; END LOOP; END `$`$;"
        $prevRoleFixEAP = $ErrorActionPreference
        $ErrorActionPreference = "Continue"
        $roleFixOutput = & $PSQL_EXE -h $hostnm -p "$port" -d $dbname -U "postgres" -c $roleFixSql 2>&1
        $roleFixExit = $LASTEXITCODE
        $ErrorActionPreference = $prevRoleFixEAP
        if ($roleFixExit -eq 0) {
            Log-DB-Ok "  Application role LOGIN/password fix-up applied."
        } else {
            Log-DB-Warn "  Application role LOGIN/password fix-up failed (exit $roleFixExit): $($roleFixOutput -join ' ')"
        }

        $f05 = Join-Path $createDbDir "05_create_extension_tablefunc.sql"
        if (Test-Path $f05) {
            Run-PsqlFile -SqlFilePath $f05 -User "postgres" -Database $dbname -LogPath $cLog -AllowErrors
        }

        $f06 = Join-Path $createDbDir "06_grant_permissions.sql"
        if (Test-Path $f06) {
            Run-PsqlFile -SqlFilePath $f06 -User "postgres" -Database $dbname -LogPath $cLog -AllowErrors
        }
    }

    # 2. Schema Object Folders (recon_master, recon_admin, recon_meta, recon_data, recon_audit, views, recon_ai)
    foreach ($sub in $roleMap.Keys) {
        $subPath = Join-Path $dirPath $sub
        if (Test-Path $subPath) {
            Run-PsqlFolder -FolderPath $subPath -User $roleMap[$sub] -LogName ($dir + "_" + $sub + ".log") -AllowErrors:$true
        }
    }


    # 4. Repeat Grant Permissions at the end of the folder
    if (Test-Path $createDbDir) {
        $f06 = Join-Path $createDbDir "06_grant_permissions.sql"
        if (Test-Path $f06) {
            $cLog = Reset-Log ($dir + "_create_db_final_grant.log")
            Run-PsqlFile -SqlFilePath $f06 -User "postgres" -Database $dbname -LogPath $cLog -AllowErrors:$true
        }
    }
}

# ==============================================================================
# Final Summary
# ==============================================================================
Log-DB-Step "Summary"

$_hdr = "=" * 70
Write-SummaryLog ""
Write-SummaryLog $_hdr
Write-SummaryLog "  DATABASE SETUP RESULTS"
Write-SummaryLog ("  Completed : " + (Get-Date -Format "yyyy-MM-dd HH:mm:ss"))
Write-SummaryLog ("  Passed    : " + $script:PassCount)
Write-SummaryLog ("  Failed    : " + $script:FailCount)
Write-SummaryLog ("  Skipped   : " + $script:SkipCount)
Write-SummaryLog $_hdr
Write-SummaryLog ""
Write-SummaryLog ("{0,-14} {1,-52} {2,-10} {3}" -f "STATUS", "SCRIPT", "DURATION", "NOTE")
Write-SummaryLog ("-" * 70)
foreach ($r in $script:Results) {
    Write-SummaryLog ("{0,-14} {1,-52} {2,-10} {3}" -f $r.Status, $r.Script, $r.Duration, $r.Message)
}
Write-SummaryLog ""
Write-SummaryLog "  Summary log : $SUMMARY_LOG"
Write-SummaryLog "  Detail logs : $LOG_DIR"
Write-SummaryLog $_hdr

# Print summary to console
Write-Host ""
Write-Host ("=" * 70) -ForegroundColor DarkCyan
Write-Host "  DATABASE SETUP RESULTS" -ForegroundColor DarkCyan
Write-Host ("=" * 70) -ForegroundColor DarkCyan
Write-Host ("  Passed  : " + $script:PassCount)  -ForegroundColor Green
$failColor = if ($script:FailCount -gt 0) { "Red" } else { "Green" }
Write-Host ("  Failed  : " + $script:FailCount)  -ForegroundColor $failColor
Write-Host ("  Skipped : " + $script:SkipCount)  -ForegroundColor Yellow
Write-Host ""
Write-Host ("{0,-14} {1,-52} {2,-10} {3}" -f "STATUS", "SCRIPT", "DURATION", "NOTE")
Write-Host ("-" * 70)
foreach ($r in $script:Results) {
    $color = switch -Wildcard ($r.Status) {
        "OK*"    { "Green"  }
        "SKIP"   { "Yellow" }
        "FAIL"   { "Red"    }
        default  { "White"  }
    }
    Write-Host ("{0,-14} {1,-52} {2,-10} {3}" -f $r.Status, $r.Script, $r.Duration, $r.Message) -ForegroundColor $color
}
Write-Host ""
Write-Host "  Summary log : $SUMMARY_LOG" -ForegroundColor Cyan
Write-Host "  Detail logs : $LOG_DIR"     -ForegroundColor Cyan
Write-Host ("=" * 70) -ForegroundColor DarkCyan

if ($script:FailCount -gt 0) {
    exit 1
} else {
    exit 0
}
