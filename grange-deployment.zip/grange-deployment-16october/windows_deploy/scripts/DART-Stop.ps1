# ===========================================================================
#  DART-Stop.ps1
#  Stops all DART services in the correct order:
#    1. Airflow  (WSL2 standalone)
#    2. FastAPI  (AI Auto Draft)
#    3. Uvicorn  (Django backend - Python)
#    4. Nginx    (Reverse proxy)
#    5. PostgreSQL
# ===========================================================================
param(
    [string]$ConfigFile = ""
)

# TOOLS_ROOT read from dart_deploy_config.json - see DART-Start.ps1 for why
# (consistency with the other two scripts; this one happened to already
# have the correct hardcoded value, but keeping it config-driven avoids the
# same class of drift if TOOLS_ROOT is ever reconfigured).
$_scriptDir = if ($PSScriptRoot) { $PSScriptRoot } else { (Get-Location).Path }
$cfgPath = if ($ConfigFile -and (Test-Path $ConfigFile)) { $ConfigFile } else { Join-Path $_scriptDir "dart_deploy_config.json" }
$cfg = $null
if (Test-Path $cfgPath) {
    try { $cfg = Get-Content $cfgPath -Raw -Encoding UTF8 | ConvertFrom-Json } catch { }
}
function Get-Cfg($key, $default) {
    if ($cfg -and $cfg.PSObject.Properties.Name -contains $key -and $cfg.$key) { return $cfg.$key }
    return $default
}

$TOOLS_ROOT   = Get-Cfg "TOOLS_ROOT"   "C:\DART_Tools"
# Needed by the Uvicorn worker cleanup below, which identifies our processes
# by executable path. Defined explicitly: without it the path test degrades to
# "*", which would match EVERY python process on the machine, not just this
# deployment's.
$INSTALL_ROOT = Get-Cfg "INSTALL_ROOT" "C:\DART_DEPLOY"
$BACKEND_DIR  = "$INSTALL_ROOT\backend\Data_Recon_Backend"
$PG_BIN       = "$TOOLS_ROOT\postgres\bin"
$PG_DATA      = "$TOOLS_ROOT\postgres\data"
$NGINX_ROOT   = "$TOOLS_ROOT\nginx"
$FASTAPI_PORT = Get-Cfg "FASTAPI_PORT" "5000"
$AIRFLOW_PORT = Get-Cfg "AIRFLOW_PORT" "8080"
$WSL_DISTRO   = Get-Cfg "WSL_DISTRO"   "Ubuntu-24.04"

function Write-Step  ($msg) { Write-Host "`n[$(Get-Date -Format 'HH:mm:ss')] >>> $msg" -ForegroundColor Cyan }
function Write-OK    ($msg) { Write-Host "[$(Get-Date -Format 'HH:mm:ss')] [OK]   $msg" -ForegroundColor Green }
function Write-WARN  ($msg) { Write-Host "[$(Get-Date -Format 'HH:mm:ss')] [WARN] $msg" -ForegroundColor Yellow }
function Write-FAIL  ($msg) { Write-Host "[$(Get-Date -Format 'HH:mm:ss')] [FAIL] $msg" -ForegroundColor Red }
function Write-INFO  ($msg) { Write-Host "[$(Get-Date -Format 'HH:mm:ss')] [INFO] $msg" -ForegroundColor Gray }

Write-Host ""
Write-Host "==========================================" -ForegroundColor DarkCyan
Write-Host "   DART  -  Stop All Services" -ForegroundColor Cyan
Write-Host "   $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')" -ForegroundColor DarkGray
Write-Host "==========================================" -ForegroundColor DarkCyan

# ---------------------------------------------------------------------------
# 1. Stop Apache Airflow (WSL2 standalone)
# ---------------------------------------------------------------------------
Write-Step "Stopping Airflow (port $AIRFLOW_PORT)"

# If DART-Start.ps1 launched this via a Scheduled Task (2026-09-04, so it
# survives RDP disconnect/logoff), stop the task's own bookkeeping first -
# harmless no-op if it wasn't started that way, or isn't registered at all.
# The actual kill below (wsl pkill) is what really matters either way.
if (Get-ScheduledTask -TaskName "DART-Airflow" -ErrorAction SilentlyContinue) {
    Stop-ScheduledTask    -TaskName "DART-Airflow" -ErrorAction SilentlyContinue
    Disable-ScheduledTask -TaskName "DART-Airflow" -ErrorAction SilentlyContinue | Out-Null
}

# Timeout-guarded via a background job - found live (this same session,
# multiple times) that a `wsl` invocation can hang indefinitely with zero
# further output if the shared WSL2 VM is busy or contended.
#
# -d $WSL_DISTRO on every call. These used to run `wsl bash -c ...` with no
# distro, i.e. in the machine's DEFAULT distro - when that was not the one
# Airflow lives in, pgrep/pkill looked in the wrong place, Airflow kept
# running, and the next DART-Start's setup hung on its database sessions.
# Found live 2026-10-14.
#
# '[a]irflow', not 'airflow': `pkill -f airflow` also matches the very
# `bash -c "pkill -f airflow"` running it and killed its own shell.
function Invoke-AfWsl([string]$Cmd, [int]$TimeoutSec = 15) {
    # --exec: run bash directly. Without it wsl hands the joined command line
    # to the distro's login shell, which parses it a second time - a ';' loop
    # then dies with a syntax error, hidden by 2>$null. Found live 2026-10-16:
    # DART-Stop's TERM/KILL never ran and Airflow survived every stop.
    $j = Start-Job -ScriptBlock { param($d, $c) & wsl -d $d -u root --exec bash -c $c 2>$null } -ArgumentList $WSL_DISTRO, $Cmd
    $out = if (Wait-Job $j -Timeout $TimeoutSec) { Receive-Job $j } else { Stop-Job $j -ErrorAction SilentlyContinue | Out-Null; $null }
    Remove-Job $j -Force -ErrorAction SilentlyContinue
    return (($out | Out-String) -replace "`0", "" -replace "`r", "").Trim()
}

$afActive   = Get-NetTCPConnection -LocalPort ([int]$AIRFLOW_PORT) -State Listen -ErrorAction SilentlyContinue
$afPgrepOut = Invoke-AfWsl "pgrep -f '[a]irflow' || true" 10

if ($afActive -or $afPgrepOut) {
    # airflow standalone runs several child processes (api-server,
    # scheduler, dag-processor, triggerer) inside WSL2, not one PID Windows
    # can see, so stop them by name inside the distro. SIGTERM first so they
    # close their Postgres sessions cleanly, SIGKILL whatever is left after 20s.
    Invoke-AfWsl "pkill -TERM -f '[a]irflow'; for i in `$(seq 1 20); do pgrep -f '[a]irflow' >/dev/null || exit 0; sleep 1; done; pkill -KILL -f '[a]irflow'; exit 0" 40 | Out-Null
    Start-Sleep -Seconds 2

    # Verify on the processes, not only the Windows port - with WSL2
    # localhost forwarding the port can look closed while Airflow still runs.
    $afLeft  = Invoke-AfWsl "pgrep -af '[a]irflow' || true" 10
    $afCheck = Get-NetTCPConnection -LocalPort ([int]$AIRFLOW_PORT) -State Listen -ErrorAction SilentlyContinue
    if (-not $afLeft -and -not $afCheck) {
        Write-OK "Airflow stopped (WSL2 distro: $WSL_DISTRO)."
    } else {
        Write-WARN "Airflow may still be running in $WSL_DISTRO$(if ($afCheck) { " (port $AIRFLOW_PORT still active)" }):"
        $afLeft -split "`n" | Where-Object { $_ } | Select-Object -First 6 | ForEach-Object { Write-WARN "    $($_.Substring(0, [Math]::Min(110, $_.Length)))" }
        Write-WARN "  Stop it by hand:  wsl -d $WSL_DISTRO -u root --exec pkill -KILL -f '[a]irflow'"
        Write-WARN "  or shut the whole distro down:  wsl --terminate $WSL_DISTRO"
    }
} else {
    Write-WARN "Airflow was not running (WSL2 distro: $WSL_DISTRO)."
}

# ---------------------------------------------------------------------------
# 2. Stop FastAPI (AI Auto Draft, port $FASTAPI_PORT)
# ---------------------------------------------------------------------------
Write-Step "Stopping FastAPI (port $FASTAPI_PORT)"

if (Get-ScheduledTask -TaskName "DART-FastAPI" -ErrorAction SilentlyContinue) {
    Stop-ScheduledTask    -TaskName "DART-FastAPI" -ErrorAction SilentlyContinue
    Disable-ScheduledTask -TaskName "DART-FastAPI" -ErrorAction SilentlyContinue | Out-Null
}

$faConn = Get-NetTCPConnection -LocalPort ([int]$FASTAPI_PORT) -State Listen -ErrorAction SilentlyContinue
if ($faConn) {
    $faConn.OwningProcess | Select-Object -Unique | ForEach-Object {
        Stop-Process -Id $_ -Force -ErrorAction SilentlyContinue
    }
    Start-Sleep -Seconds 1
    $faCheck = Get-NetTCPConnection -LocalPort ([int]$FASTAPI_PORT) -State Listen -ErrorAction SilentlyContinue
    if (-not $faCheck) { Write-OK "FastAPI stopped." }
    else                { Write-WARN "FastAPI may still be running (port $FASTAPI_PORT still active)." }
} else {
    Write-WARN "FastAPI was not running."
}

# ---------------------------------------------------------------------------
# 3. Stop Uvicorn (Python / Django backend on port 8000)
# ---------------------------------------------------------------------------
Write-Step "Stopping Uvicorn (port 8000)"

# DISABLE, not just stop.
#
# The task is registered with -RestartCount 3 -RestartInterval 1 minute, so
# Task Scheduler treats a killed process as a FAILURE and starts it again.
# Stop-ScheduledTask ends the current instance but leaves that policy armed -
# so every kill was followed by a resurrection, the port never freed, and it
# looked like the process could not be killed at all. Found live 2026-09-10
# after repeated stop/start cycles left port 8000 permanently occupied.
#
# DART-Start.ps1 re-enables the task before starting it.
if (Get-ScheduledTask -TaskName "DART-Uvicorn" -ErrorAction SilentlyContinue) {
    Stop-ScheduledTask    -TaskName "DART-Uvicorn" -ErrorAction SilentlyContinue
    Disable-ScheduledTask -TaskName "DART-Uvicorn" -ErrorAction SilentlyContinue | Out-Null
    Write-INFO "Scheduled task 'DART-Uvicorn' stopped and disabled (its restart policy would otherwise relaunch it)."
}

$uvConn = Get-NetTCPConnection -LocalPort 8000 -State Listen -ErrorAction SilentlyContinue
if ($uvConn) {
    $targetPid = $uvConn.OwningProcess
    Stop-Process -Id $targetPid -Force -ErrorAction SilentlyContinue
    Write-OK "Killed process PID $targetPid listening on port 8000."
} else {
    Write-WARN "Nothing was listening on port 8000."
}

# Kill any remaining Python processes running uvicorn (reloader workers).
#
# Matches python* (so pythonw.exe is included, not just python.exe) and
# identifies them by EXECUTABLE PATH as well as command line: a process
# launched from the backend venv is ours regardless of how its command line
# reads. -Name python alone missed processes that were still holding a
# duplicated handle to the listening socket, which is how port 8000 stayed
# occupied by an owner PID that no longer existed - for 40s+, well past any
# normal socket drain (seen live 2026-09-10).
$pyProcs = Get-Process -Name python*, uvicorn* -ErrorAction SilentlyContinue
if ($pyProcs) {
    foreach ($p in $pyProcs) {
        $cmdLine = (Get-CimInstance Win32_Process -Filter "ProcessId=$($p.Id)" -ErrorAction SilentlyContinue).CommandLine
        $exePath = $null
        try { $exePath = $p.Path } catch { }
        $isOurs = ($cmdLine -like "*uvicorn*") -or
                  ($cmdLine -like "*Data_Recon*") -or
                  ($exePath -and $exePath -like "$BACKEND_DIR*")
        if ($isOurs) {
            Stop-Process -Id $p.Id -Force -ErrorAction SilentlyContinue
            Write-OK "Killed Uvicorn worker PID $($p.Id) ($($p.ProcessName))."
        }
    }
}

Start-Sleep -Seconds 1
$check = Get-NetTCPConnection -LocalPort 8000 -State Listen -ErrorAction SilentlyContinue

# Escalate rather than just reporting the failure.
#
# Uvicorn runs with --reload, which means a reloader parent AND a worker
# child. Stop-Process -Id kills one; whichever survives keeps the socket. The
# old code warned "still in use" and stopped there - and DART-Start.ps1 then
# saw the port occupied and skipped launching Uvicorn, so Django carried on
# running with the PREVIOUS .env. That is indistinguishable from "the config
# change did not apply", and cost real debugging time on 2026-09-09 and again
# on 2026-09-10.
#
# taskkill /T kills the whole process tree, which is what --reload needs.
if ($check) {
    # Poll, do not check once.
    #
    # A listening socket is not released the instant its process dies -
    # Windows keeps reporting the old OwningProcess for a few seconds while
    # the socket drains, and uvicorn --reload makes that more likely because
    # a child inherits the listening handle. Checking once after 2s reported
    # "STILL held by PID N" for a PID that taskkill had just said did not
    # exist - a scary-looking failure for a port that was about to free
    # itself. Seen live 2026-09-10.
    #
    # Each pass re-reads the owner and only kills a process that is actually
    # alive, so a genuinely stuck holder (or a different process that grabbed
    # the port) is still dealt with.
    Write-WARN "Port 8000 still held after the first stop - waiting for it to release..."
    $spent = 0
    while ($spent -lt 20) {
        $check = Get-NetTCPConnection -LocalPort 8000 -State Listen -ErrorAction SilentlyContinue
        if (-not $check) { break }
        foreach ($holdPid in ($check.OwningProcess | Select-Object -Unique)) {
            if (Get-Process -Id $holdPid -ErrorAction SilentlyContinue) {
                Write-INFO "  PID $holdPid is still alive - taskkill /PID $holdPid /T /F"
                & taskkill /PID $holdPid /T /F 2>&1 | ForEach-Object { Write-INFO "    $_" }
            }
        }
        Start-Sleep -Seconds 2
        $spent += 2
        if ($spent % 6 -eq 0) { Write-INFO "  ...still draining (${spent}s)" }
    }
    $check = Get-NetTCPConnection -LocalPort 8000 -State Listen -ErrorAction SilentlyContinue
}

if (-not $check) {
    Write-OK "Port 8000 is now free."
} else {
    $stillPid  = ($check.OwningProcess | Select-Object -First 1)
    $stillProc = Get-Process -Id $stillPid -ErrorAction SilentlyContinue
    if ($stillProc) {
        Write-FAIL "Port 8000 is STILL held by a LIVE process: PID $stillPid ($($stillProc.ProcessName))."
        Write-WARN "  DART-Start.ps1 will skip launching Uvicorn while this port is occupied, so the backend"
        Write-WARN "  would keep running with its previous environment. Investigate before starting:"
        Write-WARN "    Get-Process -Id $stillPid | Format-List Name,Path,StartTime"
    } else {
        # Owner gone but the socket persists. Get-NetTCPConnection's
        # OwningProcess can be STALE - it kept reporting a long-dead PID while
        # a different, still-running Python process was actually serving the
        # port (confirmed 2026-09-10: reported owner 8656 did not exist, while
        # PID 8472 from hours earlier was answering HTTP on 8000).
        #
        # So do not trust the reported owner here. Kill any Python process
        # belonging to THIS deployment - identified by executable path under
        # the install or tools root, which covers both the backend venv and the
        # portable Python - then re-check.
        Write-WARN "Reported owner PID $stillPid does not exist - the reported owner is stale. Looking for the real holder..."
        $suspects = Get-Process python*, pythonw*, uvicorn* -ErrorAction SilentlyContinue |
                    Where-Object {
                        $p = $null; try { $p = $_.Path } catch { }
                        $p -and ($p -like "$INSTALL_ROOT*" -or $p -like "$TOOLS_ROOT*")
                    }
        if ($suspects) {
            foreach ($s in $suspects) {
                Write-INFO "  Killing $($s.ProcessName) PID $($s.Id)  (started $($s.StartTime))  $($s.Path)"
                & taskkill /PID $s.Id /T /F 2>&1 | ForEach-Object { Write-INFO "    $_" }
            }
            Start-Sleep -Seconds 3
            $check = Get-NetTCPConnection -LocalPort 8000 -State Listen -ErrorAction SilentlyContinue
        } else {
            Write-WARN "  No Python process under $INSTALL_ROOT or $TOOLS_ROOT is running."
        }

        # NOT `return` - this runs at script scope, so returning here would
        # abandon the rest of DART-Stop and leave Nginx and PostgreSQL running.
        if (-not $check) {
            Write-OK "Port 8000 released after killing the real holder."
        } else {
            Write-WARN "Port 8000 still shows PID $stillPid, but that process no longer exists."
            Write-WARN "  The socket has outlived its owner, so another process is holding a duplicated handle to it."
            Write-WARN "  Find it:"
            Write-WARN "    netstat -ano | findstr `":8000`""
            Write-WARN "    Get-Process python*,pythonw* | Format-List Id,ProcessName,Path,StartTime"
            Write-WARN "  DART-Start.ps1 will SKIP Uvicorn while this port is held, leaving the backend on its old"
            Write-WARN "  environment. If nothing obvious owns it, a reboot clears it definitively (the password"
            Write-WARN "  and the ALB target registration both survive a restart)."
        }
    }
}

# ---------------------------------------------------------------------------
# 4. Stop Nginx
# ---------------------------------------------------------------------------
Write-Step "Stopping Nginx"

$ngxProcs = Get-Process -Name nginx -ErrorAction SilentlyContinue
if ($ngxProcs) {
    # Graceful stop via nginx signal
    Push-Location $NGINX_ROOT
    & .\nginx.exe -s stop 2>&1 | Out-Null
    Pop-Location
    Start-Sleep -Seconds 2

    # Force kill anything still running
    Get-Process -Name nginx -ErrorAction SilentlyContinue |
        Stop-Process -Force -ErrorAction SilentlyContinue

    # Clean up stale PID file
    $pidFile = "$NGINX_ROOT\logs\nginx.pid"
    if (Test-Path $pidFile) { Remove-Item $pidFile -Force }

    Write-OK "Nginx stopped."
} else {
    Write-WARN "Nginx was not running."
}

# ---------------------------------------------------------------------------
# 5. Stop PostgreSQL
# ---------------------------------------------------------------------------
Write-Step "Stopping PostgreSQL"

$pgCtl    = "$PG_BIN\pg_ctl.exe"
$pgActive = Get-NetTCPConnection -LocalPort 5432 -State Listen -ErrorAction SilentlyContinue

if (-not $pgActive) {
    Write-WARN "PostgreSQL was not running (port 5432 not active)."
} elseif (Test-Path $pgCtl) {
    Write-INFO "Running pg_ctl stop (fast mode)..."
    $prevEAP = $ErrorActionPreference
    $ErrorActionPreference = "Continue"
    & $pgCtl stop -D $PG_DATA -m fast 2>&1 | ForEach-Object { Write-INFO "  $_" }
    $ErrorActionPreference = $prevEAP

    Start-Sleep -Seconds 3
    $pgCheck = Get-NetTCPConnection -LocalPort 5432 -State Listen -ErrorAction SilentlyContinue
    if (-not $pgCheck) { Write-OK "PostgreSQL stopped." }
    else               { Write-WARN "PostgreSQL may still be running (port 5432 still active)." }
} else {
    Write-FAIL "pg_ctl.exe not found at $pgCtl"
}

# ---------------------------------------------------------------------------
# Summary
# ---------------------------------------------------------------------------
Write-Host ""
Write-Host "==========================================" -ForegroundColor DarkCyan
Write-Host "   All DART services stopped." -ForegroundColor Green
Write-Host "==========================================" -ForegroundColor DarkCyan
Write-Host ""
