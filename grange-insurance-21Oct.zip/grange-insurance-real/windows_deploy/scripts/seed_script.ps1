# ──────────────────────────────────────────────
# Configuration – override via params (the main deploy script passes these
# in from dart_deploy_config.json so this stays aligned with the actual
# deployment instead of drifting from its own hardcoded defaults), or just
# run standalone with the defaults below for a local smoke test.
# ──────────────────────────────────────────────
param(
    [string]$BaseUrl   = "http://localhost:8000",
    [string]$Email     = "recon@admin.com",
    [string]$Password  = "recon@123",
    [string]$MediaPath = ""
)

# MEDIA_PATH resolution order: -MediaPath param -> $env:MEDIA_PATH -> a
# correct Windows default. The old default here was "/app/Recon_Files" (no
# drive letter) - on Windows that resolves relative to whatever the current
# drive happens to be via an implicit path-resolution quirk, not a real,
# explicit path. It happened to still work (Django has the same quirk, so
# both landed on the same accidental location), but relying on that was
# fragile. dart_deploy_config.json's MEDIA_PATH is now the explicit,
# unambiguous "C:/app/Recon_Files" - same real location, just no longer
# accidental.
if (-not $MediaPath) {
    if ($env:MEDIA_PATH) {
        $MediaPath = $env:MEDIA_PATH
    } elseif (Test-Path (Join-Path $PSScriptRoot "..\media")) {
        $MediaPath = (Resolve-Path (Join-Path $PSScriptRoot "..")).Path
    } else {
        $MediaPath = "C:/app/Recon_Files"
    }
}
$MediaRoot = Join-Path $MediaPath "media"

# ──────────────────────────────────────────────
# Helper function to handle API responses
# ──────────────────────────────────────────────
function Invoke-ApiResponse {
    param (
        [Parameter(Mandatory=$true)]
        [string]$Label,
        [Parameter(Mandatory=$true)]
        [string]$Method,
        [Parameter(Mandatory=$true)]
        [string]$Uri,
        [hashtable]$Headers = @{},
        [object]$Body = $null,
        [hashtable]$Form = $null,
        [int[]]$SuccessCodes = @(200, 409) # 409 often means already exists
    )

    $params = @{
        Uri = $Uri
        Method = $Method
        Headers = $Headers
    }

    if ($Body) {
        $params.Body = $Body | ConvertTo-Json -Depth 20
        $params.ContentType = "application/json"
    } elseif ($Form) {
        if ($PSVersionTable.PSVersion.Major -ge 6) {
            $params.Form = $Form
        } else {
            # Manual Multipart construction for PowerShell 5.1 compatibility
            $boundary = [System.Guid]::NewGuid().ToString()
            $LF = "`r`n"
            $encoding = [System.Text.Encoding]::GetEncoding("iso-8859-1")
            $outputStream = New-Object System.IO.MemoryStream
            $writer = New-Object System.IO.StreamWriter($outputStream, $encoding)

            foreach ($entry in $Form.GetEnumerator()) {
                $key = $entry.Key
                $value = $entry.Value
                $writer.Write("--$boundary$LF")
                if ($value -is [System.IO.FileInfo]) {
                    $writer.Write("Content-Disposition: form-data; name=`"$key`"; filename=`"$($value.Name)`"$LF")
                    $writer.Write("Content-Type: application/octet-stream$LF$LF")
                    $writer.Flush()
                    $fileStream = [System.IO.File]::OpenRead($value.FullName)
                    $fileStream.CopyTo($outputStream)
                    $fileStream.Close()
                    $writer.Write($LF)
                } else {
                    $writer.Write("Content-Disposition: form-data; name=`"$key`"$LF$LF")
                    $writer.Write("$value$LF")
                }
            }
            $writer.Write("--$boundary--$LF")
            $writer.Flush()
            $params.Body = $outputStream.ToArray()
            $params.ContentType = "multipart/form-data; boundary=$boundary"
            $writer.Dispose()
        }
    }

    Write-Host "Calling : $Method $Uri" -ForegroundColor Gray
    try {
        $response = Invoke-WebRequest @params -UseBasicParsing -ErrorAction Stop
        $statusCode = [int]$response.StatusCode
        $content = $response.Content
        
        Write-Host "Step    : $Label" -ForegroundColor Cyan
        Write-Host "Status  : $statusCode"
        Write-Host "Response: $content"
        
        if ($statusCode -in $SuccessCodes) {
            Write-Host "[OK] $Label succeeded." -ForegroundColor Green
            return $content | ConvertFrom-Json
        } else {
            Write-Error "[ERROR] $Label failed with status $statusCode."
            exit 1
        }
    } catch {
        $statusCode = "N/A"
        if ($_.Exception.Response) {
            try { $statusCode = [int]$_.Exception.Response.StatusCode } catch { }
        }

        $content = $_.ErrorDetails.Message
        if (!$content) {
            if ($_.Exception.Response) {
                try {
                    $reader = New-Object System.IO.StreamReader($_.Exception.Response.GetResponseStream())
                    $content = $reader.ReadToEnd()
                    $reader.Close()
                } catch { $content = $_.Exception.Message }
            } else {
                $content = $_.Exception.Message
            }
        }

        Write-Host "Step: $Label" -ForegroundColor Cyan
        Write-Host "Status  : $statusCode"
        Write-Host "Response: $content"

        if ($statusCode -ne "N/A" -and $statusCode -in $SuccessCodes) {
            Write-Host "[OK] $Label succeeded (Status $statusCode handled)." -ForegroundColor Yellow
            try { return $content | ConvertFrom-Json } catch { return $null }
        } else {
            Write-Host "[ERROR] $Label failed with status $statusCode." -ForegroundColor Red
            exit 1
        }
    }
}

# ──────────────────────────────────────────────
# Step 1: Authenticate
# ──────────────────────────────────────────────
Write-Host "Authenticating..." -ForegroundColor Magenta
$AuthPayload = @{
    email = $Email
    password = $Password
}

$AuthResult = Invoke-ApiResponse -Label "Authenticate" -Method Post -Uri "$BaseUrl/recon_security/auth_user" -Body $AuthPayload
$Token = $AuthResult.data.accessToken

if (-not $Token -or $Token -eq "null") {
    Write-Error "[ERROR] Failed to retrieve access token. Check your credentials."
    exit 1
}

Write-Host "[OK] Token obtained successfully." -ForegroundColor Green
$AuthHeaders = @{
    Authorization = "Bearer $Token"
}

# ──────────────────────────────────────────────
# Step 2: Assign Member
# ──────────────────────────────────────────────
$AssignPayload = @{
    user = "Admin"
    username = "Admin"
    grant = "true"
    req_level = "account"
}
Invoke-ApiResponse -Label "Assign Member" -Method Post -Uri "$BaseUrl/recon_security/assign_member" -Headers $AuthHeaders -Body $AssignPayload

# ──────────────────────────────────────────────
# Step 3: Create Role
# ──────────────────────────────────────────────
$RolePayload = @{
    req_actn = "a"
    role_name_new = "all_roles"
    role_name_old = ""
    role_privilege = @(
        "read_recon", "create_recon", "update_recon", "delete_recon",
        "read_global_variable", "create_global_variable", "assign_global_variable",
        "update_global_variable", "delete_global_variable",
        "execute_recon", "sign_off_recon",
        "import_recon", "export_recon",
        "import_global_variable", "export_global_variable",
        "replicate_recon", "replicate_global_variable",
        "archive_recon", "archive_global_variable"
    )
    req_level = "account"
    user = "Admin"
    debug = $false
}
Invoke-ApiResponse -Label "Create Role" -Method Post -Uri "$BaseUrl/recon_security/create_role" -Headers $AuthHeaders -Body $RolePayload

# ──────────────────────────────────────────────
# Step 4: Create Group
# ──────────────────────────────────────────────
$GroupPayload = @{
    group_name_new = "all_roles_grp"
    group_name_old = ""
    req_actn = "a"
    user = "Admin"
    req_level = "account"
    debug = $false
}
Invoke-ApiResponse -Label "Create Group" -Method Post -Uri "$BaseUrl/recon_security/create_group" -Headers $AuthHeaders -Body $GroupPayload

# ──────────────────────────────────────────────
# Step 5: Add Member to Group
# ──────────────────────────────────────────────
$AddMemPayload = @{
    user_name = "Admin"
    group_name = "all_roles_grp"
    mem_actn = "a"
    req_level = "account"
    user = "Admin"
    debug = $false
}
Invoke-ApiResponse -Label "Add Member to Group" -Method Post -Uri "$BaseUrl/recon_security/add/mem_grp" -Headers $AuthHeaders -Body $AddMemPayload

# ──────────────────────────────────────────────
# Step 6: Add Role to Group
# ──────────────────────────────────────────────
$AddRolePayload = @{
    role_name = "all_roles"
    group_name = "all_roles_grp"
    role_actn = "a"
    req_level = "account"
    user = "Admin"
    debug = $false
}
Invoke-ApiResponse -Label "Add Role to Group" -Method Post -Uri "$BaseUrl/recon_security/add/role_grp" -Headers $AuthHeaders -Body $AddRolePayload

# ──────────────────────────────────────────────
# Step 7: Create Recon
# ──────────────────────────────────────────────
$CreateReconPayload = @{
    user = "Admin"
    recon_name = "DART_Seed_Recon"
    recon_name_old = ""
    recon_description = ""
    is_deleted = "false"
    debug = $false
}
Invoke-ApiResponse -Label "Create Recon" -Method Post -Uri "$BaseUrl/recon/create" -Headers $AuthHeaders -Body $CreateReconPayload

# ──────────────────────────────────────────────
# Step 8: Add Group to Recon
# ──────────────────────────────────────────────
$AddGrpReconPayload = @{
    recon_name = "DART_Seed_Recon"
    recon_actn = "a"
    group_name = "all_roles_grp"
    req_level = "recon"
    globalvar_name = ""
    user = "Admin"
    debug = $false
}
Invoke-ApiResponse -Label "Add Group to Recon" -Method Post -Uri "$BaseUrl/recon_security/add/grp_recon" -Headers $AuthHeaders -Body $AddGrpReconPayload

# ──────────────────────────────────────────────
# Step 9: Update Dimensions
# ──────────────────────────────────────────────
$UpdateDimPayload = @{
    recon_name = "DART_Seed_Recon"
    user = "Admin"
    global_variable_name = ""
    in_recon = "true"
    is_deleted = "false"
    dimensions = @(
        @{app_type="0";dimension_name_old="";dimension="year";   dimension_order="0";dim_in_file="yes";type_field="1";top_member="";is_active="yes"},
        @{app_type="1";dimension_name_old="";dimension="year";   dimension_order="0";dim_in_file="yes";type_field="1";top_member="";is_active="yes"},
        @{app_type="0";dimension_name_old="";dimension="period"; dimension_order="1";dim_in_file="yes";type_field="2";top_member="";is_active="yes"},
        @{app_type="1";dimension_name_old="";dimension="period"; dimension_order="1";dim_in_file="yes";type_field="2";top_member="";is_active="yes"},
        @{app_type="0";dimension_name_old="";dimension="amount"; dimension_order="2";dim_in_file="yes";type_field="3";top_member="";is_active="yes"},
        @{app_type="1";dimension_name_old="";dimension="amount"; dimension_order="2";dim_in_file="yes";type_field="3";top_member="";is_active="yes"}
    )
    debug = $false
}
Invoke-ApiResponse -Label "Update Dimensions" -Method Post -Uri "$BaseUrl/dim_linking/update" -Headers $AuthHeaders -Body $UpdateDimPayload

# ──────────────────────────────────────────────
# Step 10: Save App Details for App1
# ──────────────────────────────────────────────
$App1DetailsPayload = @{
    user = "Admin"
    recon_name = "DART_Seed_Recon"
    global_variable_name = ""
    req_level = "recon"
    debug = $false
    details = @(
        @{
            app_type = "0"
            app_name = "App1"
            import_type = "0"
            import_delimiter = ","
            currency_delimiter = ""
            currency_symbol = ""
            has_header = "true"
            currency_th_separator = ""
            app_description = ""
            is_deleted = "false"
            original_recon_app = "App1"
        }
    )
}
Invoke-ApiResponse -Label "Save App Details (App1)" -Method Post -Uri "$BaseUrl/dim_linking/save/details" -Headers $AuthHeaders -Body $App1DetailsPayload

# ──────────────────────────────────────────────
# Step 11: Save App Details for App2
# ──────────────────────────────────────────────
$App2DetailsPayload = @{
    user = "Admin"
    recon_name = "DART_Seed_Recon"
    global_variable_name = ""
    req_level = "recon"
    debug = $false
    details = @(
        @{
            app_type = "1"
            app_name = "App2"
            import_type = "0"
            import_delimiter = ","
            currency_delimiter = ""
            currency_symbol = ""
            has_header = "true"
            currency_th_separator = ""
            app_description = ""
            is_deleted = "false"
            original_recon_app = "App2"
        }
    )
}
Invoke-ApiResponse -Label "Save App Details (App2)" -Method Post -Uri "$BaseUrl/dim_linking/save/details" -Headers $AuthHeaders -Body $App2DetailsPayload

# ──────────────────────────────────────────────
# Step 12: Import Dimensions
# ──────────────────────────────────────────────
$DimFilePath = Join-Path $MediaRoot "Seeded_Recon_files/MockDataDimension.csv"
$DimForm = @{
    Dim_File = Get-Item $DimFilePath
    recon_name = "DART_Seed_Recon"
    global_variable_name = ""
    is_deleted = "false"
    in_recon = "true"
    user = "Admin"
    debug = "false"
}
Invoke-ApiResponse -Label "Import Dimensions" -Method Post -Uri "$BaseUrl/dim_linking/import" -Headers $AuthHeaders -Form $DimForm

# ──────────────────────────────────────────────
# Step 13: Run Import Upload for App1
# ──────────────────────────────────────────────
$App1FilePath = Join-Path $MediaRoot "Seeded_Recon_files/MockData-App1.csv"
$App1Form = @{
    user = "Admin"
    recon_name = "DART_Seed_Recon"
    app_type = "0"
    app_name = "App1"
    app_delimiter = ","
    debug = "false"
    page_number = "1"
    je_flag = "false"
    num_files = "1"
    req_level = "recon"
    "source_file[0]" = Get-Item $App1FilePath
}
Invoke-ApiResponse -Label "Import Upload (App1)" -Method Post -Uri "$BaseUrl/run_import/upload" -Headers $AuthHeaders -Form $App1Form

# ──────────────────────────────────────────────
# Step 14: Run Import Upload for App2
# ──────────────────────────────────────────────
$App2FilePath = Join-Path $MediaRoot "Seeded_Recon_files/MockData-App2.csv"
$App2Form = @{
    user = "Admin"
    recon_name = "DART_Seed_Recon"
    app_type = "1"
    app_name = "App2"
    app_delimiter = ","
    debug = "false"
    page_number = "1"
    je_flag = "false"
    num_files = "1"
    req_level = "recon"
    "source_file[0]" = Get-Item $App2FilePath
}
Invoke-ApiResponse -Label "Import Upload (App2)" -Method Post -Uri "$BaseUrl/run_import/upload" -Headers $AuthHeaders -Form $App2Form

# ──────────────────────────────────────────────
# Step 15: Bridge Import for App1
# ──────────────────────────────────────────────
$BridgeApp1Path = Join-Path $MediaRoot "Seeded_Recon_files/Bridge_App1_test.csv"
$BridgeApp1Form = @{
    bridge_File = Get-Item $BridgeApp1Path
    global_variable_name = ""
    app_type = "0"
    recon_name = "DART_Seed_Recon"
    app_name = "App1"
    merge = "false"
    has_header = "true"
    je_flag = "false"
    user = "Admin"
    debug = "false"
}
Invoke-ApiResponse -Label "Bridge Import (App1)" -Method Post -Uri "$BaseUrl/bridge/import" -Headers $AuthHeaders -Form $BridgeApp1Form

# ──────────────────────────────────────────────
# Step 16: Bridge Import for App2
# ──────────────────────────────────────────────
$BridgeApp2Path = Join-Path $MediaRoot "Seeded_Recon_files/Bridge_App2_test.csv"
$BridgeApp2Form = @{
    bridge_File = Get-Item $BridgeApp2Path
    global_variable_name = ""
    app_type = "1"
    recon_name = "DART_Seed_Recon"
    app_name = "App2"
    merge = "false"
    has_header = "true"
    je_flag = "false"
    user = "Admin"
    debug = "false"
}
Invoke-ApiResponse -Label "Bridge Import (App2)" -Method Post -Uri "$BaseUrl/bridge/import" -Headers $AuthHeaders -Form $BridgeApp2Form

# ──────────────────────────────────────────────
# Step 17: Bridge Run
# ──────────────────────────────────────────────
$BridgeRunPayload = @{
    recon_name = "DART_Seed_Recon"
    je_flag = "false"
    period = ""
    debug = $false
    user = "Admin"
}
Invoke-ApiResponse -Label "Bridge Run (Initial)" -Method Post -Uri "$BaseUrl/bridge/run" -Headers $AuthHeaders -Body $BridgeRunPayload

# ──────────────────────────────────────────────
# Step 18: Check Kickouts List
# ──────────────────────────────────────────────
$KickoutsPayload = @{
    debug = $false
    recon_name = "DART_Seed_Recon"
    user = "Admin"
    je_flag = "false"
}
$KickoutsResult = Invoke-ApiResponse -Label "Check Kickouts" -Method Post -Uri "$BaseUrl/bridge/kickouts/list" -Headers $AuthHeaders -Body $KickoutsPayload

$KickoutsCount = $KickoutsResult.data.Count

if ($KickoutsCount -gt 0) {
    Write-Host "[OK] Kickouts found ($KickoutsCount). Proceeding to handle default kickouts." -ForegroundColor Green

    # Step 19: Handle Default Kickout
    $DefaultKickoutPayload = @{
        user = "Admin"
        recon_name = "DART_Seed_Recon"
        global_variable_name = ""
        je_flag = "false"
        debug = $false
        app_name = @("App1", "App2")
    }
    Invoke-ApiResponse -Label "Handle Default Kickout" -Method Post -Uri "$BaseUrl/bridge/default/kickout" -Headers $AuthHeaders -Body $DefaultKickoutPayload

    # Step 20: Final Bridge Run
    $FinalBridgeRunPayload = @{
        recon_name = "DART_Seed_Recon"
        je_flag = "false"
        period = ""
        debug = $false
        user = "Admin"
    }
    Invoke-ApiResponse -Label "Final Bridge Run" -Method Post -Uri "$BaseUrl/bridge/run" -Headers $AuthHeaders -Body $FinalBridgeRunPayload
} else {
    Write-Host "[OK] No kickouts found. Skipping kickout handling." -ForegroundColor Green
}

# ──────────────────────────────────────────────
# Step 21: Transformation Run
# ──────────────────────────────────────────────
$TransformPayload = @{
    recon_name = "DART_Seed_Recon"
    je_flag = "false"
    period = ""
    debug = $false
    user = "Admin"
}
Invoke-ApiResponse -Label "Transformation Run" -Method Post -Uri "$BaseUrl/transformation/run" -Headers $AuthHeaders -Body $TransformPayload

# ──────────────────────────────────────────────
# Step 22: Report Run
# ──────────────────────────────────────────────
$ReportPayload = @{
    recon_name = "DART_Seed_Recon"
    je_flag = "false"
    user = "Admin"
    debug = $false
    baseline_apptype = "0"
    all_report = "true"
    col_order = ""
    comparison_apptype = ""
}
Invoke-ApiResponse -Label "Report Run" -Method Post -Uri "$BaseUrl/report/run" -Headers $AuthHeaders -Body $ReportPayload

Write-Host "`n[OK] ALL STEPS COMPLETED SUCCESSFULLY." -ForegroundColor Cyan

# Explicit success exit code - without this, $LASTEXITCODE is left at
# whatever stale value existed before this script ran (this script uses
# Invoke-RestMethod throughout, not a native .exe, so nothing else sets it
# in the success path). The caller (VM-Windows-Bash-Script_V2.ps1's SeedData
# step) checks $LASTEXITCODE -eq 0 right after this script returns - found
# live 2026-08-21: a fully successful run (all 25 API calls 200, Import
# Dimensions included) still logged "seed_script.ps1 exited with code " -
# a blank/stale exit code that isn't 0 - and the whole deployment was
# reported COMPLETED WITH ERRORS despite nothing actually failing.
exit 0
