# ===========================================================================
#  DART - OUTBOUND ENDPOINT PRE-FLIGHT
#
#  Read-only. Downloads nothing, installs nothing, changes nothing. Every
#  request is a HEAD (or a 1-byte ranged GET where HEAD is refused).
#
#  Run this BEFORE VM-Windows-Bash-Script_V2.ps1 on a locked-down network, to
#  find out which endpoints a firewall is blocking while that is still cheap.
#  Without it the failures surface hours in, as a hang or an error that looks
#  nothing like a firewall - as happened 2026-09-11, where an apt repo that
#  was unreachable presented as a 20-minute silent stall inside WSL.
#
#  PASS means the host ANSWERED - any HTTP status counts, including 401/403.
#  dev.azure.com returns 401 without a PAT and pypi.org returns 403 to HEAD;
#  both prove the network path is open, which is the only thing being tested
#  here. FAIL means DNS failed, the connection was refused, or it timed out.
#
#  Covers every entry of docs/08-network-egress-allowlist.md (and the hosts
#  measured later in dart_extra_hosts.txt):
#    - INSTALL-TIME (items 1-13, 17, 18): only need to be open while the
#      installer runs. Gates the exit code - if any of these fail, exit 1.
#      Redirects are followed AND the final host is reported, because that
#      final host is the one that must be allow-listed.
#    - [SAMPLE] rows: a real host under a ROTATING wildcard (VS Code
#      extension CDN, Windows Update / Delivery Optimization). A pass proves
#      that host only - IT still needs the wildcard rule.
#    - RUNTIME (items 14-15): the app needs these forever after install -
#      Azure Blob for Airflow, SMTP for email. Never gate the exit code, but
#      must go on the SAME allowlist. (Azure OpenAI is not checked: the AI
#      features are not part of this deployment.)
#    - INFO (item 19): flagged for an IT decision, not required by DART.
#
#  Usage:
#     .\DART-Check-Endpoints.ps1                # Windows-side + WSL + runtime
#     .\DART-Check-Endpoints.ps1 -SkipWSL        # skip the WSL/apt/DNS checks
#     .\DART-Check-Endpoints.ps1 -SkipRuntime    # install-time checklist only
#     .\DART-Check-Endpoints.ps1 -ConfigFile X   # use a config other than the
#                                                   one next to this script
# ===========================================================================
param(
    [string]$ConfigFile = "",
    [int]$TimeoutSec = 20,
    [switch]$SkipWSL,
    [switch]$SkipRuntime
)

# Config, same pattern as every other script in this folder (DART-Start.ps1,
# DART-Status.ps1, DART-Uninstall.ps1, ...) - so the runtime checks below
# test the SAME Azure Blob account / mail host / WSL distro name the real
# deployment will actually use, instead of a second hardcoded copy of those
# values that can silently drift from dart_deploy_config.json.
$_scriptDir = if ($PSScriptRoot) { $PSScriptRoot } else { (Get-Location).Path }
$cfgPath = if ($ConfigFile -and (Test-Path $ConfigFile)) { $ConfigFile } else { Join-Path $_scriptDir "dart_deploy_config.json" }
$cfg = $null
if (Test-Path $cfgPath) { try { $cfg = Get-Content $cfgPath -Raw -Encoding UTF8 | ConvertFrom-Json } catch { } }
function Get-Cfg($k, $d) { if ($cfg -and $cfg.PSObject.Properties.Name -contains $k -and "$($cfg.$k)" -ne "") { return "$($cfg.$k)" }; return $d }

$WSL_DISTRO    = Get-Cfg "WSL_DISTRO"    "Ubuntu-24.04"
$AZURE_AC_NAME = Get-Cfg "AZURE_AC_NAME" ""
$EMAIL_HOST    = Get-Cfg "EMAIL_HOST"    ""
$EMAIL_PORT    = [int](Get-Cfg "EMAIL_PORT" "587")

# PowerShell 5.1 still defaults to TLS 1.0 for some calls; every host below
# requires 1.2+, so a missing line here looks like a firewall block.
try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 } catch { }
# Default is 2 connections per host, which this script exhausts while probing
# several URLs on the same CDN - raise it so a queued connection is never
# mistaken for a blocked endpoint.
try { [Net.ServicePointManager]::DefaultConnectionLimit = 20 } catch { }

$script:pass = 0
$script:fail = 0
$script:runtimePass = 0
$script:runtimeFail = 0
$script:rows = @()

# Every `wsl` call below runs through this. `wsl` can hang indefinitely with
# zero output if the shared VM is busy or contended - the same failure mode
# DART-Status.ps1 and DART-Stop.ps1 already guard against - and on the exact
# box this script exists to de-risk, a genuinely blocked outbound path is
# precisely the condition most likely to make a `wsl` call hang, not just a
# busy VM. A pre-flight check that can itself hang forever on the failure it
# is checking for defeats the one thing it exists to do.
function Invoke-WithTimeout($scriptBlock, $timeoutSec, [object[]]$argList = @()) {
    $job = Start-Job -ScriptBlock $scriptBlock -ArgumentList $argList
    if (Wait-Job $job -Timeout $timeoutSec) {
        $result = Receive-Job $job
        Remove-Job $job -Force -ErrorAction SilentlyContinue
        return @{ TimedOut = $false; Result = $result }
    } else {
        Stop-Job $job -ErrorAction SilentlyContinue | Out-Null
        Remove-Job $job -Force -ErrorAction SilentlyContinue
        return @{ TimedOut = $true; Result = $null }
    }
}

function Test-Endpoint {
    # -Sample : the URL is one real host under a ROTATING wildcard
    #           (08-network-egress-allowlist.md tag "Rotates"). A pass proves
    #           only that host; IT still needs the wildcard rule.
    # -Info   : listed for an IT decision, not required by DART - shown, but
    #           never counted toward pass/fail.
    param([string]$Item, [string]$Url, [string]$Step, [string]$Note = "", [switch]$Runtime, [switch]$Sample, [switch]$Info)

    $status = $null; $err = $null; $finalHost = $null

    # A plain GET whose response is closed as soon as the headers arrive.
    #
    #    No Range header, deliberately. An earlier version sent
    #    "Range: bytes=0-0" to avoid pulling large installers, but
    #    release-assets.githubusercontent.com HANGS on a ranged request while
    #    answering a plain GET with 404 in 0.19s - reported as a firewall
    #    block when nothing was blocked. Setting a range is also awkward
    #    (AddRange() only; a headers hashtable throws) for no benefit:
    #    GetResponse() returns once the response HEADERS are in, and the body
    #    only transfers when the stream is read. Closing here means a 40MB
    #    installer is never downloaded either way.
    #
    #    Not HEAD-first either: measured 2026-09-11, HEAD against a signed CDN
    #    asset took 22.3s because the origin resolves the redirect and signs a
    #    URL before answering, which tripped the timeout. HEAD stays as the
    #    fallback for hosts that refuse GET.
    try {
        $req = [System.Net.HttpWebRequest]::Create($Url)
        $req.Method            = 'GET'
        $req.Timeout           = $TimeoutSec * 1000
        $req.AllowAutoRedirect = $true
        $req.UserAgent         = 'DART-endpoint-check'
        $resp   = $req.GetResponse()
        $status = [int]$resp.StatusCode
        # Where a redirect actually landed (aka.ms -> download.visualstudio...,
        # update.code -> vscode.download.prss...). That final host is the one
        # that must be allow-listed, so it is reported, not just followed.
        try { $finalHost = $resp.ResponseUri.Host } catch { }
        $resp.Close()
    } catch [System.Net.WebException] {
        # An HTTP error response still proves the host answered, which is the
        # only thing being tested - 401 from dev.azure.com without a PAT and
        # 403 from pypi.org both mean "reachable".
        #
        # The response MUST be closed even on the error path. .NET allows only
        # DefaultConnectionLimit connections per ServicePoint and an undisposed
        # error response holds one open, so after a few 401/403s GetResponse()
        # blocks waiting for a free slot and eventually reports "operation has
        # timed out" - a firewall-shaped symptom with no firewall involved.
        # Observed here: GitHub timed out at 20s inside the run while the same
        # request took 0.2s on its own.
        if ($_.Exception.Response) {
            $status = [int]$_.Exception.Response.StatusCode
            try { $_.Exception.Response.Close() } catch { }
        } else { $err = $_.Exception.Message }
    } catch {
        $err = $_.Exception.Message
    }

    # 1b) .NET got no HTTP answer: ask curl.exe before calling it a block.
    #     .NET's TLS failures are not proof of a network block, and their type
    #     is not even stable - measured 2026-10-14 against
    #     https://download.windowsupdate.com (certificate issued for another
    #     name, SEC_E_WRONG_PRINCIPAL; the host is meant for port 80): .NET
    #     reported TrustFailure in one process and "Could not create SSL/TLS
    #     secure channel" in the next, while curl -k got HTTP 200 every time.
    #       curl (verified)  -> any HTTP status = reachable, plain PASS
    #       curl -k          -> full TLS handshake with the same SNI a
    #                           filtering firewall inspects, only certificate
    #                           validation skipped -> reachable, noted
    #       neither          -> a real block (DNS / refused / SNI-filtered)
    if (-not $status -and $Url -like 'https://*') {
        $curl = Get-Command curl.exe -ErrorAction SilentlyContinue
        if ($curl) {
            $vc = (& $curl.Source -s -o NUL -m $TimeoutSec -w '%{http_code}' $Url 2>$null | Out-String).Trim()
            if ($vc -match '^[1-5]\d\d$') {
                $status = $vc
                $Note = ($Note + ' | answered via curl.exe (.NET could not complete the request)').Trim(' |')
            } else {
                $kc = (& $curl.Source -k -s -o NUL -m $TimeoutSec -w '%{http_code}' $Url 2>$null | Out-String).Trim()
                if ($kc -match '^[1-5]\d\d$') {
                    $status = 'TLS'
                    $Note = ($Note + " | host answered (curl -k HTTP $kc); TLS certificate not valid for this name - not a network block").Trim(' |')
                } else { $err = "$err (curl: no answer either)" }
            }
        }
    }

    # 2) Fall back to HEAD for hosts that reject ranged requests.
    if (-not $status) {
        try {
            $r = Invoke-WebRequest -Uri $Url -Method Head -TimeoutSec $TimeoutSec -UseBasicParsing
            $status = [int]$r.StatusCode
        } catch {
            if ($_.Exception.Response) { $status = [int]$_.Exception.Response.StatusCode }
            else { $err = $_.Exception.Message }
        }
    }

    $origHost = ''
    try { $origHost = ([Uri]$Url).Host } catch { }
    $redirect = if ($finalHost -and $finalHost -ne $origHost) { " -> $finalHost" } else { '' }
    if ($redirect) { $Note = ($Note + " | final host: $finalHost").Trim(' |') }

    if ($Info) {
        $txt = if ($status) { "HTTP $status$redirect" } else { "no answer ($err)" }
        Write-Host ("  [INFO] {0,-3} {1,-55} {2}" -f $Item, $Url, $txt) -ForegroundColor DarkCyan
        $script:rows += [PSCustomObject]@{ Item = $Item; Url = $Url; Step = $Step; Result = $(if ($status) { "INFO ($status)" } else { 'INFO (no answer)' }); Note = $Note }
        return
    }

    $tag = if ($Runtime) { "RUNTIME" } elseif ($Sample) { "SAMPLE" } else { "PASS" }
    if ($status) {
        if ($Runtime) { $script:runtimePass++ } else { $script:pass++ }
        $shown = if ($status -eq 'TLS') { 'TLS answered (certificate not for this name)' } else { "HTTP $status" }
        Write-Host ("  [{0}] {1,-3} {2,-55} {3}{4}" -f $tag, $Item, $Url, $shown, $redirect) -ForegroundColor Green
        $result = if ($Sample) { "PASS-SAMPLE ($status)" } else { "PASS ($status)" }
        if ($Sample) { $Note = ($Note + ' | sample of a rotating wildcard - the WILDCARD rule is still required').Trim(' |') }
    } else {
        if ($Runtime) { $script:runtimeFail++ } else { $script:fail++ }
        Write-Host ("  [FAIL] {0,-3} {1,-55} {2}" -f $Item, $Url, $err) -ForegroundColor Red
        $result = "FAIL"
    }
    $script:rows += [PSCustomObject]@{ Item = $Item; Url = $Url; Step = $Step; Result = $result; Note = $Note }
}

# curl.exe probe, for hosts where .NET's HttpWebRequest hangs although the
# host answers (release-assets.githubusercontent.com: curl 404 in 0.19s,
# .NET hangs to the full timeout - measured 2026-09-11, see item 8 below).
# curl.exe ships with Windows 10 1803+ / Server 2019+. Any HTTP status = the
# host answered; 000 = no answer.
function Test-CurlEndpoint {
    param([string]$Item, [string]$Url, [string]$Step, [string]$Note = "")
    $curl = Get-Command curl.exe -ErrorAction SilentlyContinue
    if (-not $curl) {
        Write-Host ("  [MANUAL] {0,-3} {1,-53} curl.exe not available - verify by hand" -f $Item, $Url) -ForegroundColor Yellow
        $script:rows += [PSCustomObject]@{ Item = $Item; Url = $Url; Step = $Step; Result = 'MANUAL'; Note = "curl.exe missing; $Note" }
        return
    }
    $code = (& $curl.Source -s -o NUL -m $TimeoutSec -w '%{http_code}' $Url 2>$null | Out-String).Trim()
    if ($code -match '^[1-5]\d\d$') {
        $script:pass++
        Write-Host ("  [PASS] {0,-3} {1,-55} HTTP {2} (curl)" -f $Item, $Url, $code) -ForegroundColor Green
        $script:rows += [PSCustomObject]@{ Item = $Item; Url = $Url; Step = $Step; Result = "PASS ($code)"; Note = "probed with curl.exe; $Note".Trim(' ;') }
    } else {
        $script:fail++
        Write-Host ("  [FAIL] {0,-3} {1,-55} no answer (curl {2})" -f $Item, $Url, $code) -ForegroundColor Red
        $script:rows += [PSCustomObject]@{ Item = $Item; Url = $Url; Step = $Step; Result = 'FAIL'; Note = "probed with curl.exe; $Note".Trim(' ;') }
    }
}

# UDP 123 - a real NTP request (48-byte client packet), not a port guess. A
# UDP "connect" proves nothing, so the only valid PASS is an actual reply.
function Test-Ntp {
    param([string]$Item, [string]$HostName, [string]$Step, [string]$Note = "")
    $target = "${HostName}:123/udp"
    $udp = New-Object System.Net.Sockets.UdpClient
    try {
        $udp.Client.ReceiveTimeout = 5000
        $udp.Connect($HostName, 123)
        $pkt = New-Object byte[] 48
        $pkt[0] = 0x1B                        # LI=0, VN=3, Mode=3 (client)
        [void]$udp.Send($pkt, $pkt.Length)
        $ep = New-Object System.Net.IPEndPoint([System.Net.IPAddress]::Any, 0)
        $reply = $udp.Receive([ref]$ep)
        if ($reply.Length -ge 48) {
            $script:pass++
            Write-Host ("  [PASS] {0,-3} {1,-55} NTP reply from {2}" -f $Item, $target, $ep.Address) -ForegroundColor Green
            $script:rows += [PSCustomObject]@{ Item = $Item; Url = $target; Step = $Step; Result = 'PASS'; Note = $Note }
            return
        }
        throw "short reply ($($reply.Length) bytes)"
    } catch {
        $script:fail++
        Write-Host ("  [FAIL] {0,-3} {1,-55} no NTP reply ({2})" -f $Item, $target, $_.Exception.Message) -ForegroundColor Red
        $script:rows += [PSCustomObject]@{ Item = $Item; Url = $target; Step = $Step; Result = 'FAIL'; Note = $Note }
    } finally { $udp.Close() }
}

# A plain TCP connect test for non-HTTP endpoints (SMTP). Reachability only -
# it does not authenticate or speak the protocol, same "any answer counts"
# philosophy as Test-Endpoint above.
function Test-TcpPort {
    param([string]$Item, [string]$HostName, [int]$Port, [string]$Step, [string]$Note = "", [switch]$Runtime)

    $target = "${HostName}:${Port}"
    try {
        $client = New-Object System.Net.Sockets.TcpClient
        $iar = $client.BeginConnect($HostName, $Port, $null, $null)
        $ok = $iar.AsyncWaitHandle.WaitOne($TimeoutSec * 1000)
        if ($ok -and $client.Connected) {
            $client.EndConnect($iar)
            $client.Close()
            if ($Runtime) { $script:runtimePass++ } else { $script:pass++ }
            Write-Host ("  [{0}] {1,-3} {2,-55} TCP connect OK" -f $(if ($Runtime) {"RUNTIME"} else {"PASS"}), $Item, $target) -ForegroundColor Green
            $script:rows += [PSCustomObject]@{ Item = $Item; Url = $target; Step = $Step; Result = "PASS"; Note = $Note }
        } else {
            $client.Close()
            if ($Runtime) { $script:runtimeFail++ } else { $script:fail++ }
            Write-Host ("  [FAIL] {0,-3} {1,-55} timed out / refused" -f $Item, $target) -ForegroundColor Red
            $script:rows += [PSCustomObject]@{ Item = $Item; Url = $target; Step = $Step; Result = "FAIL"; Note = $Note }
        }
    } catch {
        if ($Runtime) { $script:runtimeFail++ } else { $script:fail++ }
        Write-Host ("  [FAIL] {0,-3} {1,-55} {2}" -f $Item, $target, $_.Exception.Message) -ForegroundColor Red
        $script:rows += [PSCustomObject]@{ Item = $Item; Url = $target; Step = $Step; Result = "FAIL"; Note = $Note }
    }
}

Write-Host ""
Write-Host "==========================================" -ForegroundColor DarkCyan
Write-Host "  DART - OUTBOUND ENDPOINT PRE-FLIGHT"      -ForegroundColor Cyan
Write-Host "==========================================" -ForegroundColor DarkCyan
Write-Host "  Read-only. Nothing is downloaded or installed." -ForegroundColor DarkGray
Write-Host ""

Write-Host ">>> Windows-side downloads (TCP 443)" -ForegroundColor Cyan
Test-Endpoint "1" "https://www.python.org/ftp/python/3.12.1/python-3.12.1-embed-amd64.zip" "PreFlight-Python"
Test-Endpoint "1" "https://bootstrap.pypa.io/get-pip.py"                                   "PreFlight-Python"
Test-Endpoint "2" "https://pypi.org/simple/"                                               "BackendSetup"
Test-Endpoint "2" "https://files.pythonhosted.org"                                         "BackendSetup"  "wheels live here, not on pypi.org"
Test-Endpoint "3" "https://get.enterprisedb.com/postgresql/postgresql-16.2-1-windows-x64-binaries.zip" "Step-5-PostgreSQL"
Test-Endpoint "3" "https://truststore.pki.rds.amazonaws.com/global/global-bundle.pem"      "Step-1-Prerequisites" "RDS CA bundle"
Test-Endpoint "4" "https://aka.ms/vs/17/release/vs_buildtools.exe"                         "Step-7-VSBuildTools"  "redirects to download.visualstudio.microsoft.com"
Test-Endpoint "5" "https://nodejs.org/dist/v20.11.0/node-v20.11.0-win-x64.zip"             "Step-3-NodeJS"
Test-Endpoint "5" "https://registry.npmjs.org"                                             "Step-12-FrontendBuild" "index AND tarballs"
Test-Endpoint "6" "https://nginx.org/download/nginx-1.24.0.zip"                            "Step-6-NginxInstall"
Test-Endpoint "7" "https://dev.azure.com/Donyati-Devops/DART/_git/Data-Recon-Backend"      "Step-8-CloneRepos"    "401 without a PAT is expected"
Test-Endpoint "7" "https://dev.azure.com/Donyati-Devops/DART/_git/Data-Recon-Frontend"     "Step-8-CloneRepos"
Test-Endpoint "7" "https://dev.azure.com/Donyati-Devops/DART/_git/Data-Recon-Database"     "Step-8-CloneRepos"
Test-Endpoint "7" "https://dev.azure.com/Donyati-Devops/DART/_git/Data-Recon-Airflow"      "Step-8-CloneRepos"
# Item 8 deliberately probes the two HOSTS rather than the release-asset URL
# itself. That URL 302s to a time-signed CDN link, and GitHub throttles
# repeated requests for it - measured 2026-09-11, the same request returned
# 206 in 0.2s and then timed out on every retry minutes later. Probing it
# produced a FAIL that looked exactly like a firewall block but was
# rate-limiting, which is the one outcome this script must never report.
# Reaching both hosts is what IT needs to confirm; the asset path is covered
# by whichever of them is allow-listed.
Test-Endpoint "8" "https://github.com"                              "Step-2-Git" "release page host"

# release-assets / objects.githubusercontent.com are probed with curl.exe,
# not .NET: measured 2026-09-11, curl gets "404 in 0.19s" (the host answers)
# while HttpWebRequest hangs to the full timeout against the same URL - a
# client-stack difference, not a network fact. A .NET probe would report a
# firewall block for an endpoint that is open.
Test-CurlEndpoint "8" "https://release-assets.githubusercontent.com" "Step-2-Git" "Git installer bytes come from here (github.com redirects)"
Test-CurlEndpoint "8" "https://objects.githubusercontent.com"        "Step-2-Git" "GitHub release-asset CDN redirect"
Test-Endpoint     "8" "https://raw.githubusercontent.com"            "Step-15-AirflowSetup" "measured 2026-09-23 (dart_extra_hosts.txt)"

# Step 7 - VS Build Tools. aka.ms only redirects; the bootstrapper and its
# Authenticode certificate checks contact these (measured 2026-09-23).
Test-Endpoint "4" "https://download.visualstudio.microsoft.com"      "Step-7-VSBuildTools" "installer payload host (aka.ms redirects here)"
Test-Endpoint "4" "https://go.microsoft.com"                         "Step-7-VSBuildTools" "measured 2026-09-23"
Test-Endpoint "4" "https://www.microsoft.com"                        "Step-7-VSBuildTools" "measured 2026-09-23"
Test-Endpoint "4" "http://www.microsoft.com"                         "Step-7-VSBuildTools" "PORT 80 - certificate checks"
Test-Endpoint "4" "http://crl.microsoft.com/pki/crl/products/MicRooCerAut2011_2011_03_22.crl" "Step-7-VSBuildTools" "PORT 80 - CRL download for Authenticode"

# Step 16 - VS Code binary: the update host redirects, the bytes come from
# these two (both Measured in 08-network-egress-allowlist.md).
Test-Endpoint "10" "https://update.code.visualstudio.com/latest/win32-x64-user/stable"     "Step-16-VSCodeInstall" "redirects to vscode.download.prss.microsoft.com"
Test-Endpoint "10" "https://vscode.download.prss.microsoft.com"      "Step-16-VSCodeInstall" "VS Code installer download host"
Test-Endpoint "10" "https://main.vscode-cdn.net"                     "Step-16-VSCodeInstall" "VS Code CDN"

# Step 16 - extensions. The Marketplace API resolves each extension, then the
# .vsix comes from a PER-PUBLISHER subdomain of two ROTATING wildcards. Each
# of the six publishers observed 2026-09-16 is probed on both; a pass is a
# [SAMPLE] - a new publisher means a new subdomain, so IT needs the wildcards:
#     *.gallery.vsassets.io   and   *.gallerycdn.vsassets.io
Test-Endpoint "12" "https://marketplace.visualstudio.com/items?itemName=ms-python.python" "Step-16-VSCodeInstall" "extension marketplace API"
foreach ($pub in @('ms-python', 'dbaeumer', 'esbenp', 'eamodio', 'ms-azuretools', 'mtxr')) {
    Test-Endpoint "12" "https://$pub.gallery.vsassets.io"    "Step-16-VSCodeInstall" "wildcard *.gallery.vsassets.io"    -Sample
    Test-Endpoint "12" "https://$pub.gallerycdn.vsassets.io" "Step-16-VSCodeInstall" "wildcard *.gallerycdn.vsassets.io" -Sample
}

# Step 15 - the Ubuntu distro itself. `wsl --install` pulls through Windows
# Update / Delivery Optimization (rotating, wildcard rules required) plus the
# two WSL blob stores measured 2026-09-23. The hosts below are the ones
# observed 2026-09-16 - samples, never a substitute for the wildcard rules:
#     *.do.dsp.mp.microsoft.com  *.delivery.mp.microsoft.com
#     *.update.microsoft.com     *.windowsupdate.com (TCP 80 AND 443)
Write-Host ""
Write-Host ">>> Step 15 - WSL distro download (Windows side)" -ForegroundColor Cyan
Write-Host "    [SAMPLE] = one real host under a rotating wildcard; IT still needs the wildcard rule." -ForegroundColor DarkGray
Test-Endpoint "17" "https://wslstorestorage.blob.core.windows.net"   "Step-15-AirflowSetup" "WSL kernel / store package (measured 2026-09-23)"
Test-Endpoint "17" "https://publicwsldistros.blob.core.windows.net"  "Step-15-AirflowSetup" "Ubuntu rootfs (measured 2026-09-23)"
Test-Endpoint "17" "https://geo.prod.do.dsp.mp.microsoft.com"        "Step-15-AirflowSetup" "wildcard *.do.dsp.mp.microsoft.com"   -Sample
Test-Endpoint "17" "https://cp801.prod.do.dsp.mp.microsoft.com"      "Step-15-AirflowSetup" "wildcard *.do.dsp.mp.microsoft.com"   -Sample
Test-Endpoint "17" "https://kv801.prod.do.dsp.mp.microsoft.com"      "Step-15-AirflowSetup" "wildcard *.do.dsp.mp.microsoft.com"   -Sample
Test-Endpoint "17" "https://fe3cr.delivery.mp.microsoft.com"         "Step-15-AirflowSetup" "wildcard *.delivery.mp.microsoft.com" -Sample
Test-Endpoint "17" "https://fe2cr.update.microsoft.com"              "Step-15-AirflowSetup" "wildcard *.update.microsoft.com"      -Sample
Test-Endpoint "17" "http://download.windowsupdate.com"               "Step-15-AirflowSetup" "wildcard *.windowsupdate.com - PORT 80" -Sample
Test-Endpoint "17" "https://download.windowsupdate.com"              "Step-15-AirflowSetup" "wildcard *.windowsupdate.com - 443"   -Sample
Test-Endpoint "17" "http://au.download.windowsupdate.com"            "Step-15-AirflowSetup" "wildcard *.windowsupdate.com - PORT 80" -Sample

Write-Host ""
Write-Host ">>> Ubuntu apt repos - PORT 80, NOT 443" -ForegroundColor Cyan
Write-Host "    A 443-only allowlist makes the Airflow step hang silently." -ForegroundColor DarkGray
Test-Endpoint "9" "http://archive.ubuntu.com/ubuntu/dists/noble/Release"  "Step-15-AirflowSetup" "plain HTTP by design - packages are GPG-signed"
Test-Endpoint "9" "http://security.ubuntu.com/ubuntu/dists/noble/Release" "Step-15-AirflowSetup"

# Time sync - the only non-TCP entry on the allowlist (UDP 123).
Test-Ntp "18" "ntp.ubuntu.com" "Step-15-AirflowSetup" "Ubuntu time sync - UDP 123, the only non-TCP rule"

# --- WSL-side checks ------------------------------------------------------
# Windows reaching a host proves nothing about the WSL guest: it has its own
# network namespace and its own resolver. On 2026-09-11 Windows resolved and
# reached archive.ubuntu.com fine while WSL could only get AAAA records, with
# no IPv6 route - so apt hung instead of failing.
if (-not $SkipWSL) {
    Write-Host ""
    Write-Host ">>> Inside WSL (separate network namespace + resolver)" -ForegroundColor Cyan

    $listResult = Invoke-WithTimeout { & wsl --list --quiet 2>&1 } 15
    $distro = $null
    if ($listResult.TimedOut) {
        Write-Host "  [SKIP] 'wsl --list' timed out after 15s - cannot enumerate distros." -ForegroundColor Yellow
        $script:rows += [PSCustomObject]@{ Item='11'; Url='(WSL DNS)'; Step='Step-15-AirflowSetup'; Result='SKIP'; Note='wsl --list timed out' }
    } else {
        $raw = (($listResult.Result | Out-String) -replace "`0", '').Trim()
        $names = $raw -split "`r?`n" | ForEach-Object { $_.Trim() } | Where-Object { $_ }
        # A real distro name is a bare token that STARTS with a letter or
        # digit. Two different non-names have to be rejected here:
        #   - an error sentence, when WSL is not installed at all ("Windows
        #     Subsystem for Linux has no installed distributions", or "Class
        #     not registered" on an unpatched box)
        #   - a bare FLAG. Observed live on a fresh Server box with no distro
        #     registered: `wsl --list --quiet` emitted "--inbox", which an
        #     earlier version of this pattern happily accepted as a distro
        #     name and then ran every WSL probe against, producing three
        #     FAILs that looked exactly like a blocked firewall on a machine
        #     whose only real problem was having no distro yet.
        # Requiring an alphanumeric first character rejects both.
        $validNames = $names | Where-Object { $_ -match '^[A-Za-z0-9][A-Za-z0-9._-]*$' }
        if (-not $validNames) {
            Write-Host "  [SKIP] no WSL distro registered yet (raw: '$raw')." -ForegroundColor Yellow
            Write-Host "         Expected before Step-15 runs on a fresh box - re-run this after it installs one." -ForegroundColor DarkGray
            $script:rows += [PSCustomObject]@{ Item='11'; Url='(WSL DNS)'; Step='Step-15-AirflowSetup'; Result='SKIP'; Note="no distro yet ($raw)" }
        } else {
            # Prefer the distro THIS deployment will actually use
            # ($WSL_DISTRO, from dart_deploy_config.json) over whichever one
            # happens to be first/default. DART-Uninstall.ps1 documents a
            # real, observed case of a stray leftover distro from a failed
            # earlier run silently becoming the Windows default and being
            # the actual cause of an Airflow install failure - testing
            # "whatever comes first" instead of the configured one would
            # reproduce exactly that blind spot here.
            $distro = if ($validNames -contains $WSL_DISTRO) { $WSL_DISTRO } else { $validNames | Select-Object -First 1 }
            if ($validNames -notcontains $WSL_DISTRO) {
                Write-Host "  [WARN] configured WSL_DISTRO '$WSL_DISTRO' is not registered - testing '$distro' instead." -ForegroundColor Yellow
            }
            Write-Host "  distro: $distro" -ForegroundColor DarkGray

            # A-record resolution specifically. AAAA-only resolution is what
            # broke apt: it resolves, so DNS "works", but there is no IPv6
            # route out.
            $v4Result = Invoke-WithTimeout { param($d) & wsl -d $d -u root -- bash -c "getent ahostsv4 archive.ubuntu.com 2>/dev/null | head -1" 2>&1 } 20 @($distro)
            if ($v4Result.TimedOut) {
                Write-Host "  [FAIL] 11  WSL DNS lookup timed out after 20s - treat as blocked, not just slow." -ForegroundColor Red
                $script:fail++
                $script:rows += [PSCustomObject]@{ Item='11'; Url='WSL DNS (A record)'; Step='Step-15'; Result='FAIL'; Note='wsl call timed out' }
            } else {
                $v4 = ($v4Result.Result | Out-String) -replace "`0", ''
                if ($v4 -match '\d+\.\d+\.\d+\.\d+') {
                    Write-Host ("  [PASS] 11  WSL resolves IPv4 for archive.ubuntu.com -> {0}" -f $v4.Trim()) -ForegroundColor Green
                    $script:pass++
                    $script:rows += [PSCustomObject]@{ Item='11'; Url='WSL DNS (A record)'; Step='Step-15'; Result='PASS'; Note=$v4.Trim() }
                } else {
                    Write-Host "  [FAIL] 11  WSL cannot resolve an IPv4 address for archive.ubuntu.com" -ForegroundColor Red
                    Write-Host "             This is the silent-hang case. Check /etc/resolv.conf inside WSL." -ForegroundColor Yellow
                    $script:fail++
                    $script:rows += [PSCustomObject]@{ Item='11'; Url='WSL DNS (A record)'; Step='Step-15'; Result='FAIL'; Note='AAAA-only or no answer' }
                }
            }

            # Actual egress from the guest on port 80.
            $codeResult = Invoke-WithTimeout { param($d,$t) & wsl -d $d -u root -- bash -c "curl -s -o /dev/null -m $t -w '%{http_code}' http://archive.ubuntu.com/ubuntu/dists/noble/Release 2>/dev/null" 2>&1 } ($TimeoutSec + 10) @($distro, $TimeoutSec)
            if ($codeResult.TimedOut) {
                Write-Host "  [FAIL] 9   WSL curl to archive.ubuntu.com timed out at the wsl-call level." -ForegroundColor Red
                $script:fail++
                $script:rows += [PSCustomObject]@{ Item='9'; Url='WSL -> archive.ubuntu.com:80'; Step='Step-15'; Result='FAIL'; Note='wsl call timed out' }
            } else {
                $code = (($codeResult.Result | Out-String) -replace "`0", '').Trim()
                if ($code -match '^[1-5]\d\d$' -and $code -ne '000') {
                    Write-Host ("  [PASS] 9   WSL reaches archive.ubuntu.com on port 80 (HTTP {0})" -f $code) -ForegroundColor Green
                    $script:pass++
                    $script:rows += [PSCustomObject]@{ Item='9'; Url='WSL -> archive.ubuntu.com:80'; Step='Step-15'; Result="PASS ($code)"; Note='' }
                } else {
                    Write-Host "  [FAIL] 9   WSL cannot reach archive.ubuntu.com on port 80" -ForegroundColor Red
                    $script:fail++
                    $script:rows += [PSCustomObject]@{ Item='9'; Url='WSL -> archive.ubuntu.com:80'; Step='Step-15'; Result='FAIL'; Note='apt will hang here' }
                }
            }

            # PyPI, from inside WSL - not just from Windows. Airflow's own
            # `pip install -r requirements.txt` (~80 packages, see
            # VM-Windows-Bash-Script_V2.ps1's AirflowSetup step) runs inside
            # this same guest, over this same separate resolver/network
            # namespace - a 443-only-from-Windows PASS above proves nothing
            # about whether WSL itself can reach PyPI.
            $pyCodeResult = Invoke-WithTimeout { param($d,$t) & wsl -d $d -u root -- bash -c "curl -s -o /dev/null -m $t -w '%{http_code}' https://pypi.org/simple/ 2>/dev/null" 2>&1 } ($TimeoutSec + 10) @($distro, $TimeoutSec)
            if ($pyCodeResult.TimedOut) {
                Write-Host "  [FAIL] 13  WSL curl to pypi.org timed out at the wsl-call level." -ForegroundColor Red
                $script:fail++
                $script:rows += [PSCustomObject]@{ Item='13'; Url='WSL -> pypi.org:443'; Step='Step-15-AirflowSetup'; Result='FAIL'; Note='wsl call timed out' }
            } else {
                $pyCode = (($pyCodeResult.Result | Out-String) -replace "`0", '').Trim()
                if ($pyCode -match '^[1-5]\d\d$' -and $pyCode -ne '000') {
                    Write-Host ("  [PASS] 13  WSL reaches pypi.org on port 443 (HTTP {0})" -f $pyCode) -ForegroundColor Green
                    $script:pass++
                    $script:rows += [PSCustomObject]@{ Item='13'; Url='WSL -> pypi.org:443'; Step='Step-15-AirflowSetup'; Result="PASS ($pyCode)"; Note='' }
                } else {
                    Write-Host "  [FAIL] 13  WSL cannot reach pypi.org on port 443 - Airflow's own pip install will hang/fail here." -ForegroundColor Red
                    $script:fail++
                    $script:rows += [PSCustomObject]@{ Item='13'; Url='WSL -> pypi.org:443'; Step='Step-15-AirflowSetup'; Result='FAIL'; Note='Airflow pip install needs this' }
                }
            }

            # The rest of the guest's list (08-network-egress-allowlist.md,
            # "Inside the Linux guest"): apt security updates on port 80, the
            # wheel CDN pip downloads from, and the Airflow repo clone.
            foreach ($probe in @(
                @{ Item = '9';  Url = 'http://security.ubuntu.com/ubuntu/dists/noble/Release'; Label = 'security.ubuntu.com on port 80'; Why = 'apt security updates' },
                @{ Item = '13'; Url = 'https://files.pythonhosted.org';                      Label = 'files.pythonhosted.org on port 443'; Why = 'pip downloads the wheels from here, not pypi.org' },
                @{ Item = '7';  Url = 'https://dev.azure.com';                               Label = 'dev.azure.com on port 443'; Why = 'Airflow repo / git from the guest' }
            )) {
                $r = Invoke-WithTimeout { param($d, $t, $u) & wsl -d $d -u root -- bash -c "curl -s -o /dev/null -m $t -w '%{http_code}' $u 2>/dev/null" 2>&1 } ($TimeoutSec + 10) @($distro, $TimeoutSec, $probe.Url)
                $c = if ($r.TimedOut) { 'timeout' } else { (($r.Result | Out-String) -replace "`0", '').Trim() }
                if ($c -match '^[1-5]\d\d$') {
                    Write-Host ("  [PASS] {0,-3} WSL reaches {1} (HTTP {2})" -f $probe.Item, $probe.Label, $c) -ForegroundColor Green
                    $script:pass++
                    $script:rows += [PSCustomObject]@{ Item = $probe.Item; Url = "WSL -> $($probe.Url)"; Step = 'Step-15-AirflowSetup'; Result = "PASS ($c)"; Note = $probe.Why }
                } else {
                    Write-Host ("  [FAIL] {0,-3} WSL cannot reach {1} ({2}) - {3}" -f $probe.Item, $probe.Label, $c, $probe.Why) -ForegroundColor Red
                    $script:fail++
                    $script:rows += [PSCustomObject]@{ Item = $probe.Item; Url = "WSL -> $($probe.Url)"; Step = 'Step-15-AirflowSetup'; Result = 'FAIL'; Note = $probe.Why }
                }
            }
        }
    }
}

# --- Runtime endpoints (required AFTER install, not by the installer) -----
# The installer never touches these, so they are excluded from the pass/fail
# gate above - but the app is broken without them, and a firewall built only
# from the install-time checklist would pass this whole script and then
# still fail the first time a DAG writes to Blob storage or Django sends an
# email. -SkipRuntime narrows this back to a pure install-readiness check.
if (-not $SkipRuntime) {
    Write-Host ""
    Write-Host ">>> Runtime endpoints (needed after install, not during it)" -ForegroundColor Cyan

    if ($AZURE_AC_NAME) {
        Test-Endpoint "14" "https://$AZURE_AC_NAME.blob.core.windows.net" "Runtime-AirflowWasbHook" "Azure Blob - Airflow DAGs + FastAPI storage" -Runtime
    } else {
        Write-Host "  [SKIP] 14  AZURE_AC_NAME not set in $cfgPath - cannot derive the Blob endpoint." -ForegroundColor Yellow
    }

    if ($EMAIL_HOST) {
        Test-TcpPort "15" $EMAIL_HOST $EMAIL_PORT "Runtime-Email" "Django + Airflow SMTP (AIRFLOW_CONN_SMTP_DART)" -Runtime
    } else {
        Write-Host "  [SKIP] 15  EMAIL_HOST not set in $cfgPath." -ForegroundColor Yellow
    }
    # Azure OpenAI is deliberately NOT checked: the AI features (Ask DART /
    # AI Auto Draft) are not part of this deployment.
}

# --- Flagged for an IT decision (not required by DART) --------------------
# 08-network-egress-allowlist.md "Two flagged rather than decided". Shown so
# IT sees their current state; never counted toward pass/fail.
Write-Host ""
Write-Host ">>> Flagged for IT decision (not required by DART - informational)" -ForegroundColor Cyan
Test-Endpoint "19" "http://ocsp.digicert.com"              "IT-decision" "cert revocation - if DROPPED, signed installers stall until timeout" -Info
Test-Endpoint "19" "https://ssm.us-east-1.amazonaws.com"   "IT-decision" "AWS Systems Manager - blocking it disconnects SSM from this instance" -Info

# --- Summary --------------------------------------------------------------
Write-Host ""
Write-Host "==========================================" -ForegroundColor DarkCyan
Write-Host "  INSTALL-TIME: $script:pass passed, $script:fail failed" -ForegroundColor $(if ($script:fail) { 'Red' } else { 'Green' })
$samples = @($script:rows | Where-Object { $_.Result -like 'PASS-SAMPLE*' }).Count
if ($samples) { Write-Host "                ($samples of the passes are [SAMPLE] hosts of rotating wildcards - IT must still allow the wildcards)" -ForegroundColor DarkGray }
if (-not $SkipRuntime) {
    Write-Host "  RUNTIME     : $script:runtimePass passed, $script:runtimeFail failed (informational - does not affect exit code)" -ForegroundColor $(if ($script:runtimeFail) { 'Yellow' } else { 'Green' })
}
Write-Host "==========================================" -ForegroundColor DarkCyan

$csv = Join-Path $env:TEMP "dart_endpoint_check.csv"
$script:rows | Export-Csv -Path $csv -NoTypeInformation -Encoding UTF8
Write-Host "  Full results (send this to IT): $csv" -ForegroundColor Cyan

if ($script:fail) {
    Write-Host ""
    Write-Host "  Blocked install-time endpoints, by checklist item:" -ForegroundColor Yellow
    $script:rows | Where-Object { $_.Result -eq 'FAIL' -and $_.Step -notlike 'Runtime-*' } | ForEach-Object {
        Write-Host ("    item {0,-3} {1}  (needed by {2})" -f $_.Item, $_.Url, $_.Step) -ForegroundColor Yellow
    }
}
if ($script:runtimeFail) {
    Write-Host ""
    Write-Host "  Blocked RUNTIME endpoints (app will be broken after install even though it succeeds):" -ForegroundColor Yellow
    $script:rows | Where-Object { $_.Result -eq 'FAIL' -and $_.Step -like 'Runtime-*' } | ForEach-Object {
        Write-Host ("    item {0,-3} {1}  (needed by {2})" -f $_.Item, $_.Url, $_.Step) -ForegroundColor Yellow
    }
}

if ($script:fail) { exit 1 }
exit 0
