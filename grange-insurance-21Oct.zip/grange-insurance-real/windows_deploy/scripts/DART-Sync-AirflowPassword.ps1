# ===========================================================================
#  DART-Sync-AirflowPassword.ps1
#
#  Copies the admin password Airflow generated into the .env Django reads,
#  then restarts the backend so Django actually picks it up.
#
#  Source : <MEDIA_PATH>\simple_auth_manager_passwords.json.generated
#           e.g. {"admin": "hBzxVSa6P29A7WuG"}
#  Target : <INSTALL_ROOT>\.env
#           airflow_admin_password=<value>     <- what settings.py reads:
#           AIRFLOW_ADMIN_PASSWORD=<value>        os.environ.get("airflow_admin_password", "<default>")
#
#  Why this exists as its own script: the sync is built into both
#  VM-Windows-Bash-Script_V2.ps1 (after Airflow starts) and DART-Start.ps1
#  (before the backend starts), but when they disagree - or when a stale
#  Uvicorn refuses to die and keeps serving the old environment - you want one
#  command that does the whole thing and tells you exactly what it found.
#
#  Usage:
#     .\DART-Sync-AirflowPassword.ps1            # sync + restart backend
#     .\DART-Sync-AirflowPassword.ps1 -WhatIf    # show what it WOULD do
#     .\DART-Sync-AirflowPassword.ps1 -NoRestart # sync only
# ===========================================================================
param(
    [string]$ConfigFile = "",
    [switch]$NoRestart,
    [switch]$WhatIf
)

$_scriptDir = if ($PSScriptRoot) { $PSScriptRoot } else { (Get-Location).Path }
$cfgPath = if ($ConfigFile -and (Test-Path $ConfigFile)) { $ConfigFile } else { Join-Path $_scriptDir "dart_deploy_config.json" }
$cfg = $null
if (Test-Path $cfgPath) {
    try { $cfg = Get-Content $cfgPath -Raw -Encoding UTF8 | ConvertFrom-Json } catch { }
}
function Get-Cfg($key, $default) {
    if ($cfg -and $cfg.PSObject.Properties.Name -contains $key -and $cfg.$key) { return $cfg.$key }
    return $default
}
function Say-OK  ($m) { Write-Host "[OK]   $m" -ForegroundColor Green }
function Say-Info($m) { Write-Host "[INFO] $m" -ForegroundColor Gray }
function Say-Warn($m) { Write-Host "[WARN] $m" -ForegroundColor Yellow }
function Say-Fail($m) { Write-Host "[FAIL] $m" -ForegroundColor Red }

$INSTALL_ROOT = Get-Cfg "INSTALL_ROOT" "C:\DART_DEPLOY"
$ADMIN_USER   = Get-Cfg "AIRFLOW_ADMIN_USER" "admin"
$API_PORT     = [int](Get-Cfg "API_PORT" "8000")

# MEDIA_PATH normalised the same way the deploy script does - a config left
# over from the old layout still points inside the backend checkout.
$MEDIA = Get-Cfg "MEDIA_PATH" "$INSTALL_ROOT\Recon_Files"
if ($MEDIA -match '[\\/]backend[\\/]Data_Recon_Backend[\\/]Recon_Files[\\/]?$') { $MEDIA = "$INSTALL_ROOT\Recon_Files" }
$MEDIA = $MEDIA.TrimEnd('\', '/')

$PW_FILE  = Join-Path $MEDIA "simple_auth_manager_passwords.json.generated"
$ENV_FILE = Join-Path $INSTALL_ROOT ".env"
$AIRFLOW_PORT = Get-Cfg "AIRFLOW_PORT" "8080"
$WSL_DISTRO   = Get-Cfg "WSL_DISTRO"   "Ubuntu-24.04"

Write-Host ""
Write-Host "==========================================" -ForegroundColor DarkCyan
Write-Host "  DART - Sync Airflow admin password"       -ForegroundColor Cyan
Write-Host "==========================================" -ForegroundColor DarkCyan
Say-Info "Password file : $PW_FILE"
Say-Info ".env          : $ENV_FILE"

if (-not (Test-Path $PW_FILE)) {
    Say-Fail "Password file not found. Airflow generates it the first time it starts."
    Say-Warn "  Start Airflow first:  .\VM-Windows-Bash-Script_V2.ps1 -Silent -StepList `"AirflowSetup`""
    exit 1
}
if (-not (Test-Path $ENV_FILE)) {
    Say-Fail "$ENV_FILE not found - run -StepList `"Prerequisites`" first."
    exit 1
}

try { $pwJson = Get-Content $PW_FILE -Raw | ConvertFrom-Json }
catch { Say-Fail "Could not parse $PW_FILE : $($_.Exception.Message)"; exit 1 }

if ($pwJson.PSObject.Properties.Name -notcontains $ADMIN_USER) {
    Say-Fail "No entry for user '$ADMIN_USER' in the password file. It contains: $($pwJson.PSObject.Properties.Name -join ', ')"
    exit 1
}
$realPw = $pwJson.$ADMIN_USER
Say-OK "Found password for '$ADMIN_USER' in the generated file."

# What .env holds today. Case-SENSITIVE match: airflow_admin_password and
# AIRFLOW_ADMIN_PASSWORD are separate lines and must not overwrite each other.
$envLines = @(Get-Content $ENV_FILE)
$currentLine = $envLines | Where-Object { $_ -cmatch '^\s*airflow_admin_password\s*=' } | Select-Object -First 1
$current = if ($currentLine) { ($currentLine -replace '^\s*airflow_admin_password\s*=', '').Trim() } else { $null }

if ($null -eq $current) { Say-Warn ".env has no 'airflow_admin_password' line - Django is falling back to the default in settings.py." }
elseif ($current -ceq $realPw) { Say-OK ".env already matches the generated password." }
else { Say-Warn ".env has a DIFFERENT password than the generated file - updating." }

if ($WhatIf) {
    Say-Info "-WhatIf: would set airflow_admin_password / AIRFLOW_ADMIN_PASSWORD (and the matching user keys) in $ENV_FILE."
    exit 0
}

# Detect live WSL2 IP to also sync airflow_base_url
$wslVmIp = $null
try {
    $wslRawVm = (& wsl -d $WSL_DISTRO -u root bash -c "hostname -I | cut -d' ' -f1" 2>$null | Out-String)
    $wslVmIp  = ($wslRawVm -replace "`0", "" -replace "`r", "").Trim()
    if ($wslVmIp -notmatch '^\d{1,3}(\.\d{1,3}){3}$') { $wslVmIp = $null }
} catch { $wslVmIp = $null }

$syncPairs = @(
    @('airflow_admin_user',     $ADMIN_USER),
    @('airflow_admin_password', $realPw),
    @('AIRFLOW_ADMIN_USER',     $ADMIN_USER),
    @('AIRFLOW_ADMIN_PASSWORD', $realPw)
)
if ($wslVmIp) {
    $afLiveUrl = "http://${wslVmIp}:${AIRFLOW_PORT}/api/v2"
    $syncPairs += ,@('airflow_base_url', $afLiveUrl)
    $syncPairs += ,@('AIRFLOW_BASE_URL', $afLiveUrl)
}

foreach ($pair in $syncPairs) {
    $k = $pair[0]; $v = $pair[1]; $hit = $false
    $envLines = foreach ($line in $envLines) {
        if ($line -cmatch "^\s*$([regex]::Escape($k))\s*=") { $hit = $true; "$k=$v" } else { $line }
    }
    if (-not $hit) { $envLines = @($envLines) + "$k=$v" }
}
# BOM-less: a BOM on line 1 makes Django read the first key name with a
# zero-width prefix, so that setting silently goes missing.
[System.IO.File]::WriteAllLines($ENV_FILE, [string[]]$envLines, (New-Object System.Text.UTF8Encoding($false)))
Say-OK "Wrote airflow_admin_user/password (both cases) into $ENV_FILE."

# --- 2. The backend's OWN committed .env ---------------------------------
# backend\Data_Recon_Backend\.env ships committed in the repo and sits CLOSER
# to settings.py than $INSTALL_ROOT\.env. Django's env loader walks up from
# settings.py and does not override an already-set key, so whichever file it
# reaches first wins - which means writing only to the deployment .env can
# leave Django reading a completely different value. Tracked as ISSUE-B01.
$BACKEND_ENV = Join-Path $INSTALL_ROOT "backend\Data_Recon_Backend\.env"
if (Test-Path $BACKEND_ENV) {
    $bLines = @(Get-Content $BACKEND_ENV)
    foreach ($pair in $syncPairs) {
        $k = $pair[0]; $v = $pair[1]; $hit = $false
        $bLines = foreach ($line in $bLines) {
            if ($line -cmatch "^\s*$([regex]::Escape($k))\s*=") { $hit = $true; "$k=$v" } else { $line }
        }
        if (-not $hit) { $bLines = @($bLines) + "$k=$v" }
    }
    [System.IO.File]::WriteAllLines($BACKEND_ENV, [string[]]$bLines, (New-Object System.Text.UTF8Encoding($false)))
    Say-OK "Also updated the backend's own .env ($BACKEND_ENV) - it shadows the deployment one."
} else {
    Say-Info "No backend-local .env at $BACKEND_ENV (nothing to shadow)."
}

# --- 3. The hardcoded fallback inside settings.py ------------------------
# settings.py reads:
#     AIRFLOW_ADMIN_PASSWORD = os.environ.get("airflow_admin_password", "<literal>")
# That literal is only used when the env var is absent - but when it IS used,
# a stale value authenticates against Airflow with the wrong password and the
# failure looks like an Airflow problem rather than a config one. Replacing it
# makes the fallback correct too, so the app works either way.
$SETTINGS_PY = Join-Path $INSTALL_ROOT "backend\Data_Recon_Backend\Data_Recon_Main\Data_Recon_Main\settings.py"
if (Test-Path $SETTINGS_PY) {
    $sTxt = [System.IO.File]::ReadAllText($SETTINGS_PY)
    $pattern = '(os\.environ\.get\(\s*["'']airflow_admin_password["'']\s*,\s*["''])([^"'']*)(["''])'
    $m = [regex]::Match($sTxt, $pattern)
    if (-not $m.Success) {
        Say-Warn "Could not find the airflow_admin_password fallback in settings.py - left untouched."
    } elseif ($m.Groups[2].Value -ceq $realPw) {
        Say-OK "settings.py fallback already matches the generated password."
    } else {
        $old = $m.Groups[2].Value
        $sNew = [regex]::Replace($sTxt, $pattern, "`${1}$realPw`${3}")
        Copy-Item $SETTINGS_PY "$SETTINGS_PY.bak" -Force -ErrorAction SilentlyContinue
        [System.IO.File]::WriteAllText($SETTINGS_PY, $sNew)
        Say-OK "settings.py fallback updated: '$old' -> '$realPw'  (backup: settings.py.bak)"
        Say-Warn "  NOTE: settings.py is tracked in git. Every step that syncs the backend repo runs"
        Say-Warn "  'git reset --hard', which will REVERT this edit. The env var is the durable fix;"
        Say-Warn "  this only makes the fallback correct in the meantime. Ask the dev team to stop"
        Say-Warn "  hardcoding a password default in settings.py."
    }
} else {
    Say-Info "settings.py not found at $SETTINGS_PY - skipped."
}

if ($NoRestart) {
    Say-Warn "-NoRestart: Django will keep using its OLD environment until the backend is restarted."
    exit 0
}

# --- Restart the backend so Django re-reads .env -------------------------
# Django reads .env once, at process start. Without this the file is correct
# and the running app still authenticates with the previous password.
Write-Host ""
Say-Info "Restarting the backend so Django re-reads .env..."

$conn = Get-NetTCPConnection -LocalPort $API_PORT -State Listen -ErrorAction SilentlyContinue
if ($conn) {
    foreach ($p in ($conn.OwningProcess | Select-Object -Unique)) {
        if (Get-Process -Id $p -ErrorAction SilentlyContinue) {
            Say-Info "  taskkill /PID $p /T /F"
            & taskkill /PID $p /T /F 2>&1 | ForEach-Object { Say-Info "    $_" }
        }
    }
    $spent = 0
    while ($spent -lt 20 -and (Get-NetTCPConnection -LocalPort $API_PORT -State Listen -ErrorAction SilentlyContinue)) {
        Start-Sleep -Seconds 2; $spent += 2
    }
}

$stillHeld = Get-NetTCPConnection -LocalPort $API_PORT -State Listen -ErrorAction SilentlyContinue
if ($stillHeld) {
    Say-Fail "Port $API_PORT is still held - DART-Start.ps1 would skip Uvicorn and the old password would stay live."
    Say-Warn "  netstat -ano | findstr `":$API_PORT`""
    Say-Warn "  If nothing owns it, reboot - that releases an orphaned socket."
    exit 1
}
Say-OK "Port $API_PORT is free."

$startScript = Join-Path $_scriptDir "DART-Start.ps1"
if (Test-Path $startScript) {
    Say-Info "Running DART-Start.ps1..."
    & powershell -ExecutionPolicy Bypass -File $startScript
} else {
    Say-Warn "DART-Start.ps1 not found next to this script - start the backend yourself."
}

Write-Host ""
Say-Info "Verify with:"
Say-Info "  Get-Content `"$ENV_FILE`" | Select-String airflow_admin_password"
