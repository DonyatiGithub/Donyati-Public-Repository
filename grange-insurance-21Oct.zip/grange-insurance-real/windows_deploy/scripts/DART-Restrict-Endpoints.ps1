# ===========================================================================
#  DART - OUTBOUND RESTRICTION (dress rehearsal for the locked-down VM)
#
#  Turns THIS machine into the restricted box before IT turns the real one
#  into it: default-deny outbound, with only the DART allowlist permitted.
#  Then you run the real installer against it and find out - here, on a
#  throwaway VM, where a mistake costs nothing - whether the list you are
#  about to hand IT is actually sufficient.
#
#  ----------------------------------------------------------------------
#  READ THIS FIRST - what this can and cannot faithfully simulate
#  ----------------------------------------------------------------------
#  Windows Firewall has NO domain-based rules. New-NetFirewallRule accepts
#  addresses, never hostnames. So "allow only these domains" cannot be
#  expressed directly and this script has to resolve the allowlist to IPs
#  and permit those. Two consequences you must plan around:
#
#   1. CDN IP ROTATION -> FALSE FAILURES. python.org, the VS Build Tools
#      CDN, npm and the Ubuntu mirrors are all CDN-fronted and answer with
#      different addresses over time and per query. An IP snapshot taken at
#      -Enable goes stale DURING a multi-hour install. The refresher below
#      re-resolves every -RefreshSeconds to keep up, but a brand-new edge
#      IP can still be denied for up to one refresh interval. So: a block
#      recorded here is a LEAD, not a verdict. Confirm it against the
#      hostname before telling IT a domain is missing.
#
#   2. WSL2 MAY BYPASS THIS ENTIRELY -> FALSE PASS. WSL2 egress leaves
#      through the Hyper-V virtual switch, and on many Windows builds host
#      Windows Firewall rules do not filter it at all. If the Airflow step
#      (apt + ~80 pip packages, all from inside WSL) sails through while
#      everything else is restricted, that may mean WSL was never
#      restricted - not that the allowlist covers it. This script detects
#      Hyper-V firewall support and reports what it found; treat an
#      unfiltered WSL as "untested", not "passed".
#
#  For a hostname-accurate rehearsal you need a filtering proxy or an
#  SNI-aware network firewall (on AWS: Network Firewall with domain rules),
#  not a host firewall. This script is the pragmatic no-extra-software
#  approximation - its real deliverable is the BLOCK LOG, which tells you
#  exactly what a deny-by-default box refused.
#
#  ----------------------------------------------------------------------
#  SAFETY
#  ----------------------------------------------------------------------
#   - Existing RDP sessions survive. These are OUTBOUND rules and Windows
#     Firewall is stateful, so traffic belonging to an inbound-initiated
#     RDP connection is not affected.
#   - A dead-man's switch is armed on every -Enable: a SYSTEM scheduled
#     task reverts everything after -AutoRevertMinutes even if this script,
#     this window, or the whole session dies.
#   - DNS, DHCP, the local subnet and the cloud metadata endpoint are
#     always permitted. Without DNS the box cannot resolve anything, the
#     refresher cannot work, and every single failure looks like a blocked
#     domain.
#   - -Revert puts every setting back, including the firewall log config.
#
#  ----------------------------------------------------------------------
#  USAGE
#  ----------------------------------------------------------------------
#    .\DART-Restrict-Endpoints.ps1 -DryRun     # resolve + print the plan
#    .\DART-Restrict-Endpoints.ps1 -Enable     # ARM default-deny outbound
#    ... run .\VM-Windows-Bash-Script_V2.ps1 -Silent ...
#    .\DART-Restrict-Endpoints.ps1 -ShowBlocked  # what got denied
#    .\DART-Restrict-Endpoints.ps1 -Revert     # put the machine back
#
#  Run DART-Capture-Endpoints.ps1 -Start alongside this. The firewall log
#  gives you denied ADDRESSES; the DNS log gives you the NAMES that were
#  being looked up at that moment. Correlating the two is what turns a
#  blocked IP into "you are missing this domain".
# ===========================================================================
param(
    [switch]$Enable,
    [switch]$Revert,
    [switch]$Status,
    [switch]$ShowBlocked,
    [switch]$DryRun,

    # Hostnames to permit, on top of whatever is discovered from the check
    # CSV. This is where the UNKNOWN hosts that DART-Capture-Endpoints.ps1
    # finds (VS Build Tools CDN, Microsoft Store / WSL delivery) go once you
    # have measured them.
    [string[]]$ExtraHosts = @(),

    # Plain text file, one hostname (or host:port) per line, '#' for
    # comments. The natural place to keep the real list once it stabilises.
    [string]$HostsFile = "",

    # Defaults to the CSV DART-Check-Endpoints.ps1 writes, so what you
    # ENFORCE is exactly what you VERIFIED - rather than a third hand-typed
    # copy of the same list that can drift from both.
    [string]$FromCheckCsv = "",

    [int]$AutoRevertMinutes = 240,
    [int]$RefreshSeconds    = 60,
    [switch]$Force
)

$RULE_PREFIX = "DART-Restrict"
$STATE_FILE  = Join-Path $env:ProgramData "DART-Restrict-state.json"
$MAP_FILE    = Join-Path $env:ProgramData "DART-Restrict-hostmap.json"
# The firewall log MUST live under the standard Firewall log directory. The
# Windows Firewall service (MpsSvc) runs restricted and only has write ACLs
# there - point it at ProgramData or a user folder and logging silently
# never starts, leaving -ShowBlocked permanently empty and this whole
# exercise reporting "nothing was denied" on a box that denied plenty.
$FW_LOG      = Join-Path $env:SystemRoot "System32\LogFiles\Firewall\dart-restrict.log"

function Say ($m, $c = "Gray") { Write-Host $m -ForegroundColor $c }
function Head($m) {
    Write-Host ""
    Write-Host ("=" * 74) -ForegroundColor DarkCyan
    Write-Host "  $m" -ForegroundColor Cyan
    Write-Host ("=" * 74) -ForegroundColor DarkCyan
}

$_scriptDir = if ($PSScriptRoot) { $PSScriptRoot } else { (Get-Location).Path }
$isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()
           ).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)

if (-not ($Enable -or $Revert -or $Status -or $ShowBlocked -or $DryRun)) {
    Say "Pick one:  -DryRun | -Enable | -ShowBlocked | -Status | -Revert" "Yellow"
    exit 1
}

# ===========================================================================
#  Build the allowlist
# ===========================================================================
function Get-AllowedTargets {
    $targets = @{}   # "host" -> [int[]] ports

    function Add-Target([string]$h, [int]$p) {
        if (-not $h) { return }
        $h = $h.Trim().TrimEnd('.').ToLower()
        if (-not $h) { return }
        if ($h -match '[*()\s]') {
            Say "  [SKIP] '$h' is a wildcard/placeholder - a firewall rule needs a concrete host." "Yellow"
            return
        }
        if (-not $targets.ContainsKey($h)) { $targets[$h] = @() }
        if ($targets[$h] -notcontains $p) { $targets[$h] += $p }
    }

    # Parses every shape the check CSV emits:
    #   https://pypi.org/simple/        -> pypi.org:443
    #   http://archive.ubuntu.com/...   -> archive.ubuntu.com:80
    #   smtp-legacy.office365.com:587   -> that host:587
    #   WSL -> pypi.org:443             -> pypi.org:443
    function Parse-Entry([string]$raw) {
        if (-not $raw) { return }
        $v = $raw.Trim()
        if ($v -match '->\s*(.+)$') { $v = $matches[1].Trim() }
        if ($v -match '^(https?)://') {
            try {
                $u = [uri]$v
                Add-Target $u.Host $(if ($u.Port -gt 0) { $u.Port } elseif ($u.Scheme -eq 'https') { 443 } else { 80 })
            } catch { Say "  [SKIP] could not parse URL '$v'" "Yellow" }
            return
        }
        if ($v -match '^([A-Za-z0-9._-]+):(\d+)$') { Add-Target $matches[1] ([int]$matches[2]); return }
        if ($v -match '^[A-Za-z0-9._-]+\.[A-Za-z]{2,}$') { Add-Target $v 443; return }
        Say "  [SKIP] '$v' is not a host or URL." "Yellow"
    }

    $csv = if ($FromCheckCsv) { $FromCheckCsv } else { Join-Path $env:TEMP "dart_endpoint_check.csv" }
    if (Test-Path $csv) {
        Say "  Source: check CSV  $csv" "DarkGray"
        $rows = @(Import-Csv $csv)
        # A CSV produced by `DART-Check-Endpoints.ps1 -SkipRuntime` has no
        # Runtime-* rows, so Azure Blob and SMTP would be missing from the
        # allowlist. The install would still pass - those are not install-time
        # endpoints - and the app would then fail at runtime on a box that
        # this exercise had just certified. Loud, because the failure it
        # prevents shows up long after the run that caused it.
        if (-not ($rows | Where-Object { $_.Step -like 'Runtime-*' })) {
            Say "  [WARN] This CSV has no Runtime-* rows - it looks like it came from a" "Yellow"
            Say "         -SkipRuntime run, so Azure Blob and SMTP are NOT in this allowlist." "Yellow"
            Say "         Re-run DART-Check-Endpoints.ps1 without -SkipRuntime, or the app will" "Yellow"
            Say "         install cleanly and then fail the first time it sends mail or hits Blob." "Yellow"
        }
        foreach ($row in $rows) {
            # MANUAL rows are wildcards/placeholders by definition and cannot
            # become a rule; FAIL rows are hosts that were already
            # unreachable, and enforcing them changes nothing.
            if ($row.Result -like 'FAIL*') { continue }
            Parse-Entry $row.Url
        }
    } else {
        Say "  [WARN] No check CSV at $csv - run DART-Check-Endpoints.ps1 first, or pass -HostsFile." "Yellow"
    }

    # dart_extra_hosts.txt sitting next to this script is picked up with no
    # flag at all, so hosts discovered by DART-Capture-Endpoints.ps1 get
    # written down ONCE and every later run - -DryRun included - inherits
    # them. Passing -ExtraHosts by hand on every invocation is how one gets
    # forgotten and a "clean" rehearsal certifies an allowlist that is
    # missing an endpoint.
    $autoHosts = Join-Path $_scriptDir "dart_extra_hosts.txt"
    $hostFiles = @()
    if (Test-Path $autoHosts) { $hostFiles += $autoHosts }
    if ($HostsFile) {
        if (Test-Path $HostsFile) { $hostFiles += $HostsFile }
        else { Say "  [WARN] -HostsFile '$HostsFile' not found." "Yellow" }
    }
    foreach ($hf in $hostFiles) {
        $n = 0
        foreach ($line in (Get-Content $hf)) {
            $l = $line.Trim()
            if (-not $l -or $l.StartsWith('#')) { continue }
            Parse-Entry $l
            $n++
        }
        Say "  Source: hosts file $hf ($n entr$(if ($n -eq 1) {'y'} else {'ies'}))" "DarkGray"
    }

    foreach ($h in $ExtraHosts) { Parse-Entry $h }
    return $targets
}

function Resolve-Targets($targets) {
    $map = @{}
    foreach ($h in ($targets.Keys | Sort-Object)) {
        $ips = @()
        try {
            $ips = (Resolve-DnsName -Name $h -Type A -ErrorAction Stop |
                    Where-Object { $_.IPAddress } |
                    Select-Object -ExpandProperty IPAddress -Unique)
        } catch { }
        if (-not $ips) {
            Say ("  [WARN] {0,-46} did not resolve - it will NOT be reachable." -f $h) "Yellow"
        }
        $map[$h] = [PSCustomObject]@{ Ports = $targets[$h]; IPs = @($ips) }
    }
    return $map
}

# ===========================================================================
#  -DryRun / plan
# ===========================================================================
if ($DryRun) {
    Head "DART - restriction PLAN (nothing is changed)"
    $targets = Get-AllowedTargets
    if (-not $targets.Count) { Say "[FAIL] Allowlist is empty - nothing to do." "Red"; exit 1 }
    Say "  Resolving $($targets.Count) host(s)..." "Gray"
    $map = Resolve-Targets $targets
    Write-Host ""
    Write-Host ("  {0,-46} {1,-12} {2}" -f "HOST", "PORTS", "RESOLVED") -ForegroundColor Cyan
    Write-Host ("  " + ("-" * 88)) -ForegroundColor DarkGray
    $ipTotal = 0
    foreach ($h in ($map.Keys | Sort-Object)) {
        $e = $map[$h]; $ipTotal += @($e.IPs).Count
        Write-Host ("  {0,-46} {1,-12} {2}" -f $h, ($e.Ports -join ','), (@($e.IPs) -join ' '))
    }
    Write-Host ""
    Say "  $($targets.Count) hosts -> $ipTotal addresses would be allowed; everything else outbound denied." "Green"
    Say "  Re-run with -Enable to actually apply it." "DarkGray"
    exit 0
}

# ===========================================================================
#  -ShowBlocked
# ===========================================================================
if ($ShowBlocked) {
    Head "DART - outbound connections DENIED while restricted"
    # The Firewall log directory is ACL'd to admins and MpsSvc, so reading it
    # from a normal shell returns "not found" rather than a permission error -
    # which reads as "nothing was blocked" and is the most misleading possible
    # answer here.
    if (-not $isAdmin) {
        Say "[FAIL] Run this in an ADMIN PowerShell - the firewall log directory is not readable otherwise." "Red"
        exit 1
    }
    if (-not (Test-Path $FW_LOG)) {
        Say "[FAIL] No firewall log at $FW_LOG - was -Enable run?" "Red"
        exit 1
    }
    $hostMap = @{}
    if (Test-Path $MAP_FILE) {
        $raw = Get-Content $MAP_FILE -Raw | ConvertFrom-Json
        foreach ($p in $raw.PSObject.Properties) {
            foreach ($ip in $p.Value.IPs) { $hostMap[$ip] = $p.Name }
        }
    }

    # pfirewall.log columns: date time action protocol src dst srcport dstport ...
    $drops = @{}
    foreach ($line in (Get-Content $FW_LOG -ErrorAction SilentlyContinue)) {
        if ($line.StartsWith('#') -or -not $line.Trim()) { continue }
        $f = $line -split '\s+'
        if ($f.Count -lt 8) { continue }
        if ($f[2] -ne 'DROP') { continue }
        $dst = $f[5]; $dport = $f[7]
        if ($dst -in @('127.0.0.1','::1','0.0.0.0') -or $dst -like '224.*' -or $dst -like 'ff*') { continue }
        $key = "$dst`:$dport"
        if (-not $drops.ContainsKey($key)) {
            $drops[$key] = [PSCustomObject]@{
                Endpoint = $key; Count = 0; FirstSeen = "$($f[0]) $($f[1])"
                KnownHost = $(if ($hostMap.ContainsKey($dst)) { $hostMap[$dst] } else { '' })
            }
        }
        $drops[$key].Count++
    }

    if (-not $drops.Count) {
        Say "  Nothing was denied. Either the allowlist is complete, or nothing tried to leave yet." "Green"
        Say "  Remember the WSL2 caveat in this script's header before reading that as a pass." "DarkGray"
        exit 0
    }

    # An IP that maps back to an ALLOWED host is the CDN-rotation artifact
    # described in the header - the host is permitted, this particular edge
    # address just was not in the set yet. That is a refresher-timing issue,
    # NOT a missing domain, and reporting the two the same way is how you
    # end up asking IT to open something that is already open.
    $rotated = $drops.Values | Where-Object { $_.KnownHost } | Sort-Object Count -Descending
    $unknown = $drops.Values | Where-Object { -not $_.KnownHost } | Sort-Object Count -Descending

    Write-Host ""
    Write-Host ("  ---- DENIED, host NOT on the allowlist  ({0}) ----" -f @($unknown).Count) -ForegroundColor Yellow
    Write-Host "       These are the real findings. Correlate each with DART-Capture-Endpoints.ps1's" -ForegroundColor DarkGray
    Write-Host "       DNS log (same timestamps) to turn the address into a domain name." -ForegroundColor DarkGray
    if (-not $unknown) { Write-Host "       (none)" -ForegroundColor DarkGray }
    foreach ($d in $unknown) {
        Write-Host ("       {0,-28} x{1,-6} first {2}" -f $d.Endpoint, $d.Count, $d.FirstSeen) -ForegroundColor Yellow
    }

    Write-Host ""
    Write-Host ("  ---- DENIED, but the host IS allowed  ({0}) ----" -f @($rotated).Count) -ForegroundColor DarkGray
    Write-Host "       CDN rotation, not a missing domain - a new edge IP appeared between" -ForegroundColor DarkGray
    Write-Host "       refreshes. Lower -RefreshSeconds if these are causing install failures." -ForegroundColor DarkGray
    if (-not $rotated) { Write-Host "       (none)" -ForegroundColor DarkGray }
    foreach ($d in $rotated) {
        Write-Host ("       {0,-28} x{1,-6} {2}" -f $d.Endpoint, $d.Count, $d.KnownHost) -ForegroundColor DarkGray
    }

    $outCsv = Join-Path $env:TEMP ("dart_blocked_{0}.csv" -f (Get-Date -Format "yyyyMMdd_HHmmss"))
    $drops.Values | Sort-Object Count -Descending | Export-Csv -Path $outCsv -NoTypeInformation -Encoding UTF8
    Write-Host ""
    Say "  Full denial list: $outCsv" "Cyan"
    exit 0
}

# ===========================================================================
#  -Status
# ===========================================================================
if ($Status) {
    Head "DART - restriction status"
    $rules = Get-NetFirewallRule -DisplayName "$RULE_PREFIX*" -ErrorAction SilentlyContinue
    if (-not $rules) { Say "  No $RULE_PREFIX rules present - the machine is NOT restricted by this script." "Green" }
    else {
        Say "  $(@($rules).Count) rule(s) active:" "Yellow"
        foreach ($r in $rules) { Say ("    {0,-44} {1}" -f $r.DisplayName, $r.Action) "Gray" }
    }
    foreach ($p in (Get-NetFirewallProfile)) {
        $c = if ($p.DefaultOutboundAction -eq 'Block') { 'Yellow' } else { 'Green' }
        Say ("  profile {0,-10} DefaultOutboundAction = {1}" -f $p.Name, $p.DefaultOutboundAction) $c
    }
    if (Test-Path $STATE_FILE) {
        $st = Get-Content $STATE_FILE -Raw | ConvertFrom-Json
        Say "  Enabled at      : $($st.EnabledAt)" "DarkGray"
        Say "  Auto-revert at  : $($st.AutoRevertAt)" "DarkGray"
        Say "  Refresher PID   : $($st.RefresherPid)" "DarkGray"
    }
    $task = Get-ScheduledTask -TaskName "DART-Restrict-AutoRevert" -ErrorAction SilentlyContinue
    if ($task) { Say "  Dead-man's switch task is registered ($($task.State))." "DarkGray" }
    exit 0
}

# --- everything past here changes machine state ---------------------------
if (-not $isAdmin) {
    Say "[FAIL] Run this in an ADMIN PowerShell - firewall changes need it." "Red"
    exit 1
}

# ===========================================================================
#  -Revert
# ===========================================================================
if ($Revert) {
    Head "DART - reverting outbound restriction"

    $st = $null
    if (Test-Path $STATE_FILE) { try { $st = Get-Content $STATE_FILE -Raw | ConvertFrom-Json } catch { } }

    if ($st -and $st.RefresherPid) {
        Stop-Process -Id $st.RefresherPid -Force -ErrorAction SilentlyContinue
        Say "  Refresher stopped (PID $($st.RefresherPid))." "DarkGray"
    }

    # Restore the per-profile outbound policy FIRST. If rule removal were to
    # fail halfway with the default still set to Block, the machine would be
    # left with no allow rules AND deny-by-default - offline.
    if ($st -and $st.Profiles) {
        foreach ($p in $st.Profiles) {
            try {
                Set-NetFirewallProfile -Name $p.Name -DefaultOutboundAction $p.DefaultOutboundAction `
                    -LogBlocked $([bool]::Parse("$($p.LogBlocked)")) -LogFileName $p.LogFileName -ErrorAction Stop
                Say "  profile $($p.Name) restored (outbound=$($p.DefaultOutboundAction))." "Gray"
            } catch { Say "  [WARN] could not fully restore profile $($p.Name): $($_.Exception.Message)" "Yellow" }
        }
    } else {
        # No state file (script was interrupted, or the dead-man's switch is
        # firing on a box whose state file was removed). Fail SAFE: the only
        # sane default here is to put outbound back to Allow.
        Say "  [WARN] No saved state - setting every profile back to Allow as the safe default." "Yellow"
        Set-NetFirewallProfile -All -DefaultOutboundAction Allow -ErrorAction SilentlyContinue
    }

    $rules = Get-NetFirewallRule -DisplayName "$RULE_PREFIX*" -ErrorAction SilentlyContinue
    foreach ($r in $rules) { Remove-NetFirewallRule -Name $r.Name -ErrorAction SilentlyContinue }
    Say "  Removed $(@($rules).Count) $RULE_PREFIX rule(s)." "Gray"

    if (Get-ScheduledTask -TaskName "DART-Restrict-AutoRevert" -ErrorAction SilentlyContinue) {
        Unregister-ScheduledTask -TaskName "DART-Restrict-AutoRevert" -Confirm:$false -ErrorAction SilentlyContinue
        Say "  Dead-man's switch unregistered." "DarkGray"
    }

    Remove-Item $STATE_FILE -Force -ErrorAction SilentlyContinue
    Say "  The firewall log is kept for analysis: $FW_LOG" "DarkGray"

    $stillBlocked = Get-NetFirewallProfile | Where-Object { $_.DefaultOutboundAction -eq 'Block' }
    if ($stillBlocked) {
        Say "[FAIL] These profiles are STILL deny-by-default: $(($stillBlocked.Name) -join ', ')" "Red"
        Say "       Fix by hand:  Set-NetFirewallProfile -All -DefaultOutboundAction Allow" "Yellow"
        exit 1
    }
    Head "Outbound restriction removed - the machine is back to normal"
    exit 0
}

# ===========================================================================
#  -Enable
# ===========================================================================
Head "DART - ARMING outbound restriction (default-deny)"

if (Get-NetFirewallRule -DisplayName "$RULE_PREFIX*" -ErrorAction SilentlyContinue) {
    Say "[FAIL] $RULE_PREFIX rules already exist - run -Revert before enabling again." "Red"
    exit 1
}

$targets = Get-AllowedTargets
if (-not $targets.Count) { Say "[FAIL] Allowlist is empty - refusing to deny everything." "Red"; exit 1 }

Say "  Resolving $($targets.Count) host(s)..." "Gray"
$map = Resolve-Targets $targets
$allIPs = @($map.Values | ForEach-Object { $_.IPs } | Select-Object -Unique)
if (-not $allIPs) { Say "[FAIL] Nothing resolved - refusing to deny everything." "Red"; exit 1 }

$allPorts = @($map.Values | ForEach-Object { $_.Ports } | Select-Object -Unique | Sort-Object)

Write-Host ""
Say "  $($targets.Count) hosts -> $($allIPs.Count) addresses, ports $($allPorts -join ',')" "Gray"
Say "  Everything else outbound will be DENIED on every profile." "Yellow"
Say "  Auto-revert in $AutoRevertMinutes min; refresh every $RefreshSeconds s." "Gray"
Write-Host ""
Say "  Existing RDP sessions are unaffected (these are outbound rules and the" "DarkGray"
Say "  firewall is stateful), but anything else this box reaches out to - agents," "DarkGray"
Say "  backups, monitoring, your own tooling - stops until you -Revert." "DarkGray"

if (-not $Force) {
    $ans = Read-Host "`nType RESTRICT to arm deny-by-default outbound"
    if ($ans -cne 'RESTRICT') { Say "Aborted - nothing changed." "Red"; exit 1 }
}

# --- save state BEFORE changing anything ----------------------------------
# Written first, deliberately. If this script dies midway, -Revert (and the
# dead-man's switch) still know what the original settings were. Writing it
# afterwards would leave the one case that actually needs it uncovered.
$profiles = @()
foreach ($p in (Get-NetFirewallProfile)) {
    $profiles += [PSCustomObject]@{
        Name = $p.Name; DefaultOutboundAction = "$($p.DefaultOutboundAction)"
        LogBlocked = "$($p.LogBlocked)"; LogFileName = "$($p.LogFileName)"
    }
}
$state = [PSCustomObject]@{
    EnabledAt    = (Get-Date).ToString('o')
    AutoRevertAt = (Get-Date).AddMinutes($AutoRevertMinutes).ToString('o')
    Profiles     = $profiles
    RefresherPid = $null
}
$state | ConvertTo-Json -Depth 5 | Set-Content -Path $STATE_FILE -Encoding UTF8
$map   | ConvertTo-Json -Depth 5 | Set-Content -Path $MAP_FILE   -Encoding UTF8

# --- dead-man's switch, armed BEFORE the block goes on --------------------
# SYSTEM/ServiceAccount so it needs no stored password (the problem
# DART-Start.ps1 had to prompt for), and registered before the restriction
# is applied so that a failure during the apply still self-heals.
try {
    if (Get-ScheduledTask -TaskName "DART-Restrict-AutoRevert" -ErrorAction SilentlyContinue) {
        Unregister-ScheduledTask -TaskName "DART-Restrict-AutoRevert" -Confirm:$false -ErrorAction SilentlyContinue
    }
    $selfPath = Join-Path $_scriptDir "DART-Restrict-Endpoints.ps1"
    $act = New-ScheduledTaskAction -Execute "powershell.exe" `
             -Argument "-ExecutionPolicy Bypass -NoProfile -File `"$selfPath`" -Revert -Force"
    $trg = New-ScheduledTaskTrigger -Once -At (Get-Date).AddMinutes($AutoRevertMinutes)
    $prn = New-ScheduledTaskPrincipal -UserId "SYSTEM" -LogonType ServiceAccount -RunLevel Highest
    Register-ScheduledTask -TaskName "DART-Restrict-AutoRevert" -Action $act -Trigger $trg -Principal $prn | Out-Null
    Say "  Dead-man's switch armed - auto-revert at $((Get-Date).AddMinutes($AutoRevertMinutes).ToString('HH:mm:ss'))." "Green"
} catch {
    Say "[FAIL] Could not arm the auto-revert task: $($_.Exception.Message)" "Red"
    Say "       Refusing to restrict without a way back. Nothing changed." "Yellow"
    Remove-Item $STATE_FILE -Force -ErrorAction SilentlyContinue
    exit 1
}

# --- infrastructure allows ------------------------------------------------
# Without these the box is not "restricted", it is bricked: no DNS means
# nothing resolves (including for the refresher), and no local subnet means
# management traffic and the app's own service-to-service calls die too.
$dnsServers = @(Get-DnsClientServerAddress -AddressFamily IPv4 -ErrorAction SilentlyContinue |
                ForEach-Object { $_.ServerAddresses } | Where-Object { $_ } | Select-Object -Unique)
if ($dnsServers) {
    New-NetFirewallRule -DisplayName "$RULE_PREFIX-DNS" -Direction Outbound -Action Allow `
        -Protocol UDP -RemotePort 53 -RemoteAddress $dnsServers -ErrorAction SilentlyContinue | Out-Null
    New-NetFirewallRule -DisplayName "$RULE_PREFIX-DNS-TCP" -Direction Outbound -Action Allow `
        -Protocol TCP -RemotePort 53 -RemoteAddress $dnsServers -ErrorAction SilentlyContinue | Out-Null
    Say "  DNS allowed to: $($dnsServers -join ', ')" "Gray"
} else {
    Say "  [WARN] No IPv4 DNS server found - allowing UDP/53 to any address so the box can still resolve." "Yellow"
    New-NetFirewallRule -DisplayName "$RULE_PREFIX-DNS" -Direction Outbound -Action Allow `
        -Protocol UDP -RemotePort 53 -ErrorAction SilentlyContinue | Out-Null
}
New-NetFirewallRule -DisplayName "$RULE_PREFIX-LocalSubnet" -Direction Outbound -Action Allow `
    -RemoteAddress LocalSubnet -ErrorAction SilentlyContinue | Out-Null
New-NetFirewallRule -DisplayName "$RULE_PREFIX-DHCP" -Direction Outbound -Action Allow `
    -Protocol UDP -RemotePort 67,68 -ErrorAction SilentlyContinue | Out-Null
# 169.254.169.254 is the cloud instance-metadata service. On EC2 the guest
# agent, credential refresh and assorted tooling all depend on it, and
# blocking it produces failures that have nothing to do with this exercise.
New-NetFirewallRule -DisplayName "$RULE_PREFIX-Metadata" -Direction Outbound -Action Allow `
    -RemoteAddress 169.254.169.254 -ErrorAction SilentlyContinue | Out-Null
Say "  Local subnet, DHCP and instance metadata allowed." "Gray"

# --- the allowlist itself -------------------------------------------------
# One rule per PORT carrying every address for that port, rather than one
# rule per host: a few hundred CDN addresses spread over one rule each makes
# the refresher's update slow and the rule list unreadable.
foreach ($port in $allPorts) {
    $ipsForPort = @($map.Values | Where-Object { $_.Ports -contains $port } |
                    ForEach-Object { $_.IPs } | Select-Object -Unique)
    if (-not $ipsForPort) { continue }
    New-NetFirewallRule -DisplayName "$RULE_PREFIX-Allow-$port" -Direction Outbound -Action Allow `
        -Protocol TCP -RemotePort $port -RemoteAddress $ipsForPort -ErrorAction SilentlyContinue | Out-Null
    Say "  allow TCP/$port  -> $($ipsForPort.Count) address(es)" "Gray"
}

# --- logging + the block itself -------------------------------------------
Set-NetFirewallProfile -All -LogBlocked True -LogFileName $FW_LOG -LogMaxSizeKilobytes 32767 -ErrorAction SilentlyContinue
Set-NetFirewallProfile -All -DefaultOutboundAction Block -ErrorAction SilentlyContinue
Say "  Deny-by-default outbound is now ACTIVE. Log: $FW_LOG" "Yellow"

# --- WSL2 reality check ---------------------------------------------------
$hvAvailable = [bool](Get-Command Get-NetFirewallHyperVVMSetting -ErrorAction SilentlyContinue)
if ($hvAvailable) {
    Say "  Hyper-V firewall cmdlets ARE present - WSL2 traffic can be filtered on this build." "Gray"
    Say "  This script does NOT configure them; verify WSL egress separately before trusting a pass." "Yellow"
} else {
    Say "  [WARN] No Hyper-V firewall support on this build - WSL2 egress is very likely" "Yellow"
    Say "         NOT filtered by these rules. If the Airflow step succeeds, treat that as" "Yellow"
    Say "         UNTESTED rather than proven. See this script's header." "Yellow"
}

# --- refresher ------------------------------------------------------------
# Re-resolves the allowlist and folds any new addresses into the rules. This
# is what keeps CDN-fronted hosts working across a long install; without it
# the very first edge-IP rotation looks like a missing domain.
$refresherFile = Join-Path $env:ProgramData "DART-Restrict-refresher.ps1"
$refresherCode = @"
`$ErrorActionPreference = 'SilentlyContinue'
while (`$true) {
    Start-Sleep -Seconds $RefreshSeconds
    `$map = Get-Content '$MAP_FILE' -Raw | ConvertFrom-Json
    `$changed = `$false
    foreach (`$p in `$map.PSObject.Properties) {
        `$fresh = @()
        try {
            `$fresh = (Resolve-DnsName -Name `$p.Name -Type A -ErrorAction Stop |
                       Where-Object { `$_.IPAddress } | Select-Object -ExpandProperty IPAddress -Unique)
        } catch { }
        foreach (`$ip in `$fresh) {
            # @(...) + is deliberate: a one-element JSON array comes back from
            # ConvertFrom-Json as a bare string, and += on a string appends
            # characters instead of growing a list.
            if (@(`$p.Value.IPs) -notcontains `$ip) {
                `$p.Value.IPs = @(`$p.Value.IPs) + `$ip
                `$changed = `$true
            }
        }
    }
    if (`$changed) {
        `$map | ConvertTo-Json -Depth 5 | Set-Content -Path '$MAP_FILE' -Encoding UTF8
        `$ports = @(`$map.PSObject.Properties | ForEach-Object { `$_.Value.Ports } | Select-Object -Unique)
        foreach (`$port in `$ports) {
            `$ips = @(`$map.PSObject.Properties |
                      Where-Object { @(`$_.Value.Ports) -contains `$port } |
                      ForEach-Object { `$_.Value.IPs } | Select-Object -Unique)
            if (`$ips) {
                # Parenthesised: without them PowerShell binds only the literal
                # to -DisplayName and passes '+' and the port as stray
                # positional arguments, so the rule is never actually updated.
                `$ruleName = '$RULE_PREFIX-Allow-' + `$port
                Set-NetFirewallRule -DisplayName `$ruleName -RemoteAddress `$ips -ErrorAction SilentlyContinue
            }
        }
    }
}
"@
[System.IO.File]::WriteAllText($refresherFile, $refresherCode, (New-Object System.Text.UTF8Encoding($false)))
$refresher = Start-Process powershell -ArgumentList "-ExecutionPolicy","Bypass","-NoProfile","-WindowStyle","Hidden","-File",$refresherFile -WindowStyle Hidden -PassThru
$state.RefresherPid = $refresher.Id
$state | ConvertTo-Json -Depth 5 | Set-Content -Path $STATE_FILE -Encoding UTF8
Say "  DNS refresher running (PID $($refresher.Id), every ${RefreshSeconds}s)." "Gray"

Head "RESTRICTED - run the installer now"
Say "  1. (recommended) .\DART-Capture-Endpoints.ps1 -Start   # names for the denied IPs" "DarkGray"
Say "  2. .\VM-Windows-Bash-Script_V2.ps1 -Silent" "DarkGray"
Say "  3. .\DART-Restrict-Endpoints.ps1 -ShowBlocked" "DarkGray"
Say "  4. .\DART-Restrict-Endpoints.ps1 -Revert" "Cyan"
Write-Host ""
Say "  If you lose the session, everything auto-reverts at $((Get-Date).AddMinutes($AutoRevertMinutes).ToString('HH:mm:ss'))." "Green"
exit 0
