# ===========================================================================
#  DART - START ALL SERVICES AFTER EVERY RESTART
#
#  Registered as the "DART-AutoStart" scheduled task. At each logon (after a
#  90-second settle delay) it runs DART-Start.ps1 in a visible window, so
#  PostgreSQL, Nginx, Uvicorn, FastAPI and Airflow come back after a VM
#  restart without anyone running anything.
#
#  AtLogon + Interactive, never AtStartup - same constraint as
#  DART-Resume-Setup.ps1: a task in session 0 cannot run WSL, so Airflow
#  would fail. Consequence: services start when the install account LOGS ON
#  after a restart, not at boot. For a box nobody logs on to, enable Windows
#  auto-logon for that account.
#
#  Registered automatically by DART-Start.ps1 when AUTO_START_AT_LOGON is
#  "true" (the default) in dart_deploy_config.json.
#
#  Skips itself while DART-Resume-Setup is still registered: the first-install
#  resume already ends with DART-Start, and two starts racing each other on
#  PostgreSQL and WSL is exactly the failure this avoids.
#
#  Usage:
#     .\DART-AutoStart.ps1               # what the scheduled task runs
#     .\DART-AutoStart.ps1 -Register     # register / refresh the task
#     .\DART-AutoStart.ps1 -Unregister   # stop auto-starting after restart
#     .\DART-AutoStart.ps1 -Status       # is it registered, last run result
# ===========================================================================
param(
    [string]$ConfigFile = "",
    [switch]$Register,
    [switch]$Unregister,
    [switch]$Status
)

$TASK_NAME = "DART-AutoStart"
$_scriptDir = if ($PSScriptRoot) { $PSScriptRoot } else { (Get-Location).Path }

$cfgPath = if ($ConfigFile -and (Test-Path $ConfigFile)) { $ConfigFile } else { Join-Path $_scriptDir "dart_deploy_config.json" }
$cfg = $null
if (Test-Path $cfgPath) { try { $cfg = Get-Content $cfgPath -Raw -Encoding UTF8 | ConvertFrom-Json } catch { } }
function Get-Cfg($k, $d) { if ($cfg -and $cfg.PSObject.Properties.Name -contains $k -and "$($cfg.$k)" -ne "") { return "$($cfg.$k)" }; return $d }

$INSTALL_ROOT = Get-Cfg "INSTALL_ROOT" "C:\DART_DEPLOY"
$LOG_DIR      = Join-Path $INSTALL_ROOT "logs"
$START_LOG    = Join-Path $LOG_DIR ("autostart_{0}.log" -f (Get-Date -Format "yyyyMMdd_HHmmss"))

function Say($m, $c = "Gray") { Write-Host $m -ForegroundColor $c }

# Set by VM-Windows-Bash-Script_V2.ps1 next to the DART-Resume-Setup task and
# removed by DART-Resume-Setup.ps1 when it finishes. A standard user may not
# be allowed to read that task, so the file is what a not-yet-elevated run
# checks - otherwise the first logon after install would ask for the admin
# password twice (here, then for the resume).
$RESUME_MARKER = Join-Path $INSTALL_ROOT ".resume_pending"

$_isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole(
    [Security.Principal.WindowsBuiltInRole]::Administrator)

# --- -Register -------------------------------------------------------------
if ($Register) {
    try {
        # Which account's logon starts DART? Normally the one running this.
        # But when a standard user elevated with an administrator's
        # credentials, this runs AS the administrator while the desktop - and
        # every later logon - is the standard user's. A task bound to the
        # administrator then never fires (EC2 2026-10-19, dart-test), and one
        # bound to the standard user cannot run Highest. So it is bound to the
        # desktop user at a normal run level, and the run below asks for the
        # administrator password at each logon - the same way the install and
        # DART-Resume-Setup do.
        $runUser  = "$env:USERDOMAIN\$env:USERNAME"
        $deskUser = $null
        try {
            $sess = (Get-Process -Id $PID).SessionId
            $deskUser = (Get-Process explorer -IncludeUserName -ErrorAction Stop |
                         Where-Object { $_.SessionId -eq $sess -and $_.UserName } | Select-Object -First 1).UserName
        } catch { }
        $otherUser = ($deskUser -and $deskUser -ne $runUser)
        $taskUser  = if ($otherUser) { $deskUser } else { $runUser }
        $runLevel  = if ($otherUser) { 'Limited' } else { 'Highest' }

        # Already registered for that account and run level: nothing to do.
        # DART-Start calls -Register on every start, so this keeps it quiet
        # while still correcting a task bound to the wrong account.
        $existing = Get-ScheduledTask -TaskName $TASK_NAME -ErrorAction SilentlyContinue
        if ($existing -and (($existing.Principal.UserId -split '\\')[-1] -eq ($taskUser -split '\\')[-1]) -and
            "$($existing.Principal.RunLevel)" -eq $runLevel) {
            exit 0
        }

        # Same shape as the DART-Resume-Setup task. The delay lets the
        # desktop, network and service control manager settle - PostgreSQL
        # started into that is how an otherwise healthy start fails for no
        # visible reason.
        $act  = New-ScheduledTaskAction -Execute "powershell.exe" `
                    -Argument "-ExecutionPolicy Bypass -NoProfile -File `"$(Join-Path $_scriptDir 'DART-AutoStart.ps1')`"" `
                    -WorkingDirectory $_scriptDir
        $trg  = New-ScheduledTaskTrigger -AtLogOn -User $taskUser
        $trg.Delay = "PT1M30S"
        $prin = New-ScheduledTaskPrincipal -UserId $taskUser -LogonType Interactive -RunLevel $runLevel
        $set  = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries `
                    -ExecutionTimeLimit (New-TimeSpan -Hours 1) -MultipleInstances IgnoreNew
        Register-ScheduledTask -TaskName $TASK_NAME -Action $act -Trigger $trg -Principal $prin -Settings $set `
            -Description "Starts all DART services (DART-Start.ps1) 90 seconds after $taskUser logs on." -Force -ErrorAction Stop | Out-Null
        Say "[OK]   '$TASK_NAME' registered - DART starts 90 seconds after $taskUser logs on." "Green"
        if ($otherUser) {
            Say "       Running as $runUser on $deskUser's desktop: at each logon a DART box asks for the administrator password ($runUser)." "DarkGray"
        }
        exit 0
    } catch {
        Say "[FAIL] Could not register '$TASK_NAME': $($_.Exception.Message)" "Red"
        Say "       Run this from an elevated PowerShell." "Yellow"
        exit 1
    }
}

# --- -Unregister -----------------------------------------------------------
if ($Unregister) {
    if (Get-ScheduledTask -TaskName $TASK_NAME -ErrorAction SilentlyContinue) {
        Unregister-ScheduledTask -TaskName $TASK_NAME -Confirm:$false
        Say "[OK]   '$TASK_NAME' removed - DART will no longer start after a restart." "Yellow"
        Say "       DART-Start.ps1 re-registers it unless AUTO_START_AT_LOGON is set to false in the config." "DarkGray"
    } else {
        Say "[INFO] '$TASK_NAME' is not registered." "Gray"
    }
    exit 0
}

# --- -Status ---------------------------------------------------------------
if ($Status) {
    $t = Get-ScheduledTask -TaskName $TASK_NAME -ErrorAction SilentlyContinue
    if (-not $t) { Say "[INFO] '$TASK_NAME' is NOT registered - DART will not start after a restart." "Yellow"; exit 1 }
    $i = Get-ScheduledTaskInfo -TaskName $TASK_NAME
    Say "[OK]   '$TASK_NAME' registered for $($t.Principal.UserId), state $($t.State)." "Green"
    Say "       Last run: $($i.LastRunTime)   result: 0x$('{0:X}' -f $i.LastTaskResult)" "Gray"
    $last = Get-ChildItem $LOG_DIR -Filter "autostart_*.log" -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending | Select-Object -First 1
    if ($last) { Say "       Last log: $($last.FullName)" "Gray" }
    exit 0
}

# --- Run (what the task executes) --------------------------------------------
if (-not (Test-Path $LOG_DIR)) { New-Item -ItemType Directory -Path $LOG_DIR -Force | Out-Null }
$host.UI.RawUI.WindowTitle = "DART - starting services after restart"

$resumeTask = Get-ScheduledTask -TaskName "DART-Resume-Setup" -ErrorAction SilentlyContinue
if ($resumeTask -or (-not $_isAdmin -and (Test-Path $RESUME_MARKER))) {
    Say "[INFO] DART-Resume-Setup is still pending - it finishes the install and starts DART itself. Skipping." "Yellow"
    Start-Sleep -Seconds 10
    exit 0
}
# Elevated and the task is gone: a marker left behind (resume removed some
# other way) must not block every later auto-start.
if ($_isAdmin -and (Test-Path $RESUME_MARKER)) { Remove-Item $RESUME_MARKER -Force -ErrorAction SilentlyContinue }

# Task bound to a standard user (see -Register): ask for the administrator
# password, exactly like the install did. Cancel = DART stays stopped until
# the next logon or a manual DART-Start.
if (-not $_isAdmin) {
    Add-Type -AssemblyName System.Windows.Forms
    $_ans = [System.Windows.Forms.MessageBox]::Show(
        "DART needs Administrator rights to start its services`n" +
        "(PostgreSQL, Nginx, backend, FastAPI, Airflow) after the restart.`n`n" +
        "OK      - Windows will ask for the administrator account and password`n" +
        "Cancel  - do not start DART now (it will ask again at your next logon)",
        "DART - start services", [System.Windows.Forms.MessageBoxButtons]::OKCancel, [System.Windows.Forms.MessageBoxIcon]::Information)
    if ($_ans -ne [System.Windows.Forms.DialogResult]::OK) {
        Say "[INFO] DART not started - Administrator rights were not granted. Start it later with DART-Start.ps1." "Yellow"
        Start-Sleep -Seconds 10
        exit 0
    }
    $_relaunchArgs = @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', "`"$PSCommandPath`"")
    if ($ConfigFile) { $_cf = (Resolve-Path -LiteralPath $ConfigFile -ErrorAction SilentlyContinue).Path; if (-not $_cf) { $_cf = $ConfigFile }; $_relaunchArgs += '-ConfigFile', "`"$_cf`"" }
    $_psExe = Join-Path $env:WINDIR 'Sysnative\WindowsPowerShell\v1.0\powershell.exe'
    if (-not (Test-Path $_psExe)) { $_psExe = Join-Path $env:WINDIR 'System32\WindowsPowerShell\v1.0\powershell.exe' }
    try {
        Start-Process -FilePath $_psExe -ArgumentList $_relaunchArgs -Verb RunAs -WorkingDirectory $_scriptDir -ErrorAction Stop | Out-Null
        exit 0
    } catch {
        [System.Windows.Forms.MessageBox]::Show("Could not start DART as Administrator:`n$($_.Exception.Message)`n`nDART is not running. It will ask again at your next logon, or run DART-Start.ps1.",
            "DART - start services", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Warning) | Out-Null
        exit 1
    }
}

$startScript = Join-Path $_scriptDir "DART-Start.ps1"
if (-not (Test-Path $startScript)) {
    Say "[FAIL] DART-Start.ps1 not found at $startScript" "Red"
    Read-Host "`nPress Enter to close"
    exit 1
}

try { Start-Transcript -Path $START_LOG -Force | Out-Null } catch { }
Say "DART auto-start after restart - $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')" "Cyan"
Say "Log: $START_LOG" "DarkGray"

$failed = $false
try {
    if ($ConfigFile) { & $startScript -ConfigFile $ConfigFile } else { & $startScript }
} catch {
    $failed = $true
    Say "[FAIL] DART-Start.ps1 stopped with an error: $($_.Exception.Message)" "Red"
}

# Judge by what is listening, not by DART-Start's output: Start reports per
# service but carries on past failures, and DART-Status always exits 0.
# Airflow is left out - it listens inside WSL, where Windows-side port
# checks are unreliable; DART-Start already verified it (localhost or WSL IP).
$ports = [ordered]@{ "PostgreSQL" = [int](Get-Cfg "DB_PORT" "5432"); "Nginx" = 443; "Uvicorn/Django" = 8000; "FastAPI" = [int](Get-Cfg "FASTAPI_PORT" "5000") }
Say "`nChecking services ..." "Cyan"
foreach ($svc in $ports.Keys) {
    if (Get-NetTCPConnection -LocalPort $ports[$svc] -State Listen -ErrorAction SilentlyContinue) {
        Say ("  [OK]   {0,-15} port {1}" -f $svc, $ports[$svc]) "Green"
    } else {
        Say ("  [FAIL] {0,-15} port {1} not listening" -f $svc, $ports[$svc]) "Red"
        $failed = $true
    }
}

try { Stop-Transcript | Out-Null } catch { }

if ($failed) {
    Say "`n[WARN] Something did not come up - see the output above and $START_LOG" "Yellow"
    Read-Host "Press Enter to close"
} else {
    # Airflow runs in this logon session (WSL), so the window may close; the
    # services keep running. Close by itself so a restart doesn't leave a
    # console waiting for a keypress.
    Say "`n[OK]   DART is up. This window closes in 60 seconds." "Green"
    Start-Sleep -Seconds 60
}
