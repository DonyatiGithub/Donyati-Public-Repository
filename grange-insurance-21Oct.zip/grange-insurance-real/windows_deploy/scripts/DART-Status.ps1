# ===========================================================================
#  DART-Status.ps1
#  Shows real-time status of all DART services:
#    - PostgreSQL
#    - Nginx
#    - Uvicorn / Django backend
#    - FastAPI (AI Auto Draft)
#    - Apache Airflow (WSL2)
#    - API reachability
#    - Recent log tails
# ===========================================================================
param(
    [string]$ConfigFile = "",
    # Turn this report into a GATE: exit 0 only when NOTHING is listening on
    # any DART port, exit 1 otherwise. DART-Resume-Setup.ps1 uses it to
    # confirm DART-Stop really stopped everything before starting again.
    # Without an exit code the caller has to scrape console text, which
    # silently 'passes' the moment a message is reworded.
    [switch]$ExpectStopped
)

# INSTALL_ROOT/TOOLS_ROOT read from dart_deploy_config.json - see
# DART-Start.ps1 for why (used to be hardcoded to "C:\DARTV1", which doesn't
# exist on this deployment; it's actually C:\DART_DEPLOY).
$_scriptDir = if ($PSScriptRoot) { $PSScriptRoot } else { (Get-Location).Path }
$cfgPath = if ($ConfigFile -and (Test-Path $ConfigFile)) { $ConfigFile } else { Join-Path $_scriptDir "dart_deploy_config.json" }
$cfg = $null
if (Test-Path $cfgPath) {
    try { $cfg = Get-Content $cfgPath -Raw -Encoding UTF8 | ConvertFrom-Json } catch { }
}
function Get-Cfg($key, $default) {
    if ($cfg -and $cfg.PSObject.Properties.Name -contains $key -and $cfg.$key) { return $cfg.$key }
    return $default
}

$INSTALL_ROOT = Get-Cfg "INSTALL_ROOT" "C:\DART_DEPLOY"
$TOOLS_ROOT   = Get-Cfg "TOOLS_ROOT"   "C:\DART_Tools"
$UI_HOST      = Get-Cfg "UI_HOST"      "local-dart.donyati.com"
$PG_BIN       = "$TOOLS_ROOT\postgres\bin"
$PG_DATA      = "$TOOLS_ROOT\postgres\data"
$NGINX_ROOT   = "$TOOLS_ROOT\nginx"
$FASTAPI_PORT = Get-Cfg "FASTAPI_PORT" "5000"
$AIRFLOW_PORT = Get-Cfg "AIRFLOW_PORT" "8080"

function Write-Section ($title) {
    Write-Host ""
    Write-Host "  ---- $title ----" -ForegroundColor Cyan
}
function Write-OK   ($msg) { Write-Host "  [OK]   $msg" -ForegroundColor Green }
function Write-WARN ($msg) { Write-Host "  [WARN] $msg" -ForegroundColor Yellow }
function Write-FAIL ($msg) { Write-Host "  [FAIL] $msg" -ForegroundColor Red }
function Write-INFO ($msg) { Write-Host "  [INFO] $msg" -ForegroundColor Gray }

Write-Host ""
Write-Host "==========================================" -ForegroundColor DarkCyan
Write-Host "   DART  -  Service Status"                -ForegroundColor Cyan
Write-Host "   $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')" -ForegroundColor DarkGray
Write-Host "==========================================" -ForegroundColor DarkCyan

# ---------------------------------------------------------------------------
# 1. PostgreSQL
# ---------------------------------------------------------------------------
Write-Section "PostgreSQL  (port 5432)"

$pgConn = Get-NetTCPConnection -LocalPort 5432 -State Listen -ErrorAction SilentlyContinue
if ($pgConn) {
    $pgPid  = $pgConn.OwningProcess | Select-Object -First 1
    $pgProc = Get-Process -Id $pgPid -ErrorAction SilentlyContinue
    $pgMem  = if ($pgProc) { "$([math]::Round($pgProc.WorkingSet/1MB,1)) MB" } else { "n/a" }
    $pgStart = if ($pgProc) { $pgProc.StartTime } else { "n/a" }
    Write-OK "RUNNING  -  PID $pgPid  |  Mem: $pgMem  |  Started: $pgStart"

    $pgCtl = "$PG_BIN\pg_ctl.exe"
    if (Test-Path $pgCtl) {
        $prevEAP = $ErrorActionPreference
        $ErrorActionPreference = "Continue"
        $statusOut = & $pgCtl status -D $PG_DATA 2>&1
        $ErrorActionPreference = $prevEAP
        Write-INFO "pg_ctl: $statusOut"
    }
} else {
    Write-FAIL "NOT RUNNING  -  Port 5432 is not listening."
    Write-INFO "Start with: .\DART-Start.ps1"
}

# ---------------------------------------------------------------------------
# 2. Nginx
# ---------------------------------------------------------------------------
Write-Section "Nginx  (port 443)"

$ngxProcs = Get-Process -Name nginx -ErrorAction SilentlyContinue
$ngxPort  = Get-NetTCPConnection -LocalPort 443 -State Listen -ErrorAction SilentlyContinue

if ($ngxProcs -and $ngxPort) {
    Write-OK "RUNNING  -  $($ngxProcs.Count) process(es) on port 443"
    foreach ($p in $ngxProcs) {
        $mem = "$([math]::Round($p.WorkingSet/1MB,1)) MB"
        Write-INFO "  PID $($p.Id)  |  CPU: $([math]::Round($p.CPU,1))s  |  Mem: $mem  |  Started: $($p.StartTime)"
    }
} elseif ($ngxProcs) {
    Write-WARN "Nginx process exists but port 443 is NOT listening - possible config error."
    Write-INFO "Check: $NGINX_ROOT\logs\error.log"
} else {
    Write-FAIL "NOT RUNNING  -  No nginx process found."
    Write-INFO "Start with: .\DART-Start.ps1"
}

# ---------------------------------------------------------------------------
# 3. Uvicorn / Django Backend
# ---------------------------------------------------------------------------
Write-Section "Uvicorn / Django Backend  (port 8000)"

$uvPort  = Get-NetTCPConnection -LocalPort 8000 -State Listen -ErrorAction SilentlyContinue
$pyProcs = Get-Process -Name python -ErrorAction SilentlyContinue

if ($uvPort) {
    $uvPid  = $uvPort.OwningProcess
    $uvProc = Get-Process -Id $uvPid -ErrorAction SilentlyContinue
    $uvMem  = if ($uvProc) { "$([math]::Round($uvProc.WorkingSet/1MB,1)) MB" } else { "n/a" }
    $uvStart = if ($uvProc) { $uvProc.StartTime } else { "n/a" }
    Write-OK "RUNNING  -  PID $uvPid  |  Mem: $uvMem  |  Started: $uvStart"

    if ($pyProcs) {
        Write-INFO "All Python processes (reloader + workers):"
        foreach ($p in $pyProcs) {
            $mem = "$([math]::Round($p.WorkingSet/1MB,1)) MB"
            Write-INFO "  PID $($p.Id)  |  CPU: $([math]::Round($p.CPU,1))s  |  Mem: $mem  |  Started: $($p.StartTime)"
        }
    }
} else {
    Write-FAIL "NOT RUNNING  -  Port 8000 is not listening."
    if ($pyProcs) {
        Write-WARN "Python processes exist but none on port 8000 (likely crashed):"
        foreach ($p in $pyProcs) {
            Write-INFO "  PID $($p.Id)  |  CPU: $([math]::Round($p.CPU,1))s  |  Started: $($p.StartTime)"
        }
    }
    Write-INFO "Start with: .\DART-Start.ps1"
}

# ---------------------------------------------------------------------------
# 4. FastAPI (AI Auto Draft)
# ---------------------------------------------------------------------------
Write-Section "FastAPI / AI Auto Draft  (port $FASTAPI_PORT)"

$faPort = Get-NetTCPConnection -LocalPort ([int]$FASTAPI_PORT) -State Listen -ErrorAction SilentlyContinue
if ($faPort) {
    $faPid  = $faPort.OwningProcess
    $faProc = Get-Process -Id $faPid -ErrorAction SilentlyContinue
    $faMem  = if ($faProc) { "$([math]::Round($faProc.WorkingSet/1MB,1)) MB" } else { "n/a" }
    $faStart = if ($faProc) { $faProc.StartTime } else { "n/a" }
    Write-OK "RUNNING  -  PID $faPid  |  Mem: $faMem  |  Started: $faStart"
} else {
    Write-FAIL "NOT RUNNING  -  Port $FASTAPI_PORT is not listening."
    Write-INFO "Start with: .\DART-Start.ps1"
}

# ---------------------------------------------------------------------------
# 5. Apache Airflow (WSL2)
# ---------------------------------------------------------------------------
Write-Section "Apache Airflow  (port $AIRFLOW_PORT)"

# Every `wsl` call here is timeout-guarded via a background job - found live
# (this same session, multiple times) that a `wsl` invocation can hang
# indefinitely with zero further output if the shared WSL2 VM is busy or
# contended (e.g. another install running concurrently). A status check
# must never itself hang - that defeats its whole purpose.
function Invoke-WithTimeout($scriptBlock, $timeoutSec) {
    $job = Start-Job -ScriptBlock $scriptBlock
    if (Wait-Job $job -Timeout $timeoutSec) {
        $result = Receive-Job $job
        Remove-Job $job -Force -ErrorAction SilentlyContinue
        return @{ TimedOut = $false; Result = $result }
    } else {
        Stop-Job $job -ErrorAction SilentlyContinue | Out-Null
        Remove-Job $job -Force -ErrorAction SilentlyContinue
        return @{ TimedOut = $true; Result = $null }
    }
}

$wslCheck = Invoke-WithTimeout { & wsl --status 2>&1; $LASTEXITCODE } 10
$afPort = Get-NetTCPConnection -LocalPort ([int]$AIRFLOW_PORT) -State Listen -ErrorAction SilentlyContinue
if (-not $afPort -and (Test-NetConnection -ComputerName 127.0.0.1 -Port ([int]$AIRFLOW_PORT) -WarningAction SilentlyContinue).TcpTestSucceeded) {
    $afPort = $true
}

if ($wslCheck.TimedOut) {
    Write-WARN "WSL2 status check timed out after 10s (shared WSL2 VM may be busy) - skipping process detail."
} elseif ($wslCheck.Result -notcontains 0) {
    Write-FAIL "WSL2 not available - Airflow cannot be running."
} elseif ($afPort) {
    Write-OK "RUNNING  -  port $AIRFLOW_PORT listening"
    # airflow standalone runs several child processes (webserver, scheduler,
    # triggerer) inside WSL2 - Windows' Get-Process can't see them directly,
    # so list them from inside WSL2 instead.
    $afProcsResult = Invoke-WithTimeout { & wsl bash -c "pgrep -af airflow 2>/dev/null" } 10
    if ($afProcsResult.TimedOut) {
        Write-WARN "WSL2 process list timed out after 10s - port is listening, so Airflow is still considered up."
    } elseif ($afProcsResult.Result) {
        Write-INFO "WSL2 processes:"
        $afProcsResult.Result | ForEach-Object { Write-INFO "  $_" }
    }
} else {
    Write-FAIL "NOT RUNNING  -  Port $AIRFLOW_PORT is not listening."
    Write-INFO "Start with: .\DART-Start.ps1"
}

# ---------------------------------------------------------------------------
# 6. API Reachability
# ---------------------------------------------------------------------------
Write-Section "API Reachability"

# curl.exe, not Invoke-WebRequest - found live in this same engagement:
# Invoke-WebRequest / .NET's HttpWebRequest fails against this Nginx's TLS
# behavior every time with "The underlying connection was closed: An
# unexpected error occurred on a send", even when the app is completely
# healthy (verified side-by-side: curl.exe got a clean HTTP 200 for the
# exact same URL at the exact same moment Invoke-WebRequest failed). Using
# Invoke-WebRequest here would misreport a healthy app as down.
$curlExe = "$env:SystemRoot\System32\curl.exe"
if (Test-Path $curlExe) {
    $directCode = & $curlExe -s -o NUL -w "%{http_code}" "http://127.0.0.1:8000/" --max-time 5 2>&1
    if ($directCode -match "^\d{3}$" -and $directCode -ne "000") {
        Write-OK "Direct backend (http://127.0.0.1:8000/)  ->  HTTP $directCode"
    } else {
        Write-FAIL "Direct backend unreachable (curl: $directCode)"
    }

    $nginxCode = & $curlExe -s -k -o NUL -w "%{http_code}" "https://127.0.0.1/" --max-time 5 2>&1
    if ($nginxCode -match "^\d{3}$" -and $nginxCode -ne "000") {
        Write-OK "Via Nginx (https://127.0.0.1/)  ->  HTTP $nginxCode"
    } else {
        Write-FAIL "Nginx not reachable on 443 (curl: $nginxCode)"
    }
} else {
    Write-WARN "curl.exe not found at $curlExe - skipping API reachability checks."
}

# ---------------------------------------------------------------------------
# 7. Port Summary
# ---------------------------------------------------------------------------
Write-Section "Open Ports Summary"

$portMap = @{443="Nginx HTTPS"; 80="Nginx HTTP"; 5432="PostgreSQL"; 8000="Uvicorn/Django"; [int]$FASTAPI_PORT="FastAPI"; [int]$AIRFLOW_PORT="Airflow"}
foreach ($port in @(443, 80, 5432, 8000, [int]$FASTAPI_PORT, [int]$AIRFLOW_PORT)) {
    $conn = Get-NetTCPConnection -LocalPort $port -State Listen -ErrorAction SilentlyContinue
    $label = $portMap[$port]
    if ($conn) {
        $ownerPid = $conn.OwningProcess | Select-Object -First 1
        Write-OK "Port $port  ($label)  -  PID $ownerPid"
    } else {
        Write-FAIL "Port $port  ($label)  -  NOT LISTENING"
    }
}

# ---------------------------------------------------------------------------
# 8. Recent PostgreSQL Log
# ---------------------------------------------------------------------------
Write-Section "PostgreSQL Log  (last 8 lines)"

$pgLog = "$TOOLS_ROOT\postgres\server.log"
if (Test-Path $pgLog) {
    Get-Content $pgLog -Tail 8 | ForEach-Object { Write-INFO $_ }
} else {
    Write-INFO "Log not found at: $pgLog"
}

# ---------------------------------------------------------------------------
# 9. Recent Nginx Error Log
# ---------------------------------------------------------------------------
Write-Section "Nginx Error Log  (last 5 lines)"

$ngxLog = "$NGINX_ROOT\logs\error.log"
if (Test-Path $ngxLog) {
    Get-Content $ngxLog -Tail 5 | ForEach-Object { Write-INFO $_ }
} else {
    Write-INFO "Log not found at: $ngxLog"
}

# ---------------------------------------------------------------------------
# 10. Recent Deployment Log
# ---------------------------------------------------------------------------
Write-Section "Latest Deployment Log  (last 8 lines)"

$latestLog = Get-ChildItem "$INSTALL_ROOT\logs\*.log" -ErrorAction SilentlyContinue |
             Sort-Object LastWriteTime -Descending |
             Select-Object -First 1
if ($latestLog) {
    Write-INFO "File: $($latestLog.FullName)"
    Get-Content $latestLog.FullName -Tail 8 | ForEach-Object { Write-INFO $_ }
} else {
    Write-INFO "No deployment logs found in: $INSTALL_ROOT\logs"
}

# ---------------------------------------------------------------------------
# Footer
# ---------------------------------------------------------------------------
Write-Host ""
Write-Host "==========================================" -ForegroundColor DarkCyan
Write-Host "   Status check complete."                  -ForegroundColor Cyan
Write-Host "   To start services : .\DART-Start.ps1"   -ForegroundColor DarkGray
Write-Host "   To stop services  : .\DART-Stop.ps1"    -ForegroundColor DarkGray
Write-Host "==========================================" -ForegroundColor DarkCyan
Write-Host ""


if ($ExpectStopped) {
    $stillUp = @()
    foreach ($p in @(443, 80, 5432, 8000, [int]$FASTAPI_PORT, [int]$AIRFLOW_PORT) | Select-Object -Unique) {
        if (Get-NetTCPConnection -LocalPort $p -State Listen -ErrorAction SilentlyContinue) {
            $stillUp += $p
        }
    }
    if ($stillUp.Count -gt 0) {
        Write-Host "  [FAIL] -ExpectStopped: still listening on $($stillUp -join ', ')" -ForegroundColor Red
        exit 1
    }
    Write-Host "  [OK]   -ExpectStopped: no DART port is listening." -ForegroundColor Green
}

exit 0
