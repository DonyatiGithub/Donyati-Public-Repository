# ===========================================================================
#  DART - WSL / UBUNTU READINESS CHECK  (read-only)
#
#  Answers, before anything is installed: can Airflow run on this machine,
#  and what will AirflowSetup do about WSL?
#
#  Airflow 3.1 needs Python 3.10-3.13. Ubuntu 24.04 ships 3.12 (what the
#  installer uses; 22.04 with 3.10 is the fallback). Ubuntu 26.04 - the
#  newest LTS and what a plain "Ubuntu" install now gives you - ships 3.14,
#  which Airflow does not support. A machine that already has WSL with only
#  26.04 is fine: AirflowSetup installs Ubuntu-24.04 alongside it and leaves
#  26.04 (and the default distro) alone.
#
#  Changes nothing: no install, no upgrade, no default-distro change. The only
#  side effect is that reading a distro's /etc/os-release starts that distro
#  if it was stopped (it stops again by itself when idle).
#
#  Usage:
#     .\DART-Check-Wsl.ps1
#     .\DART-Check-Wsl.ps1 -ConfigFile .\dart_deploy_config.json
#  Exit code: 0 = READY or WILL INSTALL, 1 = BLOCKED
# ===========================================================================
param([string]$ConfigFile = "")

$_scriptDir = if ($PSScriptRoot) { $PSScriptRoot } else { (Get-Location).Path }
$cfgPath = if ($ConfigFile -and (Test-Path $ConfigFile)) { $ConfigFile } else { Join-Path $_scriptDir "dart_deploy_config.json" }
$cfg = $null
if (Test-Path $cfgPath) { try { $cfg = Get-Content $cfgPath -Raw -Encoding UTF8 | ConvertFrom-Json } catch { } }
function Get-Cfg($k, $d) { if ($cfg -and $cfg.PSObject.Properties.Name -contains $k -and "$($cfg.$k)" -ne "") { return "$($cfg.$k)" }; return $d }

$WSL_DISTRO   = Get-Cfg "WSL_DISTRO" "Ubuntu-24.04"
$INSTALL_ROOT = Get-Cfg "INSTALL_ROOT" "C:\DART_DEPLOY"
$logDir  = if (Test-Path (Join-Path $INSTALL_ROOT "logs")) { Join-Path $INSTALL_ROOT "logs" } else { $_scriptDir }
$LOG     = Join-Path $logDir ("wsl_check_{0}.log" -f (Get-Date -Format "yyyyMMdd_HHmmss"))
$SUPPORTED = @('24.04', '22.04')

function Say($m, $c = "Gray") {
    Write-Host $m -ForegroundColor $c
    try { Add-Content -Path $LOG -Value $m -Encoding UTF8 } catch { }
}
function Row($label, $value, $c = "Gray") { Say ("  {0,-34} {1}" -f $label, $value) $c }
function Clean($s) { return (($s | Out-String) -replace "`0", '').Trim() }

# Same timeout guard as the installer: a distro's first start can hang on a prompt.
function Invoke-WslRead($distro, [string[]]$cmd, [int]$timeoutSec = 60) {
    $job = Start-Job -ScriptBlock { param($d, $c) & wsl -d $d -u root -- @c 2>&1 } -ArgumentList $distro, $cmd
    $out = $null
    if (Wait-Job $job -Timeout $timeoutSec) { $out = Clean (Receive-Job $job) }
    Stop-Job $job -ErrorAction SilentlyContinue | Out-Null
    Remove-Job $job -Force -ErrorAction SilentlyContinue
    return $out
}

$blockers = @()
$plan = @()

Say ""
Say "==========================================" "DarkCyan"
Say "   DART - WSL / Ubuntu readiness (read-only)" "Cyan"
Say "   $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')   host: $env:COMPUTERNAME" "DarkGray"
Say "==========================================" "DarkCyan"

# --- 1. Windows and virtualization ------------------------------------------
Say "`n[1] Windows and virtualization" "Cyan"
$os = Get-CimInstance Win32_OperatingSystem
Row "Windows" "$($os.Caption) (build $($os.BuildNumber))"
$cs  = Get-CimInstance Win32_ComputerSystem
$cpu = Get-CimInstance Win32_Processor | Select-Object -First 1
if ($cs.HypervisorPresent) {
    Row "Hypervisor" "running (WSL2 can start)" "Green"
} elseif ($cpu.VirtualizationFirmwareEnabled) {
    Row "Hypervisor" "not running yet, CPU virtualization enabled - OK once WSL is installed" "Green"
} else {
    Row "Hypervisor" "NOT available - CPU virtualization off (BIOS) or nested virtualization not exposed to this VM" "Red"
    $blockers += "No CPU virtualization: WSL2 cannot run. Physical server: enable VT-x/AMD-V in BIOS. VM: enable nested virtualization (EC2: a supported instance type with NestedVirtualization enabled)."
}

# --- 2. WSL itself -----------------------------------------------------------
Say "`n[2] WSL" "Cyan"
$wslExe = Get-Command wsl.exe -ErrorAction SilentlyContinue
$wslOk = $false
if (-not $wslExe) {
    Row "wsl.exe" "not found - WSL not installed" "Yellow"
    $plan += "Install WSL (Windows features + one restart), then Ubuntu-24.04."
} else {
    $ver = Clean (& wsl --version 2>&1)
    if ($LASTEXITCODE -eq 0 -and $ver -match 'WSL[^:]*:\s*([0-9.]+)') { Row "WSL version" $Matches[1] "Green" }
    else { Row "WSL version" "unknown (inbox WSL, or 'wsl --version' unsupported)" "Yellow" }
    $status = Clean (& wsl --status 2>&1)
    if ($LASTEXITCODE -eq 0) {
        $wslOk = $true
        if ($status -match 'Default Version:\s*(\d)') {
            $dv = $Matches[1]
            Row "Default WSL version" $dv $(if ($dv -eq '2') { "Green" } else { "Yellow" })
        }
    } else {
        Row "wsl --status" "fails - WSL feature not enabled or needs a restart" "Yellow"
        $plan += "Enable the WSL features (one restart), then install Ubuntu-24.04."
    }
}

# --- 3. Registered distros -----------------------------------------------------
$registered = @()
$distros = @()
if ($wslOk) {
    Say "`n[3] Installed distros (wsl -l -v)" "Cyan"
    $raw = Clean (& wsl -l -v 2>&1)
    if ($LASTEXITCODE -eq 0) {
        foreach ($line in ($raw -split "`r?`n")) {
            if ($line -match '^\s*NAME\s') { continue }
            $isDefault = $line -match '^\s*\*'
            $parts = @(($line -replace '^\s*\*?\s*', '') -split '\s+' | Where-Object { $_ })
            if ($parts.Count -ge 3) {
                $distros += [pscustomobject]@{ Name = $parts[0]; State = $parts[1]; WslVer = $parts[-1]; Default = $isDefault }
            }
        }
    }
    $registered = @($distros | ForEach-Object Name)
    if (-not $distros) { Row "(none)" "WSL is installed but has no distro" "Yellow" }

    foreach ($d in $distros) {
        $rel = ''; $py = ''
        if ($d.Name -notlike 'docker-desktop*') {
            $osr = Invoke-WslRead $d.Name @('cat', '/etc/os-release')
            if ($osr -match '(?m)^VERSION_ID="?([0-9.]+)"?') { $rel = $Matches[1] }
            if ($osr -match '(?m)^ID=(\w+)' -and $Matches[1] -ne 'ubuntu') { $rel = "$($Matches[1]) $rel" }
            $p = Invoke-WslRead $d.Name @('sh', '-c', 'python3 --version 2>/dev/null || true') 30
            if ($p -match 'Python (\d+\.\d+)') { $py = $Matches[1] }
        }
        $d | Add-Member Release $rel; $d | Add-Member Python $py
        $tag = if ($d.Default) { " [default]" } else { "" }
        $fit = if ($SUPPORTED -contains $rel) { "usable for Airflow" } elseif ($rel) { "not used for Airflow" } else { "" }
        $c = if ($SUPPORTED -contains $rel) { "Green" } else { "Gray" }
        if ($d.Name -like 'docker-desktop*') { Row "$($d.Name)$tag" "WSL $($d.WslVer), $($d.State) - Docker Desktop's own distro, not used" "DarkGray"; continue }
        Row "$($d.Name)$tag" ("WSL {0}, {1}, Ubuntu {2}, python3 {3}  {4}" -f $d.WslVer, $d.State, $(if ($rel) { $rel } else { '?' }), $(if ($py) { $py } else { '?' }), $fit) $c
    }
}

# --- 4. The distro DART uses -----------------------------------------------------
Say "`n[4] Distro for Airflow (WSL_DISTRO = $WSL_DISTRO)" "Cyan"
$target = $distros | Where-Object Name -eq $WSL_DISTRO | Select-Object -First 1
$usable = $distros | Where-Object { $SUPPORTED -contains $_.Release } | Sort-Object { if ($_.Name -eq $WSL_DISTRO) { 0 } elseif ($_.Release -eq '24.04') { 1 } else { 2 } } | Select-Object -First 1
if ($wslOk -and $target -and ($SUPPORTED -contains $target.Release)) {
    Row $WSL_DISTRO "installed - Ubuntu $($target.Release), WSL $($target.WslVer)" "Green"
    if ($target.WslVer -ne '2') { $plan += "Convert '$WSL_DISTRO' from WSL 1 to WSL 2 (wsl --set-version $WSL_DISTRO 2)." }
} elseif ($wslOk -and $target) {
    Row $WSL_DISTRO "installed but it is Ubuntu $(if ($target.Release) { $target.Release } else { '(unknown)' }) - not usable for Airflow" "Yellow"
    if ($usable) { $plan += "Use '$($usable.Name)' (Ubuntu $($usable.Release)) instead and save it as WSL_DISTRO." }
    else { $plan += "Install Ubuntu-24.04 alongside '$WSL_DISTRO' and save it as WSL_DISTRO." }
} elseif ($wslOk) {
    if ($usable) {
        Row $WSL_DISTRO "not installed - '$($usable.Name)' (Ubuntu $($usable.Release)) will be used instead" "Yellow"
        $plan += "Use '$($usable.Name)' (Ubuntu $($usable.Release)) and save it as WSL_DISTRO."
    } else {
        Row $WSL_DISTRO "not installed" "Yellow"
        $plan += "Install Ubuntu-24.04 alongside the existing distros (they and the default distro are not changed)."
    }
}

# --- 5. Can 24.04 be downloaded? (only matters if it has to be installed) ------------
$needsInstall = -not ($wslOk -and $usable)
if ($wslExe -and $needsInstall) {
    Say "`n[5] Distro catalog (wsl --list --online)" "Cyan"
    $online = Clean (& wsl --list --online 2>&1)
    if ($LASTEXITCODE -ne 0 -or -not $online) {
        Row "Catalog" "could not be read - offline, or blocked by the firewall" "Red"
        $blockers += "Cannot read the WSL distro catalog. Check internet access (see 08-network-egress-allowlist.md, Step 15) or pre-install Ubuntu-24.04 into the image."
    } else {
        $has24 = $online -match '(?m)^\s*\*?\s*Ubuntu-24\.04\b'
        $has22 = $online -match '(?m)^\s*\*?\s*Ubuntu-22\.04\b'
        Row "Ubuntu-24.04 offered" $(if ($has24) { "yes" } else { "no" }) $(if ($has24) { "Green" } else { "Yellow" })
        Row "Ubuntu-22.04 offered (fallback)" $(if ($has22) { "yes" } else { "no" }) $(if ($has22) { "Green" } else { "Yellow" })
        if (-not $has24 -and $has22) { $plan += "Ubuntu-24.04 is not in this catalog - 22.04 (Python 3.10) will be used." }
        if (-not $has24 -and -not $has22) { $blockers += "Neither Ubuntu-24.04 nor Ubuntu-22.04 is in this machine's WSL catalog." }
    }
}

# --- Verdict -----------------------------------------------------------------------
Say "`n==========================================" "DarkCyan"
if ($blockers) {
    Say "   VERDICT: BLOCKED" "Red"
    foreach ($b in $blockers) { Say "   - $b" "Red" }
} elseif (-not $plan) {
    Say "   VERDICT: READY - Airflow will be installed into '$WSL_DISTRO'." "Green"
} else {
    Say "   VERDICT: READY - AirflowSetup will:" "Green"
    foreach ($p in $plan) { Say "   - $p" "Yellow" }
}
$other = @($distros | Where-Object { $SUPPORTED -notcontains $_.Release -and $_.Name -notlike 'docker-desktop*' } | ForEach-Object Name)
if ($other) { Say "   Left untouched: $($other -join ', ')" "DarkGray" }
Say "   Log: $LOG" "DarkGray"
Say "==========================================" "DarkCyan"
if ($blockers) { exit 1 } else { exit 0 }
