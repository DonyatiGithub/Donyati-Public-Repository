# ===========================================================================
#  DART - OUTBOUND ENDPOINT CAPTURE
#
#  Records every domain this machine actually contacts while you run a real
#  install, so the allowlist handed to IT is measured rather than guessed.
#
#  WHY THIS EXISTS, given DART-Check-Endpoints.ps1 already exists:
#    That script PROBES a known list - every URL written literally in
#    VM-Windows-Bash-Script_V2.ps1. Two steps cannot be covered that way,
#    because the script only names a bootstrapper and the bootstrapper then
#    decides for itself what to download:
#      Step 7  VS Build Tools - the script fetches aka.ms/vs/17/release/
#              vs_buildtools.exe, and that installer then pulls the actual
#              C++ payloads from Microsoft CDN hosts that appear nowhere in
#              our source.
#      Step 15 `wsl --install -d <distro>` - the distro image comes through
#              the Microsoft Store delivery backend, again named nowhere in
#              our source, and the host set moves between Windows builds.
#    Guessing those two and handing the guess to IT is how you get a
#    firewall that passes the pre-flight check and still fails the install.
#
#  HOW TO USE IT (needs an ADMIN PowerShell, and outbound still WIDE OPEN):
#     1.  .\DART-Capture-Endpoints.ps1 -Start
#     2.  run the real installer:  .\VM-Windows-Bash-Script_V2.ps1 -Silent
#         (or just the steps you are pinning down, e.g.
#          -StepList "VSBuildTools" / "AirflowSetup")
#     3.  .\DART-Capture-Endpoints.ps1 -Stop
#    -Report prints the findings so far without ending the capture.
#
#  WHAT IT RECORDS:
#    - Every DNS query name, from the Windows DNS Client operational log.
#      WSL's guest queries normally appear here too: the default WSL network
#      points /etc/resolv.conf at the host gateway, which proxies DNS to this
#      same Windows resolver. They will NOT appear if this box runs WSL with
#      generateResolvConf=false and a hardcoded external nameserver - check
#      that before trusting an empty apt/pypi result.
#    - Every established TCP connection to a non-private IP, sampled on an
#      interval. This is the backstop for anything that connects to a literal
#      IP and so never issues a DNS query at all.
#
#  It changes one machine setting: it ENABLES the DNS Client operational log
#  (off by default on Windows) and restores it to whatever it was on -Stop.
# ===========================================================================
param(
    [switch]$Start,
    [switch]$Stop,
    [switch]$Report,
    # Seconds between TCP connection samples. A short interval catches more
    # brief connections at the cost of more wakeups; it never affects the DNS
    # capture, which is event-driven and misses nothing regardless.
    [int]$SampleSeconds = 2,
    [string]$OutDir = "",

    # step_timeline.csv, written by VM-Windows-Bash-Script_V2.ps1. When
    # present, every captured DNS query is attributed to the STEP that was
    # running at the time - which turns "something contacted an unknown host"
    # into "Step-7-VSBuildTools wanted this host", the only form of the
    # answer that is actually actionable for an allowlist.
    [string]$TimelineCsv = ""
)

$_scriptDirCap = if ($PSScriptRoot) { $PSScriptRoot } else { (Get-Location).Path }
$DNS_LOG    = 'Microsoft-Windows-DNS-Client/Operational'
$STATE_FILE = Join-Path $env:TEMP "dart_capture_state.json"
$TCP_FILE   = Join-Path $env:TEMP "dart_capture_tcp.csv"

function Say ($m, $c = "Gray") { Write-Host $m -ForegroundColor $c }
function Head($m) {
    Write-Host ""
    Write-Host ("=" * 74) -ForegroundColor DarkCyan
    Write-Host "  $m" -ForegroundColor Cyan
    Write-Host ("=" * 74) -ForegroundColor DarkCyan
}

if (-not ($Start -or $Stop -or $Report)) {
    Say "Pick one:  -Start  |  -Stop  |  -Report" "Yellow"
    Say "  .\DART-Capture-Endpoints.ps1 -Start     # begin recording" "DarkGray"
    Say "  ...run the installer..." "DarkGray"
    Say "  .\DART-Capture-Endpoints.ps1 -Stop      # end + write the report" "DarkGray"
    exit 1
}

$isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()
           ).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)

# ===========================================================================
#  Classification
# ===========================================================================
# Three buckets, because "not on our list" does not mean "safe to block".
#
# EXPECTED - already on the DART-Check-Endpoints.ps1 checklist.
# CERT/OS  - certificate revocation, root-cert refresh, OS/telemetry. These
#            are NOT automatically noise: Authenticode verification of a
#            downloaded installer performs an OCSP/CRL fetch, and when those
#            hosts are blackholed (dropped rather than refused) the check
#            waits out its timeout - which is how a blocked OCSP endpoint
#            turns into an installer that appears to hang for no reason.
#            Review them; do not delete them from the report.
# UNKNOWN  - everything else. This is the column the whole exercise exists
#            to produce: the hosts our source never names.
$EXPECTED = @(
    'python.org', 'pypa.io', 'pypi.org', 'pythonhosted.org',
    'enterprisedb.com', 'truststore.pki.rds.amazonaws.com',
    'nodejs.org', 'npmjs.org', 'nginx.org',
    'dev.azure.com', 'github.com', 'githubusercontent.com',
    'ubuntu.com',
    'update.code.visualstudio.com', 'marketplace.visualstudio.com',
    'blob.core.windows.net', 'office365.com', 'outlook.com'
)
$CERT_OS = @(
    'ocsp.digicert.com', 'crl3.digicert.com', 'crl4.digicert.com', 'digicert.com',
    'ocsp.msocsp.com', 'mscrl.microsoft.com', 'crl.microsoft.com',
    'ctldl.windowsupdate.com', 'windowsupdate.com', 'update.microsoft.com',
    'msftconnecttest.com', 'msftncsi.com', 'time.windows.com',
    'events.data.microsoft.com', 'settings-win.data.microsoft.com',
    'telecommand.telemetry.microsoft.com', 'watson.telemetry.microsoft.com',
    'ec2.internal', 'amazonaws.com'
)

function Get-Bucket([string]$name) {
    $n = $name.ToLower().TrimEnd('.')
    foreach ($e in $EXPECTED) { if ($n -eq $e -or $n.EndsWith(".$e")) { return 'EXPECTED' } }
    foreach ($c in $CERT_OS)  { if ($n -eq $c -or $n.EndsWith(".$c")) { return 'CERT/OS' } }
    return 'UNKNOWN'
}

# ===========================================================================
#  -Start
# ===========================================================================
if ($Start) {
    Head "DART - starting endpoint capture"

    if (-not $isAdmin) {
        Say "[FAIL] Run this in an ADMIN PowerShell - enabling the DNS log needs it." "Red"
        exit 1
    }

    # Remember whether the log was already on, so -Stop can put the machine
    # back exactly as it found it rather than leaving a log enabled forever.
    $wasEnabled = $false
    try {
        $gl = & wevtutil gl $DNS_LOG 2>&1
        $wasEnabled = [bool](($gl | Out-String) -match 'enabled:\s*true')
    } catch { }

    if (-not $wasEnabled) {
        & wevtutil sl $DNS_LOG /e:true 2>&1 | Out-Null
        Say "  DNS Client operational log ENABLED (was off; will be restored on -Stop)." "Gray"
    } else {
        Say "  DNS Client operational log was already enabled - leaving it on." "Gray"
    }

    # Sampled in a DETACHED process, not a background job: a job dies with
    # the PowerShell that created it, and this capture has to outlive this
    # invocation and span the whole install, which runs from a different
    # window entirely.
    if (Test-Path $TCP_FILE) { Remove-Item $TCP_FILE -Force -ErrorAction SilentlyContinue }
    $samplerCode = @"
`$ErrorActionPreference = 'SilentlyContinue'
while (`$true) {
    Get-NetTCPConnection -State Established -ErrorAction SilentlyContinue |
        Where-Object {
            `$r = `$_.RemoteAddress
            `$r -and `$r -ne '127.0.0.1' -and `$r -ne '::1' -and `$r -ne '0.0.0.0' -and
            `$r -notlike '10.*' -and `$r -notlike '192.168.*' -and `$r -notlike '169.254.*' -and
            `$r -notlike '172.1*' -and `$r -notlike '172.2*' -and `$r -notlike '172.3*' -and
            `$r -notlike 'fe80*' -and `$r -notlike 'ff*'
        } |
        ForEach-Object {
            `$procName = ''
            try { `$procName = (Get-Process -Id `$_.OwningProcess -ErrorAction SilentlyContinue).ProcessName } catch { }
            '{0},{1},{2},{3}' -f (Get-Date -Format 'o'), `$_.RemoteAddress, `$_.RemotePort, `$procName |
                Add-Content -Path '$TCP_FILE' -Encoding UTF8
        }
    Start-Sleep -Seconds $SampleSeconds
}
"@
    $samplerFile = Join-Path $env:TEMP "dart_capture_sampler.ps1"
    [System.IO.File]::WriteAllText($samplerFile, $samplerCode, (New-Object System.Text.UTF8Encoding($false)))
    $sampler = Start-Process powershell -ArgumentList "-ExecutionPolicy","Bypass","-NoProfile","-WindowStyle","Hidden","-File",$samplerFile -WindowStyle Hidden -PassThru

    # Flush the resolver cache, or this capture silently under-reports.
    #
    # Only names that actually LEAVE the machine produce a 3008 event. A name
    # already in the cache - typically resolved minutes earlier by
    # DART-Check-Endpoints.ps1, which probes every host in the checklist - is
    # answered locally and never appears. Measured 2026-09-16: Step-2-Git ran
    # for 94s and downloaded PortableGit while the capture recorded "no DNS
    # queries in this window", purely because github.com was already cached.
    # An allowlist built from that capture would have been missing the very
    # hosts the pre-flight had just confirmed.
    try {
        Clear-DnsClientCache -ErrorAction Stop
        Say "  DNS resolver cache flushed - every lookup now re-queries and gets recorded." "Gray"
    } catch {
        Say "  [WARN] Could not flush the DNS cache: $($_.Exception.Message)" "Yellow"
        Say "         Hosts resolved before this point may not appear in the capture." "Yellow"
    }

    $state = [PSCustomObject]@{
        StartTime     = (Get-Date).ToString('o')
        DnsWasEnabled = $wasEnabled
        SamplerPid    = $sampler.Id
    }
    $state | ConvertTo-Json | Set-Content -Path $STATE_FILE -Encoding UTF8

    Say "  TCP connection sampler running (PID $($sampler.Id), every ${SampleSeconds}s)." "Gray"
    Write-Host ""
    Say "  CAPTURING. Now run the installer in another window:" "Green"
    Say "     .\VM-Windows-Bash-Script_V2.ps1 -Silent" "DarkGray"
    Write-Host ""
    Say "  When it finishes:  .\DART-Capture-Endpoints.ps1 -Stop" "Cyan"
    exit 0
}

# ===========================================================================
#  -Stop / -Report
# ===========================================================================
if (-not (Test-Path $STATE_FILE)) {
    Say "[FAIL] No capture in progress - $STATE_FILE not found. Run -Start first." "Red"
    exit 1
}
$state     = Get-Content $STATE_FILE -Raw | ConvertFrom-Json
$startTime = [datetime]::Parse($state.StartTime)

Head $(if ($Stop) { "DART - stopping capture and building the report" } else { "DART - capture report (still running)" })
Say "  Capture started : $startTime" "DarkGray"
Say "  Elapsed         : $([math]::Round(((Get-Date) - $startTime).TotalMinutes, 1)) min" "DarkGray"

if ($Stop -and $state.SamplerPid) {
    Stop-Process -Id $state.SamplerPid -Force -ErrorAction SilentlyContinue
    Say "  TCP sampler stopped (PID $($state.SamplerPid))." "DarkGray"
}

# --- DNS queries ----------------------------------------------------------
# Event 3008 carries both the queried name and the addresses it resolved to.
# Parsed from the event XML rather than the rendered Message string: the
# message text is localised and depends on provider metadata being present,
# while the Data element names are stable.
$dnsRows = @{}
try {
    $events = Get-WinEvent -FilterHashtable @{ LogName = $DNS_LOG; Id = 3008; StartTime = $startTime } -ErrorAction Stop
    foreach ($e in $events) {
        $x = [xml]$e.ToXml()
        $name = ($x.Event.EventData.Data | Where-Object { $_.Name -eq 'QueryName' }).'#text'
        $res  = ($x.Event.EventData.Data | Where-Object { $_.Name -eq 'QueryResults' }).'#text'
        if (-not $name) { continue }
        $name = $name.TrimEnd('.')
        # Single-label names are LAN/AD/WPAD lookups, never an internet
        # endpoint IT would allow-list - they only pad the report.
        if ($name -notmatch '\.') { continue }
        if (-not $dnsRows.ContainsKey($name)) {
            $dnsRows[$name] = [PSCustomObject]@{
                Name      = $name
                Bucket    = Get-Bucket $name
                Count     = 0
                FirstSeen = $e.TimeCreated
                Resolved  = ''
                CnameTo   = ''
            }
        }
        $dnsRows[$name].Count++
        if ($e.TimeCreated -lt $dnsRows[$name].FirstSeen) { $dnsRows[$name].FirstSeen = $e.TimeCreated }
        if ($res -and -not $dnsRows[$name].Resolved) {
            # QueryResults is a ';'-joined list mixing two kinds of entry:
            #   "type: 5 some.cdn.example.net"   - a CNAME target
            #   "::ffff:151.101.128.223"         - an address
            # Windows writes IPv4 answers in the ::ffff: mapped form, so a
            # plain ^\d+\.\d+\.\d+\.\d+$ match drops every address and leaves
            # this column silently empty (verified against a real 3008
            # payload before this was fixed).
            $ips    = @()
            $cnames = @()
            foreach ($part in ($res -split ';')) {
                $p = $part.Trim()
                if (-not $p) { continue }
                if ($p -match '^type:\s*\d+\s+(.+)$') { $cnames += $matches[1].TrimEnd('.'); continue }
                $ip = $p -replace '^::ffff:', ''
                if ($ip -match '^\d+\.\d+\.\d+\.\d+$' -or $ip -match '^[0-9a-fA-F:]+$') { $ips += $ip }
            }
            $dnsRows[$name].Resolved = ($ips | Select-Object -Unique) -join ' '
            # CNAME targets matter here specifically: when a name we allow-list
            # is a CNAME onto a CDN (fastly, akamai, azureedge...), an
            # FQDN-based firewall rule written against the original name alone
            # can still fail, because the connection is made to the target.
            $dnsRows[$name].CnameTo  = ($cnames | Select-Object -Unique) -join ' '
        }
    }
} catch {
    Say "  [WARN] Could not read $DNS_LOG : $($_.Exception.Message)" "Yellow"
    Say "         If this says no events were found, the log may have been off - re-run -Start as admin." "DarkGray"
}

# --- Direct-IP connections ------------------------------------------------
$tcpRows = @()
if (Test-Path $TCP_FILE) {
    $seen = @{}
    foreach ($line in (Get-Content $TCP_FILE -ErrorAction SilentlyContinue)) {
        $p = $line -split ','
        if ($p.Count -lt 3) { continue }
        $key = "$($p[1]):$($p[2])"
        if (-not $seen.ContainsKey($key)) {
            $seen[$key] = [PSCustomObject]@{
                Endpoint = $key
                Port     = $p[2]
                Process  = $p[3]
                FirstSeen = $p[0]
            }
        }
    }
    $tcpRows = $seen.Values | Sort-Object Endpoint
}

# --- Report ---------------------------------------------------------------
$all = $dnsRows.Values | Sort-Object FirstSeen

foreach ($bucket in @('UNKNOWN', 'EXPECTED', 'CERT/OS')) {
    $rows = $all | Where-Object { $_.Bucket -eq $bucket }
    Write-Host ""
    $color = switch ($bucket) { 'UNKNOWN' { 'Yellow' } 'EXPECTED' { 'Green' } default { 'DarkGray' } }
    Write-Host ("  ---- $bucket  ({0}) ----" -f @($rows).Count) -ForegroundColor $color
    if ($bucket -eq 'UNKNOWN') {
        Write-Host "       Contacted, but named nowhere in the DART scripts - these are the" -ForegroundColor DarkGray
        Write-Host "       ones the probe-based checker cannot find. Expect VS Build Tools" -ForegroundColor DarkGray
        Write-Host "       and Microsoft Store / WSL delivery hosts here." -ForegroundColor DarkGray
    }
    if ($bucket -eq 'CERT/OS') {
        Write-Host "       Certificate-revocation and OS hosts. Review, do not blanket-block:" -ForegroundColor DarkGray
        Write-Host "       a blackholed OCSP/CRL host makes signed installers stall on the" -ForegroundColor DarkGray
        Write-Host "       signature check instead of failing outright." -ForegroundColor DarkGray
    }
    if (-not $rows) { Write-Host "       (none)" -ForegroundColor DarkGray; continue }
    foreach ($r in $rows) {
        Write-Host ("       {0:HH:mm:ss}  {1,-52} x{2}" -f $r.FirstSeen, $r.Name, $r.Count) -ForegroundColor $color
        if ($r.CnameTo) {
            Write-Host ("                   -> CNAME {0}" -f $r.CnameTo) -ForegroundColor DarkGray
        }
    }
}

if ($tcpRows) {
    Write-Host ""
    Write-Host ("  ---- DIRECT IP CONNECTIONS  ({0}) ----" -f @($tcpRows).Count) -ForegroundColor Cyan
    Write-Host "       Sampled connections to public IPs. Cross-check against the DNS names" -ForegroundColor DarkGray
    Write-Host "       above - anything left over connected without ever resolving a name," -ForegroundColor DarkGray
    Write-Host "       so an FQDN-based firewall rule would not cover it." -ForegroundColor DarkGray
    foreach ($t in $tcpRows) {
        Write-Host ("       {0,-46} {1}" -f $t.Endpoint, $t.Process) -ForegroundColor Gray
    }
}

# --- Per-step attribution -------------------------------------------------
# Finds the deployment's step_timeline.csv and buckets each DNS query into
# the step whose window it falls inside. Without this you get one flat list
# for a multi-hour run and have to guess which step wanted what.
$tlPath = $TimelineCsv
if (-not $tlPath) {
    $installRoot = "C:\DART_DEPLOY"
    $cfg = Join-Path $_scriptDirCap "dart_deploy_config.json"
    if (Test-Path $cfg) {
        try {
            $c = Get-Content $cfg -Raw -Encoding UTF8 | ConvertFrom-Json
            if ($c.INSTALL_ROOT) { $installRoot = "$($c.INSTALL_ROOT)" }
        } catch { }
    }
    $candidate = Join-Path $installRoot "logs\step_timeline.csv"
    if (Test-Path $candidate) { $tlPath = $candidate }
}

if ($tlPath -and (Test-Path $tlPath)) {
    Write-Host ""
    Write-Host "  ---- BY INSTALLER STEP ----" -ForegroundColor Cyan
    Write-Host "       Source: $tlPath" -ForegroundColor DarkGray
    $steps = @(Import-Csv $tlPath)
    foreach ($s in $steps) {
        $st = $null; $en = $null
        try { $st = [datetime]::Parse($s.Start); $en = [datetime]::Parse($s.End) } catch { continue }
        $inWindow = $all | Where-Object { $_.FirstSeen -ge $st -and $_.FirstSeen -le $en }
        $dur = [math]::Round(($en - $st).TotalSeconds, 0)
        $stepColor = if ($s.Result -eq 'ERRORS') { 'Red' } else { 'Gray' }
        Write-Host ("       {0,-26} {1:HH:mm:ss}-{2:HH:mm:ss} ({3}s) {4}" -f `
            $s.Step, $st, $en, $dur, $s.Result) -ForegroundColor $stepColor
        if (-not $inWindow) {
            # A step that contacted nothing is normal (skipped, or already
            # installed). Worth showing, because a step that SHOULD have
            # downloaded and resolved nothing at all is itself a finding.
            Write-Host "                                  (no DNS queries in this window)" -ForegroundColor DarkGray
            continue
        }
        foreach ($h in ($inWindow | Sort-Object Bucket, Name)) {
            $c = switch ($h.Bucket) { 'UNKNOWN' { 'Yellow' } 'EXPECTED' { 'Green' } default { 'DarkGray' } }
            Write-Host ("                                  [{0,-8}] {1}" -f $h.Bucket, $h.Name) -ForegroundColor $c
        }
    }
} else {
    Write-Host ""
    Write-Host "  ---- BY INSTALLER STEP ----" -ForegroundColor Cyan
    Write-Host "       No step_timeline.csv found - run the installer with the instrumented" -ForegroundColor DarkGray
    Write-Host "       VM-Windows-Bash-Script_V2.ps1 to get per-step attribution, or pass" -ForegroundColor DarkGray
    Write-Host "       -TimelineCsv <path> explicitly." -ForegroundColor DarkGray
}

# --- CSVs -----------------------------------------------------------------
$outRoot = if ($OutDir) { $OutDir } else { $env:TEMP }
if (-not (Test-Path $outRoot)) { New-Item -ItemType Directory -Path $outRoot -Force | Out-Null }
$stamp   = Get-Date -Format "yyyyMMdd_HHmmss"
$dnsCsv  = Join-Path $outRoot "dart_capture_domains_$stamp.csv"
$tcpCsv  = Join-Path $outRoot "dart_capture_ips_$stamp.csv"

$all     | Select-Object Bucket, Name, Count, FirstSeen, Resolved, CnameTo | Export-Csv -Path $dnsCsv -NoTypeInformation -Encoding UTF8
if ($tcpRows) { $tcpRows | Export-Csv -Path $tcpCsv -NoTypeInformation -Encoding UTF8 }

Write-Host ""
Say "  Domains CSV : $dnsCsv" "Cyan"
if ($tcpRows) { Say "  Direct IPs  : $tcpCsv" "Cyan" }

# --- Restore ---------------------------------------------------------------
if ($Stop) {
    if (-not $state.DnsWasEnabled) {
        if ($isAdmin) {
            & wevtutil sl $DNS_LOG /e:false 2>&1 | Out-Null
            Say "  DNS Client operational log restored to disabled." "DarkGray"
        } else {
            Say "  [WARN] Not admin - could not restore the DNS log to disabled. Run:" "Yellow"
            Say "         wevtutil sl `"$DNS_LOG`" /e:false" "DarkGray"
        }
    }
    Remove-Item $STATE_FILE -Force -ErrorAction SilentlyContinue

    Write-Host ""
    Say "  NEXT: fold every UNKNOWN host above into the allowlist you hand IT," "Green"
    Say "  then re-run .\DART-Check-Endpoints.ps1 on the restricted box to confirm." "Green"
}
exit 0
